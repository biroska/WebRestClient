$(document).keyup(function(e) {
	  if (e.keyCode == 27){
		  PF('dlgStrategyParameters').hide();
		  PF('dlgStrategyParametersEdit').hide();
		  PF('dlgOTC').hide();
		  PF('dlgUnlegging').hide();
	  }
});

function onClickBtnDownFontSize(tab) {
	var fontSizeDown = parseInt($("div.fontSize tbody").css("font-size"));
	fontSizeDown = fontSizeDown - 1 + "px";
	$("div.fontSize tbody").css({
		"font-size" : fontSizeDown
	});
}
function onClickBtnUpFontSize(tab) {
	var fontSizeUp = parseInt($("div.fontSize tbody").css("font-size"));
	fontSizeUp = fontSizeUp + 1 + "px";
	$("div.fontSize tbody").css({
		"font-size" : fontSizeUp
	});
}

function onDblClickLabel(commandHtmlId) {	
	PF(commandHtmlId).jq.click();
}

function showEditDialog(statusHtmlId) {
	showDialog = ($('.' + statusHtmlId).html() != strategyTypes.ERROR) && 
		($('.' + statusHtmlId).html() != strategyTypes.CANCELLED) && 
		($('.' + statusHtmlId).html() != strategyTypes.COMPLETED) &&
		($('.' + statusHtmlId).html() != strategyTypes.DISCONNECT);
	
	if (showDialog)
		PF('dlgStrategyParametersEdit').show();
}

function showOTCDialog(statusHtmlId) {
	showDialog = ($('.' + statusHtmlId).html() != strategyTypes.ERROR) && 
		($('.' + statusHtmlId).html() != strategyTypes.CANCELLED) &&
		($('.' + statusHtmlId).html() != strategyTypes.COMPLETED) &&
		($('.' + statusHtmlId).html() != strategyTypes.DISCONNECT);
	
	if (showDialog)
		PF('dlgOTC').show();
}

function showUnleggingDialog(statusHtmlId, qtyUnleggingHtmlId) {
	showDialog = ($('.' + statusHtmlId).html() != strategyTypes.ERROR) && 
		($('.' + statusHtmlId).html() != strategyTypes.CANCELLED) &&
		($('.' + statusHtmlId).html() != strategyTypes.COMPLETED) &&
		($('.' + statusHtmlId).html() != strategyTypes.DISCONNECT) &&
		($('.' + qtyUnleggingHtmlId).html() != "0");
	
	if (showDialog)
		PF('dlgUnlegging').show();
}

function quantityLostFocus(isLast, index, obj) {
	if (isLast) {
		if(PF('qty' + index) != undefined) {
			var qtyValue = obj.value;
			var sideValue = parseInt(PF('side' + index).jq.val());
					
			var changeSide = false;
			if(qtyValue >= parseInt(0)) {
				changeSide = (sideValue == 2);
			} else {
				changeSide = (sideValue == 1);
			}
			
			if (qtyValue < 0)
				obj.value = (qtyValue * -1);

			if (changeSide)
				changeStrategySide(isLast, index);
		}
	}
}

function quantityEditLostFocus(isLast, index, obj) {
	if (isLast) {
		if(PF('qtyEdit' + index) != undefined) {
			var qtyValue = obj.value;
			var sideValue = parseInt(PF('sideEdit' + index).jq.val());
					
			var changeSide = false;
			if(qtyValue >= parseInt(0)) {
				changeSide = (sideValue == 2);
			} else {
				changeSide = (sideValue == 1);
			}
			
			if (qtyValue < 0)
				obj.value = (qtyValue * -1);

			if (changeSide)
				changeStrategyEditSide(isLast, index);
		}
	}
}

function changeStrategySide(isLast, index) {
	if (isLast) {
		if (PF('side'+index) != undefined) {
			var side = parseInt(PF('side'+index).jq.val());
			if(side == 1) {
				newClass = "sell";
				PF('side' + index).jq.val(2);
				PF('sideDisplay' + index).jq.val("SELL");
				PF('sideDisplay' + index).jq.removeClass("buy");
				PF('sideDisplay' + index).jq.addClass(newClass);
			} else {
				newClass = "buy";
				PF('side' + index).jq.val(1);
				PF('sideDisplay' + index).jq.val("BUY");
				PF('sideDisplay' + index).jq.removeClass("sell");
				PF('sideDisplay' + index).jq.addClass(newClass);
			}

			for(var i = (index -1); i > -1; i--){
			    if (newClass == "sell") {
			    	newClass = "buy";
					PF('side' + i).jq.val(1);
					PF('sideDisplay' + i).jq.val("BUY");
					PF('sideDisplay' + i).jq.removeClass("sell");
					PF('sideDisplay' + i).jq.addClass(newClass);
			    } else {
			    	newClass = "sell";
					PF('side' + i).jq.val(2);
					PF('sideDisplay' + i).jq.val("SELL");
					PF('sideDisplay' + i).jq.removeClass("buy");
					PF('sideDisplay' + i).jq.addClass(newClass);
			    }
			}		

			changeSideFromDoubleClick();
		}
	}
}

function changeStrategyEditSide(isLast, index) {
	if (isLast) {
		if (PF('sideEdit'+index) != undefined) {
			var side = parseInt(PF('sideEdit'+index).jq.val());
			if(side == 1) {
				newClass = "sell";
				PF('sideEdit' + index).jq.val(2);
				PF('sideDisplayEdit' + index).jq.val("SELL");
				PF('sideDisplayEdit' + index).jq.removeClass("buy");
				PF('sideDisplayEdit' + index).jq.addClass(newClass);
			} else {
				newClass = "buy";
				PF('sideEdit' + index).jq.val(1);
				PF('sideDisplayEdit' + index).jq.val("BUY");
				PF('sideDisplayEdit' + index).jq.removeClass("sell");
				PF('sideDisplayEdit' + index).jq.addClass(newClass);
			}

			for(var i = (index -1); i > -1; i--){
			    if (newClass == "sell") {
			    	newClass = "buy";
					PF('sideEdit' + i).jq.val(1);
					PF('sideDisplayEdit' + i).jq.val("BUY");
					PF('sideDisplayEdit' + i).jq.removeClass("sell");
					PF('sideDisplayEdit' + i).jq.addClass(newClass);
			    } else {
			    	newClass = "sell";
					PF('sideEdit' + i).jq.val(2);
					PF('sideDisplayEdit' + i).jq.val("SELL");
					PF('sideDisplayEdit' + i).jq.removeClass("buy");
					PF('sideDisplayEdit' + i).jq.addClass(newClass);
			    }
			}		

			changeSideEditFromDoubleClick();
		}
	}
}

function funcFocusSide(index){
	var pos = index + 1;
	if(PF('contract'+pos) != undefined) {
		PF('contract'+pos).jq.focus();
	}else{
		PF('contract'+0).jq.focus();
		PF('btnAdd').jq.focus();
	}
}

function funcTabEnter(){
	if (window.event && window.event.keyCode == 13){
		window.event.keyCode = 9;
	}
}

/*
 * Funcao responsavel pelo enter "navegar" como tab
 * */

function flowControl( obj ){
	
	jObj = jQuery( obj );
	
	var key = event.keyCode;
	
	// If the pressed key was enter (return)
	if (key == 13) {
		
		var jQueryEvent = jQuery.Event( window.event );
		jQueryEvent.preventDefault();
		
		// Get the tabindex from the input wich fires the action
		var currentTabIndex = jObj.attr('tabindex');
		
		if (currentTabIndex != 'undefined') {			
			var newTabIndex = parseInt(currentTabIndex) + 1;
			
			// Set the focus on the next input according with the next tabindex
			$('input[tabindex=' + newTabIndex + ']').focus();
		}
		
		return false;
	}
}