var countReceivedPackage = 0;
var countReceivedManagerPackage = 0;
var countReceivedMarketWatchPackage = 0;
var heartBeat = false;

var replaceDataEnabled = true;
var logEnabled = true;

var thousandSeparator=",";
var decimalSeparator=".";
var fractionDigits=3;

function checkheartBeat() {
	setTimeout(function () {
    	if (!heartBeat) {	    		
    		//error in connection with push/subscriber process
    		log("Error in connection with server, process push/subscriber");
    		
    		setDisconnectedStyleForStatus();
    	} else {
    		heartBeat = false;
    	}
    	
    	checkheartBeat(); 
	 }, 7000);
}

function handleMessage(objJson) {
	countReceivedPackage++;
	heartBeat = true;

	if (objJson.heartBeat) {
		log("handleMessage - heartBeat");		
	} else {
		log("handleMessage - total package [" + countReceivedPackage + "]");

		if (objJson.messageId == messageTypes.MARKETWATCH) { //Market Whatch data
			handleMessageMarketWhatch(objJson);
		} else { //Manager data
			handleMessageManager(objJson);
		}
	}
}

function handleMessageMarketWhatch(objJson) {
	countReceivedMarketWatchPackage++;
	
	log("handleMessageMarketWhatch - total package [" + countReceivedMarketWatchPackage + "]");
	
	handleMarketWatchObject(objJson);
}

function handleMessageManager(objJson) {
	countReceivedManagerPackage++;
	
	log("handleMessageManager - total package [" + countReceivedManagerPackage + "]");
	
	if (objJson.refreshTableIsNeeded == "S") {
		log("Refresh Screen Status for Manager" + objJson.refreshTableIsNeeded);
		
		updateManagerTable();
	} else {
		handleManagerObject(objJson);
	}
}

function handleMarketWatchObject(objJson) {
	
	log("handleMarketWatch()");

	if (replaceDataEnabled == false) {
		log("replace data is disabled");
		
		return;
	}
	
	log("Process " + objJson.fields.length + " records for market whatch");
	
	for (var i = 0; i < objJson.fields.length; i++) {	
		//Update values 
		processMarketWatchObject(objJson.fields[i]);
	}
}

function handleManagerObject(objJson) {

	log("handleManager()");
	
	if (replaceDataEnabled == false) {
		log("replace data is disabled");
		
		return;
	}

	if (objJson.notificationMessage != null && objJson.notificationMessage != "") {
		notificationUser(objJson.notificationMessage);
	} else {
		if (objJson.fields == null)
			return;
		
		log("Process " + objJson.fields.length + " records for manager");
		
		for (var i = 0; i < objJson.fields.length; i++) {
			processManagerObject(objJson.fields[i]);
		}
	}
}

function processMarketWatchObject(objJson) {
	
	log("processMarketWatchObject()");
	
	setNewStyleForLastPrice(objJson.lastPriceHtmlId, objJson.lastPrice);
	
	setNewFieldValue(objJson.lastQuantityHtmlId, objJson.lastQuantity);	
	if (objJson.lastPrice == null) {
		setNewFieldValue(objJson.lastPriceHtmlId, objJson.lastPrice);
	}else{
		setNewFieldValue(objJson.lastPriceHtmlId, number_format(objJson.lastPrice, fractionDigits, decimalSeparator, thousandSeparator));
	}
		
	setNewFieldValue(objJson.buyQuantityHtmlId, objJson.buyQuantity);	
	
	if (objJson.buyPrice == null) {
		setNewFieldValue(objJson.buyPriceHtmlId, objJson.buyPrice);	
	}else{
		setNewFieldValue(objJson.buyPriceHtmlId, number_format(objJson.buyPrice, fractionDigits, decimalSeparator, thousandSeparator));	
	}
		
	setNewFieldValue(objJson.sellQuantityHtmlId, objJson.sellQuantity);	
	setNewFieldValue(objJson.sellPriceHtmlId, number_format(objJson.sellPrice, fractionDigits, decimalSeparator, thousandSeparator));		
	if (objJson.sellPrice == null) {
		setNewFieldValue(objJson.sellPriceHtmlId, objJson.sellPrice);
	}else{
		setNewFieldValue(objJson.sellPriceHtmlId, number_format(objJson.sellPrice, fractionDigits, decimalSeparator, thousandSeparator));
	}
}

function processManagerObject(objJson) {
	if (!objJson.isALeg) { //Is strategy report, not is a leg
		
		//test if is unleged
		if (objJson.leggedQuantity > 0) {
			//setRowStyleForUnlegging(objJson.cancelColumnHtmlId);
			setRowStyleForUnlegging(objJson.rowKey);
		} else {
			//resetRowStyle(objJson.cancelColumnHtmlId);
			resetRowStyle(objJson.rowKey);
		}
		
		setNewFieldValue(objJson.statusHtmlId, objJson.status);
		setNewFieldValue(objJson.statusDisplayHtmlId, objJson.statusDisplayText);
		setNewStyleForCancel(objJson.cancelHtmlId, objJson.status);			
		setNewStyleForStatus(objJson.cancelColumnHtmlId, objJson.status);
		setNewFieldValue(objJson.targetHtmlId, number_format(objJson.target, fractionDigits, decimalSeparator, thousandSeparator));
		setNewFieldValue(objJson.executedTargetHtmlId, number_format(objJson.executedTarget, fractionDigits, decimalSeparator, thousandSeparator));
		setNewFieldValue(objJson.startTimeHtmlId, objJson.startTime);
		setNewFieldValue(objJson.endTimeHtmlId, objJson.endTime);
		setStyleForNotificationBar(objJson.status);
	} else { //Is leg
		if (typeof $(objJson.leggedQuantityHtmlId).html() == "undefined") {
			log("Received a leg information but the same is colsed in webbrowser");
			
			return;
		} else {
			setNewFieldValue(objJson.leggedPriceHtmlId, number_format(objJson.leggedPrice, fractionDigits, decimalSeparator, thousandSeparator));
			setNewFieldValue(objJson.averagePriceHtmlId, number_format(objJson.averagePrice, fractionDigits, decimalSeparator, thousandSeparator));
			setNewFieldValue(objJson.otcPriceHtmlId, number_format(objJson.otcPrice, fractionDigits, decimalSeparator, thousandSeparator), "-", "-");
			setNewFieldValue(objJson.poPriceHtmlId, number_format(objJson.poPrice, fractionDigits, decimalSeparator, thousandSeparator));
		}
	}
	
	setNewFieldValue(objJson.executedPercentHtmlId, number_format(objJson.executedPercent, 0, decimalSeparator, thousandSeparator));
	setNewFieldValue(objJson.leggedQuantityHtmlId, objJson.leggedQuantity); //common fields for report and leg
	setNewFieldValue(objJson.totalQuantityHtmlId, objJson.totalQuantity);
	setNewFieldValue(objJson.quantityRemainHtmlId, objJson.quantityRemain);
	setNewFieldValue(objJson.quantityExecutedHtmlId, objJson.quantityExecuted);
	setNewFieldValue(objJson.otcQuantityHtmlId, objJson.otcQuantity, "-", "-");
	setNewFieldValue(objJson.poQuantityHtmlId, objJson.poQuantity);
	setNewFieldValue(objJson.rankHtmlId, objJson.rank);
	setNewFieldValue(objJson.textHtmlId, objJson.text);
}

function setNewStyleForLastPrice(fieldHtmlId, fieldNewValue) {
	
	var textOld = $(fieldHtmlId).html();
	var fieldOldValue = 0;
	if (textOld !=null) {
		textOld = textOld.replace(thousandSeparator, decimalSeparator);
		fieldOldValue = parseFloat(textOld);
	}
	
	if (fieldOldValue > fieldNewValue) {
		$(fieldHtmlId).attr("style", "color: red;");
	} else if (fieldOldValue < fieldNewValue) {
		$(fieldHtmlId).attr("style", "color: green;");
	} else {
		$(fieldHtmlId).attr("style", "color: black;");
	}
}

function setNewFieldValue(fieldHtmlId, fieldNewValue, defaultTextIfIsNull, defaultTextIfIsZero) {
	
	var textIfIsNull = (typeof defaultTextIfIsNull === 'undefined') ? '-' : defaultTextIfIsNull;
	var textIfIsZero = (typeof defaultTextIfIsZero === 'undefined') ? '0' : defaultTextIfIsZero;

	if (fieldNewValue == null) { 
		$(fieldHtmlId).html(textIfIsNull);
	} else {
		if ($(fieldHtmlId).html() != fieldNewValue) {
			logNewFieldValue(fieldHtmlId, fieldNewValue);
			
			if (isNumber(fieldNewValue)) {
				if (fieldNewValue <= 0) {
					$(fieldHtmlId).html(textIfIsZero);
				} else {
					$(fieldHtmlId).html(fieldNewValue);
				}
			} else {
				$(fieldHtmlId).html(fieldNewValue);
			}
		}
	}	
}

function setNewStyleForCancel(fieldHtmlId, fieldNewValue) {
	if (fieldNewValue != strategyTypes.CANCELLING && fieldNewValue != strategyTypes.CANCELLED 
			&& fieldNewValue != strategyTypes.ERROR && fieldNewValue != strategyTypes.COMPLETED) {
		$(fieldHtmlId).attr("style", "display: block; border: 0");
	} else {
		$(fieldHtmlId).attr("style", "display: none;");
	}
}

function setDisconnectedStyleForStatus() {
	
	elements = $('.renderStatusClass');
	
	elements.each(function() {
			if ($(this).html().toUpperCase() != strategyTypesText.CANCELLED &&
					$(this).html().toUpperCase() != strategyTypesText.COMPLETED &&
					$(this).html().toUpperCase() != strategyTypesText.ERROR) {

				$(this).html("disconnect");
				$(this).parent('td').attr("style", "background-color: black !important; color: white !important; text-align: center; text-transform: lowercase;");
			}
		}
	);
	
	$(".renderObsClass").html("webbrowser disconnected from server");
	$('.notification').html("The system is off-line");
	$('.notification_icon_green').hide();
	$('.notification_icon_red').show();
}


function setNewStyleForStatus(fieldHtmlId, fieldNewValue) {
	if (fieldNewValue == strategyTypes.PAUSED) {
		$(fieldHtmlId).attr("style", "background-color: yellow !important; color: black !important; text-align: center; text-transform: lowercase;");
	} else if (fieldNewValue == strategyTypes.ERROR) {
		$(fieldHtmlId).attr("style", "background-color: orange !important; color: black !important; text-align: center; text-transform: lowercase;");
	} else if (fieldNewValue == strategyTypes.RESUMED) {
		$(fieldHtmlId).attr("style", "background-color: green !important; color: black !important; text-align: center; text-transform: lowercase;");
	} else if (fieldNewValue == strategyTypes.DISCONNECT) {
		$(fieldHtmlId).attr("style", "background-color: black !important; color: white !important; text-align: center; text-transform: lowercase;");
	} else {
		$(fieldHtmlId).attr("style", "background-color: transparent !important; text-align: center; text-transform: lowercase;");
	}
}

function setRowStyleForUnlegging(rowColumnKey) {
	$(rowColumnKey).addClass("column-red");
}

function resetRowStyle(rowColumnKey) {
	$(rowColumnKey).removeClass("column-red");
}

function setStyleForNotificationBar(fieldNewValue) {
	if (fieldNewValue == strategyTypes.DISCONNECT) { //Disconnected engine
		$('.notification').html("The system is off-line");
		$('.notification_icon_green').hide();
		$('.notification_icon_red').show();
	}
}

function notificationUser(fieldMessageValue) {
	alert(fieldMessageValue);	
}

function logNewFieldValue(fieldHtmlId, fieldNewValue) {
	log("Field [" + fieldHtmlId + "] [" + $(fieldHtmlId).html() + "], [" + fieldNewValue + "]" );
}

function log(logText) {
	if (logEnabled == true) {
		if ( window.console && window.console.log ) {
			console.log("Package [" + countReceivedPackage + "] ==> " + logText);
		}
	}
}

function number_format(number, decimals, dec_point, thousands_sep)
{
	var n = number, prec = decimals;

	var toFixedFix = function (n, prec) {
		var k = Math.pow(10, prec);
		return (Math.round(n * k) / k).toString();
	};

	n = !isFinite( +n ) ? 0 : +n;
	prec = !isFinite( +prec ) ? 0 : Math.abs(prec);
	var sep = (typeof thousands_sep === 'undefined') ? ',' : thousands_sep;
	var dec = (typeof dec_point === 'undefined') ? '.' : dec_point;

	var s = (prec > 0) ? toFixedFix(n, prec) : toFixedFix(Math.round(n), prec); //fix for IE parseFloat(0.55).toFixed(0) = 0;

	var abs = toFixedFix(Math.abs(n), prec);
	var _, i;

	if(abs >= 1000) {
		_ = abs.split(/\D/);
		i = _[0].length % 3 || 3;
 
		_[0] = s.slice(0,i + (n < 0)) + _[0].slice(i).replace(/(\d{3})/g, sep + '$1');
		s = _.join(dec);
	}
	else {
		s = s.replace('.', dec);
	}

	var decPos = s.indexOf(dec);

	if(prec >= 1 && decPos !== -1 && (s.length-decPos-1) < prec) {
		s += new Array(prec - (s.length - decPos - 1)).join(0) + '0';
	}
	else if(prec >= 1 && decPos === -1) {
		s += dec + new Array(prec).join(0) + '0';
	}

	return s;
}

function isNumber(obj) { 
	return !isNaN(parseFloat(obj)); 
}

checkheartBeat();