package com.ubs.manhatthan.filters;

import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

public class SessionListener implements HttpSessionListener {

	@Override
	public void sessionCreated(HttpSessionEvent ev) {
		System.out.println("sessionCreated - add one session into counter");
	}

	@Override
	public void sessionDestroyed(HttpSessionEvent ev) {
		System.out.println("sessionDestroyed - deduct one session from counter");
		
		   // Get the session
//	    HttpSession session = ev.getSession();

	    // Get the access bean
//	    Access access = (Access) session.getAttribute("scopedTarget.access");

	    // Print the serial
//	    System.out.println(access.getSerial());
	}
}
