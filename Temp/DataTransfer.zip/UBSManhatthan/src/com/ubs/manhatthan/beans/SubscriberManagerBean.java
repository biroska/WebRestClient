package com.ubs.manhatthan.beans;

import java.io.Serializable;
import java.util.List;
import java.util.UUID;

import javax.annotation.PostConstruct;

import org.apache.log4j.Level;
import org.primefaces.json.JSONObject;
import org.primefaces.push.EventBus;
import org.primefaces.push.EventBusFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.cache.LmdsCache;
import com.ubs.manhatthan.manager.facade.FacadeService;
import com.ubs.manhatthan.manager.logger.ManhattanLogger;
import com.ubs.manhatthan.manager.utils.Util;
import com.ubs.manhatthan.model.StrategyReport;
import com.ubs.manhatthan.model.LegStrategyReport;
import com.ubs.manhatthan.model.PushManager;

@Component("subscriberManagerBean")
@Scope("session")
public class SubscriberManagerBean implements Serializable, Runnable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -686269472821533540L;
   
    private static Integer sleepTimeout = 1000;

    private String channel;
    
    @Autowired
    private ResourceChannelBean resourceChannelBean;
    
    @Autowired
    private ManagerBean managerBean;
    
    private User userLogged;
    
    private volatile boolean done;
    
	@Autowired
	protected FacadeService facadeService;
	
	private long lastPositionCacheIndex = 0;
		
	private PushManager pushManagerObject;
	
	@PostConstruct
    public void init() {
    	channel = "/" + UUID.randomUUID().toString();
    }
    
    public void setManagerBean(ManagerBean managerBean)
    {
    	this.managerBean = managerBean;
    }

    public void setResourceChannelBean(ResourceChannelBean resourceChannelBean)
    {
    	this.resourceChannelBean = resourceChannelBean;
    }

	public void setFacadeService(FacadeService facadeService) {
		this.facadeService = facadeService;
	}
	
	public String getChannel() {
		return this.channel;
	}
	
    public void start() {
    	
    	ManhattanLogger.log(Util.getManagerId().toString(), "SubscriberBean() - Start thread for user " + this.userLogged.getLogin() + " get market whatch and manager information", Level.DEBUG);
    	
        if (EventBusFactory.getDefault() != null) {
        	
	        EventBus eventBus = EventBusFactory.getDefault().eventBus();
	        
	        if (pushManagerObject == null)
	        	pushManagerObject = new PushManager();
	    	
	        resourceChannelBean.addChannel(userLogged.getSessionId(), channel);
            
	        List<StrategyReport> strategies;
	        
	        while (!done) {
	            try {

	            	//Get strategies from facade	            	
	            	if (userLogged.getCanViewAllManagerRecords()) {
			        	strategies = facadeService.getMessages("", lastPositionCacheIndex);
	            	} else {
			        	strategies = facadeService.getMessages(userLogged.getLogin(), lastPositionCacheIndex);
	            	}
	            			        	
		        	//Get manager (strategy reports)
		        	GetManagerSymbolsValues(strategies);

		        	//Serialize JSON object and send to webbrowser
        			JSONObject jsonObjectManager = new JSONObject(pushManagerObject);	
					    		        			
		        	eventBus.publish(resourceChannelBean.getChannel(userLogged.getSessionId()), String.valueOf(jsonObjectManager));
		        	
		            Thread.sleep(sleepTimeout);   
		        } catch (Exception ex) {
		        	ex.printStackTrace();
		        	
		        	ManhattanLogger.log(Util.getManagerId().toString(), ex.getMessage(), Level.DEBUG);
		        }
    		}
        	
	        resourceChannelBean.removeChannel(userLogged.getSessionId());
        } else {
        	ManhattanLogger.log(Util.getManagerId().toString(), "SubscriberBean() - EventBusFactory is null" , Level.ERROR);
        }
        
    	ManhattanLogger.log(Util.getManagerId().toString(), "SubscriberBean() - End thread for user " + this.userLogged.getLogin() + " used to get manager information", Level.DEBUG);
    }
        
    private void GetManagerSymbolsValues(List<StrategyReport> strategies) {   	

    	try {    		
    		com.ubs.manhatthan.model.StrategyReport strategyReportModelToPush = null;
    		
    		pushManagerObject.clearFields();
    		
    		if (strategies != null) {
//    	    	ManhattanLogger.log(Util.getManagerId().toString(), "GetManagerSymbolsValues - Will process " + strategies.size() + " strategies." , Level.DEBUG);    	    	
    	    	
	    		if (strategies.size() > 0) {
	    			
        	    	for (int i=0; i < strategies.size(); i++) {
    	    			//Check and add strategy report body to push object, if needed
    					StrategyReport strategyReport = strategies.get(i);    					

    					ManhattanLogger.log(Util.getManagerId().toString(), "Ready strategy report [" + strategyReport.getEngineId() + ", " + strategyReport.getStrategyId() + "]", Level.DEBUG);
    					
    					//Check if strategy report is a message
    					if (strategyReport.getMessage() != null && strategyReport.getMessage().length() > 0) {
    						lastPositionCacheIndex = strategyReport.getCounter();

    						if (strategyReport.getRequestId() == userLogged.getRequestId()) {    						
    							pushManagerObject.setNotificationMessage(strategyReport.getMessage());
    						}
    					} else {
	    					
    						strategyReportModelToPush = getStrategyReportModelInSession(strategyReport);    					
	
	    					if (strategyReportModelToPush != null) {
	    						pushManagerObject.addStrategyReport(strategyReportModelToPush);
	    						
	        					if (strategyReportModelToPush.getLegStrategyList() != null) {    					
	    	    					//Check and add strategy report legs to push object
	    	    					for (LegStrategyReport legStrategyReportToPush: strategyReportModelToPush.getLegStrategyList()) {
	    	    						pushManagerObject.addLegStrategyReport(legStrategyReportToPush);
	    		    				}
	        					}
	    					} else {
	    						pushManagerObject.setRefreshTableIsNeeded("S");
	    					}
    					}
    	    		}	
    	    	} else {
    	    		pushManagerObject.setHeartBeat(true);
    	    	}    	    	
    		} else {
    			pushManagerObject.setHeartBeat(true);

//	    		ManhattanLogger.log(Util.getManagerId().toString(), "GetManagerSymbolsValues - Will process 0 strategies." , Level.DEBUG);
    		}
    	} catch (Exception ex) {
    		ex.printStackTrace();
    		
    		ManhattanLogger.log(Util.getManagerId().toString(), ex.getMessage(), Level.ERROR);
    	}
    }
    
    private com.ubs.manhatthan.model.StrategyReport getStrategyReportModelInSession(StrategyReport strategyReportModel) throws BeansException, DAOExceptionManhattan {
    	
    	//Add report in session, if needed
    	if (!managerBean.getStrategyReports().contains(strategyReportModel)) {    		    		
    		int i; 
    		
    		//Try setting contract by instrument in LMDS
    		for (i = 0; i < strategyReportModel.getLegStrategyList().size(); i++) {
    			if (strategyReportModel.getLegStrategyList().get(i).getContract() == null || 
    				strategyReportModel.getLegStrategyList().get(i).getContract().length() == 0) {
    					strategyReportModel.getLegStrategyList().get(i).setContract(LmdsCache.getLmdsContractFromInstrument(strategyReportModel.getLegStrategyList().get(i).getInstrument()));
    				}
    		}

    		if (strategyReportModel.getContractsDisplayText() != null && 
    				strategyReportModel.getContractsDisplayText().length() > 0) {
    			
    			managerBean.getStrategyReports().add(strategyReportModel);
    			
    			lastPositionCacheIndex = strategyReportModel.getCounter();
    			
    			return null;
    		}
    	} else {
    		if (strategyReportModel.getContractsDisplayText() != null && 
    				strategyReportModel.getContractsDisplayText().length() > 0) {
    			
    			lastPositionCacheIndex = strategyReportModel.getCounter();
    		}
    	}
    	
    	return strategyReportModel;
    }

	@Override
	public void run() {
		setDone(false);
		this.start();
	}

	public void shutdown() {
		setDone(true);
	}

	public User getUserLogged() {
		return userLogged;
	}

	public void setUserLogged(User userLogged) {
		this.userLogged = userLogged;
	}

	public boolean isDone() {
		return done;
	}

	public void setDone(boolean done) {
		this.done = done;
	}
}