package com.ubs.manhatthan.beans;

import java.util.ArrayList;
import java.util.List;

import javax.faces.application.Application;
import javax.faces.application.FacesMessage;
import javax.faces.application.ViewHandler;
import javax.faces.component.EditableValueHolder;
import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Level;
import org.primefaces.context.RequestContext;
import org.springframework.beans.factory.annotation.Autowired;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.manager.cache.CacheHelper;
import com.ubs.manhatthan.manager.logger.ApplicationLogger;
import com.ubs.manhatthan.manager.logger.ManhattanLogger;
import com.ubs.manhatthan.manager.utils.Util;
import com.ubs.manhatthan.model.StrategyType;

public class UBSCommonBean {

	protected List<StrategyType> strategyTypes = new ArrayList<StrategyType>();

	@Autowired
	User user;

	public UBSCommonBean() {
		strategyTypes = new ArrayList<StrategyType>();
		if (strategyTypes.isEmpty()) {
			strategyTypes = CacheHelper.strategyTypeVOList;
		}
	}

	public RequestContext getRctx() {
		return RequestContext.getCurrentInstance();
	}

	public void logoutSession() {
		
		FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
	}

	public static HttpSession getSession() {
		return (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false);
	}

	public static String mainPageTrader() {
		return "main.xhtml" + forceRedirect();
	}

	public static String forceRedirect() {
		return "?faces-redirect=true";
	}

	public static HttpServletRequest getRequest() {
		return (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
	}

	public static String getUserName() {
		HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false);
		return session.getAttribute("username").toString();
	}

	public static User getUserSession() {
		UserLoginBean loginBean = (UserLoginBean) getRequest().getSession().getAttribute("userLoginBean");
		User user = loginBean.getUser();
		return user;
	}

	public static String getUserId() {
		HttpSession session = getSession();
		if (session != null)
			return (String) session.getAttribute("userid");
		else
			return null;
	}

	public static <T> Object getObjectSession(String sessionAtribute) {
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		HttpSession session = request.getSession(true);
		return session.getAttribute(sessionAtribute);
	}

	protected void refresh() {
		FacesContext context = FacesContext.getCurrentInstance();
		Application application = context.getApplication();
		ViewHandler viewHandler = application.getViewHandler();
		UIViewRoot viewRoot = viewHandler.createView(context, context.getViewRoot().getViewId());
		context.setViewRoot(viewRoot);
		context.renderResponse();
	}

	public static void addMsgValidationSucess(String msgTitle, String msgCause) {
		FacesMessage message = null;
		message = new FacesMessage(FacesMessage.SEVERITY_INFO, msgTitle, msgCause);

		FacesContext.getCurrentInstance().addMessage(null, message);
	}
	
	public static void addMsgValidationError(String msgCause) {
		FacesMessage message = null;
		message = new FacesMessage(FacesMessage.SEVERITY_ERROR, null, msgCause);

		FacesContext.getCurrentInstance().addMessage(null, message);
	}

	public static void addMsgValidationError(String msgTitle, String msgCause) {
		FacesMessage message = null;
		message = new FacesMessage(FacesMessage.SEVERITY_ERROR, msgTitle, msgCause);

		FacesContext.getCurrentInstance().addMessage(null, message);
	}

	public static void addMsgValidationWarn(String msgTitle, String msgCause) {
		FacesMessage message = null;
		message = new FacesMessage(FacesMessage.SEVERITY_WARN, msgTitle, msgCause);

		FacesContext.getCurrentInstance().addMessage(null, message);
	}

	public void logError(String message) {
		ManhattanLogger.log(Util.getManagerId().toString(), message, Level.ERROR);
	}
	
	public static void addValidationMessage(String componentId, String msgTitle, String msgCause) {
		
		addMsgValidationError(msgTitle, msgCause);
		
		addValidationBorder( componentId );
		
		FacesContext.getCurrentInstance().validationFailed();
	}
	
	public static void addValidationBorder( String componentId ) {
		try {
			UIViewRoot uiv = FacesContext.getCurrentInstance().getViewRoot();
			if (uiv!=null) {
				EditableValueHolder uii = (EditableValueHolder) uiv.findComponent( componentId );
				if (uii!=null) {
					uii.setValid( false );
				}
			}
			
		}catch (Exception e){
			ApplicationLogger.logError("======================================================================================");
			ApplicationLogger.logError( "[addValidationBorder] ComponentId: " + componentId + " nao encontrado ");
			ApplicationLogger.logError("======================================================================================");
			
			e.printStackTrace();
		}
	}
	
	public static void removeValidationBorder( String componentId ) {
		try {
			UIViewRoot uiv = FacesContext.getCurrentInstance().getViewRoot();
			if (uiv!=null) {
				EditableValueHolder uii = (EditableValueHolder) uiv.findComponent( componentId );
				if (uii!=null) {
					uii.setValid( true );
				}
			}			
			
		}catch (Exception e){
			ApplicationLogger.logError("======================================================================================");
			ApplicationLogger.logError( "[removeValidationBorder] ComponentId: " + componentId + " nao encontrado ");
			ApplicationLogger.logError("======================================================================================");
			
			e.printStackTrace();
		}
	}
	
	public static void hideDialog(String dialogId){
		if (dialogId!=null) {
			RequestContext context = RequestContext.getCurrentInstance(); 
			if (context!=null) {
				context.execute("PF('" + dialogId + "').hide()");
			}			
		}		
	}

	public List<StrategyType> getStrategyTypes() {
		return strategyTypes;
	}

	public void setStrategyTypes(List<StrategyType> strategyTypes) {
		this.strategyTypes = strategyTypes;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
	public String getGeneralConfigurationThousandSeparator() {
		return Util.getPropertyFromFile("manhattan.general.configuration.number.thousandSeparator");
	}

	public String getGeneralConfigurationDecimalSeparator() {
		return Util.getPropertyFromFile("manhattan.general.configuration.number.decimalSeparator");
	}

	public String getGeneralConfigurationLocale() {
		return Util.getPropertyFromFile("manhattan.general.configuration.number.locale");
	}
	
	public String getGeneralConfigurationFractionDigits() {
		return Util.getPropertyFromFile("manhattan.general.configuration.number.grids.fractionDigits");
	}
}