package com.ubs.manhatthan.beans;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@ManagedBean(name="resourceChannelBean")
@ApplicationScoped
@Component("resourceChannelBean")
@Scope("singleton")
public class ResourceChannelBean implements Serializable {

	private static final long serialVersionUID = 4511970693627082646L;
	
	Map<String, String> channels = new HashMap<String, String>();

    public void addChannel(String sessionId, String channel) {
        channels.put(sessionId, channel);
    }

    public String getChannel(String sessionId) {
        return channels.get(sessionId);
    }
    
    public void removeChannel(String sessionId) {
    	channels.remove(sessionId);
    }
}