package com.ubs.manhatthan.beans;

import java.io.Serializable;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import org.primefaces.event.TabChangeEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ubs.manhatthan.admin.beans.AccountBean;
import com.ubs.manhatthan.admin.beans.BaseBean;
import com.ubs.manhatthan.admin.beans.EngineBean;
import com.ubs.manhatthan.admin.beans.OrderEntryBean;
import com.ubs.manhatthan.admin.beans.RecoveryBean;
import com.ubs.manhatthan.admin.beans.UmdfChannelBean;

@SuppressWarnings("serial")
@SessionScoped
@ManagedBean(name = "controllerMainAdminBean")
@Component("controllerMainAdminBean")
@Scope("session")
public class ControllerMainAdminBean extends BaseBean implements Serializable {
	
	@Autowired
	private EngineBean engineBean;
	
	@Autowired
	private OrderEntryBean orderEntryBean;
	
	@Autowired
	private AccountBean accountBean;
	
	@Autowired
	private UmdfChannelBean umdfChannelBean;
	
	@Autowired
	private RecoveryBean recoveryBean;
	
	private int indexTabActive = 0;
	
	private int indexSubTabActive = 0;
	
	public void onTabChange(TabChangeEvent event) {
		
		try {
			
			if (event.getTab().getId().trim().equals("engine")) {							
				engineBean.loadEngines();
				indexTabActive = 0;

			} else if ((event.getTab().getId().trim().equals("market_data"))) {
				recoveryBean.loadRecovery();
				umdfChannelBean.loadUmdfChannel();	
				indexTabActive = 1;
			
			}else if ((event.getTab().getId().trim().equals("order_entry"))){				
				orderEntryBean.loadOrderEntries();
				indexTabActive = 2;		
				
			}else if ((event.getTab().getId().trim().equals("account"))){
				accountBean.loadAccount();
				indexTabActive = 3;	
				
			}
			
		} catch (Exception ex) {
			ex.printStackTrace();			
			logError(ex.getMessage());
		}
		
	}
	
	public void onSubTabChange(TabChangeEvent event) {
		
		try {
			
			if (event.getTab().getId().trim().equals("umdf_channels")) {	
				umdfChannelBean.loadUmdfChannel();	
				indexSubTabActive = 0;
				
				return;
			} else if ((event.getTab().getId().trim().equals("tcp_recovery"))) {
				recoveryBean.loadRecovery();	
				indexSubTabActive = 1;
										
				return;
			}
			
		} catch (Exception ex) {
			ex.printStackTrace();			
			logError(ex.getMessage());
		}
		
	}
	
	
	public int getIndexTabActive() {
		return indexTabActive;
	}

	public void setIndexTabActive(int indexTabActive) {
		this.indexTabActive = indexTabActive;
	}

	public int getIndexSubTabActive() {
		return indexSubTabActive;
	}

	public void setIndexSubTabActive(int indexSubTabActive) {
		this.indexSubTabActive = indexSubTabActive;
	}
	
}
