package com.ubs.manhatthan.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ubs.manhatthan.common.enuns.StrategyStatusEnum;
import com.ubs.manhatthan.exception.BussinessExceptionManhattan;
import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.cache.LmdsCache;
import com.ubs.manhatthan.manager.enums.MessageTypeEnum;
import com.ubs.manhatthan.manager.enums.SideEnum;
import com.ubs.manhatthan.manager.facade.FacadeService;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.SecurityDefinition;
import com.ubs.manhatthan.manager.utils.Constant;
import com.ubs.manhatthan.manager.utils.Util;
import com.ubs.manhatthan.model.Account;
import com.ubs.manhatthan.model.LegStrategyReport;
import com.ubs.manhatthan.model.StrategyReport;
import com.ubs.manhatthan.model.StrategyType;
import com.ubs.manhatthan.model.StrategyTypeLeg;
import com.ubs.manhatthan.model.Unlegging;
import com.ubs.manhatthan.service.ManagerFacade;
import com.ubs.manhatthan.service.MarketWatchFacade;

@Component("managerBean")
@Scope("session")
@SessionScoped
@ManagedBean(name = "managerBean")
public class ManagerBean extends UBSCommonBean implements Serializable {

	private static final long serialVersionUID = -4696450270615840861L;
	
	@Autowired
	MarketWatchFacade marketWatchFacade;

	@Autowired
	ManagerFacade managerFacade;

	@Autowired
	FacadeService facadeService;

	private StrategyTypeLeg selectStrategyTypeLeg;
	private StrategyType selectStrategyType;
	private StrategyReport strategyReport;
	private StrategyReport selectStrategyReport;
	private LegStrategyReport selectLegStrategyReport;
	private Unlegging selectUnlegging;
	
	private Account selectAccount;

	private List<StrategyReport> strategyReports;
	private List<StrategyReport> selectStrategyReports;
	private List<StrategyReport> filteredStrategyReports;

	private String idSelectStrategyType;

	private long marketingExec;

	private boolean isStrategyPauseAll;
	private boolean isStrategyResumeAll;
	private boolean isOnlyMarket;
	
	private boolean checkAllPO;
	private boolean checkAllEditPO;
	
	private String instrument;
	
	private boolean protectQty;
	private boolean protectDiv1;
	
	private Integer otherTabOrderIndex = 100;
	
	private Double leggedPrice = 0.00;

	public ManagerBean() {
		isStrategyPauseAll = true;
		isStrategyResumeAll = false;
		selectStrategyTypeLeg = new StrategyTypeLeg();
	}

	@PostConstruct
	private void loadView() {
		loadInfo();
	}
	
	public void loadInfo() {
		try {
			strategyReports = new ArrayList<StrategyReport>();
			strategyTypes = marketWatchFacade.getStrategyTypesDomain();
			if (null != strategyTypes) {
				idSelectStrategyType = String.valueOf(strategyTypes.get(0).getId());
				selectStrategyType = strategyTypes.get(0);
				strategyReport = initInfoStrategyReport(idSelectStrategyType);
				selectStrategyReport = initInfoStrategyReport(idSelectStrategyType);
				selectLegStrategyReport = new LegStrategyReport();
				selectUnlegging = new Unlegging();
			}

		} catch (DAOExceptionManhattan e) {
			logError(e.getMessage());
		}
	}

	public void loadFormAddStrategy() {
		selectStrategyType = strategyTypes.get(0);
		idSelectStrategyType = selectStrategyType.getId().toString();
		strategyReport = initInfoStrategyReport(idSelectStrategyType);
		refresh();
	}

	public void changeComboStrategy(ValueChangeEvent event) {
		String tw = (String) event.getNewValue();
		idSelectStrategyType = tw;
		strategyReport = initInfoStrategyReport(idSelectStrategyType);
		refresh();
	}
	
	public void clearBorders( StrategyReport report, boolean isStrategyParameterEdition) {
		
		if ( report == null )
			return;
		
		
		String idPrefix = getIdPrefix( isStrategyParameterEdition );
		
		removeValidationBorder( idPrefix + ":accName" );
		removeValidationBorder( idPrefix + ":aggressiveness" );
		removeValidationBorder( idPrefix + ":txtStart" );
		removeValidationBorder( idPrefix + ":txtEnd" );
		removeValidationBorder( idPrefix + ":createStrategyPaused" );
		removeValidationBorder( idPrefix + ":target" );
		
		if ( report.getLegStrategyList() == null || report.getLegStrategyList().isEmpty() )
			return;
		
		for (int i = 0; i < report.getLegStrategyList().size(); i++) {
			removeValidationBorder( idPrefix + ":clip"+i );
			removeValidationBorder( idPrefix + ":contracts"+i );
		}
		
		removeValidationBorder( idPrefix + ":qty" + ( report.getLegStrategyList().size() -1 ) );
		removeValidationBorder( idPrefix + ":dv" + ( report.getLegStrategyList().size() -1 ) );
	}
	
	public void clearStrategyParameters( boolean isStrategyParameterEdition, StrategyReport report ) {
		clearStrategyParametersFields( false, isStrategyParameterEdition, report );
		
		clearBorders( report, isStrategyParameterEdition );
	}
	
	public void changeSideFromDoubleClick( StrategyReport report ) {
//		No fim, nao precisou do parametro vindo do remoteCommand,
//		mas fica como modelo quando precisar
//		FacesContext context = FacesContext.getCurrentInstance();
//	    Map map = context.getExternalContext().getRequestParameterMap();
//	    Object object = map.get("index" );
		
		for (LegStrategyReport leg : report.getLegStrategyList() ) {
			
			if ( SideEnum.BUY.getCode().equals( leg.getSide() ) ){
				leg.setSide( SideEnum.SELL.getCode() );
			} else {
				leg.setSide( SideEnum.BUY.getCode() );
			}
		}
	}

	private StrategyReport initInfoStrategyReport(String value) {
		StrategyReport report = new StrategyReport();
		
		Double aggressivenessDefault = Double.valueOf(com.ubs.manhatthan.manager.utils.Util.getPropertyFromFile("manhattan.manager.aggressiveness.defaulvalue"));
		Integer restingLevelDefault = Integer.valueOf(com.ubs.manhatthan.manager.utils.Util.getPropertyFromFile("manhattan.manager.restinglevel.defaulvalue"));
		String endTimeText = com.ubs.manhatthan.manager.utils.Util.getPropertyFromFile("manhattan.manager.endtimestrategy.defaultvalue");
		String startTimeText = com.ubs.manhatthan.manager.utils.Util.getPropertyFromFile("manhattan.manager.starttimestrategy.defaultvalue");
		
		report.setRestingLevel(restingLevelDefault);
		report.setRiskLevel( Constant.DEFAULT.RISK_LEVEL );
		report.setAgressiviness(aggressivenessDefault);
		report.setEndTimeText(Util.convertDateHourNowPattern(endTimeText));
		report.setStartTimeText( Util.convertDateHourNowPattern(startTimeText) );
		for (StrategyType strategyType : strategyTypes) {
			if (Long.valueOf(value).equals(strategyType.getId())) {
				selectStrategyType = strategyType;
				report.setStrategyType(selectStrategyType);
				if (null != selectStrategyType.getStrategyTypeLegList()) {
					report.setLegStrategyList(new ArrayList<LegStrategyReport>());
					for (StrategyTypeLeg typeLeg : selectStrategyType.getStrategyTypeLegList()) {
						LegStrategyReport legStrategyReport = new LegStrategyReport();
						BeanUtils.copyProperties(typeLeg, legStrategyReport);
						legStrategyReport.setSide(typeLeg.getDefaultSide());
						report.getLegStrategyList().add(legStrategyReport);
					}
				}
				break;
			}
		}
		return report;
	}

	public void changeSellBuy() {

		for (int i = 0; i < selectStrategyType.getStrategyTypeLegList().size(); i++) {
			if (null != selectStrategyType.getStrategyTypeLegList().get(i).getLegged().getTotalQty()
					&& selectStrategyType.getStrategyTypeLegList().get(i).getLegged().getTotalQty() < 0) {
				long positivo = selectStrategyType.getStrategyTypeLegList().get(i).getLegged().getTotalQty() * -1;
				selectStrategyType.getStrategyTypeLegList().get(i).getLegged().setTotalQty(positivo);
				selectStrategyType.getStrategyTypeLegList().get(i).setDefaultSide(2);
			} else {
				selectStrategyType.getStrategyTypeLegList().get(i).setDefaultSide(1);
			}
		}
	}
	
	public void changeSellBuyByQuantity( String indexParam, StrategyReport report ) {
			
		if ( StringUtils.isNotBlank( indexParam ) ){
		
			int lastIndexOfLegList = report.getLegStrategyList().size() -1;
			
			Integer intIndexParam = Integer.valueOf( indexParam );
			
			if ( lastIndexOfLegList == intIndexParam ){
			
//				Define o ultimo objeto da lista, se for negativo, considera o modulo
//				e ajusta o side para Sell, caso contrario define o side como buy
				if ( null != report.getLegStrategyList().get( lastIndexOfLegList ).getTotalQuantity() &&
						report.getLegStrategyList().get( lastIndexOfLegList ).getTotalQuantity() < 0) {
					
					Long positivo = Math.abs( report.getLegStrategyList().get( lastIndexOfLegList ).getTotalQuantity() );
					report.getLegStrategyList().get( lastIndexOfLegList ).setTotalQuantity(positivo);
					
					report.getLegStrategyList().get( lastIndexOfLegList ).setSide(SideEnum.SELL.getCode());
				} else { 
					if ( null != report.getLegStrategyList().get( lastIndexOfLegList ).getTotalQuantity() ){
							report.getLegStrategyList().get( lastIndexOfLegList ).setSide(SideEnum.BUY.getCode());
					}
				}
				
//				ajusta os buy/sell de todas as legs baseado na ultima
				changeSideByLastLeg( report.getLegStrategyList().get( lastIndexOfLegList ).getSide(),
			             			 lastIndexOfLegList, report );
			} else {
				if ( report.getLegStrategyList().get( intIndexParam ).getTotalQuantity() != null ){
					report.getLegStrategyList().get( intIndexParam ).setTotalQuantity( 
								   Math.abs( report.getLegStrategyList().get( intIndexParam ).getTotalQuantity() ) );
				}
			}

			for (LegStrategyReport legItem : report.getLegStrategyList() ) {
				
				if ( legItem.getTotalQuantity() != null ){
					protectQty = false;
					protectDiv1 = true;
				} else {
					protectQty = false;
					protectDiv1 = false;
				}
			}
		}
	}
	
	public void changeSellBuyByDiv( String indexParam, StrategyReport report ) {
		
		if ( StringUtils.isNotBlank( indexParam ) ){
			
			int lastIndexOfLegList = report.getLegStrategyList().size() -1;
			
			Integer intIndexParam = Integer.valueOf( indexParam );
			
			if ( lastIndexOfLegList == intIndexParam ){
				
//				Define o ultimo objeto da lista, se for negativo, considera o modulo
//				e ajusta o side para Sell, caso contrario define o side como buy
				if ( null != report.getLegStrategyList().get( lastIndexOfLegList ).getDiv1() &&
						report.getLegStrategyList().get( lastIndexOfLegList ).getDiv1() < 0) {
					
					double positivo = Math.abs( report.getLegStrategyList().get( lastIndexOfLegList ).getDiv1() );
					report.getLegStrategyList().get( lastIndexOfLegList ).setDiv1(positivo);
					
					report.getLegStrategyList().get( lastIndexOfLegList ).setSide(SideEnum.SELL.getCode());

				} else { 
					if ( null != report.getLegStrategyList().get( lastIndexOfLegList ).getDiv1() ){
						report.getLegStrategyList().get( lastIndexOfLegList ).setSide(SideEnum.BUY.getCode());
					}
				}
//				ajusta os buy/sell de todas as legs baseado na ultima
					changeSideByLastLeg( report.getLegStrategyList().get( lastIndexOfLegList ).getSide(),
										 lastIndexOfLegList, report );				
			} else {
				if ( report.getLegStrategyList().get( intIndexParam ).getDiv1() != null ){
					report.getLegStrategyList().get( intIndexParam ).setDiv1( 
								   Math.abs( report.getLegStrategyList().get( intIndexParam ).getDiv1() ) );
				}
			}
			
			for (LegStrategyReport legItem : report.getLegStrategyList() ) {
				
				if ( legItem.getDiv1() != null ){
					protectQty = true;
					protectDiv1 = false;
					break;
				} else {
					protectQty = false;
					protectDiv1 = false;
				}
			}
		}
	}
	
	private void changeSideByLastLeg( Integer lastSide, Integer lastIndexOfLegList, StrategyReport report ){
		
		for (int i = lastIndexOfLegList -1; i >= 0; i--) {
			
			if ( SideEnum.BUY.equals( SideEnum.fromValue( lastSide ) ) ){
				report.getLegStrategyList().get( i ).setSide(SideEnum.SELL.getCode());	
			} else {
				report.getLegStrategyList().get( i ).setSide(SideEnum.BUY.getCode());	
			}
			lastSide = report.getLegStrategyList().get( i ).getSide();
		}
	}
	
	public void checkAll(StrategyReport report) {
		for (LegStrategyReport leg : report.getLegStrategyList()) {
			leg.setPassiveLeg(checkAllPO);
		}
	}
	
	public void checkAllEditPO(StrategyReport report) {
		for (LegStrategyReport leg : report.getLegStrategyList()) {
			leg.setPassiveLeg(checkAllEditPO);
		}
	}

	public void startPaused( StrategyReport report ) {
		
		String endTimeText = com.ubs.manhatthan.manager.utils.Util.getPropertyFromFile("manhattan.manager.endtimestrategy.defaultvalue");
				
		if ( report.getStartPaused() ){
			report.setStartTimeText( null );
			report.setEndTimeText( null );
		} else {
			report.setEndTimeText(Util.convertDateHourNowPattern( endTimeText ));
		}
		
	}
	
	public void callSendOTC(ActionEvent actionEvent) {
		try {
			
	    	if (strategyReports.contains(selectStrategyReport)) {
	    	
	    		int index = strategyReports.indexOf(selectStrategyReport);
	    		
				for (int i = 0; i < strategyReports.get(index).getLegStrategyList().size(); i++) {

					if (strategyReports.get(index).getLegStrategyList().get(i).getLegSeq().equals(selectLegStrategyReport.getLegSeq())) {
						
						long otcQty = selectLegStrategyReport.getOtcQuantity();
						Double otcPx = selectLegStrategyReport.getOtcPrice();
						
						strategyReports.get(index).getLegStrategyList().get(i).setOtcQuantity(otcQty);
						strategyReports.get(index).getLegStrategyList().get(i).setOtcPrice(otcPx);
						
						break;
					}
					
				}	    		
	    	}
	    	
			managerFacade.sendOTC(selectStrategyReport, selectLegStrategyReport, user.getRequestId());
		} catch (BussinessExceptionManhattan e) {
			addMsgValidationError(e.getLocalizedMessage());
			
			logError(e.getMessage());
		} catch (DAOExceptionManhattan e) {
			logError(e.getMessage());
		}
		
	}

	public void changeOrderBSUnLegged() {
		if (SideEnum.BUY.getCode().equals(selectStrategyTypeLeg.getDefaultSide())) {
			selectStrategyTypeLeg.setDefaultSide(2);
		} else {
			selectStrategyTypeLeg.setDefaultSide(1);
		}
	}

	public void calculateIsOnlyTarget(boolean isStrategyParameterEdition, StrategyReport report) {
		
		try {
			if ( validation( true, isStrategyParameterEdition, report ) ){
				report = managerFacade.calculateValuesStrategyReport(report, true);
			}
		} catch (DAOExceptionManhattan e) {
			e.printStackTrace();
			logError(e.getMessage());
			
			addMsgValidationError(e.getLocalizedMessage());
		} catch (BussinessExceptionManhattan e) {
			e.printStackTrace();
			
			logError(e.getMessage());
			
			addMsgValidationError(e.getLocalizedMessage());
		}
	}

	public void calculateStrategyValues(boolean isStrategyParameterEdition, StrategyReport report) {
		
		try {
			
			if ( validation( false, isStrategyParameterEdition, report ) ){
				report = managerFacade.calculateValuesStrategyReport(report, false);
			}			
		} catch (DAOExceptionManhattan e) {		
			e.printStackTrace();
			
			logError(e.getMessage());
			
			addMsgValidationError(e.getLocalizedMessage());
		} catch (BussinessExceptionManhattan e) {
			e.printStackTrace();
			
			logError(e.getMessage());
			
			addMsgValidationError(e.getLocalizedMessage());
		}
	}
	
	public void getBusinessDay( StrategyReport report ){
		
		if ( report == null || report.getLegStrategyList() == null || report.getLegStrategyList().isEmpty() )
			return;
		
		for (LegStrategyReport leg : report.getLegStrategyList()) {
			
			if ( StringUtils.isNotBlank( leg.getContract() ) ){
				SecurityDefinition security = LmdsCache.getSecurityDefinitionBySymbol( leg.getContract() );
				
				if ( security == null || security.getBusinessDays() == null )
					return;
				
				leg.setDuration( security.getBusinessDays() );
			}
		}
	}
	
	public boolean validateStrategyCreation( boolean isStrategyParameterEdition, StrategyReport report ){
		
		boolean validationOK = true;
		
		validationOK = validation( false, isStrategyParameterEdition, report );
		
		String idPrefix = getIdPrefix( isStrategyParameterEdition );
		
		for (int i = 0; i < report.getLegStrategyList().size(); i++) {
			LegStrategyReport leg = report.getLegStrategyList().get( i );
			
			if ( leg.getClip() == null ){
				addValidationMessage( idPrefix + ":clip"+i,
						  			  "Strategy Creation Error",
									  "Clip " + (i+1) + " is mandatory" );
				validationOK = false;
			} else 
				if ( leg.getClip() < 1 ){
					addValidationMessage( idPrefix + ":clip"+i,
							  			  "Strategy Creation Error",
										  "Clip " + (i+1) + " must be positive" );
					validationOK = false;
				} else {
					if (leg.getTotalQuantity() != null) {
						//positivate quantity if is negative
						if (leg.getTotalQuantity() < 0) leg.setTotalQuantity(leg.getTotalQuantity() * -1); 
						
						if (leg.getClip() > leg.getTotalQuantity()) {
							addValidationMessage( idPrefix + ":clip"+i,
					  			  "Strategy Creation Error",
								  "Clip " + (i+1) + " be less than the quantity" );
							validationOK = false;	
						}
					} else {
						addValidationMessage( idPrefix + ":clip"+i,
				  			  "Strategy Creation Error",
							  "Clip " + (i+1) + " be less than the quantity" );
					}
				}
		}
		
		
		if ( isStrategyParameterEdition ){
			if ( selectStrategyReport == null || selectStrategyReport.getLegStrategyList() == null ||
				 selectStrategyReport.getLegStrategyList().isEmpty() ||
				 selectStrategyReport.getLegStrategyList().get( 0 ).getAccount() == null ){
				addValidationMessage( idPrefix + ":accName",
												 "Strategy Creation Error",
												 "Account is mandatory" );
				validationOK = false;
			}
		} else {
		
			if ( selectAccount == null ){
				addValidationMessage( idPrefix + ":accName",
												 "Strategy Creation Error",
												 "Account is mandatory" );
				validationOK = false;
			}
		}
		
		if ( report.getRestingLevel() == null ){
			addValidationMessage( idPrefix + ":bookLevel_input",
					  			  "Strategy Creation Error",
								  "Book Level is mandatory" );
			validationOK = false;
		}
		
		if ( report.getAgressiviness()== null ){
			addValidationMessage( idPrefix + ":aggressiveness",
								  "Strategy Creation Error",
								  "Aggressiveness is mandatory" );
			
			validationOK = false;
		} else {
			if ( report.getAgressiviness() < 0 || report.getAgressiviness() > 100 ){
				addValidationMessage( idPrefix + ":aggressiveness",
									  "Strategy Creation Error",
									  "Aggressiveness must be between 0 and 100" );
	
				validationOK = false;
			}
		
			if ( report.getStartPaused() == false && 
				 ( report.getEndTimeText() == null || report.getStartTimeText() == null ) ){
				
				addValidationMessage( idPrefix + ":txtStart",
								      "Strategy Creation Error",
									  "Create Strategy Paused or set a time to start and end" );
				
				addValidationBorder( idPrefix + ":txtEnd" );
				addValidationBorder( idPrefix + ":createStrategyPaused" );
				
				validationOK = false;
			}
			
			
			if ( report.getEndTimeText() != null && report.getStartTimeText() != null ) {
				if ( report.getStartTimeText().compareTo( report.getEndTimeText() ) > 0 ){
					addValidationMessage( idPrefix + ":txtStart",
									      "Strategy Creation Error",
										  "Set a start time before the end time" );
		
					addValidationBorder( idPrefix + ":txtEnd" );
				}
			}
		}
	
		return validationOK;
	}
	
	public boolean validateUnlegging( Unlegging unlegging){
		boolean validationOK = true;
							
		if ( unlegging == null || unlegging.getPrice() == null ||  unlegging.getPrice().equals(0D)){
			addValidationBorder( "componentStrategyParameters:formUnlegging:leggedPx" );
			
			addValidationMessage( "componentStrategyParameters:formUnlegging:leggedPx",
								  "Send Error",
								  "Price is mandatory" );
			
			validationOK = false;
		}
		
		return validationOK;
	}
	
	private boolean validation( boolean isOnlyTarget, boolean isStrategyParameterEdition, StrategyReport report ){
		
		clearBorders( report, isStrategyParameterEdition );
		
		boolean validationOK = true;
		
		if ( report == null || report.getLegStrategyList() == null ||
			 report.getLegStrategyList().isEmpty() || report.getLegStrategyList().size() < 2  ){
			
			addMsgValidationError( "Generic Error", "The report structure is incorrect");

			return false;
		}
		
		String idPrefix = getIdPrefix( isStrategyParameterEdition );
						
		for (int i = 0; i < report.getLegStrategyList().size(); i++) {
			
			LegStrategyReport leg = report.getLegStrategyList().get( i );
			
			if ( leg.getLegSeq() == null || leg.getSide() == null ){
				addMsgValidationError( "Generic Error", "The report structure is incorrect");
				return false;
			}
			
			if ( StringUtils.isBlank( leg.getContract() ) ){
				addValidationMessage( idPrefix + ":contracts"+i,
						  			  "Calculation Error",
									  "Contract " + (i+1) + " is mandatory" );
				validationOK = false;
			} else {
				try {
					instrument = facadeService.getInstrument( leg.getContract() );
					
					if ( StringUtils.isBlank( instrument ) ){
						addValidationMessage( idPrefix + ":contracts"+i,
					  			  			  "Calculation Error",
					  			  			  "Invalid contract: " + leg.getContract() );
						validationOK = false;
					}
					
				} catch (DAOExceptionManhattan e) {
					e.printStackTrace();
				}
			}
			
		}
			
		if( !isOnlyTarget ){
			
			if ( report.getTarget() == null ){
				addValidationMessage( idPrefix + ":target",
									  "Calculation Error",
									  "Target is mandatory" );
				validationOK = false;
				
			}
			
			Integer lastIndex = report.getLegStrategyList().size() -1;
			
			LegStrategyReport lastLeg = report.getLegStrategyList().get( lastIndex );
			
			if ( lastLeg.getTotalQuantity() == null && lastLeg.getDiv1() == null ){
				addValidationBorder( idPrefix + ":dv"+lastIndex );
				
				addValidationMessage( idPrefix + ":qty"+lastIndex,
									  "Calculation Error",
									  "Quantity or Div1 is mandatory" );
				
				validationOK = false;
			}
		}
		
		return validationOK;
	}

	public List<Account> completeAccount(String name) {
		List<Account> accounts = new ArrayList<Account>();
		try {
			accounts = managerFacade.findListAccountByName(name);
		} catch (DAOExceptionManhattan e) {
			logError(e.getMessage());
		}
		return accounts;
	}

	public void createStrategy(StrategyReport report) {
		try {			
			if (getCanEditStrategy()) {
				if ( validateStrategyCreation(false, report) ) {
					
					for (int i = 0; i < report.getLegStrategyList().size(); i++) {
						report.getLegStrategyList().get(i).setAccount(selectAccount);
					}					
					
					managerFacade.createStrategyReport(report, user.getRequestId());
	
					clearStrategyParametersFields( false, false, report );
					
					hideDialog("dlgStrategyParameters");
				}
			} else {
				addMsgValidationError("Permission denied for create strategy.");
				
				logError("Permission denied for create strategy for user [" + user.getLogin() + "]");
			}
		} catch (BussinessExceptionManhattan e) {
			addMsgValidationError(e.getMessage());
			
			logError(e.getMessage());
		} catch (DAOExceptionManhattan e) {
			addMsgValidationError(e.getMessage());
			
			logError(e.getMessage());
		}
	}
	
	private void clearStrategyParametersFields( boolean onlyStrategyParameters, boolean isStrategyParameterEdition, StrategyReport report ){
		
		this.setCheckAllPO( false );
		this.setCheckAllEditPO( false );
		this.otherTabOrderIndex = 100;
		
		for ( LegStrategyReport leg : report.getLegStrategyList() ) {
			
			if ( !isStrategyParameterEdition ){
				leg.setContract( "" );
				leg.setDuration( null );
			}
			
			leg.setTotalQuantity( null );
			leg.setClip( null );
			leg.setRestingRank( null );
			leg.setDiv1( null );
			leg.setPassiveLeg( false );
			
			protectQty = false;
			protectDiv1 = false;
		}
		
		if ( !isStrategyParameterEdition ){
			this.selectAccount = null;
		}		
		
		Double aggressivenessDefault = Double.valueOf(com.ubs.manhatthan.manager.utils.Util.getPropertyFromFile("manhattan.manager.aggressiveness.defaulvalue"));
		Integer restingLevelDefault = Integer.valueOf(com.ubs.manhatthan.manager.utils.Util.getPropertyFromFile("manhattan.manager.restinglevel.defaulvalue"));
		String endDefaultTime = com.ubs.manhatthan.manager.utils.Util.getPropertyFromFile("manhattan.manager.endtimestrategy.defaultvalue");
		String startDefaultTime = com.ubs.manhatthan.manager.utils.Util.getPropertyFromFile("manhattan.manager.starttimestrategy.defaultvalue");
				
		if ( !onlyStrategyParameters ){
			report.setRestingLevel(restingLevelDefault);
			report.setRiskLevel(Constant.DEFAULT.RISK_LEVEL);
			report.setAgressiviness(aggressivenessDefault);
			report.setTarget(null);
			report.setTargetWarning(false);
			report.setTargetDif(null);
			report.setMarket(null);
			report.setStartTime(Util.convertDateHourNowPattern(startDefaultTime));
			report.setStartTimeText(Util.convertDateHourNowPattern(startDefaultTime));
			report.setEndTimeText(Util.convertDateHourNowPattern(endDefaultTime));
			report.setStartPaused(false);
		}
	}

	public void updateStrategy( StrategyReport report ) {
		try {
			if (getCanEditStrategy()) {
				if ( validateStrategyCreation( true, report ) ){
				
					managerFacade.updateStrategyReport(report, MessageTypeEnum.MODIFY_STRATEGY, user.getRequestId());
					
					hideDialog("dlgStrategyParametersEdit");
				}
			} else {
				addMsgValidationError("Permission denied for edit strategy.");
				
				logError("Permission denied for edit strategy for user [" + user.getLogin() + "]");
			}		
		} catch (BussinessExceptionManhattan e) {
			addMsgValidationError(e.getMessage());
			
			logError(e.getMessage());
		} catch (DAOExceptionManhattan e) {
			addMsgValidationError(e.getMessage());
			
			logError(e.getMessage());
		}
	}

	public void resumeStrategy(ActionEvent actionEvent) {
		boolean canResumeStrategy = false;

		try {
			for (int i = 0; i < selectStrategyReports.size(); i++) {
				if (getCanResumeAllStrategies()) {
					canResumeStrategy = true;
				} else {
					if (getCanResumeStrategy()) {
						canResumeStrategy = selectStrategyReports.get(i).getLogin().equals(user.getLogin());
					}
				}

				if (canResumeStrategy)
					managerFacade.updateActionsStrategyReport(selectStrategyReports.get(i), MessageTypeEnum.RESUME_STRATEGY, user.getRequestId());
			}
		} catch (BussinessExceptionManhattan e) {
			addMsgValidationError(e.getMessage());
			logError(e.getMessage());
		} catch (DAOExceptionManhattan e) {
			logError(e.getMessage());
		}
	}

	public void cancelStrategy(StrategyReport newSelectStrategyReport) {

		boolean canCancelStrategy = false;
		
		if (getCanCancelAllStrategies()) {
			canCancelStrategy = true;
		} else {
			if (getCanCancelStrategy()) {
				canCancelStrategy = newSelectStrategyReport.getLogin().equals(user.getLogin());
			}
		}
		
		if (canCancelStrategy) {
			try {
				this.setSelectStrategyReport(newSelectStrategyReport);
				
				if (this.selectStrategyReport != null) {
					managerFacade.updateActionsStrategyReport(selectStrategyReport, MessageTypeEnum.CANCEL_STRATEGY, user.getRequestId());
				}
			} catch (BussinessExceptionManhattan e) {
				logError(e.getMessage());
	
				addMsgValidationError(e.getMessage());
			} catch (DAOExceptionManhattan e) {
				logError(e.getMessage());
	
				addMsgValidationError(e.getMessage());
			}
		}
	}

	public void cancelAllStrategies(ActionEvent actionEvent) {
		boolean canCancelStrategy = false;

		try {
			for (int i = 0; i < selectStrategyReports.size(); i++) {
				
				if (getCanCancelAllStrategies()) {
					canCancelStrategy = true;
				} else {
					if (getCanCancelStrategy()) {
						canCancelStrategy = selectStrategyReports.get(i).getLogin().equals(user.getLogin());
					}
				}

				if (canCancelStrategy)
					managerFacade.updateActionsStrategyReport(selectStrategyReports.get(i), MessageTypeEnum.CANCEL_STRATEGY, user.getRequestId());
			}
		} catch (BussinessExceptionManhattan e) {
			logError(e.getMessage());
		} catch (DAOExceptionManhattan e) {
			logError(e.getMessage());
		}
	}

	public void pauseStrategy(ActionEvent actionEvent) {
		boolean canPauseStrategy = false;

		try {
			for (int i = 0; i < selectStrategyReports.size(); i++) {
				
				if (getCanPauseAllStrategies()) {
					canPauseStrategy = true;
				} else {
					if (getCanPauseStrategy()) {
						canPauseStrategy = selectStrategyReports.get(i).getLogin().equals(user.getLogin());
					}
				}

				if (canPauseStrategy)
					managerFacade.updateActionsStrategyReport(selectStrategyReports.get(i), MessageTypeEnum.PAUSE_STRATEGY, user.getRequestId());
			}
		} catch (BussinessExceptionManhattan e) {
			addMsgValidationError(e.getMessage());
			logError(e.getMessage());
		} catch (DAOExceptionManhattan e) {
			logError(e.getMessage());
		}
	}

	public void statusStrategyClicked(StrategyReport newSelectStrategyReport) {
		boolean canChangeStatusStrategy = false;

		try {
			this.setSelectStrategyReport(newSelectStrategyReport);
			
			if (selectStrategyReport != null) {
				if (StrategyStatusEnum.RESUMED.getCode().equals(selectStrategyReport.getStatus()) || 
						StrategyStatusEnum.RESUMING.getCode().equals(selectStrategyReport.getStatus())) {
					
					if (getCanPauseAllStrategies()) {
						canChangeStatusStrategy = true;
					} else {
						if (getCanPauseStrategy()) {
							canChangeStatusStrategy = selectStrategyReport.getLogin().equals(user.getLogin());
						}
					}
					
					if (canChangeStatusStrategy)
						managerFacade.updateActionsStrategyReport(selectStrategyReport, MessageTypeEnum.PAUSE_STRATEGY, user.getRequestId());
				} if (StrategyStatusEnum.PAUSED.getCode().equals(selectStrategyReport.getStatus())) {

					if (getCanPauseAllStrategies()) {
						canChangeStatusStrategy = true;
					} else {
						if (getCanPauseStrategy()) {
							canChangeStatusStrategy = selectStrategyReport.getLogin().equals(user.getLogin());
						}
					}

					if (canChangeStatusStrategy)
						managerFacade.updateActionsStrategyReport(selectStrategyReport, MessageTypeEnum.RESUME_STRATEGY, user.getRequestId());
				}				
			}
		} catch (BussinessExceptionManhattan e) {
			addMsgValidationError(e.getMessage());
			
			logError(e.getMessage());
		} catch (DAOExceptionManhattan e) {
			logError(e.getMessage());
		}
	}

	public void submitSend(Unlegging selectUnlegging) {
		try {
			setSelectUnlegging(selectUnlegging);

	    	if ( validateUnlegging(selectUnlegging) ){
				selectUnlegging.setMarket(false);

		    	managerFacade.sendUnlegged(selectUnlegging, user.getRequestId());
			}
			
		} catch (BussinessExceptionManhattan e) {
			addMsgValidationError(e.getLocalizedMessage());
			
			logError(e.getMessage());
		} catch (DAOExceptionManhattan e) {
			
			logError(e.getMessage());
		}
	}

	public void submitMarket(Unlegging selectUnlegging) {
		try {
			setSelectUnlegging(selectUnlegging);
			
			if ( validateUnlegging(selectUnlegging) ){
				selectUnlegging.setMarket(true);

		    	managerFacade.sendUnlegged(selectUnlegging, user.getRequestId());
			}
		} catch (BussinessExceptionManhattan e) {
			addMsgValidationError(e.getLocalizedMessage());
			
			logError(e.getMessage());
		} catch (DAOExceptionManhattan e) {
			
			logError(e.getMessage());
		}
	}

	public void submitAllSend() {
		try {
			if (this.selectLegStrategyReport!=null && !this.selectLegStrategyReport.getUnleggingList().isEmpty()) {
				
				for (Unlegging unlegging : this.selectLegStrategyReport.getUnleggingList()) {					
					
					if (validateUnlegging(unlegging)) {
				    	unlegging.setPrice(this.leggedPrice); //Set the screen price put by user for all unlegs
						unlegging.setMarket(false);
				    	
				    	managerFacade.sendUnlegged(unlegging, user.getRequestId());
					}	
				}			
			}			
			
		} catch (BussinessExceptionManhattan e) {
			addMsgValidationError(e.getLocalizedMessage());
			
			logError(e.getMessage());
		} catch (DAOExceptionManhattan e) {
			
			logError(e.getMessage());
		}
	}

	public void submitAllMarket() {
		try {
			if (this.selectLegStrategyReport!=null && !this.selectLegStrategyReport.getUnleggingList().isEmpty()) {
				
				for (Unlegging unlegging : this.selectLegStrategyReport.getUnleggingList()) {					
					
					if (validateUnlegging(unlegging)) {						
						unlegging.setMarket(true);
						
						managerFacade.sendUnlegged(unlegging, user.getRequestId());
					}	
				}			
			}		
		} catch (BussinessExceptionManhattan e) {
			addMsgValidationError(e.getLocalizedMessage());
			
			logError(e.getMessage());
		} catch (DAOExceptionManhattan e) {
			
			logError(e.getMessage());
		}
	}

	private String getIdPrefix( boolean isStrategyParameterEdition){
		if ( isStrategyParameterEdition ){
			return "componentStrategyParametersEdit:formManagerEditStrategy";
		} else {
			return "componentStrategyParameters:formManagerAddStrategy";
		}
	}

	public boolean getDisabledButtons() {
		return ((this.strategyReports != null) && (this.strategyReports.size() == 0));
	}
	
	public StrategyTypeLeg getSelectStrategyTypeLeg() {
		return selectStrategyTypeLeg;
	}

	public void setSelectStrategyTypeLeg(StrategyTypeLeg selectStrategyTypeLeg) {
		this.selectStrategyTypeLeg = selectStrategyTypeLeg;
	}

	public StrategyType getSelectStrategyType() {
		return selectStrategyType;
	}

	public void setSelectStrategyType(StrategyType selectStrategyType) {
		this.selectStrategyType = selectStrategyType;
	}

	public String getIdSelectStrategyType() {
		return idSelectStrategyType;
	}

	public void setIdSelectStrategyType(String idSelectStrategyType) {
		this.idSelectStrategyType = idSelectStrategyType;
	}

	public long getMarketingExec() {
		return marketingExec;
	}

	public void setMarketingExec(long marketingExec) {
		this.marketingExec = marketingExec;
	}

	public void setMarketWatchFacade(MarketWatchFacade marketWatchFacade) {
		this.marketWatchFacade = marketWatchFacade;
	}

	public StrategyReport getStrategyReport() {
		return strategyReport;
	}

	public void setStrategyReport(StrategyReport strategyReport) {
		this.strategyReport = strategyReport;
	}

	public List<StrategyReport> getStrategyReports() {
		return strategyReports;
	}

	public void setStrategyReports(List<StrategyReport> strategyReports) {
		this.strategyReports = strategyReports;
	}	

	public List<StrategyReport> getFilteredStrategyReports() {
		return filteredStrategyReports;
	}

	public void setFilteredStrategyReports(
			List<StrategyReport> filteredStrategyReports) {
		this.filteredStrategyReports = filteredStrategyReports;
	}

	public List<StrategyReport> getSelectStrategyReports() {
		return selectStrategyReports;
	}

	public void setSelectStrategyReports(List<StrategyReport> selectStrategyReports) {
		this.selectStrategyReports = selectStrategyReports;
	}

	public Account getSelectAccount() {
		return selectAccount;
	}

	public void setSelectAccount(Account selectAccount) {
		this.selectAccount = selectAccount;
	}

	public StrategyReport getSelectStrategyReport() {
		return selectStrategyReport;
	}

	public void setSelectStrategyReport(StrategyReport selectStrategyReport) {
		
		if (selectStrategyReport != null) {
			BeanUtils.copyProperties(selectStrategyReport, this.selectStrategyReport);

			this.selectStrategyReport.setStrategyType(new StrategyType());		
			BeanUtils.copyProperties(selectStrategyReport.getStrategyType(), this.selectStrategyReport.getStrategyType());
	
			if (selectStrategyReport.getLegStrategyList() != null) {		
				this.selectStrategyReport.setLegStrategyList(new ArrayList<LegStrategyReport>());
				
				for (int i=0; i<selectStrategyReport.getLegStrategyList().size(); i++) {
					LegStrategyReport legStrategyReport = new LegStrategyReport();
					
					BeanUtils.copyProperties(selectStrategyReport.getLegStrategyList().get(i), legStrategyReport);
					
					legStrategyReport.setAccount(new Account());
					BeanUtils.copyProperties(selectStrategyReport.getLegStrategyList().get(i).getAccount(), legStrategyReport.getAccount());

					legStrategyReport.setOrderType(selectStrategyReport.getLegStrategyList().get(i).getOrderType());
					
					if (selectStrategyReport.getLegStrategyList().get(i).getUnleggingList() != null) {
						
						legStrategyReport.setUnleggingList(new ArrayList<Unlegging>());
						
						for (int ii=0; ii<selectStrategyReport.getLegStrategyList().get(i).getUnleggingList().size();ii++) {
							Unlegging unlegging = new Unlegging(); 
							
							BeanUtils.copyProperties(selectStrategyReport.getLegStrategyList().get(i).getUnleggingList().get(ii), unlegging);
							
							legStrategyReport.getUnleggingList().add(unlegging);
						}
					}
					
					this.selectStrategyReport.getLegStrategyList().add(legStrategyReport);	
				}
			}
		}
	}

	public LegStrategyReport getSelectLegStrategyReport() {
		return selectLegStrategyReport;
	}

	public void setSelectLegStrategyReport(LegStrategyReport selectLegStrategyReport) {
		if (selectLegStrategyReport != null) {
			this.leggedPrice = selectLegStrategyReport.getLeggedPrice();
			
			BeanUtils.copyProperties(selectLegStrategyReport, this.selectLegStrategyReport);
			
			this.selectLegStrategyReport.setAccount(new Account());
			BeanUtils.copyProperties(selectLegStrategyReport.getAccount(), this.selectLegStrategyReport.getAccount());

			this.selectLegStrategyReport.setOrderType(selectLegStrategyReport.getOrderType());
			
			if (selectLegStrategyReport.getUnleggingList() != null) {
				
				this.selectLegStrategyReport.setUnleggingList(new ArrayList<Unlegging>());
				
				for (int i=0; i<selectLegStrategyReport.getUnleggingList().size();i++) {
					Unlegging unlegging = new Unlegging(); 
					
					BeanUtils.copyProperties(selectLegStrategyReport.getUnleggingList().get(i), unlegging);
					
					this.selectLegStrategyReport.getUnleggingList().add(unlegging);
				}
			}
		}
	}
	
	/*
	 * Esses metodos sao responsaveis por gerar o tab order da grid dinamica do strategyParameters
	 * 
	 * ideia
	 * 
	 * Utilizar o size da lista utilizada no dataTable para gerar o indice base de cada coluna,
	 * dai em diante soma-se o index da iteracao do dataTable para fazer a variacao do indice
	 * 
	 * Para a coluna 2,3, etc... multiplica-se o size da lista pelo respectivo numero da coluna
	 * 2,3, etc...
	 * 
	 * */
	private Integer columnGeneratrix(StrategyReport report, Integer columnIndex, Integer rowIndex) {
		otherTabOrderIndex = 3 + rowIndex + (report.getLegStrategyList().size() * columnIndex);
		return otherTabOrderIndex;
	}
	
	public Integer getColumnGeneratrix(StrategyReport report, Integer columnIndex, Integer rowIndex) {
		return columnGeneratrix(report, columnIndex, rowIndex); 		
	}
	
	public Integer getOrdenedTabOrder(StrategyReport report, Integer index) {
		otherTabOrderIndex = otherTabOrderIndex + index;
		return otherTabOrderIndex;
	}
	
	public Integer getOtherTabOrder() {
		return otherTabOrderIndex++;
	}
	
	/*
	 * 
	 * termino
	 * 
	 * */
	
	public Unlegging getSelectUnlegging() {
		return selectUnlegging;
	}

	public void setSelectUnlegging(Unlegging selectUnlegging) {
		BeanUtils.copyProperties(selectUnlegging, this.selectUnlegging);
	}

	public void setManagerFacade(ManagerFacade managerFacade) {
		this.managerFacade = managerFacade;
	}

	public void setFacade(FacadeService facade) {
		this.facadeService = facade;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public MarketWatchFacade getMarketWatchFacade() {
		return marketWatchFacade;
	}

	public boolean isStrategyPauseAll() {
		return isStrategyPauseAll;
	}

	public void setStrategyPauseAll(boolean isStrategyPauseAll) {
		this.isStrategyPauseAll = isStrategyPauseAll;
	}

	public boolean isStrategyResumeAll() {
		return isStrategyResumeAll;
	}

	public void setStrategyResumeAll(boolean isStrategyResumeAll) {
		this.isStrategyResumeAll = isStrategyResumeAll;
	}

	public boolean isOnlyMarket() {
		return isOnlyMarket;
	}

	public void setOnlyMarket(boolean isOnlyMarket) {
		this.isOnlyMarket = isOnlyMarket;
	}

	public boolean isCheckAllPO() {
		return checkAllPO;
	}

	public void setCheckAllPO(boolean checkAllPO) {
		this.checkAllPO = checkAllPO;
	}

	public boolean isCheckAllEditPO() {
		return checkAllEditPO;
	}

	public void setCheckAllEditPO(boolean checkAllEditPO) {
		this.checkAllEditPO = checkAllEditPO;
	}

	public boolean isProtectQty() {
		return protectQty;
	}

	public void setProtectQty(boolean protectQty) {
		this.protectQty = protectQty;
	}

	public boolean isProtectDiv1() {
		return protectDiv1;
	}

	public void setProtectDiv1(boolean protectDiv1) {
		this.protectDiv1 = protectDiv1;
	}
	
	public Double getLeggedPrice() {
		return this.leggedPrice;
	}
	
	public void setLeggedPrice(Double leggedPrice) {
		this.leggedPrice = leggedPrice;
	}

	public boolean verifyAccess() {
		return user.getCanViewManagerRecords();
	}
	
	public boolean getCanEditStrategy() {
		return user.getCanEditStrategy();
	}
	
	public boolean getCanPauseStrategy() {
		return user.getCanPauseManagerRecords();
	}
	
	public boolean getCanPauseAllStrategies() {
		return user.getCanPauseAllManagerRecords();
	}

	public boolean getCanResumeStrategy() {
		return user.getCanResumeManagerRecords();
	}
	
	public boolean getCanResumeAllStrategies() {
		return user.getCanResumeAllManagerRecords();
	}

	public boolean getCanCancelStrategy() {
		return user.getCanCancelManagerRecords();
	}
	
	public boolean getCanCancelAllStrategies() {
		return user.getCanCancelAllManagerRecords();
	}
	
	public String getAccountText(StrategyReport strategyReport) {
    	if (user.getCanViewCustomerInformation() == false) {
    		return "-";
    	} else {    		
    		return strategyReport.getLegStrategyList().get(0).getAccount().getNameDisplay();
    	}
	}
}