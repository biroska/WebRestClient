package com.ubs.manhatthan.beans;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import org.apache.log4j.Level;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.logger.ManhattanLogger;
import com.ubs.manhatthan.manager.persistence.entities.OrderTrade;
import com.ubs.manhatthan.manager.utils.Util;

@SuppressWarnings("serial")
@SessionScoped
@ManagedBean(name="reportAverageBean")
@Component("reportAverageBean")
@Scope("session")
public class ReportAverageBean extends ReportBaseBean {

	private List<OrderTrade> orders;
		
    @PostConstruct
    public void init() {

    }
    
    public void openDialog(){    	
    	this.orders = new ArrayList<OrderTrade>();
    	this.orderFilter = new OrderTrade();
    	this.selectAccount = null;
    	removeValidationBorder("componentReportByAverage:formReportAverage:panelFilter:calendarDateFrom");
    	removeValidationBorder("componentReportByAverage:formReportAverage:panelFilter:calendarDateTo");
    	refreshView();
    }
	
	public List<OrderTrade> getRecords() {
		return orders;
	}

	public void setRecords(List<OrderTrade> orders) {
		this.orders = orders;
	}


	public void execute() {
    	try {
    		
    		if (checkIfDateFromIsBiggerThanTo(this.orderFilter.getStartDt(), this.orderFilter.getEndDt())) {
    			orders = facade.reportByAverage(this.orderFilter);
        		refreshView();
			}else{
				addValidationBorder("componentReportByAverage:formReportAverage:panelFilter:calendarDateFrom");
		    	addValidationBorder("componentReportByAverage:formReportAverage:panelFilter:calendarDateTo");
				this.errorMessage(Util.getMessageFromFile( "msg.report.error.date.validation"));
			}
    		
    	} catch (DAOExceptionManhattan daoEx) {
    		daoEx.printStackTrace();
    		
    		ManhattanLogger.log(Util.getManagerId().toString(), "Error on get data for report by average", Level.ERROR);
    		
    		this.errorMessage(Util.getMessageFromFile( "msg.report.error"));
    	}
	}
	
	public void generateCSV()  {
		try {
			if (orders!=null) {
				DecimalFormatSymbols dfs = new DecimalFormatSymbols (Locale.US);
				NumberFormat nf = new DecimalFormat ("#.####", dfs);
				nf.setMinimumFractionDigits(4);
				
				FacesContext facesContext = FacesContext.getCurrentInstance();
			    ExternalContext externalContext = facesContext.getExternalContext();
			    externalContext.setResponseContentType("text/csv");
			    externalContext.setResponseHeader("Content-Disposition", "attachment; filename=\"ReportByAverage.csv\"");

			    OutputStream out = externalContext.getResponseOutputStream();
			    Writer writer = new OutputStreamWriter(out);
				writer.append("B/S,Symbol,Quantity,Price\n");
				
				for (OrderTrade order : orders) {
					if (order.getStrategyDescription()!=null && selectAccount.getDescription()!=null) {
						writer.append(order.getStrategyDescription() + " / " + selectAccount.getDescription());
					}
					if (order.getBuySellDesc()!=null) {
						writer.append(order.getBuySellDesc());
					}	
					writer.append(",");
					if (order.getSymbol()!=null) {
						writer.append(order.getSymbol());
					}				
					writer.append(",");
					if (order.getQuantitySum()!=null) {
						writer.append(order.getQuantitySum().toString());
					}
					writer.append(",");
					if (order.getPriceAverage()!=null) {						
						writer.append(nf.format(order.getPriceAverage()));
					}			
					writer.append( "\n");
				}
				
				writer.flush();
				writer.close();
				
				facesContext.responseComplete();
			}
		} catch (IOException e) {
			this.errorMessage(Util.getMessageFromFile( "msg.report.error.export.csv"));
		}		
    }
	
	public boolean getDisabled(){
		if (orders!=null && !orders.isEmpty()) {
			return false;
		}else{
			return true;
		}
	}
}