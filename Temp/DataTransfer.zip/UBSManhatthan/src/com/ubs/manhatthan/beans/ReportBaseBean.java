package com.ubs.manhatthan.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.faces.application.Application;
import javax.faces.application.FacesMessage;
import javax.faces.application.ViewHandler;
import javax.faces.component.EditableValueHolder;
import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;

import org.apache.log4j.Level;
import org.springframework.beans.factory.annotation.Autowired;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.facade.Facade;
import com.ubs.manhatthan.manager.logger.ApplicationLogger;
import com.ubs.manhatthan.manager.logger.ManhattanLogger;
import com.ubs.manhatthan.manager.persistence.entities.ClientAccount;
import com.ubs.manhatthan.manager.persistence.entities.OrderTrade;
import com.ubs.manhatthan.manager.persistence.entities.Trader;
import com.ubs.manhatthan.manager.utils.Constant;
import com.ubs.manhatthan.manager.utils.Util;
import com.ubs.manhatthan.model.Account;
import com.ubs.manhatthan.service.ManagerFacade;

@SuppressWarnings("serial")
public class ReportBaseBean implements Serializable {

	protected Account selectAccount;
	
	@Autowired
	protected Facade facade;
	
	@Autowired
	protected User user;	
	
	protected ArrayList<Trader> traderList = new ArrayList<>();

	@Autowired
	protected ManagerFacade managerFacade;

	protected OrderTrade orderFilter = new OrderTrade();
	
	public void infoMessage(String messageText) {
		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, messageText, null);
		FacesContext.getCurrentInstance().addMessage(null, message);
	}

	public void warnMessage(String messageText) {
		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_WARN, messageText, null);
		FacesContext.getCurrentInstance().addMessage(null, message);
	}

	public void errorMessage(String messageText) {
		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, messageText, null);
		FacesContext.getCurrentInstance().addMessage(null, message);
	}

	public void fatalMessage(String messageText) {
		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_FATAL, messageText, null);
		FacesContext.getCurrentInstance().addMessage(null, message);
	}
	
	public void logWarn(String message) {
		ManhattanLogger.log(Util.getManagerId().toString(), message, Level.WARN);
	}

	public void logError(String message) {
		ManhattanLogger.log(Util.getManagerId().toString(), message, Level.ERROR);
	}
	
	public Account getSelectAccount() {
		return selectAccount;
	}

	public void setSelectAccount(Account selectAccount) {
		
		if (selectAccount!=null) {
			this.selectAccount = selectAccount;
		
		ClientAccount clientAccount = new ClientAccount(selectAccount.getCode(),
				selectAccount.getName(), selectAccount.getDescription());
		
		this.orderFilter.setAccount(clientAccount);
		}		
	}

	public List<Account> completeAccount(String name) {
		List<Account> accounts = new ArrayList<Account>();
		try {
			accounts =  managerFacade.findListAccountByName(name);
		} catch (DAOExceptionManhattan e) {
			logError(e.getMessage());
		}
		return accounts;
	}
	
	public Date getPeriodFrom() {
		return this.orderFilter.getStartDt();
	}

	public void setPeriodFrom(Date periodFrom) {
		this.orderFilter.setStartDt(periodFrom);
	}
		
	public Date getPeriodTo() {
		return this.orderFilter.getEndDt();
	}
	
	public void setPeriodTo(Date periodTo) {
		this.orderFilter.setStartDt(periodTo);
	}
		
	public void setFacade(Facade facade) {
		this.facade = facade;
	}

	public void setManagerFacade(ManagerFacade managerFacade) {
		this.managerFacade = managerFacade;
	}
	
	public void setUser(User user) {
		this.user = user;
	}
	
	protected void refreshView() {
		FacesContext context = FacesContext.getCurrentInstance();
		Application application = context.getApplication();
		ViewHandler viewHandler = application.getViewHandler();
		UIViewRoot viewRoot = viewHandler.createView(context, context.getViewRoot().getViewId());
		context.setViewRoot(viewRoot);
		context.renderResponse();
	}

	public OrderTrade getOrderFilter() {
		return orderFilter;
	}

	public void setOrderFilter(OrderTrade orderFilter) {
		this.orderFilter = orderFilter;
	}

	public User getUser() {
		return user;
	}
	
	public boolean isAdmin(){
		if (user !=null && user.getProfile()!=null 
				&& user.getProfile().equals(Constant.USER_PROFILE_TYPE.ADMIN)) {
			return true;
		}else {
			return false;
		}
	}
	
	public boolean isSupervisor(){
		if (user !=null && user.getProfile()!=null 
				&& user.getProfile().equals(Constant.USER_PROFILE_TYPE.SUPER)) {
			return true;
		}else {
			return false;
		}
	}

	public ArrayList<Trader> getTraderList() {
		
		traderList = (ArrayList<Trader>) facade.getAllTraders();
		
		return traderList;
	}

	public void setTraderList(ArrayList<Trader> traderList) {
		this.traderList = traderList;
	}
	
	public boolean checkIfDateFromIsBiggerThanTo(Date from, Date to){
		
		boolean isBigger = true;
		
		if ( from !=null && to !=null) {
			if (from.after(to)) {
				isBigger = false;
			}
		}
		
		return isBigger;
		
	}
	
	public static void addValidationBorder( String componentId ) {
		try {
			UIViewRoot uiv = FacesContext.getCurrentInstance().getViewRoot();
			if (uiv!=null) {
				EditableValueHolder uii = (EditableValueHolder) uiv.findComponent( componentId );
				if (uii!=null) {
					uii.setValid( false );
				}
			}
			
		}catch (Exception e){
			ApplicationLogger.logError("======================================================================================");
			ApplicationLogger.logError( "[addValidationBorder] ComponentId: " + componentId + " nao encontrado ");
			ApplicationLogger.logError("======================================================================================");
			
			e.printStackTrace();
		}
	}
	
	public static void removeValidationBorder( String componentId ) {
		try {
			UIViewRoot uiv = FacesContext.getCurrentInstance().getViewRoot();
			if (uiv!=null) {
				EditableValueHolder uii = (EditableValueHolder) uiv.findComponent( componentId );
				if (uii!=null) {
					uii.setValid( true );
				}
			}			
			
		}catch (Exception e){
			ApplicationLogger.logError("======================================================================================");
			ApplicationLogger.logError( "[removeValidationBorder] ComponentId: " + componentId + " nao encontrado ");
			ApplicationLogger.logError("======================================================================================");
			
			e.printStackTrace();
		}
	}
}