package com.ubs.manhatthan.beans;

import java.io.Serializable;
import java.util.List;
import java.util.UUID;

import javax.annotation.PostConstruct;

import org.apache.log4j.Level;
import org.primefaces.json.JSONObject;
import org.primefaces.push.EventBus;
import org.primefaces.push.EventBusFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.helper.PushHelper;
import com.ubs.manhatthan.manager.dto.ReceiveSymbolSyntheticItem;
import com.ubs.manhatthan.manager.dto.ReceiveSynthetic;
import com.ubs.manhatthan.manager.enums.StrategyTypeEnum;
import com.ubs.manhatthan.manager.facade.FacadeService;
import com.ubs.manhatthan.manager.lmdsadapter.SimulationItem;
import com.ubs.manhatthan.manager.logger.ManhattanLogger;
import com.ubs.manhatthan.manager.utils.Util;
import com.ubs.manhatthan.model.Market;
import com.ubs.manhatthan.model.MarketWhatchTab;
import com.ubs.manhatthan.model.PushMarketWatch;
import com.ubs.manhatthan.service.MarketWatchFacade;

@Component("subscriberMarketWhatchBean")
@Scope("session")
public class SubscriberMarketWhacthBean implements Serializable, Runnable {

	private static final long serialVersionUID = 6787918110709028224L;

    private String channel;
    
    @Autowired
    private ResourceChannelBean resourceChannelBean;
    
    @Autowired
    private MarketWatchBean marketBean;
    
    private User userLogged;
    
    private volatile boolean done;
    
	@Autowired
	protected FacadeService facadeService;
	
	@Autowired
	private MarketWatchFacade marketWatchFacade;

	private PushMarketWatch pushMarketWatchObject;
	
	@PostConstruct
    public void init() {
    	channel = "/" + UUID.randomUUID().toString();
    }
    
    public void setMarketBean(MarketWatchBean marketBean)
    {
    	this.marketBean = marketBean;
    }

    public void setResourceChannelBean(ResourceChannelBean resourceChannelBean)
    {
    	this.resourceChannelBean = resourceChannelBean;
    }

	public void setFacadeService(FacadeService facadeService) {
		this.facadeService = facadeService;
	}

	public String getChannel() {
		return this.channel;
	}
	
    public void start() {
    	
    	ManhattanLogger.log(Util.getManagerId().toString(), "SubscriberMarketWhacthBean() - Start thread for user " + this.userLogged.getLogin() + " get market whatch and manager information", Level.DEBUG);
    	
        EventBus eventBus = null;
        
        if (eventBus == null)
        	eventBus = EventBusFactory.getDefault().eventBus();

        if (pushMarketWatchObject == null)
        	pushMarketWatchObject = new PushMarketWatch();
    	
        resourceChannelBean.addChannel(userLogged.getSessionId(), channel);
    	
        if (EventBusFactory.getDefault() != null) {
        	while (!done) {
	            try {
		        	
		        	//Get simulation list
		        	this.GetMarketWhatchSymbolsValues(); 
	        		
		        	if (pushMarketWatchObject != null && pushMarketWatchObject.getFields()!=null && !pushMarketWatchObject.getFields().isEmpty()) {
		        		JSONObject jsonObjectMarketWatch = new JSONObject(pushMarketWatchObject);	
				     
			        	eventBus.publish(resourceChannelBean.getChannel(userLogged.getSessionId()), String.valueOf(jsonObjectMarketWatch));
		        	} else {
		        		ManhattanLogger.log(Util.getManagerId().toString(), "SubscriberMarketWhacthBean() - 0 instruments to send for market whatch screen", Level.DEBUG);
		        	}
		        	
		            Thread.sleep(1000);	        
		        } catch (Exception ex) {
		        	ex.printStackTrace();
		        	
		        	ManhattanLogger.log(Util.getManagerId().toString(), ex.getMessage(), Level.DEBUG);
		        }
		    }
        	
        	resourceChannelBean.removeChannel(userLogged.getSessionId());
        } else {
        	ManhattanLogger.log(Util.getManagerId().toString(), "SubscriberMarketWhacthBean() - EventBusFactory is null" , Level.ERROR);
        }
        
    	ManhattanLogger.log(Util.getManagerId().toString(), "SubscriberMarketWhacthBean() - End thread for user " + this.userLogged.getLogin() + " used to get market whatch information", Level.DEBUG);
    }
        
    private void GetMarketWhatchSymbolsValues() {

    	try {
    		pushMarketWatchObject.clearFields();
    		
        	if (this.marketBean != null && marketBean.getMarketWhatchTabs()!= null ) {        		
        			if(!marketBean.getMarketWhatchTabs().isEmpty()){
	        		MarketWhatchTab marketWatchTab = marketBean.getMarketWhatchTabs().get(marketBean.getIndexTabActive());
	        			
        			if ( marketWatchTab.getMarkets()!=null && !marketWatchTab.getMarkets().isEmpty() ) {
        				
        				pushMarketWatchObject.setTabViewId(marketWatchTab.getId());	        				
        				
			    		for (Market marketItem: marketWatchTab.getMarkets()) {
			    			
			    			List<ReceiveSymbolSyntheticItem> syntheticList = marketItem.getContractsList();
			    			
			    			if ( syntheticList!=null && !syntheticList.isEmpty() ) {
			    				
			    				if (!marketItem.isSubscribed() && marketItem.getStrategyType()!=null ) {
			    					
		    						ReceiveSynthetic synthetic = new ReceiveSynthetic();
		    						if (marketItem.getStrategyType().getStrategyCode()!=null) {
										synthetic.setStrategyType(StrategyTypeEnum.fromValue(marketItem.getStrategyType().getStrategyCode()));
									}else {
										synthetic.setStrategyType(StrategyTypeEnum.UNKNOWN);
									}
		    						
	    							synthetic.setSyntheticList(syntheticList);		    							
		    						String returnSubscribe = facadeService.subscribe(synthetic);
		    						
		    						if (returnSubscribe != null) {
		    							
		    							marketItem.setErrorOnSubscribe(" - " + returnSubscribe);
									}else{
										marketItem.setSubscribed(true);
									}
								}
			    				
								for (ReceiveSymbolSyntheticItem syntheticItem: syntheticList) {			    					
			    					List<SimulationItem> simulationItens = facadeService.getSimulationListBySymbol(syntheticItem.getSymbol());
			    					
			    					if (simulationItens == null) {
			    						ManhattanLogger.log(Util.getManagerId().toString(), "FacadeServiceImpl getSimulationListBySymbol return null for instrument [" + syntheticItem.getSymbol() + "]", Level.ERROR);
			    					} else {
			    						for (SimulationItem simulationItem: simulationItens) {
			    							if (PushHelper.checkIfNeedUpdate(marketItem, simulationItem)) {
			    								pushMarketWatchObject.addSimulationItem(marketItem.getId(), simulationItem);	    			
			    							}
			    						}
			    					}
			    				}				    				
			    			}
		    			}   
        			}
        		}
        	} else {
        		ManhattanLogger.log(Util.getManagerId().toString(), "MarketBean object is null for subscriber", Level.ERROR);
        	}
    	} catch (Exception ex) {
    		ex.printStackTrace();
    		
    		ManhattanLogger.log(Util.getManagerId().toString(), ex.getMessage(), Level.ERROR);
    	}
    }    	

	@Override
	public void run() {
		setDone(false);
		this.start();
	}

	public void shutdown() {
		setDone(true);
	}

	public User getUserLogged() {
		return userLogged;
	}

	public void setUserLogged(User userLogged) {
		this.userLogged = userLogged;
	}

	public boolean isDone() {
		return done;
	}

	public void setDone(boolean done) {
		this.done = done;
	}

	public void setMarketWatchFacade(MarketWatchFacade marketWatchFacade) {
		this.marketWatchFacade = marketWatchFacade;
	}
}