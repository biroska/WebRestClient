package com.ubs.manhatthan.beans;

import java.io.Serializable;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;

import org.apache.commons.lang.StringUtils;
import org.primefaces.component.tabview.TabView;
import org.primefaces.event.TabChangeEvent;
import org.primefaces.event.TabCloseEvent;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.exception.BussinessExceptionManhattan;
import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.cache.CacheHelper;
import com.ubs.manhatthan.manager.cache.LmdsCache;
import com.ubs.manhatthan.manager.dto.ReceiveSymbolSyntheticItem;
import com.ubs.manhatthan.manager.dto.ReceiveSynthetic;
import com.ubs.manhatthan.manager.enums.SideEnum;
import com.ubs.manhatthan.manager.enums.StrategyTypeEnum;
import com.ubs.manhatthan.manager.facade.FacadeService;
import com.ubs.manhatthan.manager.lmdsadapter.LmdsManager;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.SecurityDefinition;
import com.ubs.manhatthan.manager.persistence.entities.StrategyByTab;
import com.ubs.manhatthan.manager.utils.Constant;
import com.ubs.manhatthan.manager.utils.Util;
import com.ubs.manhatthan.model.Account;
import com.ubs.manhatthan.model.LegStrategyReport;
import com.ubs.manhatthan.model.Market;
import com.ubs.manhatthan.model.MarketWhatchTab;
import com.ubs.manhatthan.model.StrategyReport;
import com.ubs.manhatthan.model.StrategyType;
import com.ubs.manhatthan.model.StrategyTypeLeg;
import com.ubs.manhatthan.service.ManagerFacade;
import com.ubs.manhatthan.service.MarketWatchFacade;

@Component("marketBean")
@Scope("session")
@SessionScoped
@ManagedBean(name = "marketBean")
public class MarketWatchBean extends UBSCommonBean implements Serializable {

	private static final long serialVersionUID = -2334341418292057103L;

	@Autowired
	private MarketWatchFacade marketWatchFacade;
	
	@Autowired
	protected FacadeService facadeService;

	private int indexTabActive = 0;

	private String idSelectMarket;

	private Account selectAccount;

	private MarketWhatchTab marketWhatchTab;

	private StrategyType selectStrategyType;

	private Market selectMarket;

	private StrategyType selectStrategyTypeInstrument;

	private Account selectedAccount;

	private List<MarketWhatchTab> marketWhatchTabs;

	private List<MarketWhatchTab> marketWhatchTabsUnSave;

	private List<StrategyByTab> strategyByTabsUnSave;

	private List<Market> marketByTabsToDelete;

	private TabView tabView;
	
	private Boolean disableStrategyType = false;
	
	private boolean disableButton = false;
	private boolean disableButtonSave = false;
	
	private LmdsManager lmds;
	
	/* ###### Fields to Add Strategy - Copied from ManagerBean ###### */
	
	private boolean checkAllPO;	
	private boolean protectQty;
	private boolean protectDiv1;
	private Integer otherTabOrderIndex = 100;
	private String instrument;
	private boolean isOnlyMarket;
	
	private StrategyReport strategyReport;
	private String idSelectStrategyType;
	
	@Autowired
	ManagerFacade managerFacade;
	
	/* ###### Fields to Add Strategy - Copied from ManagerBean ###### */
	

	public MarketWatchBean() {
		reset();
		lmds = CacheHelper.lmdsCommunicatorInstance.get( Util.getManagerId() );
	}	
	
	public void init(){
		try {
			this.strategyTypes = marketWatchFacade.getStrategyTypesDomain();
			if (marketWhatchTabs == null) {
				marketWhatchTabs = marketWatchFacade.getWatchTabMarkets(user.getLogin());
			}			
		} catch (DAOExceptionManhattan e) {
			e.printStackTrace();
			logError(e.getMessage());
		}
	}

	private void reset() {
		marketWhatchTabsUnSave = new ArrayList<MarketWhatchTab>();
		marketByTabsToDelete = new ArrayList<Market>();
		selectStrategyType = new StrategyType();
		selectStrategyTypeInstrument = new StrategyType();
		strategyByTabsUnSave = new ArrayList<StrategyByTab>();
	}

	public String clear() {
		this.selectAccount = null;
		return "";
	}

	public void loadFormMarketNewTab() {
		removeValidationBorder("componentStrategy:formMarketWatchAddTab:txtTabName");
		marketWhatchTab = new MarketWhatchTab();
		setMarketWhatchTab(new MarketWhatchTab());
	}

	public void loadFormAddSyntetic() throws DAOExceptionManhattan {		
		selectStrategyType = new StrategyType();
		idSelectMarket = strategyTypes.get(0).getId().toString();
		selectStrategyType = marketWatchFacade.getStrategyVOById(idSelectMarket);
	}

	public void changeComboValueSyntetic(ValueChangeEvent event) {
		idSelectMarket = String.valueOf(event.getNewValue());
		try {
			selectStrategyType = marketWatchFacade.getStrategyVOById(idSelectMarket);
		} catch (DAOExceptionManhattan e) {
			logError(e.getMessage());
		}
		refresh();
	}

	public void changeOrderBS() {
		for (int i = 0; i < selectStrategyType.getStrategyTypeLegList().size(); i++) {
			if (SideEnum.BUY.getCode().equals(selectStrategyType.getStrategyTypeLegList().get(i).getDefaultSide())) {
				selectStrategyType.getStrategyTypeLegList().get(i).setDefaultSide(2);
			} else {
				selectStrategyType.getStrategyTypeLegList().get(i).setDefaultSide(1);
			}
		}

	}
	
	public StrategyType setInstrumentInfoByName(StrategyType strategyType) throws BussinessExceptionManhattan, DAOExceptionManhattan{
		
		if (strategyType !=null && strategyType.getInstrumentByName()!=null && !strategyType.getInstrumentByName().isEmpty()) {
			
			SecurityDefinition intrumentDefinition  = lmds.getIntrumentDefinitionBySymbol( strategyType.getInstrumentByName().trim() );
			if ( intrumentDefinition != null && intrumentDefinition.getSecurity() != null && intrumentDefinition.getSecurity().getSecurityID() != null ){
				strategyType.setInstrument( Integer.valueOf( intrumentDefinition.getSecurity().getSecurityID() ) );
			}else {
				throw new BussinessExceptionManhattan(Util.getMessageFromFile( "msg.mwatch.instrument.notfound") );
			}
		}
		
		return strategyType;
		
	}
	
	public StrategyTypeLeg setInstrumentInfoByName(StrategyTypeLeg strategyTypeLeg) throws BussinessExceptionManhattan, DAOExceptionManhattan{
		
		if (strategyTypeLeg !=null && strategyTypeLeg.getInstrumentByName()!=null && !strategyTypeLeg.getInstrumentByName().isEmpty()) {
			
			SecurityDefinition intrumentDefinition  = lmds.getIntrumentDefinitionBySymbol( strategyTypeLeg.getInstrumentByName().trim() );
			if ( intrumentDefinition != null && intrumentDefinition.getSecurity() != null && intrumentDefinition.getSecurity().getSecurityID() != null ){
				strategyTypeLeg.setInstrument( Integer.valueOf( intrumentDefinition.getSecurity().getSecurityID() ) );
			}else {
				throw new BussinessExceptionManhattan(Util.getMessageFromFile( "msg.mwatch.instrument.notfound") );
			}
		}
		
		return strategyTypeLeg;
		
	}

	public void addInstrument(ActionEvent actionEvent) {

		try {
			
			if (selectStrategyTypeInstrument!=null
					&& selectStrategyTypeInstrument.getInstrumentByName()!=null 
					&& !selectStrategyTypeInstrument.getInstrumentByName().isEmpty()) {
				
				setInstrumentInfoByName(selectStrategyTypeInstrument);
				
				List<Market> listTemp = marketWhatchTabs.get(indexTabActive).getMarkets();

				boolean isAllowed = true;
	
				for (Market market : listTemp) {
					if (market.getStrategyType().getId() == null
							&& (market.getStrategyType().getInstrumentNameById()).equals(selectStrategyTypeInstrument.getInstrumentByName().trim())) {
						addMsgValidationWarn("", Util.getMessageFromFile( "msg.mwatch.instrument.already.exist" ));
						isAllowed = false;
					}
				}
	
				if (isAllowed) {					
    					
					ReceiveSynthetic synthetic = new ReceiveSynthetic();
					List<ReceiveSymbolSyntheticItem> syntheticList = new ArrayList<ReceiveSymbolSyntheticItem>();
					ReceiveSymbolSyntheticItem syntheticItem = new ReceiveSymbolSyntheticItem();
					syntheticItem.setSymbol(selectStrategyTypeInstrument.getInstrumentByName());
					syntheticItem.setLegSeq(0);					
					syntheticList.add(syntheticItem);
					synthetic.setSyntheticList(syntheticList);
					
					facadeService.subscribe(synthetic);
					Market market = this.marketWatchFacade.populateMarketVO(this.selectStrategyTypeInstrument);
					market.setTabViewId(this.marketWhatchTabs.get(this.indexTabActive).getId());						
					market.setId(getLastMarketIdValid(this.marketWhatchTabs.get(this.indexTabActive).getMarkets()));
					
					this.marketWhatchTabs.get(this.indexTabActive).getMarkets().add(market);				
					this.strategyByTabsUnSave.add(this.marketWatchFacade.populateStrategyByTab(this.selectStrategyTypeInstrument, this.marketWhatchTabs.get(this.indexTabActive)));
					refresh();
				}
			} else {
				addMsgValidationError(Util.getMessageFromFile( "msg.mwatch.instrument.required" ));
				addValidationBorder("componentTab:componentTabMain:formInstrumentWatch:txtMarketWhatchInstrument");
			}
			
		} catch (DAOExceptionManhattan e) {

			logError(e.getMessage());
			addMsgValidationError(e.getMessage());
		}catch (BussinessExceptionManhattan e) {

			logError(e.getMessage());
			addMsgValidationError(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			
			logError(e.getMessage());
			
			addMsgValidationError(Util.getMessageFromFile( "msg.mwatch.instrument.error.add") );
		}
	}
	
	private Long getLastMarketIdValid(List<Market> marketList){
		Long marketId = 0L;
		if ( marketList!=null && !marketList.isEmpty() ) {
			for (Market marketAlreadyOnList : this.marketWhatchTabs.get(this.indexTabActive).getMarkets()) {
				if ( marketAlreadyOnList.getId() >= marketId ) {
					marketId = marketAlreadyOnList.getId();
					marketId++;
				}
			}
		}
		return marketId;
	}

	public void addSyntetic(ActionEvent actionEvent) {
		try {
			
			
			for (StrategyTypeLeg strategyTypeLeg : selectStrategyType.getStrategyTypeLegList()) {
				setInstrumentInfoByName(strategyTypeLeg);
			}
			
			List<Market> listTemp = this.marketWhatchTabs.get(indexTabActive).getMarkets();
			boolean isAllowed = true;
			
			if (null != idSelectMarket && !"0".equals(idSelectMarket.trim())) {
				for (Market market : listTemp) {
					if (market.getStrategyType().getStrategyTypeLegList()!=null && !market.getStrategyType().getStrategyTypeLegList().isEmpty()
							&& market.getStrategyType().getStrategyTypeLegList().size() == selectStrategyType.getStrategyTypeLegList().size()
							&& market.getStrategyType().getStrategyCode().equals(selectStrategyType.getStrategyCode())) {
						
						int qtdEquals = 0;
						
						for (StrategyTypeLeg strategyTypeLeg : market.getStrategyType().getStrategyTypeLegList()) {
							
							for (StrategyTypeLeg strategyTypeLegSelected : selectStrategyType.getStrategyTypeLegList()) {
								if (strategyTypeLeg.getInstrumentNameById().equalsIgnoreCase(strategyTypeLegSelected.getInstrumentByName())) {
									qtdEquals +=1;
								}
							}							
						}
						if (qtdEquals == selectStrategyType.getStrategyTypeLegList().size()) {
							addMsgValidationWarn("", Util.getMessageFromFile( "msg.mwatch.synthetic.already.exist" ));
							isAllowed = false;
							break;
						}
					}
				}

			} else {
				isAllowed = false;
				addMsgValidationWarn("", Util.getMessageFromFile( "msg.mwatch.synthetic.required"));
			}
			if (isAllowed) {
				

				ReceiveSynthetic synthetic = new ReceiveSynthetic();
				List<ReceiveSymbolSyntheticItem> syntheticList = new ArrayList<ReceiveSymbolSyntheticItem>();
				
				for (int i = 0; i < selectStrategyType.getStrategyTypeLegList().size(); i++) {
					ReceiveSymbolSyntheticItem syntheticItem = new ReceiveSymbolSyntheticItem();
					syntheticItem.setSymbol(selectStrategyType.getStrategyTypeLegList().get(i).getInstrumentByName());
					syntheticItem.setLegSeq(i);
					if (selectStrategyType.getStrategyTypeLegList().get(i).getDefaultSide()!=null) {
						syntheticItem.setSide(SideEnum.fromValue(selectStrategyType.getStrategyTypeLegList().get(i).getDefaultSide()));
					}					
					syntheticList.add(syntheticItem);
				}
				if (selectStrategyType.getStrategyCode()!=null) {
					synthetic.setStrategyType(StrategyTypeEnum.fromValue(selectStrategyType.getStrategyCode()));
				}
				
				synthetic.setSyntheticList(syntheticList);
								
				facadeService.subscribe(synthetic);
				
				Market market = marketWatchFacade.populateMarketVO(selectStrategyType);
				market.setTabViewId(this.marketWhatchTabs.get(this.indexTabActive).getId());
				
				market.setId(getLastMarketIdValid(this.marketWhatchTabs.get(this.indexTabActive).getMarkets()));
				
				this.marketWhatchTabs.get(indexTabActive).getMarkets().add(market);
				strategyByTabsUnSave.add(marketWatchFacade.populateStrategyByTab(selectStrategyType, this.marketWhatchTabs.get(indexTabActive)));
				selectStrategyType = new StrategyType();
				refresh();
				hideDialog("dlgStrategyParametersMarketAddContract");
			}

		} catch (DAOExceptionManhattan e) {

			logError(e.getMessage());
			addMsgValidationError(e.getMessage());
		}catch (BussinessExceptionManhattan e) {

			logError(e.getMessage());
			addMsgValidationError(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			
			logError(e.getMessage());
			
			addMsgValidationError(Util.getMessageFromFile( "msg.mwatch.instrument.error.add") );
		}

	}

	public void addTabMarketPerUser(ActionEvent actionEvent) {
		if (null != marketWhatchTab.getDescription() && !"".equals(marketWhatchTab.getDescription().trim())) {
			marketWhatchTab.setLogin(user.getLogin());
			if (null != marketWhatchTabs) {	
				//Nao valida, poderao ser inseridos abas com o mesmo nome e o ID.
				long newId = marketWhatchTabs.size() + 1;
				marketWhatchTab.setId(newId);
				marketWhatchTab.setSaved(false);
				marketWhatchTabs.add(marketWhatchTab);
				marketWhatchTab = new MarketWhatchTab();
				hideDialog("dlgMarketTabStrategy");
			}
		}else {
			addMsgValidationError(Util.getMessageFromFile( "msg.mwatch.tab.required" ));			
			addValidationBorder( "componentStrategy:formMarketWatchAddTab:txtTabName" );
		}
	}

	public void onTabCloseMarket(TabCloseEvent event) {

		String id = event.getTab().getTitleStyleClass();
		if (null != marketWhatchTabs) {
			List<MarketWhatchTab> listTemp = marketWhatchTabs;
			for (int i = 0; i < listTemp.size(); i++) {
				MarketWhatchTab tab = listTemp.get(i);				
				if (id.trim().equals(tab.getId().toString())) {
					marketWhatchTabs.remove(i);
					if (indexTabActive!=0) {
						indexTabActive = indexTabActive-1;
					}										
					marketWhatchTabsUnSave.add(tab);
					break;
				}
			}
		}
	}

	public void onTabChange(TabChangeEvent event) {
		TabView tab = (TabView) event.getSource();
		indexTabActive = tab.getIndex();
	}

	public void deleteStrategy(ActionEvent actionEvent) {
		try {
			for (Market mk : marketWhatchTabs.get(indexTabActive).getMarkets()) {
				if (null != selectMarket.getStratagyTabId() && null != selectMarket.getTabViewId()) {
					marketWhatchTabs.get(indexTabActive).getMarkets().remove(selectMarket);
					marketByTabsToDelete.add(selectMarket);
					break;
				} else if (mk.getStrategyType().getId() == selectMarket.getStrategyType().getId()) {
					marketWhatchTabs.get(indexTabActive).getMarkets().remove(selectMarket);
					for (StrategyByTab t : strategyByTabsUnSave) {
						if (t.getTab().getId().equals(marketWhatchTabs.get(indexTabActive).getId())
								&& (t.getStrategyType()!=null && t.getStrategyType().getId() == selectMarket.getStrategyType().getId()))
							strategyByTabsUnSave.remove(t);
						break;
					}
					break;
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			logError(ex.getMessage());
			addMsgValidationError( "", Util.getMessageFromFile( "msg.mwatch.strategy.error.delete" ));
		}
	}

	public void saveSession() {
		try {
			marketWatchFacade.saveSession(marketWhatchTabsUnSave, marketByTabsToDelete, marketWhatchTabs, strategyByTabsUnSave);
			marketWhatchTabs = marketWatchFacade.getWatchTabMarkets(user.getLogin());
			reset();
			
			addMsgValidationSucess( Util.getMessageFromFile( "msg.mwatch.save" ), Util.getMessageFromFile( "msg.mwatch.save" ) );
		} catch (Exception e) {
			addMsgValidationError("", e.getMessage());
		}
		
	}
	
	public List<Account> completeAccount(String name) {
		List<Account> accounts = new ArrayList<Account>();
		try {
			accounts = managerFacade.findListAccountByName(name);
		} catch (DAOExceptionManhattan e) {
			logError(e.getMessage());
		}
		return accounts;
	}
	
	public void verifyDisableButtonsTab(){
				
		//Verifica se a lista esta vazia, devido a mesma poder ja ter sido populada na Thread
		if (marketWhatchTabs==null || marketWhatchTabs.isEmpty()) {			
			
			disableButton = true;
			
			if (marketWhatchTabsUnSave.isEmpty()) {
				disableButtonSave = true;
			}
		}else{
			disableButton = false;
			disableButtonSave = false;
		}
	}
	
	/* ###### Methods to Add Strategy - Copied from ManagerBean ###### */
	
	public void clearStrategyParameters( StrategyReport report ) {
		clearStrategyParametersFields( false, report );
		
		clearBorders( report );
	}
		
	private void clearStrategyParametersFields( boolean onlyStrategyParameters, StrategyReport report ){
		
		this.setCheckAllPO( false );
		this.otherTabOrderIndex = 100;
		
		for ( LegStrategyReport leg : report.getLegStrategyList() ) {
			
			
			leg.setTotalQuantity( null );
			leg.setClip( null );
			leg.setRestingRank( null );
			leg.setDiv1( null );
			leg.setPassiveLeg( false );
			
			protectQty = false;
			protectDiv1 = false;
		}	
		
		Double aggressivenessDefault = Double.valueOf(com.ubs.manhatthan.manager.utils.Util.getPropertyFromFile("manhattan.manager.aggressiveness.defaulvalue"));
		Integer restingLevelDefault = Integer.valueOf(com.ubs.manhatthan.manager.utils.Util.getPropertyFromFile("manhattan.manager.restinglevel.defaulvalue"));
		String endDefaultTime = com.ubs.manhatthan.manager.utils.Util.getPropertyFromFile("manhattan.manager.endtimestrategy.defaultvalue");
		String startDefaultTime = com.ubs.manhatthan.manager.utils.Util.getPropertyFromFile("manhattan.manager.starttimestrategy.defaultvalue");
				
		if ( !onlyStrategyParameters ){
			report.setRestingLevel(restingLevelDefault);
			report.setRiskLevel(Constant.DEFAULT.RISK_LEVEL);
			report.setAgressiviness(aggressivenessDefault);
			report.setTarget(null);
			report.setTargetWarning(false);
			report.setTargetDif(null);
			report.setMarket(null);
			report.setStartTime(Util.convertDateHourNowPattern(startDefaultTime));
			report.setStartTimeText(Util.convertDateHourNowPattern(startDefaultTime));
			report.setEndTimeText(Util.convertDateHourNowPattern(endDefaultTime));
			report.setStartPaused(false);
		}
	}
	
	public void changeSideFromDoubleClick( StrategyReport report ) {
//		No fim, nao precisou do parametro vindo do remoteCommand,
//		mas fica como modelo quando precisar
//		FacesContext context = FacesContext.getCurrentInstance();
//	    Map map = context.getExternalContext().getRequestParameterMap();
//	    Object object = map.get("index" );
		
		for (LegStrategyReport leg : report.getLegStrategyList() ) {
			
			if ( SideEnum.BUY.getCode().equals( leg.getSide() ) ){
				leg.setSide( SideEnum.SELL.getCode() );
			} else {
				leg.setSide( SideEnum.BUY.getCode() );
			}
		}
	}
	
	public void changeComboStrategy(ValueChangeEvent event) {
		String tw = (String) event.getNewValue();
		idSelectStrategyType = tw;
		strategyReport = initInfoStrategyReport(idSelectStrategyType);
		refresh();
	}
	
	private StrategyReport initInfoStrategyReport(String value) {
		StrategyReport report = new StrategyReport();
		
		Double aggressivenessDefault = Double.valueOf(com.ubs.manhatthan.manager.utils.Util.getPropertyFromFile("manhattan.manager.aggressiveness.defaulvalue"));
		Integer restingLevelDefault = Integer.valueOf(com.ubs.manhatthan.manager.utils.Util.getPropertyFromFile("manhattan.manager.restinglevel.defaulvalue"));
		String endTimeText = com.ubs.manhatthan.manager.utils.Util.getPropertyFromFile("manhattan.manager.endtimestrategy.defaultvalue");
		String startTimeText = com.ubs.manhatthan.manager.utils.Util.getPropertyFromFile("manhattan.manager.starttimestrategy.defaultvalue");
		
		report.setRestingLevel(restingLevelDefault);
		report.setRiskLevel( Constant.DEFAULT.RISK_LEVEL );
		report.setAgressiviness(aggressivenessDefault);
		report.setEndTimeText(Util.convertDateHourNowPattern(endTimeText));
		report.setStartTimeText(Util.convertDateHourNowPattern(startTimeText));
		for (StrategyType strategyType : strategyTypes) {
			if (Long.valueOf(value).equals(strategyType.getId())) {
				selectStrategyType = strategyType;
				report.setStrategyType(selectStrategyType);
				if (null != selectStrategyType.getStrategyTypeLegList()) {
					report.setLegStrategyList(new ArrayList<LegStrategyReport>());
					for (StrategyTypeLeg typeLeg : selectStrategyType.getStrategyTypeLegList()) {
						LegStrategyReport legStrategyReport = new LegStrategyReport();
						BeanUtils.copyProperties(typeLeg, legStrategyReport);
						legStrategyReport.setSide(typeLeg.getDefaultSide());
						report.getLegStrategyList().add(legStrategyReport);
					}
				}
				break;
			}
		}
		return report;
	}
	
	public void checkAll(StrategyReport report) {
		for (LegStrategyReport leg : report.getLegStrategyList()) {
			leg.setPassiveLeg(checkAllPO);
		}
	}
	
	private Integer columnGeneratrix(StrategyReport report, Integer columnIndex, Integer rowIndex) {
		otherTabOrderIndex = 2 + rowIndex + (report.getLegStrategyList().size() * columnIndex);
		return otherTabOrderIndex;
	}
	
	public void getBusinessDay( StrategyReport report ){
		
		if ( report == null || report.getLegStrategyList() == null || report.getLegStrategyList().isEmpty() )
			return;
		
		for (LegStrategyReport leg : report.getLegStrategyList()) {
			
			if ( StringUtils.isNotBlank( leg.getContract() ) ){
				SecurityDefinition security = LmdsCache.getSecurityDefinitionBySymbol( leg.getContract() );
				
				if ( security == null || security.getBusinessDays() == null )
					return;
				
				leg.setDuration( security.getBusinessDays() );
			}
		}
	}
	
	public void changeSellBuyByQuantity( String indexParam, StrategyReport report ) {
		
		if ( StringUtils.isNotBlank( indexParam ) ){
		
			int lastIndexOfLegList = report.getLegStrategyList().size() -1;
			
			Integer intIndexParam = Integer.valueOf( indexParam );
			
			if ( lastIndexOfLegList == intIndexParam ){
			
//				Define o ultimo objeto da lista, se for negativo, considera o modulo
//				e ajusta o side para Sell, caso contrario define o side como buy
				if ( null != report.getLegStrategyList().get( lastIndexOfLegList ).getTotalQuantity() &&
						report.getLegStrategyList().get( lastIndexOfLegList ).getTotalQuantity() < 0) {
					
					Long positivo = Math.abs( report.getLegStrategyList().get( lastIndexOfLegList ).getTotalQuantity() );
					report.getLegStrategyList().get( lastIndexOfLegList ).setTotalQuantity(positivo);
					
					report.getLegStrategyList().get( lastIndexOfLegList ).setSide(SideEnum.SELL.getCode());
				} else { 
					if ( null != report.getLegStrategyList().get( lastIndexOfLegList ).getTotalQuantity() ){
							report.getLegStrategyList().get( lastIndexOfLegList ).setSide(SideEnum.BUY.getCode());
					}
				}
				
//				ajusta os buy/sell de todas as legs baseado na ultima
				changeSideByLastLeg( report.getLegStrategyList().get( lastIndexOfLegList ).getSide(),
			             			 lastIndexOfLegList, report );
			} else {
				if ( report.getLegStrategyList().get( intIndexParam ).getTotalQuantity() != null ){
					report.getLegStrategyList().get( intIndexParam ).setTotalQuantity( 
								   Math.abs( report.getLegStrategyList().get( intIndexParam ).getTotalQuantity() ) );
				}
			}

			for (LegStrategyReport legItem : report.getLegStrategyList() ) {
				
				if ( legItem.getTotalQuantity() != null ){
					protectQty = false;
					protectDiv1 = true;
				} else {
					protectQty = false;
					protectDiv1 = false;
				}
			}
		}
		
//		managerEmptyFields();
	}
	
	private void changeSideByLastLeg( Integer lastSide, Integer lastIndexOfLegList, StrategyReport report ){
		
		for (int i = lastIndexOfLegList -1; i >= 0; i--) {
			
			if ( SideEnum.BUY.equals( SideEnum.fromValue( lastSide ) ) ){
				report.getLegStrategyList().get( i ).setSide(SideEnum.SELL.getCode());	
			} else {
				report.getLegStrategyList().get( i ).setSide(SideEnum.BUY.getCode());	
			}
			lastSide = report.getLegStrategyList().get( i ).getSide();
		}
	}
	
	public Integer getOrdenedTabOrder(StrategyReport report, Integer index) {
		otherTabOrderIndex = otherTabOrderIndex + index;
		return otherTabOrderIndex;
	}
	
public void calculateIsOnlyTarget( StrategyReport report) {
		
		try {
			if ( validation( true, report ) ){
				report = managerFacade.calculateValuesStrategyReport(report, true);
			}
		} catch (DAOExceptionManhattan e) {
			e.printStackTrace();
			logError(e.getMessage());
			
			addMsgValidationError(e.getLocalizedMessage());
		} catch (BussinessExceptionManhattan e) {
			e.printStackTrace();
			
			logError(e.getMessage());
			
			addMsgValidationError(e.getLocalizedMessage());
		}

	}
		
	public boolean validation( boolean isOnlyTarget, StrategyReport report ){
		
		clearBorders( report );
		
		boolean validationOK = true;
		
		if ( report == null || report.getLegStrategyList() == null ||
			 report.getLegStrategyList().isEmpty() || report.getLegStrategyList().size() < 2  ){
			
			addMsgValidationError( "", Util.getMessageFromFile( "msg.mwatch.strategy.error.valid.structure" ));
	
			return false;
		}
		
		String idPrefix = getIdPrefix(  );
						
		for (int i = 0; i < report.getLegStrategyList().size(); i++) {
			
			LegStrategyReport leg = report.getLegStrategyList().get( i );
			
			if ( leg.getLegSeq() == null || leg.getSide() == null ){
				addMsgValidationError( "", Util.getMessageFromFile( "msg.mwatch.strategy.error.valid.structure" ));
				return false;
			}
			
			if ( StringUtils.isBlank( leg.getContract() ) ){
				
				String messageDynamic = MessageFormat.format(Util.getMessageFromFile( "msg.mwatch.strategy.error.calculation.contract.required"), (i+1));
				
				addValidationMessage( idPrefix + ":contracts"+i,
										"",
										messageDynamic);
				validationOK = false;
			} else {
				try {
					instrument = facadeService.getInstrument( leg.getContract() );
					
					if ( StringUtils.isBlank( instrument ) ){
						addValidationMessage( idPrefix + ":contracts"+i,
					  			  			  "",
					  			  			Util.getMessageFromFile( "msg.mwatch.strategy.error.calculation.contract.invalid") + leg.getContract() );
						validationOK = false;
					}
					
				} catch (DAOExceptionManhattan e) {
					e.printStackTrace();
				}
			}
			
		}
			
		if( !isOnlyTarget ){
			
			if ( report.getTarget() == null ){
				addValidationMessage( idPrefix + ":target",
									  "",
									  Util.getMessageFromFile( "msg.mwatch.strategy.error.calculation.target.required") );
				validationOK = false;
				
			}
			
			Integer lastIndex = report.getLegStrategyList().size() -1;
			
			LegStrategyReport lastLeg = report.getLegStrategyList().get( lastIndex );
			
			if ( lastLeg.getTotalQuantity() == null && lastLeg.getDiv1() == null ){
				addValidationBorder( idPrefix + ":dv"+lastIndex );
				
				addValidationMessage( idPrefix + ":qty"+lastIndex,
									  "",
									  Util.getMessageFromFile( "msg.mwatch.strategy.error.calculation.qty.div1.required") );
				
				validationOK = false;
			}
		}
		
		return validationOK;
	}

	private String getIdPrefix(){		
		return "componentStrategyParametersMarket:formMarketAddStrategy";
	}
	
	public void calculateStrategyValues( StrategyReport report) {
		
		try {
			
			if ( validation( false, report ) ){
				report = managerFacade.calculateValuesStrategyReport(report, false);
			}			
		} catch (DAOExceptionManhattan e) {		
			e.printStackTrace();
			
			logError(e.getMessage());
			
			addMsgValidationError(e.getLocalizedMessage());
		} catch (BussinessExceptionManhattan e) {
			e.printStackTrace();
			
			logError(e.getMessage());
			
			addMsgValidationError(e.getLocalizedMessage());
		}
	}
	
	public void clearBorders( StrategyReport report ) {
		
		if ( report == null )
			return;
		
		
		String idPrefix = getIdPrefix();
		
		removeValidationBorder( idPrefix + ":accName" );
		removeValidationBorder( idPrefix + ":aggressiveness" );
		removeValidationBorder( idPrefix + ":txtStart" );
		removeValidationBorder( idPrefix + ":txtEnd" );
		removeValidationBorder( idPrefix + ":createStrategyPaused" );
		removeValidationBorder( idPrefix + ":target" );
		
		if ( report.getLegStrategyList() == null || report.getLegStrategyList().isEmpty() )
			return;
		
		for (int i = 0; i < report.getLegStrategyList().size(); i++) {
			removeValidationBorder( idPrefix + ":clip"+i );
			removeValidationBorder( idPrefix + ":contracts"+i );
		}
		
		removeValidationBorder( idPrefix + ":qty" + ( report.getLegStrategyList().size() -1 ) );
		removeValidationBorder( idPrefix + ":dv" + ( report.getLegStrategyList().size() -1 ) );
	}
	
	public void createStrategy( StrategyReport report) {
		try {			
			if ( validateStrategyCreation( report) ){
				
				for (int i = 0; i < report.getLegStrategyList().size(); i++) {
					report.getLegStrategyList().get(i).setAccount(selectAccount);
				}
	
				managerFacade.createStrategyReport(report, user.getRequestId());

				clearStrategyParametersFields( false, report );
				
				hideDialog("dlgStrategyParametersMarket");
			}
		} catch (BussinessExceptionManhattan e) {
			addMsgValidationError(e.getMessage());
			
			logError(e.getMessage());
		} catch (DAOExceptionManhattan e) {
			addMsgValidationError(e.getMessage());
			
			logError(e.getMessage());
		}
	}
	
	public boolean validateStrategyCreation( StrategyReport report ){
		
		boolean validationOK = true;
		
		validationOK = validation( false, report );
		
		String idPrefix = getIdPrefix( );
		
		for (int i = 0; i < report.getLegStrategyList().size(); i++) {
			LegStrategyReport leg = report.getLegStrategyList().get( i );
			
			if ( leg.getClip() == null ){
				String messageDynamic = MessageFormat.format(Util.getMessageFromFile( "msg.mwatch.strategy.error.calculation.clip.required"), (i+1));
				addValidationMessage( idPrefix + ":clip"+i,
									   "",
									   messageDynamic );
				validationOK = false;
			} else 
				if ( leg.getClip() < 1 ){
					String messageDynamic = MessageFormat.format(Util.getMessageFromFile( "msg.mwatch.strategy.error.calculation.clip.positive"), (i+1));
					addValidationMessage( idPrefix + ":clip"+i,
							  			  "",
							  			messageDynamic );
					validationOK = false;
				} else {
					if ( leg.getTotalQuantity() == null ||
						 leg.getClip() > leg.getTotalQuantity() ){
						String messageDynamic = MessageFormat.format(Util.getMessageFromFile( "msg.mwatch.strategy.error.calculation.clip.less.quantity"), (i+1));
						addValidationMessage( idPrefix + ":clip"+i,
					  			  "",
					  			messageDynamic );
						validationOK = false;	
					}
				}
		}
		
		if ( selectAccount == null ){
			addValidationMessage( idPrefix + ":accName",
											 "",
											 Util.getMessageFromFile( "msg.mwatch.strategy.error.calculation.account.required") );
			validationOK = false;
		}
		if ( report.getRestingLevel() == null ){
			addValidationMessage( idPrefix + ":bookLevel_input",
					  			  "",
					  			Util.getMessageFromFile( "msg.mwatch.strategy.error.calculation.booklvl.required") );
			validationOK = false;
		}
		if ( report.getAgressiviness()== null ){
			addValidationMessage( idPrefix + ":aggressiveness",
								  "",
								  Util.getMessageFromFile( "msg.mwatch.strategy.error.calculation.aggressiveness.required") );
			
			validationOK = false;
		} else
			if ( report.getAgressiviness() < 0 || report.getAgressiviness() > 100 ){
				addValidationMessage( idPrefix + ":aggressiveness",
									  "",
									  Util.getMessageFromFile( "msg.mwatch.strategy.error.calculation.aggressiveness.valid.value" ));
	
				validationOK = false;
			}
		
		if ( report.getStartPaused() == false && 
			 ( report.getEndTimeText() == null || report.getStartTimeText() == null ) ){
			
			addValidationMessage( idPrefix + ":txtStart",
							      "",
							      Util.getMessageFromFile( "msg.mwatch.strategy.error.calculation.time.required") );
			
			addValidationBorder( idPrefix + ":txtEnd" );
			addValidationBorder( idPrefix + ":createStrategyPaused" );
			
			validationOK = false;
		}
		
		
		if ( report.getEndTimeText() != null && report.getStartTimeText() != null ) {
			if ( report.getStartTimeText().compareTo( report.getEndTimeText() ) > 0 ){
				addValidationMessage( idPrefix + ":txtStart",
								      "",
								      Util.getMessageFromFile( "msg.mwatch.strategy.error.calculation.time.valid") );
	
				addValidationBorder( idPrefix + ":txtEnd" );
			}
		}
		
		return validationOK;
	}
	
	public void loadFormAddStrategy(Market market) {
		
		try {
			if (market!=null) {
				this.setSelectMarket(market);

				if (selectMarket.getStrategyType()!=null && selectMarket.getStrategyType().getStrategyCode()!=null) {
					if (strategyTypes!=null && !strategyTypes.isEmpty()) {
						for (StrategyType strategyType : strategyTypes) {
							if (strategyType.getStrategyCode()!=null && strategyType.getStrategyCode().equals(selectMarket.getStrategyType().getStrategyCode())) {
								selectStrategyType = strategyType;
								disableStrategyType = true;
							}
						}
					}
				}else {
					selectStrategyType = strategyTypes.get(0);
				}
			}		
			
			idSelectStrategyType = selectStrategyType.getId().toString();
			strategyReport = initInfoStrategyReport(idSelectStrategyType);			
			
			for (StrategyTypeLeg strategyTypeLeg : selectMarket.getStrategyType().getStrategyTypeLegList()) {			
				for (LegStrategyReport legStrategyReport : strategyReport.getLegStrategyList()) {
					if (legStrategyReport.getContract() == null || legStrategyReport.getContract().isEmpty() ) {
						legStrategyReport.setContract(strategyTypeLeg.getInstrumentNameById());
						legStrategyReport.setInstrument(strategyTypeLeg.getInstrument().longValue());
						legStrategyReport.setSide(strategyTypeLeg.getDefaultSide());
						break;
					}
				}
			}
			selectAccount = null;
			
			getBusinessDay(strategyReport);
		}  catch (Exception e) {
			addMsgValidationError(e.getMessage());
			
			logError(e.getMessage());
		}
	}
	
	public void changeSellBuyByDiv( String indexParam, StrategyReport report ) {
		
		if ( StringUtils.isNotBlank( indexParam ) ){
			
			int lastIndexOfLegList = report.getLegStrategyList().size() -1;
			
			Integer intIndexParam = Integer.valueOf( indexParam );
			
			if ( lastIndexOfLegList == intIndexParam ){
				
//				Define o ultimo objeto da lista, se for negativo, considera o modulo
//				e ajusta o side para Sell, caso contrario define o side como buy
				if ( null != report.getLegStrategyList().get( lastIndexOfLegList ).getDiv1() &&
						report.getLegStrategyList().get( lastIndexOfLegList ).getDiv1() < 0) {
					
					double positivo = Math.abs( report.getLegStrategyList().get( lastIndexOfLegList ).getDiv1() );
					report.getLegStrategyList().get( lastIndexOfLegList ).setDiv1(positivo);
					
					report.getLegStrategyList().get( lastIndexOfLegList ).setSide(SideEnum.SELL.getCode());

				} else { 
					if ( null != report.getLegStrategyList().get( lastIndexOfLegList ).getDiv1() ){
						report.getLegStrategyList().get( lastIndexOfLegList ).setSide(SideEnum.BUY.getCode());
					}
				}
//				ajusta os buy/sell de todas as legs baseado na ultima
					changeSideByLastLeg( report.getLegStrategyList().get( lastIndexOfLegList ).getSide(),
										 lastIndexOfLegList, report );				
			} else {
				if ( report.getLegStrategyList().get( intIndexParam ).getDiv1() != null ){
					report.getLegStrategyList().get( intIndexParam ).setDiv1( 
								   Math.abs( report.getLegStrategyList().get( intIndexParam ).getDiv1() ) );
				}
			}
			
			for (LegStrategyReport legItem : report.getLegStrategyList() ) {
				
				if ( legItem.getDiv1() != null ){
					protectQty = true;
					protectDiv1 = false;
					break;
				} else {
					protectQty = false;
					protectDiv1 = false;
				}
			}
		}
		
//		managerEmptyFields();
	}
	
	public Integer getColumnGeneratrix(StrategyReport report, Integer columnIndex, Integer rowIndex) {
		return columnGeneratrix(report, columnIndex, rowIndex); 		
	}
	
	/* ###### Methods to Add Strategy - Copied from ManagerBean ###### */
	
	public boolean verifyAccess(){
		return user.getCanViewMarketWhatch();
	}

	public Account getSelectedAccount() {
		return selectedAccount;
	}

	public void setSelectedAccount(Account selectedAccount) {
		this.selectedAccount = selectedAccount;
	}

	public MarketWhatchTab getMarketWhatchTab() {
		return marketWhatchTab;
	}

	public void setMarketWhatchTab(MarketWhatchTab marketWhatchTab) {
		this.marketWhatchTab = marketWhatchTab;
	}

	public List<MarketWhatchTab> getMarketWhatchTabs() {
		return marketWhatchTabs;
	}

	public void setMarketWhatchTabs(List<MarketWhatchTab> marketWhatchTabs) {
		this.marketWhatchTabs = marketWhatchTabs;
	}

	public String getIdSelectMarket() {
		return idSelectMarket;
	}

	public void setIdSelectMarket(String idSelectMarket) {
		this.idSelectMarket = idSelectMarket;
	}

	public TabView getTabView() {
		return tabView;
	}

	public void setTabView(TabView tabView) {
		this.tabView = tabView;
	}

	public int getIndexTabActive() {
		return indexTabActive;
	}

	public void setIndexTabActive(int indexTabActive) {
		this.indexTabActive = indexTabActive;
	}

	public boolean isDisableButton() {
		return disableButton;
	}
	
	public void setDisableButton(boolean disableButton) {
		this.disableButton = disableButton;
	}
	
	public boolean isDisableButtonSave() {
		return disableButtonSave;
	}

	public void setDisableButtonSave(boolean disableButtonSave) {
		this.disableButtonSave = disableButtonSave;
	}

	public StrategyType getSelectStrategyType() {
		return selectStrategyType;
	}

	public void setSelectStrategyType(StrategyType selectStrategyType) {
		this.selectStrategyType = selectStrategyType;
	}

	public Account getSelectAccount() {
		return selectAccount;
	}

	public void setSelectAccount(Account selectAccount) {
		this.selectAccount = selectAccount;
	}

	public void setMarketWatchFacade(MarketWatchFacade marketWatchFacade) {
		this.marketWatchFacade = marketWatchFacade;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public StrategyType getSelectStrategyTypeInstrument() {
		return selectStrategyTypeInstrument;
	}

	public void setSelectStrategyTypeInstrument(StrategyType selectStrategyTypeInstrument) {
		this.selectStrategyTypeInstrument = selectStrategyTypeInstrument;
	}

	public List<StrategyByTab> getStrategyByTabsUnSave() {
		return strategyByTabsUnSave;
	}

	public void setStrategyByTabsUnSave(List<StrategyByTab> strategyByTabsUnSave) {
		this.strategyByTabsUnSave = strategyByTabsUnSave;
	}

	public List<Market> getMarketByTabsToDelete() {
		return marketByTabsToDelete;
	}

	public void setMarketByTabsToDelete(List<Market> marketByTabsToDelete) {
		this.marketByTabsToDelete = marketByTabsToDelete;
	}

	public Market getSelectMarket() {
		return selectMarket;
	}

	public void setSelectMarket(Market selectMarket) {
		this.selectMarket = selectMarket;
	}

	public List<MarketWhatchTab> getMarketWhatchTabsUnSave() {
		return marketWhatchTabsUnSave;
	}

	public void setMarketWhatchTabsUnSave(List<MarketWhatchTab> marketWhatchTabsUnSave) {
		this.marketWhatchTabsUnSave = marketWhatchTabsUnSave;
	}

	public boolean isCheckAllPO() {
		return checkAllPO;
	}

	public void setCheckAllPO(boolean checkAllPO) {
		this.checkAllPO = checkAllPO;
	}

	public boolean isProtectQty() {
		return protectQty;
	}

	public void setProtectQty(boolean protectQty) {
		this.protectQty = protectQty;
	}

	public boolean isProtectDiv1() {
		return protectDiv1;
	}

	public void setProtectDiv1(boolean protectDiv1) {
		this.protectDiv1 = protectDiv1;
	}

	public Integer getOtherTabOrderIndex() {
		return otherTabOrderIndex;
	}
	
	public Integer getOtherTabOrder() {
		return otherTabOrderIndex++;
	}

	public void setOtherTabOrderIndex(Integer otherTabOrderIndex) {
		this.otherTabOrderIndex = otherTabOrderIndex;
	}

	public StrategyReport getStrategyReport() {
		return strategyReport;
	}

	public void setStrategyReport(StrategyReport strategyReport) {
		this.strategyReport = strategyReport;
	}

	public String getIdSelectStrategyType() {
		return idSelectStrategyType;
	}

	public void setIdSelectStrategyType(String idSelectStrategyType) {
		this.idSelectStrategyType = idSelectStrategyType;
	}

	public String getInstrument() {
		return instrument;
	}

	public void setInstrument(String instrument) {
		this.instrument = instrument;
	}

	public Boolean getDisableStrategyType() {
		return disableStrategyType;
	}

	public void setDisableStrategyType(Boolean disableStrategyType) {
		this.disableStrategyType = disableStrategyType;
	}

	public boolean isOnlyMarket() {
		return isOnlyMarket;
	}

	public void setOnlyMarket(boolean isOnlyMarket) {
		this.isOnlyMarket = isOnlyMarket;
	}
}