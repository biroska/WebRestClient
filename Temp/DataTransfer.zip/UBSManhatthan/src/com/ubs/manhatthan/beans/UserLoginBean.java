package com.ubs.manhatthan.beans;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.xml.bind.JAXBElement;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.common.enuns.SecurityActionEnum;
import com.ubs.manhatthan.kerberos.methods.ISecurityGatewayService;
import com.ubs.manhatthan.kerberos.methods.SgServiceHttp_SIT;
import com.ubs.manhatthan.kerberos.methods.SgServiceHttp_UAT;
import com.ubs.manhatthan.kerberos.ws.model.ArrayOfMenuDTO;
import com.ubs.manhatthan.kerberos.ws.model.AuthenticatedUserDTO;
import com.ubs.manhatthan.kerberos.ws.model.MenuDTO;
import com.ubs.manhatthan.kerberos.ws.model.UserMenusDTO;
import com.ubs.manhatthan.manager.logger.ApplicationLogger;
import com.ubs.manhatthan.manager.utils.Constant;
import com.ubs.manhatthan.manager.utils.Util;


@Component("userLoginBean")
@Scope("session")
public class UserLoginBean extends UBSCommonBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5217352473575716096L;
	
	Thread threadMarketWhatchForPersistence;
	
	Thread threadManagerForPersistence;	
	
	ISecurityGatewayService proxyHttp;
	
	private SgServiceHttp_SIT sgHttpSit;
	private SgServiceHttp_UAT sgHttpUat;	
	//private SgServiceHttp_PRD sgHttpPrd; 
	
	private String environment = com.ubs.manhatthan.manager.utils.Util.getPropertyFromFile( "manhattan.kerberos.enviroment" );
	
	public final String APP_KEY = Util.getPropertyFromFile("manhattan.kerberos.appKey");
	
	@Autowired
	SubscriberMarketWhacthBean subscriberMarketWhatchBean;

	@Autowired
	SubscriberManagerBean subscriberManagerBean;
	
	@Autowired
	ManagerBean managerBean;

	private User userLogged;

	private boolean loginUserinKerberos() {
        AuthenticatedUserDTO authenticatedUserDTO = null;
        
        try {
               authenticatedUserDTO = proxyHttp.authenticateUser(APP_KEY, user.getLogin(), user.getPassword());
        } catch (Exception ex) {
               ApplicationLogger.logDebug("Error on authentication user", ex);
               return false;
        }
        
        if (authenticatedUserDTO.isStatusSuccess()) {
               FacesContext fc = FacesContext.getCurrentInstance();
               String sessionId = fc.getExternalContext().getSessionId(false);
               user.setSessionId(sessionId);
               user.setRequestId(Util.getNewRequestId());
               
               return true;
        } else {
               return false;
        }

	}
	
	public String loginAdmin() {
		
		try {
			if (Constant.ENVIRONMENT.SIT.equals(environment)) {
							
				if (sgHttpSit == null) {
					sgHttpSit = new SgServiceHttp_SIT();
				}
				proxyHttp = sgHttpSit.getBasicHttpBindingISecurityGatewayService();	
			}else if (Constant.ENVIRONMENT.UAT.equals(environment)) {
				
				if (sgHttpUat == null) {
					sgHttpUat = new SgServiceHttp_UAT();
				}
				proxyHttp = sgHttpUat.getBasicHttpBindingISecurityGatewayService();	
			}/*else if (Constant.ENVIRONMENT.PRD.equals(environment)) {
				proxyHttp = sgHttpPrd.getBasicHttpBindingISecurityGatewayService();	
			}*/
		} catch (Exception e1) {
			addMsgValidationWarn(Util.getMessageFromFile( "msg.login.error.connect.kerberos"), "");
			e1.printStackTrace();
			return "";
		}
		
		boolean isUserLogged = loginUserinKerberos();
		
		if (!isUserLogged) {
			addMsgValidationWarn(Util.getMessageFromFile( "msg.login.error.invalid.credentials"), "");
			
			return "";
		} else {
			user.setProfile(user.getLogin());
			user.setLogged(true);
			
			userLogged = new User();			
			BeanUtils.copyProperties(user, userLogged);
			
			List<SecurityActionEnum> securityActions = new ArrayList<SecurityActionEnum>();
			
//			--MOCK
//			securityActions.add(SecurityActionEnum.ADMIN_ENGINE_VIEW);
//			securityActions.add(SecurityActionEnum.ADMIN_ENGINE_MANAGEMENT);
//			securityActions.add(SecurityActionEnum.ADMIN_UMDF_VIEW);
//			securityActions.add(SecurityActionEnum.ADMIN_UMDF_MANAGEMENT);
//			securityActions.add(SecurityActionEnum.ADMIN_TCP_RECOVERY_VIEW);
//			securityActions.add(SecurityActionEnum.ADMIN_TCP_RECOVERY_MANAGEMENT);
//			securityActions.add(SecurityActionEnum.ADMIN_ORDER_ENTRY_VIEW);
//			securityActions.add(SecurityActionEnum.ADMIN_ORDER_ENTRY_MANAGEMENT);
//			securityActions.add(SecurityActionEnum.ADMIN_ENGINE_MANAGEMENT);
//			securityActions.add(SecurityActionEnum.ADMIN_ACCOUNT_VIEW);
//			securityActions.add(SecurityActionEnum.ADMIN_ACCOUNT_MANAGEMENT);
//			userLogged.setSecurityActions(securityActions);
//			user.setSecurityActions(securityActions);
//			--MOCK
			
			try{
				UserMenusDTO userMenusDTO = proxyHttp.getUserMenus(APP_KEY, user.getLogin());
				JAXBElement<ArrayOfMenuDTO> arrayMenu =  userMenusDTO.getMenusDTO();
				
				if (arrayMenu == null || arrayMenu.getValue() == null || arrayMenu.getValue().getMenuDTO().size() == 0) {
					addMsgValidationWarn(Util.getMessageFromFile( "msg.login.error.access.denied"), "");
					return "";
				} else {
					for(MenuDTO dto : arrayMenu.getValue().getMenuDTO()){
						ApplicationLogger.logDebug("ADD function:"+dto.getFunctionName().getValue() +" to user: "+user.getLogin());
						for(SecurityActionEnum enm : SecurityActionEnum.values()){
							if(enm.getDescription().equals(dto.getFunctionName().getValue())){
								securityActions.add(enm);
								break;
							}
						}
					}

					userLogged.setSecurityActions(securityActions);
					user.setSecurityActions(securityActions);
				}
			}catch(Exception e){
				logError(e.getMessage());
				addMsgValidationWarn(Util.getMessageFromFile( "msg.login.error.kerberos"), "");
				return "";
			}
			if(user.getHasAccesToAdmin()){
				return "mainAdmin.xhtml" + UBSCommonBean.forceRedirect();
			}else{
				addMsgValidationWarn(Util.getMessageFromFile( "msg.login.error.access.denied"), "");
				return "";
			}
		}
	}
	
	public String login() {
		
		try {
			if (Constant.ENVIRONMENT.SIT.equals(environment)) {
							
				if (sgHttpSit == null) {
					sgHttpSit = new SgServiceHttp_SIT();
				}
				proxyHttp = sgHttpSit.getBasicHttpBindingISecurityGatewayService();	
			}else if (Constant.ENVIRONMENT.UAT.equals(environment)) {
				
				if (sgHttpUat == null) {
					sgHttpUat = new SgServiceHttp_UAT();
				}
				proxyHttp = sgHttpUat.getBasicHttpBindingISecurityGatewayService();	
			}/*else if (Constant.ENVIRONMENT.PRD.equals(environment)) {
				proxyHttp = sgHttpPrd.getBasicHttpBindingISecurityGatewayService();	
			}*/
		} catch (Exception e1) {
			addMsgValidationWarn(Util.getMessageFromFile( "msg.login.error.connect.kerberos"), "");
			e1.printStackTrace();
			return "";
		}
		
		boolean isUserLogged = loginUserinKerberos();

		if (!isUserLogged) {
			addMsgValidationWarn(Util.getMessageFromFile( "msg.login.error.invalid.credentials"), "");
			return "";
		} else {
			user.setProfile(user.getLogin());
			user.setLogged(true);
			
			userLogged = new User();			
			BeanUtils.copyProperties(user, userLogged);
			
			List<SecurityActionEnum> securityActions = new ArrayList<SecurityActionEnum>();
			
//			--MOCK
//			securityActions.add(SecurityActionEnum.MANAGER_FULL_MANAGEMENT);
//			securityActions.add(SecurityActionEnum.MARKETWHATCH_SELF_MANAGEMENT);
//			userLogged.setSecurityActions(securityActions);
//			user.setSecurityActions(securityActions);
//			startPushSubscriber();
//			--MOCK

			try{
				UserMenusDTO userMenusDTO = proxyHttp.getUserMenus(APP_KEY, user.getLogin());
				JAXBElement<ArrayOfMenuDTO> arrayMenu =  userMenusDTO.getMenusDTO();
				
				if (arrayMenu == null || arrayMenu.getValue() == null || arrayMenu.getValue().getMenuDTO().size() == 0) {
					addMsgValidationWarn(Util.getMessageFromFile( "msg.login.error.access.denied"), "");
					return "";
				} else {
					for(MenuDTO dto : arrayMenu.getValue().getMenuDTO()){
						ApplicationLogger.logDebug("ADD function:"+dto.getFunctionName().getValue() +" to user: "+user.getLogin());
						for(SecurityActionEnum enm : SecurityActionEnum.values()){
							if(enm.getDescription().equals(dto.getFunctionName().getValue())){
								securityActions.add(enm);
								break;
							}
						}
					}

					userLogged.setSecurityActions(securityActions);
					user.setSecurityActions(securityActions);
					startPushSubscriber();
				}
			}catch(Exception e){
				logError(e.getMessage());
				addMsgValidationWarn(Util.getMessageFromFile( "msg.login.error.kerberos"), "");
				return "";
			}
			
			if(user.getHasAccessToTrader()){
				return "main.xhtml" + UBSCommonBean.forceRedirect();
			}else{
				addMsgValidationWarn(Util.getMessageFromFile( "msg.login.error.access.denied"), "");
				return "";
			}
		}
	}

	private void logoutUser() {
		user.setLogged(false);
		user.setLogin("");
		user.setPassword("");
		
		if (Util.getPropertyFromFile("manhattan.subscriber.marketwatch").equals("1")) {
			subscriberMarketWhatchBean.shutdown();
			threadMarketWhatchForPersistence = null;
		}
		
		if (Util.getPropertyFromFile("manhattan.subscriber.manager").equals("1")) {
			subscriberManagerBean.shutdown();
			threadManagerForPersistence = null;
		}
		
		if (managerBean != null && managerBean.getStrategyReports() != null) {
			managerBean.getStrategyReports().clear();
		}
	}
			
	public String logoutAdmin() {
		logoutUser();
		
		return "loginAdmin.xhtml?logout=true&faces-redirect=true&includeViewParams=true";
	}

	public String logout() {
		/*Encerra Threads e realiza o logout no Carregar na tela de Login com os parametros abaixo*/
		logoutUser();
		
		return "login.xhtml?logout=true&faces-redirect=true&includeViewParams=true";
	}
	
	public void logoutPreRender() throws IOException {
		
		FacesContext fc = FacesContext.getCurrentInstance();
		
		boolean isLogout = fc.getExternalContext().getRequestParameterMap().get("logout") != null ? true : false;
		if (isLogout) {
			logoutSession();
			//Limpa o parametro de logout apos realizar o mesmo.
			ExternalContext ec = FacesContext.getCurrentInstance().getExternalContext();
	        ec.redirect(ec.getRequestContextPath() + "/login.xhtml");
		}
	}
	
	public void logoutAdminPreRender() throws IOException {
		
		FacesContext fc = FacesContext.getCurrentInstance();
		
		boolean isLogout = fc.getExternalContext().getRequestParameterMap().get("logout") != null ? true : false;
		if (isLogout) {
			logoutSession();
			//Limpa o parametro de logout apos realizar o mesmo.
			ExternalContext ec = FacesContext.getCurrentInstance().getExternalContext();
	        ec.redirect(ec.getRequestContextPath() + "/loginAdmin.xhtml");
		}
	}
	
	private void startPushSubscriber() {
		if (Util.getPropertyFromFile("manhattan.subscriber.marketwatch").equals("1")) {
			if (user.getCanViewMarketWhatch()) {
				if (threadMarketWhatchForPersistence == null) {
					ApplicationLogger.logDebug("Start Market Whatch push/subscriber thread");
					subscriberMarketWhatchBean.setUserLogged(userLogged);
					threadMarketWhatchForPersistence = new Thread(subscriberMarketWhatchBean, "### Manhatthan Thread - SubscriberManagerBean");
					threadMarketWhatchForPersistence.start();
				}
			} else {
				ApplicationLogger.logDebug("User don't have permission to view market whatch");
			}
		} else {
			ApplicationLogger.logDebug("Market Watch push/subscriber thread is disabled");
		}

		if (Util.getPropertyFromFile("manhattan.subscriber.manager").equals("1")) {
			if (user.getCanViewManagerRecords()) {
				if (threadManagerForPersistence == null) {
					ApplicationLogger.logDebug("Start Manager push/subscriber thread");			
					subscriberManagerBean.setUserLogged(userLogged);
					threadManagerForPersistence = new Thread(subscriberManagerBean, "### Manhatthan Thread - SubscriberMarketWhacthBean");
					threadManagerForPersistence.start();
				}
			} else {
				ApplicationLogger.logDebug("User don't have permission to view market whatch");
			}
		} else {
			ApplicationLogger.logDebug("Manager push/subscriber thread is disabled");
		}
	}

	public void setSubscriberMarketWhatchBean(SubscriberMarketWhacthBean subscriberMarketWhatchBean) {
		this.subscriberMarketWhatchBean = subscriberMarketWhatchBean;
	}

	public void setSubscriberManagerBean(SubscriberManagerBean subscriberManagerBean) {
		this.subscriberManagerBean = subscriberManagerBean;
	}

	public void setManagerBean(ManagerBean managerBean) {
		this.managerBean = managerBean;
	}

	public SgServiceHttp_SIT getSgHttpSit() {
		return sgHttpSit;
	}

	public void setSgHttpSit(SgServiceHttp_SIT sgHttpSit) {
		this.sgHttpSit = sgHttpSit;
	}

	public SgServiceHttp_UAT getSgHttpUat() {
		return sgHttpUat;
	}

	public void setSgHttpUat(SgServiceHttp_UAT sgHttpUat) {
		this.sgHttpUat = sgHttpUat;
	}
}