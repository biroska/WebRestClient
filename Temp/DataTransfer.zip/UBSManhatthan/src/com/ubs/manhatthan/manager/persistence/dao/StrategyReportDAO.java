package com.ubs.manhatthan.manager.persistence.dao;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IStrategyReportAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IStrategyReportDAO;
import com.ubs.manhatthan.manager.persistence.entities.StrategyReport;
import com.ubs.manhatthan.manager.persistence.entities.id.StrategyReportPK;

@Repository
@Scope("singleton")
public class StrategyReportDAO extends GenericDAO<StrategyReport, StrategyReportPK> implements IStrategyReportDAO, Serializable {
	private static final long serialVersionUID = 1L;
	public StrategyReportDAO() {}
	
	@Autowired
	private IStrategyReportAuditDAO strategyReportAuditDAO;
	
	@Override 
	public List<StrategyReport> getStrategyReportsByDate(Date date) throws DAOExceptionManhattan {
		List<StrategyReport> resultList = null;

		try {
			String query = " SELECT tab1 FROM StrategyReport tab1"
						+ " join fetch tab1.legStrategyList"
						+  " WHERE tab1.id.strategyDate = :date";
			
			TypedQuery<StrategyReport> typedQuery = getEm().createQuery( query, StrategyReport.class );
			
			typedQuery.setParameter("date", date);			
			resultList = typedQuery.getResultList();
			
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return resultList;
	}
	
	
	@Override
	public StrategyReport saveReport( StrategyReport report ) throws DAOExceptionManhattan {
		try {
			report.setStrategyTimestamp( new Date() );
			
			// Salva o strategy report, legs e orders
			report = update( report );
			
			// Gera registro na tabela de auditoria - Strategyreport
			strategyReportAuditDAO.saveReportAudit( report );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return report;
	}

	public void setStrategyReportAuditDAO(IStrategyReportAuditDAO strategyReportAuditDAO) {
		this.strategyReportAuditDAO = strategyReportAuditDAO;
	}
}