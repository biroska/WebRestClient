package com.ubs.manhatthan.manager.persistence.dao;

import java.io.Serializable;
import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.criterion.Restrictions;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.ILegStrategyReportDAO;
import com.ubs.manhatthan.manager.persistence.entities.LegStrategyReport;
import com.ubs.manhatthan.manager.persistence.entities.id.LegStrategyReportPK;

@Repository
@Scope("singleton")
public class LegStrategyReportDAO extends GenericDAO<LegStrategyReport, LegStrategyReportPK> implements ILegStrategyReportDAO, Serializable {
	
	private static final long serialVersionUID = 5640335530590521237L;

	@Override
	public List<LegStrategyReport> findByStrategyId( Long reportId ) throws DAOExceptionManhattan {
		
		List<LegStrategyReport> findByCriteria = null;
		
		try {
			findByCriteria = findByCriteria( Restrictions.eq("id.strategyId", reportId ) );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return findByCriteria;
	}
	
	public boolean verifyExistByOrderFixSessionId(Integer orderFixSessionId) throws DAOExceptionManhattan{		
		
		boolean exist = false;
		List<Long> resultList = null;
		try {
			
			if (orderFixSessionId!=null) {
				String query = " SELECT  o.id.engineId " +
		            	   " FROM LegStrategyReport o "
		            	   + " WHERE o.routeId.id = :orderFixSessionId ";
			
				TypedQuery<Long> typedQuery = getEm().createQuery( query, Long.class );
				typedQuery.setParameter("orderFixSessionId", orderFixSessionId);
				
				resultList = typedQuery.getResultList();
				if (resultList!=null && !resultList.isEmpty()) {
					exist = true;
				}
			}			
			
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return exist;		
	}
}