/**
 * 
 */
package com.ubs.manhatthan.manager.utils;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.cache.CacheHelper;
import com.ubs.manhatthan.manager.cache.MessageCache;
import com.ubs.manhatthan.manager.cache.StrategyCache;
import com.ubs.manhatthan.manager.converters.ConverterToModel;
import com.ubs.manhatthan.manager.enums.EnviromentEnum;
import com.ubs.manhatthan.manager.facade.Facade;
import com.ubs.manhatthan.manager.facade.FacadeService;
import com.ubs.manhatthan.manager.lmdsadapter.LmdsManager;
import com.ubs.manhatthan.manager.lmdsadapter.adapter.AdapterConfigurationException;
import com.ubs.manhatthan.manager.lmdsadapter.adapter.AdapterRuntimeException;
import com.ubs.manhatthan.manager.logger.ApplicationLogger;
import com.ubs.manhatthan.manager.network.client.NetworkClientManager;
import com.ubs.manhatthan.manager.persistence.PersistenceThread;
import com.ubs.manhatthan.manager.persistence.entities.EngineInstance;
import com.ubs.manhatthan.manager.persistence.entities.Exchange;
import com.ubs.manhatthan.manager.persistence.entities.SessionByAccount;
import com.ubs.manhatthan.manager.persistence.entities.StrategyReport;
import com.ubs.manhatthan.manager.persistence.entities.StrategyType;
import com.ubs.manhatthan.manager.persistence.entities.Trader;
import com.ubs.manhatthan.manager.service.ServiceException;
import com.ubs.manhatthan.service.MarketWatchFacade;


/**
 * @author galdinoa
 *
 */

/* Objeto que e criado no deploy da aplicacao e possui um metodo init que 
 * inicializa as conexoes com o engine e com o LMDS
 */
public class DeployInitialize {
	
	@Autowired
	private PersistenceThread persistenceThread;
	
	@Autowired
	private Facade facade;
	
	@Autowired
	private FacadeService facadeService;
	
	@Autowired
	private MarketWatchFacade marketWatchFacade;
	
	@Autowired
	ApplicationContext applicationContext;

	private LmdsManager lmds;
	
	private boolean engineStarted = false;
	
	private List<EngineInstance> engineList;
	
	private String fileName;
	
	public void init(){
		
		try {
			
			setApplicationLog();
			
			listOfAllNonSpringBeans();
			
			/* Busca os strategies types para colocar em cache, caso nao encontre ha algum 
			 *  problema de conexao ou de integridade dos dados
			 */
			if (!loadDomainsToCache()){
				ApplicationLogger.logError("======================================================================================");
				ApplicationLogger.logError("Ocorreu um erro ao carregar as tabelas de dominio");
				ApplicationLogger.logError("======================================================================================");
				
				System.exit( 1 );
			}
			
			CacheHelper.facade = facade; //Using in JSF convereter's because a injection problem of Spring in this type classes
			CacheHelper.facadeService = facadeService; //Using in JSF convereter's because a injection problem of Spring in this type classes
			
			if (!loadStrategyCache()) {
				ApplicationLogger.logError("======================================================================================");
				ApplicationLogger.logError("Ocorreu um erro ao carregar o cache de estrategias");
				ApplicationLogger.logError("======================================================================================");

				System.exit(1);
			}
			
			if (!loadStrategyFromDataBase()) {
				ApplicationLogger.logError("============================================================");
				ApplicationLogger.logError("Ocorreu um erro ao carregar as estrategias do banco de dados");
				ApplicationLogger.logError("============================================================");

				System.exit(1);
			}

			if (!loadMessageForDataBaseTemporaryCache()) {
				ApplicationLogger.logError("=====================================================================================================");
				ApplicationLogger.logError("Ocorreu um erro ao carregar o cache temporario para as mensagens que serao gravadas no banco de dados");
				ApplicationLogger.logError("=====================================================================================================");

				System.exit(1);
			}

			// Se a aplicacao estiver rodando em ambiente local, nao startar as conexoes
			if ( EnviromentEnum.LOCAL.name().equals( com.ubs.manhatthan.manager.utils.Util.getPropertyFromFile( "manhattan.enviroment" ) ) ){
				ApplicationLogger.logInfo("=======================================================================");
				ApplicationLogger.logInfo("Ambiente rodando como local! \t Engine and LMDS nao serao inicializados");
				ApplicationLogger.logInfo("=======================================================================");
			} else {
				if(Boolean.valueOf(com.ubs.manhatthan.manager.utils.Util.getPropertyFromFile( "manhattan.lmds.enabled" ))){
					try {
	
						if ( !connectToLMDS() ){
							ApplicationLogger.logError("===================================");
							ApplicationLogger.logError( "Ocorreu um erro ao iniciar o lmds" );
							ApplicationLogger.logError("===================================");
						
							System.exit( 1 );
						}
					} catch (FileNotFoundException e) {
						e.printStackTrace();
						
						ApplicationLogger.logError("Erro: ", e);
						
						System.exit( 1 );
					} catch (IOException e) {
						e.printStackTrace();
						
						ApplicationLogger.logError("Erro: ", e);
						
						System.exit( 1 );
					} catch (AdapterConfigurationException e) {
						e.printStackTrace();
						
						ApplicationLogger.logError("Erro: ", e);
						
						System.exit( 1 );
					} catch (AdapterRuntimeException e) {
						e.printStackTrace();
						
						ApplicationLogger.logError("Erro: ", e);
						
						System.exit( 1 );
					} 
				}


				try {
					Thread.sleep(2000);
					
					connectToEngines();
					
				} catch (ServiceException | InterruptedException e) {
					e.printStackTrace();
					
					ApplicationLogger.logError("Erro: ", e);
				}

				if ( engineStarted ){
					Thread threadForPersistence = new Thread( persistenceThread, "### Manhatthan Thread - Persistence");
					threadForPersistence.start();				
				}
			}
		} catch (DAOExceptionManhattan /*| IOException*/ e1) {
			e1.printStackTrace();
			
			ApplicationLogger.logError("Erro: ", e1);
			
			System.exit( 1 );
		}
	}
	
	private boolean loadDomainsToCache() throws DAOExceptionManhattan{

		/* Busca os strategies types para colocar em cache, caso nao encontre ha algum 
		 *  problema de conexao ou de integridade dos dados
		 */
		List<StrategyType> findAllStrategyType;
		List<Exchange> findAllExchange;
		
		findAllStrategyType = facade.findAllStrategyType();
		
		findAllExchange = facade.findAllExchange();

		if ( findAllStrategyType == null || findAllStrategyType.isEmpty() ){
			ApplicationLogger.logError("===================================================");
			ApplicationLogger.logError( "Ocorreu um erro ao carregar os tipos de strategia" );
			ApplicationLogger.logError("===================================================");
			return false;
		}
		
		// Gera cache do Exchange
		ApplicationLogger.logInfo("======================================================================================");

		// Load strategy type cache
		for (StrategyType strategyType : findAllStrategyType) {
			CacheHelper.strategyTypeCache.put(strategyType.getStrategyCode(), strategyType);
			if (!strategyType.getStrategyTypeLegList().isEmpty()) {
				com.ubs.manhatthan.model.StrategyType converted = marketWatchFacade.convertEntityStrategyTypeToVO(strategyType);	
				CacheHelper.strategyTypeVOList.add(converted);
			}
			
			ApplicationLogger.logInfo("StrategyType added in cache: " +  strategyType);
		}
				
		// Gera cache do Exchange
		ApplicationLogger.logInfo("======================================================================================");

		if ( findAllExchange == null || findAllExchange.isEmpty() ){
			ApplicationLogger.logError("======================================================================================");
			ApplicationLogger.logError("Ocorreu um erro ao carregar os dados de Exchange");
			ApplicationLogger.logError("======================================================================================");
			return false;
		}
				
		// Gera cache do Exchange
		ApplicationLogger.logInfo("======================================================================================");

		CacheHelper.exchangeListCache.addAll( findAllExchange );
		
		for (Exchange exchange : findAllExchange) {
			
			CacheHelper.exchangeCache.put( exchange.getId(), exchange );
			
			ApplicationLogger.logInfo( "Exchange added in cache: " +  exchange );
		}
		
		// gera cache do client account pegando somente os clientes que possuem sessoes vinculadas
		ApplicationLogger.logInfo("======================================================================================");
		
		List<SessionByAccount> sessionAccounts = facade.getAccountSessions();

		if ( sessionAccounts == null || sessionAccounts.isEmpty() ){
			ApplicationLogger.logError("======================================================================================");
			ApplicationLogger.logError( "Nao foi possivel carregar as contas dos clientes" );
			ApplicationLogger.logError("======================================================================================");
			return false;
		}
		
		int qtd = 0;
		for (SessionByAccount sessionAccount : sessionAccounts) {
			
			
			if ( sessionAccount.getClientAccount() == null || sessionAccount.getClientAccount().getCode() == null )
				continue;
			
			CacheHelper.putClientAccount( sessionAccount.getClientAccount() );
			
			qtd++;
		}

		if( qtd == 0 ){
			ApplicationLogger.logError("======================================================================================");
			ApplicationLogger.logError( "Ocorreu um erro ao carregar as contas dos clientes" );
			ApplicationLogger.logError("======================================================================================");
			return false;
		}
		
		ApplicationLogger.logInfo( "Foram adcicionadas: " + qtd +" contas no cache");
		ApplicationLogger.logInfo("======================================================================================");
		
		
		List<Trader> allTraders = facade.getAllActiveTraders(false);
		
		if ( allTraders == null || allTraders.isEmpty() ){
			ApplicationLogger.logError("======================================================================================");
			ApplicationLogger.logError( "Ocorreu um erro ao carregar os Traders" );
			ApplicationLogger.logError("======================================================================================");
			return false;	
		}
		
		qtd = 0;
		for (Trader trader : allTraders) {
			CacheHelper.putTrader( trader );
			qtd++;
		}
		
		ApplicationLogger.logInfo("======================================================================================");
		ApplicationLogger.logInfo( "Foram adcicionados: " + qtd +" traders no cache");
		ApplicationLogger.logInfo("======================================================================================");
		
		return true;
	}
	
	private boolean loadStrategyCache() {
		
		int numberOfEngines = Integer.parseInt(Util.getPropertyFromFile("manhattan.cache.engine.max"));
		if (numberOfEngines <= 0) {
			ApplicationLogger.logError("===============================================================================================================================================");
			ApplicationLogger.logError("Ocorreu um erro ao carregar cache de estrategias. Nao foi possivel inicializar o cache pois a configuracao para o numero de engines esta zerada");
			ApplicationLogger.logError("===============================================================================================================================================");
			
			return false;
		}
		
		int numberOfInstances = Integer.parseInt(Util.getPropertyFromFile("manhattan.cache.engineInstance.max"));
		if (numberOfInstances <= 0) {
			ApplicationLogger.logError("==================================================================================================================================================");
			ApplicationLogger.logError("Ocorreu um erro ao carregar cache de estrategias. Nao foi possivel inicializar o cache pois a configuracao para o numero de instancias esta zerada");
			ApplicationLogger.logError("==================================================================================================================================================");
			
			return false;
		}

		int numberOfStrategies = Integer.parseInt(Util.getPropertyFromFile("manhattan.cache.strategy.max"));
		if (numberOfStrategies <= 0) {
			ApplicationLogger.logError("===================================================================================================================================================");
			ApplicationLogger.logError("Ocorreu um erro ao carregar cache de estrategias. Nao foi possivel inicializar o cache pois a configuracao para o numero de estrategias esta zerada");
			ApplicationLogger.logError("===================================================================================================================================================");
			
			return false;
		}

		// Inicializa o cache das estrategias que sera consumido pela tela
		ApplicationLogger.logInfo("====================================");
		ApplicationLogger.logInfo("Inicializando o cache de estrategias");
		ApplicationLogger.logInfo("====================================");
		StrategyCache.InitializeCache(numberOfEngines, numberOfInstances, numberOfStrategies);
		ApplicationLogger.logInfo("====================================================================================================================================================");
		ApplicationLogger.logInfo("Cache das estrategias alocados em Engines[" + numberOfEngines + "], Instancias [" + numberOfInstances + "], Estrategias [" + numberOfStrategies + "]");
		ApplicationLogger.logInfo("====================================================================================================================================================");
		
		return true;
	}
	
	private boolean loadMessageForDataBaseTemporaryCache() {		
		int numberOfMessages = Integer.parseInt(Util.getPropertyFromFile("manhattan.cache.temporary.message.max"));
		if (numberOfMessages <= 0) {
			ApplicationLogger.logError("==================================================================================================================================================================================================");
			ApplicationLogger.logError("Ocorreu um erro ao carregar cache temporario para as mensagens a serem gravadas no banco de dados. Nao foi possivel inicializar o cache pois a configuracao para o numero de mensagens esta zerada");
			ApplicationLogger.logError("==================================================================================================================================================================================================");
			
			return false;
		}
		
		// Inicializa o cache temporario das mensagens que sera consumido pela thread de persistencia
		ApplicationLogger.logInfo("====================================");
		ApplicationLogger.logInfo("Inicializando o cache de estrategias");
		ApplicationLogger.logInfo("====================================");
		MessageCache.InitializeTemporaryCache(numberOfMessages);
		ApplicationLogger.logInfo("==============================================================================");
		ApplicationLogger.logInfo("Cache temporario das mesnsagens alocados em Messages[" + numberOfMessages + "]");
		ApplicationLogger.logInfo("==============================================================================");

		return true;
	}
	
	// Load strategies of database in cache
	private boolean loadStrategyFromDataBase() {
		try {
			List<StrategyReport> strategyReports = facade.findStrategyByDate(new Date());
			
			if (strategyReports != null) {
				com.ubs.manhatthan.model.StrategyReport strategyReport = null; 
				
				int maxFor = strategyReports.size();
				for (int i = 0; i < maxFor; i++) {
					strategyReport = ConverterToModel.convertStrategyReportToModel(strategyReports.get(i));
					
					StrategyCache.loadStrategy(strategyReport);
				}
			}
		} catch (Exception e) {
			ApplicationLogger.logError("Ocorreu um erro ao carregar cache de estrategias com as estrategias do banco de dados.");
			
			return false;
		}

		return true;		
	}
	
	private boolean connectToEngines() throws DAOExceptionManhattan, ServiceException{
		
		int qtdEngineStrated = 0;
		
		try {
			engineList = facade.getEngines();
		} catch (DAOExceptionManhattan e) {
			e.printStackTrace();
			ApplicationLogger.logError("Erro: ", e);
		}
		
		if ( engineList == null || engineList.isEmpty() ){
			ApplicationLogger.logError("======================================================================================");
			ApplicationLogger.logError("Nao foi possivel recuperar os engines");
			ApplicationLogger.logError("======================================================================================");
		}
		
		if (engineList!=null) {
			for (EngineInstance engineInstance : engineList) {
				
				if( engineInstance.getEngineId() != null && engineInstance.getEngineId() > 0 ){
					
					ApplicationLogger.logInfo("======================================================================================");
					ApplicationLogger.logInfo("Starting Engine " + engineInstance.getEngineId() + " Service");
					ApplicationLogger.logInfo("======================================================================================");
					
	
					//Start & Register Network Service
					NetworkClientManager client = new NetworkClientManager( engineInstance.getHost(), 
																		    Integer.valueOf( ""+engineInstance.getPort() ) );
					
					//Start
					if (client.Start() ){
						qtdEngineStrated++;
						
						// Put the instance of engine in the cache
						CacheHelper.engineCommunicatorInstance.put( engineInstance.getEngineId(), client );
						
						engineStarted = true;
					}
				}
			}
		}
		
		if ( qtdEngineStrated == 0 ){
			ApplicationLogger.logError("======================================================================================");
			ApplicationLogger.logError( "Nao foi possivel conectar em nenhum engine" );
			ApplicationLogger.logError("======================================================================================");
		}
		
		return true;
	}
	
	private boolean connectToLMDS() throws FileNotFoundException, IOException, AdapterConfigurationException, AdapterRuntimeException{
		
		ApplicationLogger.logInfo("======================================================================================");
		ApplicationLogger.logInfo("Starting LMDS Service");		
		ApplicationLogger.logInfo("======================================================================================");
		
		lmds = new LmdsManager();
		
		//Initializing the LMDS Adapter
		ExternalContext ec = FacesContext.getCurrentInstance().getExternalContext();
		
		lmds.startLmdsAdapter( ec.getResourceAsStream("/WEB-INF/lmds-client-api.cfg") );
		
		CacheHelper.lmdsCommunicatorInstance.put( Util.getManagerId() , lmds );
		 
//		boolean _ret = getShortFowardDollar();
//		if( !_ret )
//		{	
//			ApplicationLogger.logError("Error defining the Foward Dollar");
//			return false;
//		}		
		
		CacheHelper.fowardDollar = Constant.SYMBOL.SPOT_DOLLAR;
		ApplicationLogger.logInfo("Using Foward Dollar: <" + CacheHelper.fowardDollar + ">");	
		lmds.subscribeSymbol( CacheHelper.fowardDollar );
		
		return true;
	}
	
	@SuppressWarnings("unused")
	private boolean getShortFowardDollar()
	{
		CacheHelper.fowardDollar = Constant.SYMBOL.FOWARD_DOLLAR_PREFIX;
				
		DateFormat _yearFormat = new SimpleDateFormat("yy");
		DateFormat _monthFormat = new SimpleDateFormat("MM");
		Date date = new Date();	
		
		int _month  = Integer.parseInt(_monthFormat.format(date).toString());
		switch (_month)
		{	
		case 1:  CacheHelper.fowardDollar += Constant.SYMBOL.FOWARD_DOLLAR_FEBRUARY;  break;
		case 2:  CacheHelper.fowardDollar += Constant.SYMBOL.FOWARD_DOLLAR_MARCH;     break;
		case 3:  CacheHelper.fowardDollar += Constant.SYMBOL.FOWARD_DOLLAR_APRIL;     break;
		case 4:  CacheHelper.fowardDollar += Constant.SYMBOL.FOWARD_DOLLAR_MAY;       break;
		case 5:  CacheHelper.fowardDollar += Constant.SYMBOL.FOWARD_DOLLAR_JUNE;      break;
		case 6:  CacheHelper.fowardDollar += Constant.SYMBOL.FOWARD_DOLLAR_JULY;      break;
		case 7:  CacheHelper.fowardDollar += Constant.SYMBOL.FOWARD_DOLLAR_AUGUST;    break;
		case 8:  CacheHelper.fowardDollar += Constant.SYMBOL.FOWARD_DOLLAR_SEPTEMBER; break;
		case 9:  CacheHelper.fowardDollar += Constant.SYMBOL.FOWARD_DOLLAR_OCTOBER;   break;
		case 10: CacheHelper.fowardDollar += Constant.SYMBOL.FOWARD_DOLLAR_NOVEMBER;  break;
		case 11: CacheHelper.fowardDollar += Constant.SYMBOL.FOWARD_DOLLAR_DECEMBER;  break;
		case 12: CacheHelper.fowardDollar += Constant.SYMBOL.FOWARD_DOLLAR_JANUARY;   break;

		default: return false;
		}
		
		CacheHelper.fowardDollar += _yearFormat.format(date).toString();
		
		return true;
	}	
	
	public void destroy() throws Exception {
		
		
		Set<Long> keySet = CacheHelper.engineCommunicatorInstance.keySet();
		
		for (Long key : keySet) {
			CacheHelper.engineCommunicatorInstance.get( key ).Stop();
		}
		
		System.out.println("======================================================================================");
		System.out.println("Spring Container is destroy! Customer clean up");
		System.out.println("======================================================================================");
		
		ApplicationLogger.logInfo("======================================================================================");
		ApplicationLogger.logInfo("Spring Container is destroy! Customer clean up");
		ApplicationLogger.logInfo("======================================================================================");
	}
	
	private void listOfAllNonSpringBeans(){
		
		ApplicationLogger.logInfo("======================================================================================");
		
		for (String beanName : applicationContext.getBeanDefinitionNames()) {
			if ( beanName.contains("org.springframework") )
				continue;
			
			ApplicationLogger.logInfo("Bean name: " + beanName);
		}
		ApplicationLogger.logInfo("======================================================================================");
	}
	
	private void setApplicationLog(){
		CacheHelper.logPath = Util.getPropertyFromFile("manhattan.log.location");
		
		fileName = CacheHelper.logPath + Constant.LOG_CONFIGURATION.FILE_NAME + 
				Util.convertDatePattern( new Date(), "yyyyMMdd") + Constant.LOG_CONFIGURATION.FILE_EXTENSION;
		
		ApplicationLogger.configureLogger( fileName );
		
		ApplicationLogger.logInfo("======================================================================================");
		ApplicationLogger.logInfo("Logfile configured: " + fileName );
		ApplicationLogger.logInfo("======================================================================================");
	}
	
	public void setPersistenceThread(PersistenceThread persistenceThread) {
		this.persistenceThread = persistenceThread;
	}

	public void setFacade(Facade facade) {
		this.facade = facade;
	}

	public void setMarketWatchFacade(MarketWatchFacade marketWatchFacade) {
		this.marketWatchFacade = marketWatchFacade;
	}

	public void setFacadeService(FacadeService facadeService) {
		this.facadeService = facadeService;
	}
}