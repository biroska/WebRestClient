/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import com.ubs.manhatthan.manager.persistence.entities.audit.TraderExchangeCodeAudit;

/**
 * @author galdinoa
 *
 */
public interface ITraderExchangeCodeAuditDAO extends IGenericDAO<TraderExchangeCodeAudit, Long> {

}
