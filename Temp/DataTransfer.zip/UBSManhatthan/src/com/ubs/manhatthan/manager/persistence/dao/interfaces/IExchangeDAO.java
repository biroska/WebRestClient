/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import java.util.List;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.persistence.entities.Exchange;

/**
 * @author galdinoa
 *
 */
public interface IExchangeDAO extends IGenericDAO<Exchange, Long> {

	public Exchange saveExchange(Exchange exchange) throws DAOExceptionManhattan;

	public List<Exchange> findExchange(Exchange exchange) throws DAOExceptionManhattan;
}
