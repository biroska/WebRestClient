package com.ubs.manhatthan.manager.enums;

public enum ActionTypeEnum{
	
    INSERT,
    UPDATE,
    DELETE;
    
    private ActionTypeEnum() {
    }
}
