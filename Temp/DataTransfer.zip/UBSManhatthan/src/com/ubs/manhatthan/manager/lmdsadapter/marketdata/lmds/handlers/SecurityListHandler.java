package com.ubs.manhatthan.manager.lmdsadapter.marketdata.lmds.handlers;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import quickfix.FieldNotFound;
import quickfix.field.MaturityDate;
import quickfix.field.MinPriceIncrement;
import quickfix.field.NoRelatedSym;
import quickfix.field.RoundLot;
import quickfix.field.SecurityExchange;
import quickfix.field.SecurityID;
import quickfix.field.Symbol;
import quickfix.fix44.SecurityList;

import com.ubs.manhatthan.manager.lmdsadapter.marketdata.basicimplementation.BasicSecurity;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.basicimplementation.BasicSecurityDefinition;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.SecurityDefinition;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.lmds.LMDSController;
import com.ubs.manhatthan.manager.utils.Constant;
import com.ubs.manhatthan.manager.utils.Util;


public class SecurityListHandler implements QuickFixHandler<quickfix.fix44.SecurityList>, Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -980672928893899237L;
	private final LMDSController controller;
	
	public SecurityListHandler(LMDSController controller)
	{
		this.controller = controller;
	}

	@Override
	public void handle(SecurityList event)
	{
		//
		// Parse security list
		//
		List<SecurityDefinition> instruments = null;
		try
		{
			
			instruments = parseInstrumentList(event);
		} catch (FieldNotFound e)
		{
			return;
		}
		
		//
		// Register instruments on controller
		//
		this.controller.onSecurityListReceived(instruments);
		
	}
	
	protected List<SecurityDefinition> parseInstrumentList(SecurityList securityList) throws FieldNotFound {
		
		
		//
		// Get the number of groups
		//
		NoRelatedSym noRelatedSym = new NoRelatedSym();
		securityList.get(noRelatedSym);
		
		//
		// Create return list
		//

		List<SecurityDefinition> instruments = new ArrayList<>(noRelatedSym.getValue());
		
		//
		// Iterate over security list
		//		
		SecurityList.NoRelatedSym noRelatedSymGroup = new SecurityList.NoRelatedSym();
		
		for (int i = 1; i <= noRelatedSym.getValue(); i++) {
			securityList.getGroup(i, noRelatedSymGroup);
			SecurityDefinition instrument = parseInstrument(noRelatedSymGroup);
			instruments.add(instrument);
		}		
		
		return instruments;		
	}
	
	protected SecurityDefinition parseInstrument(SecurityList.NoRelatedSym noRelatedSymGroup) throws FieldNotFound {
		
		BasicSecurity security = new BasicSecurity(noRelatedSymGroup.getString(SecurityID.FIELD),
												   noRelatedSymGroup.getString(SecurityExchange.FIELD),
												   noRelatedSymGroup.getString(Symbol.FIELD)
												  );
		Date maturityDate = new Date();
		
		if( noRelatedSymGroup.isSetField(MaturityDate.FIELD) )
		{
			Integer intMaturityDate = noRelatedSymGroup.getInt(MaturityDate.FIELD);
			maturityDate = Util.convertDatePattern( ""+intMaturityDate, "yyyyMMdd" );
		}
		else
		{
			maturityDate = Util.convertDatePattern( Constant.SIMULATION.INITIAL_MATURITY_DATE, "yyyyMMdd" );
		}
			
		BasicSecurityDefinition securityDefinition = new BasicSecurityDefinition(security,
																				 noRelatedSymGroup.getInt(RoundLot.FIELD),
																				 noRelatedSymGroup.getDecimal(MinPriceIncrement.FIELD),
																				 maturityDate
																				);
		
		return securityDefinition;
	}
}

