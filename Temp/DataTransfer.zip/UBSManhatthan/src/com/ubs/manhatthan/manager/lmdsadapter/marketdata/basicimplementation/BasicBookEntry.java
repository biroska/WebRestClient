package com.ubs.manhatthan.manager.lmdsadapter.marketdata.basicimplementation;

import java.io.Serializable;
import java.math.BigDecimal;

import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.BookEntry;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.Side;


/**
 * Basic book entry
 * 
 * @author pretof
 *
 */
public class BasicBookEntry implements BookEntry, Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5539316772414162690L;
	private final Side side;
	private final long quantity;
	private final BigDecimal price;
	private final boolean aggregated;
	private final int numberoforders;

	public BasicBookEntry(Side side, long quantity, BigDecimal price,
			boolean aggregated, int numberoforders) {
		super();
		this.side = side;
		this.quantity = quantity;
		this.price = price;
		this.aggregated = aggregated;
		this.numberoforders = numberoforders;
	}

	@Override
	public Side getSide() {
		return this.side;
	}

	@Override
	public long getQuantity() {
		return this.quantity;
	}

	@Override
	public BigDecimal getPrice() {
		return this.price;
	}

	@Override
	public boolean isAggregatedEntry() {
		return this.aggregated;
	}

	@Override
	public int numberOfAggregatedOrders() {
		return this.numberoforders;
	}
	
	
}
