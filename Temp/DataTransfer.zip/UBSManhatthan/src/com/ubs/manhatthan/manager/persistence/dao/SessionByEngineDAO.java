package com.ubs.manhatthan.manager.persistence.dao;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IEngineInstanceDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IOrderFixSessionDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.ISessionByEngineAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.ISessionByEngineDAO;
import com.ubs.manhatthan.manager.persistence.entities.EngineInstance;
import com.ubs.manhatthan.manager.persistence.entities.OrderFixSession;
import com.ubs.manhatthan.manager.persistence.entities.SessionByEngine;
import com.ubs.manhatthan.manager.persistence.entities.audit.SessionByEngineAudit;

@Repository
@Scope("singleton")
public class SessionByEngineDAO extends GenericDAO<SessionByEngine, Long> implements ISessionByEngineDAO, Serializable {

	private static final long serialVersionUID = 3449024482215992901L;

	String deleteQuery = "DELETE FROM SessionByEngine o WHERE o.engine.id = ? and o.orderFixSession.id = ?";

	@Autowired
	private IEngineInstanceDAO engineInstanceDAO;
	
	@Autowired
	private IOrderFixSessionDAO orderFixSessionDAO;
	
	@Autowired
	private ISessionByEngineAuditDAO sessionByEngineAuditDAO;
	
	@Autowired
	private User user;
	
	@Override
	public SessionByEngine saveSessionByEngine( SessionByEngine sessionByEngine ) throws DAOExceptionManhattan {
		try {
			ActionTypeEnum action = sessionByEngine.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;
	
			sessionByEngine  = update( sessionByEngine );
	
			SessionByEngineAudit sbea = new SessionByEngineAudit( sessionByEngine, action, user.getLogin(), new Date() );
			
			sessionByEngineAuditDAO.save( sbea );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return sessionByEngine;
	}

	@Override
	public void deleteSessionByEngine (SessionByEngine sessionByEngine) throws DAOExceptionManhattan {
		if ((sessionByEngine != null) && (sessionByEngine.getEngine() != null && sessionByEngine.getEngine().getId() != null)
				 && (sessionByEngine.getOrderFixSession() != null && sessionByEngine.getOrderFixSession().getId() != null)) {
			try {
				Query createQuery = getEm().createQuery(deleteQuery);
				createQuery.setParameter(1, sessionByEngine.getEngine().getId());
				createQuery.setParameter(2, sessionByEngine.getOrderFixSession().getId());
				
				createQuery.executeUpdate();
			} catch ( Exception e ) {
				throw new DAOExceptionManhattan( e );
			}
		}
	}

	public Long generate( int qtd ) throws DAOExceptionManhattan {
		
		List<EngineInstance> engineInstanceList = engineInstanceDAO.findAll();
		List<OrderFixSession> orderFixSessionList = orderFixSessionDAO.findAll();
		
		Long qtRegs = 0L;
		
		for ( int i = 1; i<= qtd; i++ ){
			saveSessionByEngine( new SessionByEngine( engineInstanceList.get( i -1), orderFixSessionList.get( qtd -i) ) );
			qtRegs++;
		}
		
		return qtRegs;
	}
	
	public SessionByEngine getByIndex( int index ) throws DAOExceptionManhattan  {
		return findAll().get( index );
	}
	
	public SessionByEngine getByEngineIdAndSessionId( Integer idEngine, Integer idSession ) throws DAOExceptionManhattan  {
		
		SessionByEngine sessionByEngine = new SessionByEngine();
		List<SessionByEngine> sessionByEngineList = new ArrayList<>();
		
		String query = " FROM SessionByEngine o "
         	   + " WHERE o.engine.id = :idEngine "
         	   + " AND o.orderFixSession.id = :idSession";
	
		TypedQuery<SessionByEngine> typedQuery = getEm().createQuery( query, SessionByEngine.class );
		typedQuery.setParameter("idEngine", idEngine);
		typedQuery.setParameter("idSession", idSession);
		
		sessionByEngineList = typedQuery.getResultList();
		
		if (sessionByEngineList!=null && !sessionByEngineList.isEmpty()) {
			sessionByEngine = sessionByEngineList.get(0);
		}
		
		return sessionByEngine;
	}
	
	public boolean verifyExistByEngineId(Long engineId) throws DAOExceptionManhattan{		
		
		boolean exist = false;
		List<Long> resultList = null;
		try {
			
			if (engineId!=null) {
				String query = " SELECT  o.id " +
		            	   " FROM SessionByEngine o "
		            	   + " WHERE o.engine.engineId = :engineId ";
			
				TypedQuery<Long> typedQuery = getEm().createQuery( query, Long.class );
				typedQuery.setParameter("engineId", engineId);
				
				resultList = typedQuery.getResultList();
				if (resultList!=null && !resultList.isEmpty()) {
					exist = true;
				}
			}			
			
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return exist;		
	}

	public void setOrderFixSessionDAO(IOrderFixSessionDAO orderFixSessionDAO) {
		this.orderFixSessionDAO = orderFixSessionDAO;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public void setSessionByEngineAuditDAO(ISessionByEngineAuditDAO sessionByEngineAuditDAO) {
		this.sessionByEngineAuditDAO = sessionByEngineAuditDAO;
	}

	public IEngineInstanceDAO getEngineInstanceDAO() {
		return engineInstanceDAO;
	}
}