package com.ubs.manhatthan.manager.persistence.dao.audit;

import java.io.Serializable;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.manager.persistence.dao.GenericDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.ISessionByAccountAuditDAO;
import com.ubs.manhatthan.manager.persistence.entities.audit.SessionByAccountAudit;

@Repository
@Scope("singleton")
public class SessionByAccountAuditDAO extends GenericDAO<SessionByAccountAudit, Long> implements ISessionByAccountAuditDAO, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;}
