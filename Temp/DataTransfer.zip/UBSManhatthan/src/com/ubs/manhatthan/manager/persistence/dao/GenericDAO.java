package com.ubs.manhatthan.manager.persistence.dao;

import java.io.Serializable;
import java.lang.reflect.ParameterizedType;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IGenericDAO;

public class GenericDAO<T, ID extends Serializable> implements IGenericDAO<T, ID> {

    // ~ Instance fields
    // --------------------------------------------------------
    private final Class<T> persistentClass;

	@PersistenceContext
	private EntityManager em;

    // ~ Constructors
    // -----------------------------------------------------------

    @SuppressWarnings("unchecked")
    public GenericDAO() {

        this.persistentClass = (Class<T>) ((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments()[0];
    }

    public GenericDAO(final Class<T> persistentClass) {
        super();
        this.persistentClass = persistentClass;
    }

    // ~ Methods
    // ----------------------------------------------------------------

    @Override
    public Class<T> getEntityClass() {
        return persistentClass;
    }

    @Override
    public long countAll() throws DAOExceptionManhattan {
        return countByCriteria();
    }

    @Override
    public int countByExample(final T exampleInstance) throws DAOExceptionManhattan {
        Criteria crit = null;
            Session session = (Session) getEm().getDelegate();
            crit = session.createCriteria(getEntityClass());
            crit.setProjection(Projections.rowCount());
            crit.add(Example.create(exampleInstance));
        return (Integer) crit.list().get(0);
    }

    @Override
    public List<T> findAll() throws DAOExceptionManhattan {
        return findByCriteria();
    }
    
    public List<T> findAllOrdened( String orderColumn , boolean isDesc ) throws DAOExceptionManhattan {
    	return findByCriteriaOrdened( orderColumn, isDesc );
    }

    @Override
    public List<T> findAll(String propertyOrder, Boolean isDesc) throws DAOExceptionManhattan {
    	return findByCriteria(propertyOrder, isDesc);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<T> findByExample(final T exampleInstance) throws DAOExceptionManhattan {
        List<T> result = null;
            Session session = (Session) getEm().getDelegate();
            Criteria crit = session.createCriteria(getEntityClass());
            crit.add( Example.create( exampleInstance )
		             	     .ignoreCase()
		             	     .enableLike()
            		);
            result = crit.list();
        return result;
    }

    @Override
    public T findById(final ID id) throws DAOExceptionManhattan {
        return getEm().find(persistentClass, id);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<T> findByNamedQuery(final String name, Object... params) throws DAOExceptionManhattan {
        List<T> result = null;

            javax.persistence.Query query = getEm().createNamedQuery(name);

            for (int i = 0; i < params.length; i++) {
                query.setParameter(i + 1, params[i]);
            }
            result = (List<T>) query.getResultList();
        return result;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<T> findByNamedQueryAndNamedParams(final String name, final Map<String, ? extends Object> params) throws DAOExceptionManhattan
            {
        List<T> result = null;
            javax.persistence.Query query = getEm().createNamedQuery(name);

            for (final Map.Entry<String, ? extends Object> param : params.entrySet()) {
                query.setParameter(param.getKey(), param.getValue());
            }
            result = (List<T>) query.getResultList();
        return result;
    }

    /**
     * Use this inside subclasses as a convenience method.
     */
    public List<T> findByCriteria(final Criterion... criterion) throws DAOExceptionManhattan {
        List<T> ret = null;
            ret = findByCriteria(null, null, -1, -1, criterion);
        return ret;
    }
    
    /**
     * Use this inside subclasses as a convenience method.
     */
    public List<T> findByCriteriaOrdened(String orderColumn , boolean isDesc, final Criterion... criterion) throws DAOExceptionManhattan {
        return findByCriteria(orderColumn, isDesc, -1, -1, criterion);
    }

    /**
     * Use this inside subclasses as a convenience method.
     */
    public List<T> findByCriteria(String propertyOrder, Boolean isDesc, final Criterion... criterion) throws DAOExceptionManhattan {
        return findByCriteria(propertyOrder, isDesc, -1, -1, criterion);
    }

    /**
     * Use this inside subclasses as a convenience method.
     */
    @SuppressWarnings("unchecked")
    public List<T> findByCriteria(String propertyOrder, Boolean isDesc, final int firstResult, final int maxResults,
            final Criterion... criterion) throws DAOExceptionManhattan {
        List<T> result = null;

            Session session = (Session) getEm().getDelegate();
            Criteria crit = session.createCriteria(getEntityClass());

            for (final Criterion c : criterion) {
                crit.add(c);
            }

            if (firstResult > 0) {
                crit.setFirstResult(firstResult);
            }

            if (maxResults > 0) {
                crit.setMaxResults(maxResults);
            }

            if (propertyOrder != null && !propertyOrder.isEmpty()) {
                if (isDesc) {
                    crit.addOrder(Order.desc(propertyOrder));
                } else {
                    crit.addOrder(Order.asc(propertyOrder));
                }
            }
            crit.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);


            result = crit.list();
        return result;
    }

    public long countByCriteria(Criterion... criterion) throws DAOExceptionManhattan {

        Long ret = null;
            Session session = (Session) getEm().getDelegate();
            Criteria crit = session.createCriteria(getEntityClass());
            crit.setProjection(Projections.rowCount());

            for (final Criterion c : criterion) {
                crit.add(c);
            }
            ret = (Long) crit.list().get(0);
        return ret;
    }

    @Override
    public void delete(T entity) throws DAOExceptionManhattan {
    	try {
            getEm().remove(entity);
            
            getEm().flush();
    	} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
    }

    @Override
    public T save(T entity) throws DAOExceptionManhattan {
    	try {
	        getEm().persist(entity);
	        return entity;
    	} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
    }

    @Override
    public T update(T entity) throws DAOExceptionManhattan {
    	T merge = null;
    	try {
    		merge = getEm().merge(entity);
    	} catch ( Exception e ) {
    		throw new DAOExceptionManhattan( e );
    	}
        getEm().flush();
        return merge;
    }

    public void deleteById(final ID id) throws DAOExceptionManhattan {
    	try {
	        T entity = findById(id);
	        if (entity != null) {
	            getEm().remove(entity);
	        }
    	} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
    }
    
	public T getByIndex(int index) throws DAOExceptionManhattan {
		
		List<T> findByCriteria = findByCriteria(null, null, -1, index );
		
		if ( findByCriteria == null || findByCriteria.isEmpty() || findByCriteria.size() < index +1 )
			return null;
		
		return findByCriteria.get( index );
	}
    
	public EntityManager getEm() {
//		if ( em == null)
//			return FactoryManager.getEntityManager();
		
		return em;
	}

	public void setEm(EntityManager em) {
		this.em = em;
	}
	
}