/**
 * 
 */
package com.ubs.manhatthan.manager.tests;

import java.util.Date;

import com.ubs.manhatthan.manager.utils.Util;



/**
 * @author galdinoa
 *
 */
public class DiversosTestes {
	
	public static void main (String[] args){
		
//		Date date = new Date();
//		try {
//		
//		System.out.println( date );
//		
//		SimpleDateFormat sdfAmerica = new SimpleDateFormat("dd-M-yyyy hh:mm:ss a");
//		sdfAmerica.setTimeZone(TimeZone.getTimeZone("America/New_York"));
//		String sDateInAmerica = sdfAmerica.format( date );
//		
//		System.out.println(sDateInAmerica);
//		
//		SimpleDateFormat defaultTZ = new SimpleDateFormat("dd-M-yyyy hh:mm:ss a");
//		defaultTZ.setTimeZone(TimeZone.getDefault() );
//		Date parse = defaultTZ.parse( sDateInAmerica );
//		System.out.println( parse );
//		} catch (ParseException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
//		Date date = new Date();
//		Calendar calendar = new GregorianCalendar();
////		TimeZone timeZone = calendar.getTimeZone();
//		
//		TimeZone time1 = TimeZone.getTimeZone("UTC");
//		TimeZone time2 = TimeZone.getTimeZone("Europe/Gibraltar");
//		
//		System.out.println("Time now....\n");
//		
//		System.out.println(date.getTime());
//		
//		long timeCPH = calendar.getTimeInMillis();
//		System.out.println("timeCPH  = " + timeCPH);
//		System.out.println("hour     = " + calendar.get(Calendar.HOUR_OF_DAY));
//		System.out.println("Date     = " + calendar.getTime() );
//
//		calendar.setTimeZone(time1);
//
//		long timeUTC = calendar.getTimeInMillis();
//		System.out.println("\ntimeUTC   = " + timeUTC);
//		System.out.println("hour     = " + calendar.get(Calendar.HOUR_OF_DAY));
//		System.out.println("Date     = " + calendar.getTime() );
//		
//		calendar.setTimeZone(time2);
//		
//		long timeEu = calendar.getTimeInMillis();
//		System.out.println("\ntimeUTC   = " + timeEu);
//		System.out.println("hour     = " + calendar.get(Calendar.HOUR_OF_DAY));
//		System.out.println("Date     = " + calendar.getTime() );
//		
//		
//		System.exit(1);
//		
//		
//		Long engine = 33001L;
//		
//		long teste = engine / 1000;
//		
//		System.out.println( teste );
		
		
		Date data = new Date();
		
		System.out.println( data );
		
		System.out.println( Util.convertDatePattern(data, "HH:mm:ss") );;
		
		System.exit(1);
		
		
		
//		System.out.println( Util.convertDatePattern( new Date(), "yyMMdd" ) );
//		System.out.println( Util.convertDatePattern( "151126", "yyMMdd" ) );
//		
//		System.out.println( Util.convertDatePattern( new Date(), "dd-MMM-yy HH.mm.ss" ) );
//		System.out.println( Util.convertDatePattern( new Date(), "dd-MMM-yy HH.mm.ss.SSSSSSSSS a" ) );
		
//		Long maxValue = (long) ( Math.pow( 2, 63 ) -1);
//		
//		Long maxValueFixed = 9_223_372_036_854_775_807L;
//		
//		System.out.printf("Max value: %f\n", ( Math.pow( 2, 63 ) -1 ) );
//		System.out.println("Max value: " + maxValue);
//		System.out.println("Max value: " + maxValueFixed);
//		System.out.println("Max value: " + "9223372036854775807 ");
		
//		Calendar cal = Calendar.getInstance();
//		cal.add( Calendar.DATE , -10 );
		
	}
	
}