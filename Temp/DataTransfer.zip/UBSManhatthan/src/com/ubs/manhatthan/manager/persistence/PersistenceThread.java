/**
 * 
 */
package com.ubs.manhatthan.manager.persistence;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.ubs.manhatthan.manager.cache.MessageCache;
import com.ubs.manhatthan.manager.converters.ConverterToEntity;
import com.ubs.manhatthan.manager.enums.ExecutionTypeEnum;
import com.ubs.manhatthan.manager.facade.Facade;
import com.ubs.manhatthan.manager.logger.ApplicationLogger;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_reject_create_modify_cancel_strategy_message;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_report_order_message;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_report_strategy_message;
import com.ubs.manhatthan.manager.persistence.entities.OrderTrade;
import com.ubs.manhatthan.manager.persistence.entities.StrategyOrders;
import com.ubs.manhatthan.manager.persistence.entities.StrategyReport;
import com.ubs.manhatthan.manager.utils.Util;
import com.ubs.manhatthan.model.StrategyMessagePersistence;

/**
 * @author Resource
 * 
 */
@Service
@Scope("singleton")
public class PersistenceThread implements Runnable {

	@Autowired
	private Facade facade;

	private int blockLenght;

	@Override
	public void run() {
		ApplicationLogger.logInfo("======================================================================================");
		ApplicationLogger.logInfo("Thread: " + Thread.currentThread().getName() + " iniciada");
		ApplicationLogger.logInfo("======================================================================================");

		blockLenght = Integer.parseInt(Util.getPropertyFromFile("manhattan.cache.temporary.message.blockLenght"));

		OutputStream out = null;
		OutputStreamWriter osw = null;
		BufferedWriter bw = null;

		try {
			out = new FileOutputStream(new File(Util.getPropertyFromFile("manhattan.log.location"), "contingencia.log"));
			osw = new OutputStreamWriter(out);
			bw = new BufferedWriter(osw);

			while (!Thread.interrupted()) {
				try {
					List<StrategyMessagePersistence> listStrategyReportPersistence = MessageCache.getMessages(blockLenght);

					if (listStrategyReportPersistence != null) {

						for (int i = 0; i < listStrategyReportPersistence.size(); i++) {
							if (listStrategyReportPersistence.get(i).getMessage() instanceof pb_report_strategy_message) {
								pb_report_strategy_message message = (pb_report_strategy_message) listStrategyReportPersistence.get(i).getMessage();

								StrategyReport report = ConverterToEntity.convertToStrategy(listStrategyReportPersistence.get(i).getEngineId(), message);

								try {
									facade.saveReport(report);
									throw new Exception();
								} catch (Exception e) {
									bw.write(report.toContigenciaLog());
									bw.flush();
								}

							} else if (listStrategyReportPersistence.get(i).getMessage() instanceof pb_report_order_message) {
								pb_report_order_message message = (pb_report_order_message) listStrategyReportPersistence.get(i).getMessage();

								StrategyOrders orders = ConverterToEntity.convertToStrategy(listStrategyReportPersistence.get(i).getEngineId(), message);

								try {
									facade.saveOrder(orders);
								} catch (Exception e) {
									
									bw.write(orders.toContigenciaLog());
									bw.flush();
									
									if (ExecutionTypeEnum.TRADE.getCode().equals( orders.getExecutionType().getCode())) {
										OrderTrade orderTrade = ConverterToEntity.convertToOrderTrade(orders);
										
										bw.write(orderTrade.toContigenciaLog());
										bw.flush();
									}
								}

							} else if (listStrategyReportPersistence.get(i).getMessage() instanceof pb_reject_create_modify_cancel_strategy_message) {
								// pb_reject_create_modify_cancel_strategy_message message = (pb_reject_create_modify_cancel_strategy_message) listStrategyReportPersistence.get(i).getMessage();
							} else {
								ApplicationLogger.logWarn("======================================================================================");
								ApplicationLogger.logWarn("Tipo desconhecido: \t" + listStrategyReportPersistence.get(i).getMessage());
								ApplicationLogger.logWarn("======================================================================================");
							}
						}
					}

					Thread.sleep(1000);

				} catch (Exception e) {
					e.printStackTrace();

					ApplicationLogger.logError("Erro na thread de persistencia. ", e);
				}
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();

			ApplicationLogger.logError("Arquivo de contingencia nao encontrado.", e);

		} finally {
			if (bw != null)
				try {
					bw.close();
				} catch (IOException e) { /* ignorar */
				}

			if (osw != null)
				try {
					osw.close();
				} catch (IOException e) { /* ignorar */
				}

			if (out != null)
				try {
					out.close();
				} catch (IOException e) { /* ignorar */
				}
		}

	}

}
