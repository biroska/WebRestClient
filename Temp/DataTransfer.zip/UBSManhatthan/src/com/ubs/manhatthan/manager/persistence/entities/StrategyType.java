package com.ubs.manhatthan.manager.persistence.entities;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name="TB_DOMAIN_STRATEGY_TYPE",
uniqueConstraints={
		   @UniqueConstraint(columnNames={"DESCRIPTION"}, name = "CK_STRATEGY_TYPE_DESCRIPTION")
		})
public class StrategyType implements Serializable {
	
	private static final long serialVersionUID = -6678940486723650040L;

	public StrategyType(){}
	
	public StrategyType(Integer strategyCode, String description, Integer numberOfLegs) {
		super();
		this.strategyCode = strategyCode;
		this.description = description;
		this.numberOfLegs = numberOfLegs;
	}
	
	public StrategyType(Integer strategyCode) {
		super();
		this.strategyCode = strategyCode;
	}
	
	public StrategyType(String description) {
		this.description = description;
	}

	@Id
	@Column ( name = "ID")
	@SequenceGenerator(name = "TB_DOMAIN_STRATEGY_TYPE_ID_GENERATOR", sequenceName = "SEQ_STRATEGY_TYPE", allocationSize = 1)
	@GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "TB_DOMAIN_STRATEGY_TYPE_ID_GENERATOR" )
	private Long id;
	
	@Column ( name = "STRATEGY_CODE", nullable=false )
	private Integer strategyCode;
	
	@Column ( name = "DESCRIPTION", nullable=false, length = 32 )
	private String description;
	
	@Column ( name = "NUMBER_OF_LEGS", nullable=false )
	private Integer numberOfLegs;
	
	@Column ( name = "ORDER_PER_SECOND", nullable=false )
	private Integer orderBySecond;
	
	@OneToMany(mappedBy = "strategyType", fetch=FetchType.EAGER, cascade = CascadeType.ALL)
	@OrderBy("legSeq ASC")
	private List<StrategyTypeLeg> strategyTypeLegList;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Integer getStrategyCode() {
		return strategyCode;
	}

	public void setStrategyCode(Integer strategyCode) {
		this.strategyCode = strategyCode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getNumberOfLegs() {
		return numberOfLegs;
	}

	public void setNumberOfLegs(Integer numberOfLegs) {
		this.numberOfLegs = numberOfLegs;
	}
	
	public Integer getOrderBySecond() {
		return orderBySecond;
	}

	public void setOrderBySecond(Integer orderBySecond) {
		this.orderBySecond = orderBySecond;
	}

	public List<StrategyTypeLeg> getStrategyTypeLegList() {
		return strategyTypeLegList;
	}

	public void setStrategyTypeLegList(List<StrategyTypeLeg> strategyTypeLegList) {
		this.strategyTypeLegList = strategyTypeLegList;
	}
	
//	Seta o relacionamento entre StrategyType e StrategyTypeLeg
	public StrategyTypeLeg addStrategyTypeLeg( StrategyTypeLeg strategyTypeLeg ){
		if ( getStrategyTypeLegList() == null )
			setStrategyTypeLegList( new ArrayList<StrategyTypeLeg>() );
		
		getStrategyTypeLegList().add( strategyTypeLeg );
		strategyTypeLeg.setStrategyType( this );
		
		return strategyTypeLeg;
	}
	
	public StrategyTypeLeg removeStrategyTypeLeg( StrategyTypeLeg legStrategyReport ){
		getStrategyTypeLegList().remove( legStrategyReport );
		legStrategyReport.setStrategyType( null );
		
		return legStrategyReport;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((description == null) ? 0 : description.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result
				+ ((numberOfLegs == null) ? 0 : numberOfLegs.hashCode());
		result = prime * result
				+ ((orderBySecond == null) ? 0 : orderBySecond.hashCode());
		result = prime * result
				+ ((strategyCode == null) ? 0 : strategyCode.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StrategyType other = (StrategyType) obj;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (numberOfLegs == null) {
			if (other.numberOfLegs != null)
				return false;
		} else if (!numberOfLegs.equals(other.numberOfLegs))
			return false;
		if (orderBySecond == null) {
			if (other.orderBySecond != null)
				return false;
		} else if (!orderBySecond.equals(other.orderBySecond))
			return false;
		if (strategyCode == null) {
			if (other.strategyCode != null)
				return false;
		} else if (!strategyCode.equals(other.strategyCode))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "StrategyType [id=" + id + ", strategyCode=" + strategyCode
				+ ", description=" + description + ", numberOfLegs="
				+ numberOfLegs + ", orderBySecond=" + orderBySecond + "]";
	}
}