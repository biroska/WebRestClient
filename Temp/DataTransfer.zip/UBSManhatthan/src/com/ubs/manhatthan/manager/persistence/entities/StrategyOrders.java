package com.ubs.manhatthan.manager.persistence.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import com.ubs.manhatthan.manager.enums.ExecutionTypeEnum;
import com.ubs.manhatthan.manager.enums.OrderStatusEnum;
import com.ubs.manhatthan.manager.enums.OrderTypeEnum;
import com.ubs.manhatthan.manager.enums.SideEnum;
import com.ubs.manhatthan.manager.enums.TimeInForceEnum;
import com.ubs.manhatthan.manager.persistence.entities.id.StrategyOrdersPK;

@Entity
@Table(name="TB_STRATEGY_ORDERS")
public class StrategyOrders extends Strategy implements Serializable {
	
	private static final long serialVersionUID = -3917990608159128371L;

	public StrategyOrders(){
		this.header = new Header();
		this.id = new StrategyOrdersPK();
	}
	
	@EmbeddedId
	private StrategyOrdersPK id;
	
	@Temporal ( TemporalType.TIMESTAMP )
	@Column ( name = "ORDER_TIMESTAMP", nullable=false )
	private Date orderTimestamp;
	
	@ManyToOne(fetch=FetchType.LAZY, cascade = CascadeType.ALL )
	@JoinColumns({
		  @JoinColumn( name = "ENGINE_ID", referencedColumnName = "ENGINE_ID" , nullable = true, insertable = false, updatable= false ),
		  @JoinColumn( name = "STRATEGY_DATE", referencedColumnName = "STRATEGY_DATE" , nullable = true, insertable = false, updatable= false ),
		  @JoinColumn( name = "STRATEGY_ID", referencedColumnName = "STRATEGY_ID" , nullable = true, insertable = false, updatable= false ),
		  @JoinColumn( name = "LEG_SEQ", referencedColumnName = "LEG_SEQ" , nullable = true, insertable = false, updatable= false )
		})
	private LegStrategyReport legStrategyReport;
	
	@Temporal(TemporalType.DATE)
	@Column ( name = "STRATEGY_DATE", nullable = false)
	private Date strategyDate;
	
	@Column ( name = "STRATEGY_ID", nullable = false)
	private Long strategyId;
	
	@Column ( name = "LEG_SEQ", nullable = false)
	private Integer legSeq;
	
	@Column ( name = "EXECUTED_QUANTITY", nullable = false)
	private Long executedQuantity;
	
	@Column ( name = "AVERAGE_PRICE", columnDefinition="Decimal(13,7)")
	private Double averagePrice;
	
	@Column ( name = "SYMBOL", nullable = false)
	private String symbol;
	
	@Column ( name = "SIDE", nullable = false)
	private SideEnum side;
	
	@Column ( name = "QUANTITY", nullable = false)
	private Long quantity;
	
	@Column ( name = "REMAINING_QTY", nullable = false)
	private Long remainingQuantity;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "ROUTE_ID", nullable = false )
	private OrderFixSession routeId;
	
	@Column ( name = "ORDER_TYPE", nullable = false)
	private OrderTypeEnum orderType;
	
	@Column ( name = "TIME_IN_FORCE", nullable = false)
	private TimeInForceEnum timeInForce;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "ACCOUNT", nullable = false )
	private ClientAccount account;
	
	@Column(name = "CLIENT_ORDER_ID" )
	private String clientOrderId;
	
	@Column ( name = "ORDER_STATUS", nullable = false)
	private OrderStatusEnum orderStatus;
	
	@Column ( name = "EXECUTION_TYPE", nullable = false)
	private ExecutionTypeEnum executionType;
	
	@Column ( name = "PRICE", columnDefinition= "Decimal(13,7)" )
	private Double price;
	
	@Column ( name = "TEXT", length = 256)
	private String text;
	
	@Column ( name = "LOGIN", length = 64)
	private String login;
	
	// Campo enviado pela tela para o engine
	@Transient
	private boolean market;
	
	@Transient
	private Header header;
	
	@Transient
	private String tradeId;
	
	@Transient
	private Long lastQuantity;
	
	@Transient
	private Double lastPrice;
	
	public StrategyOrdersPK getId() {
		return id;
	}

	public void setId(StrategyOrdersPK id) {
		this.id = id;
	}

	public Date getOrderTimestamp() {
		return orderTimestamp;
	}

	public void setOrderTimestamp(Date orderTimestamp) {
		this.orderTimestamp = orderTimestamp;
	}

	public LegStrategyReport getLegStrategyReport() {
		return legStrategyReport;
	}

	public void setLegStrategyReport(LegStrategyReport legStrategyReport) {
		this.legStrategyReport = legStrategyReport;
	}

	public Date getStrategyDate() {
		return strategyDate;
	}

	public void setStrategyDate(Date strategyDate) {
		this.strategyDate = strategyDate;
	}

	public Long getStrategyId() {
		return strategyId;
	}

	public void setStrategyId(Long strategyId) {
		this.strategyId = strategyId;
	}

	public Integer getLegSeq() {
		return legSeq;
	}

	public void setLegSeq(Integer legSeq) {
		this.legSeq = legSeq;
	}

	public Long getExecutedQuantity() {
		return executedQuantity;
	}

	public void setExecutedQuantity(Long executedQuantity) {
		this.executedQuantity = executedQuantity;
	}

	public Double getAveragePrice() {
		return averagePrice;
	}

	public void setAveragePrice(Double averagePrice) {
		this.averagePrice = averagePrice;
	}

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	public SideEnum getSide() {
		return side;
	}

	public void setSide(SideEnum side) {
		this.side = side;
	}

	public Long getQuantity() {
		return quantity;
	}

	public void setQuantity(Long quantity) {
		this.quantity = quantity;
	}

	public Long getRemainingQuantity() {
		return remainingQuantity;
	}

	public void setRemainingQuantity(Long remainingQuantity) {
		this.remainingQuantity = remainingQuantity;
	}

	public OrderFixSession getRouteId() {
		return routeId;
	}

	public void setRouteId(OrderFixSession routeId) {
		this.routeId = routeId;
	}

	public OrderTypeEnum getOrderType() {
		return orderType;
	}

	public void setOrderType(OrderTypeEnum orderType) {
		this.orderType = orderType;
	}

	public TimeInForceEnum getTimeInForce() {
		return timeInForce;
	}

	public void setTimeInForce(TimeInForceEnum timeInForce) {
		this.timeInForce = timeInForce;
	}

	public ClientAccount getAccount() {
		return account;
	}

	public void setAccount(ClientAccount account) {
		this.account = account;
	}

	public String getClientOrderId() {
		return clientOrderId;
	}

	public void setClientOrderId(String clientOrderId) {
		this.clientOrderId = clientOrderId;
	}

	public OrderStatusEnum getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(OrderStatusEnum orderStatus) {
		this.orderStatus = orderStatus;
	}

	public ExecutionTypeEnum getExecutionType() {
		return executionType;
	}

	public void setExecutionType(ExecutionTypeEnum executionType) {
		this.executionType = executionType;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}
	
	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public boolean isMarket() {
		return market;
	}

	public void setMarket(boolean market) {
		this.market = market;
	}

	public Header getHeader() {
		return header;
	}

	public void setHeader(Header header) {
		this.header = header;
	}

	public String getTradeId() {
		return tradeId;
	}

	public void setTradeId(String tradeId) {
		this.tradeId = tradeId;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}
	
	public Long getLastQuantity() {
		return lastQuantity;
	}

	public void setLastQuantity(Long lastQuantity) {
		this.lastQuantity = lastQuantity;
	}

	public Double getLastPrice() {
		return lastPrice;
	}

	public void setLastPrice(Double lastPrice) {
		this.lastPrice = lastPrice;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		StrategyOrders other = (StrategyOrders) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
	
	public String toContigenciaLog() {
		
		String order_report = "|order_report|";
		
		if (id!=null) {
			order_report += "ENGINE_ID=" + id.getEngineId()
			+ ",ORDER_ID=" + id.getOrderId()
			+ ",ORDER_DATE=" + id.getOrderDate();
		}else{
			order_report += "ENGINE_ID="
			+ ",ORDER_ID="
			+ ",ORDER_DATE=";
		}

		order_report += ",ORDER_TIMESTAMP=" + orderTimestamp
		+ ",STRATEGY_DATE=" + strategyDate
		+ ",STRATEGY_ID=" + strategyId
		+ ",LEG_SEQ=" + legSeq
		+ ",EXECUTED_QUANTITY=" + executedQuantity
		+ ",AVERAGE_PRICE=" + averagePrice
		+ ",SYMBOL=" + symbol
		+ ",SIDE=" + side
		+ ",QUANTITY=" + quantity
		+ ",REMAINING_QTY=" + remainingQuantity;
		
		if (routeId!= null) {
			order_report += ",ROUTE_ID=" + routeId.getId();
		}else{
			order_report += ",ROUTE_ID=";
		}		
		
		order_report += ",ORDER_TYPE=" + orderType
		+ ",TIME_IN_FORCE=" + timeInForce;
		
		if (account!= null) {
			order_report += ",ACCOUNT=" + account.getCode();
		}else{
			order_report += ",ACCOUNT=";
		}
		
		order_report += ",CLIENT_ORDER_ID=" + clientOrderId
		+ ",ORDER_STATUS=" + orderStatus
		+ ",EXECUTION_TYPE=" + executionType
		+ ",PRICE=" + price
		+ ",TEXT=" + text
		+ ",LOGIN=" + login + "|\n";	
		
		return order_report;
	}

	@Override
	public String toString() {
		return "StrategyOrders [id=" + id + ", orderTimestamp=" + orderTimestamp +  ", strategyDate=" + strategyDate 
				+ ", strategyId=" + strategyId + ", legSeq="
				+ legSeq + ", executedQuantity=" + executedQuantity + ", averagePrice=" + averagePrice + ", symbol="
				+ symbol + ", side=" + side + ", quantity=" + quantity + ", remainingQuantity=" + remainingQuantity
				+ ", routeId=" + routeId + ", orderType=" + orderType + ", timeInForce=" + timeInForce + ", account="
				+ account + ", clientOrderId=" + clientOrderId + ", orderStatus=" + orderStatus + ", executionType="
				+ executionType + ", price=" + price + ", text=" + text + ", login=" + login + ", market=" + market 
				+ ", header=" + header + ", tradeId="+ tradeId + "]\n";
	}
}