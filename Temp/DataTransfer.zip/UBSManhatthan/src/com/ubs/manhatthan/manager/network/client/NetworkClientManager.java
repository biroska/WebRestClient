//Package
package com.ubs.manhatthan.manager.network.client;

//Import
import java.io.IOException;

import org.apache.log4j.Level;

import com.ubs.manhatthan.exception.EngineExceptionManhattan;
import com.ubs.manhatthan.exception.MessageExceptionManhattan;
import com.ubs.manhatthan.manager.cache.MessageCache;
import com.ubs.manhatthan.manager.cache.StrategyCache;
import com.ubs.manhatthan.manager.logger.ManhattanLogger;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_legged_order;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_message_type_enum;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_reject_create_modify_cancel_strategy_message;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_report_order_message;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_report_strategy_message;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_statistics_message;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_to_engine_message;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_warning_message;
import com.ubs.manhatthan.manager.service.ServiceException;
import com.ubs.manhatthan.manager.utils.Util;
import com.ubs.manhatthan.model.StrategyReport;

//Test network client
public class NetworkClientManager implements NetworkClient.NetworkClientCallback{

	//Private members
	final private NetworkClient m_client;
	private String messageToLog;
	
	@SuppressWarnings("unused")
	private StrategyReport strategyReport;
	
	private Long engineId;

	public boolean Start() {
		
		boolean success = false;

		try {
			success = m_client.onLoad() && m_client.onStart();
			
		} catch (ServiceException e) {}
		
		return success;
		
	}
	
	public void Stop(){
		

		try {
			m_client.onUnLoad();
			
		} catch (ServiceException e) {}
		

		
		try {
			m_client.onStop();
			
		} catch (ServiceException e) {}
		
	}
	
	public boolean isLoggedOn(){
		
		return m_client.isLoggedOn();
	}
	
	//Constructor
	public NetworkClientManager(String address, int port){
		m_client = new NetworkClient(this, address, port);
		engineId = new Long(0);	
	}
	
	public void send(pb_to_engine_message msg) throws EngineExceptionManhattan, MessageExceptionManhattan, IOException {
		try {
			m_client.send(msg);
		} catch (EngineExceptionManhattan e) {
			e.printStackTrace();
			
			throw e;
		} catch (MessageExceptionManhattan e) {
			e.printStackTrace();
			
			throw e;
		} catch (IOException e) {
			e.printStackTrace();
			
			throw e;
		}
	}
	
	//Function
	public NetworkClient getService(){
		return m_client;
	}
	
	@Override
	public void onStart(){
		onPrint("Client Process - [onStart]");		
	}
	
	@Override
	public void onStop(){
		onPrint("Client Process - [onStop]");
	}
	
	@Override
	public void onPrint(String msg){
		ManhattanLogger.log( ""+Util.getManagerId(), msg, Level.INFO );
	}
	
	@Override
	public void onLoad(){
		onPrint("Client Process - [onLoad]");
	}
	
	@Override
	public void onUnLoad(){
		onPrint("Client Process - [onUnLoad]");
	}
	
	@Override
	public void onConnect() {
		onPrint("Client Process - [onConnect]");
	}
	
	@Override
	public void onLogon() {				
		onPrint("Client Process - [onLogon]");
		
		//Check if engine and instance is ha a new value, in this case engine its down and 
		//strategies associates with him must be send like error
		if(engineId!=null && m_client!=null && engineId != m_client.engineId()) {
			
			if (engineId != 0L) {
				StrategyCache.invalidateStrategiesForInstance(engineId, true);
			}
			
			//New Engine Instance
			engineId = m_client.engineId();
		}
	}
	
	@Override
	public void onLogoff(String str){
		onPrint("Client Process - [onLogoff] message: " + str);
	}

	@Override
	public void onDisconnect() {
		onPrint("Client Process - [onDisconnect]");
		
		StrategyCache.invalidateStrategiesForInstance(m_client.engineId(), false);
	}
	
	@Override
	public void onMessage_ReportStrategy(long manager_id, long request_id, pb_report_strategy_message msg) {		
		messageToLog = buildLog("onMessage_ReportStrategy", manager_id, request_id, msg);
		onPrint(messageToLog);
		
		if ( msg.isInitialized() ) {
			StrategyCache.processStrategy(m_client.engineId(), request_id, msg);
			
			MessageCache.putMessage(m_client.engineId(), msg);
		}
	}
	
	@Override
	public void onMessage_RejectStrategy(long manager_id, long request_id, pb_message_type_enum msg_type, pb_reject_create_modify_cancel_strategy_message msg) {
		messageToLog = buildLog("onMessage_RejectStrategy", manager_id, request_id, msg);
		onPrint(messageToLog);
		
		if ( msg.isInitialized() ){
			if (msg_type == pb_message_type_enum.PB_REJECT_PAUSE_STRATEGY || 
					msg_type == pb_message_type_enum.PB_REJECT_RESUME_STRATEGY ||
					msg_type == pb_message_type_enum.PB_REJECT_CANCEL_STRATEGY) {			
						StrategyCache.updateTextStrategy(m_client.engineId(), msg.getStrategyId(), msg.getText());
			} else {
				if (msg_type != pb_message_type_enum.PB_REJECT_CREATE_STRATEGY) { // Update only messages that has a strategy id
					StrategyCache.invalidateStrategy(m_client.engineId(), msg.getStrategyId(), msg.getText());
				}
			}

			MessageCache.putMessage(m_client.engineId(), msg);
		}
	}
	
	@Override
	public void onMessage_ReportOrder(long manager_id, long request_id, pb_report_order_message msg) {
		messageToLog = buildLog("onMessage_ReportOrder", manager_id,request_id, msg);
		onPrint(messageToLog);
		
		if (msg.isInitialized()) {
			MessageCache.putMessage(m_client.engineId(), msg);
		}
	}

	@Override
	public void onMessage_RejectExecutionOrder(long manager_id, long request_id, pb_reject_create_modify_cancel_strategy_message msg) {
		messageToLog = buildLog("onMessage_RejectExecutionOrder", manager_id, request_id, msg);
		onPrint(messageToLog);
	
		if ( msg.isInitialized() ) {
				
			StrategyCache.rejectOrder(m_client.engineId(), request_id, msg);
		}
	}
	
	@Override
	public void onMessage_LeggedOrder(long manager_id, long request_id, pb_legged_order msg) {		
		messageToLog = buildLog("onMessage_LeggedOrder", manager_id, request_id, msg);
		onPrint(messageToLog);
		
		if (msg.isInitialized()) {
			StrategyCache.processOrderLegged(m_client.engineId(), request_id, msg);
		}
	}
	
	@Override
	public void onMessage_Statistics(long manager_id, long request_id, pb_statistics_message msg) {
		if ( m_client.managerId() == manager_id ){
			messageToLog = buildLog("onMessage_Statistics", manager_id, request_id, msg);
			onPrint( messageToLog );
		}
	}
	
	@Override
	public void onMessage_Warning(long manager_id, long request_id, pb_warning_message msg) {
		if ( m_client.managerId() == manager_id ){
			messageToLog = buildLog("onMessage_Warning", manager_id, request_id, msg);
			onPrint( messageToLog );
		}
	}
	
	private String buildLog( String method, long manager_id, long request_id, Object msg) {
		return "[" + method + "] \n EngineId: " + m_client.engineId() + "\n ManagerId: "+ manager_id +"\n RequestId: " + request_id + "\n message: " + msg.toString();
	}
	
	@SuppressWarnings("unused")
	private String buildLog( String method, long manager_id, long request_id, pb_message_type_enum messageType, Object msg ) {
		return "[" + method + "] \n EngineId: " + m_client.engineId() + "\n ManagerId: "+ manager_id +"\n RequestId: " + request_id + "\n messageType: " + messageType + "\n message: " + msg.toString();
	}
}