package com.ubs.manhatthan.manager.lmdsadapter;

import com.ubs.manhatthan.manager.simulator.multileg.InputMultilegSimulation;
import com.ubs.manhatthan.manager.simulator.multileg.ReturnMultilegSimulation;

public class SimulationItem
{
	private boolean onlySymbol;

	private InputMultilegSimulation buyInputMultilegSimulationList;
	private InputMultilegSimulation sellInputMultilegSimulationList;

	private ReturnMultilegSimulation buyReturnMultilegSimulation;
	private ReturnMultilegSimulation sellReturnMultilegSimulation;

	private Long   LastQty;
	private Double LastPx;
	private String BuyQty;
	private Double BuyPx;
	private String SellQty;
	private Double SellPx;
	
	public SimulationItem()
	{
		buyInputMultilegSimulationList  = new InputMultilegSimulation();
		sellInputMultilegSimulationList = new InputMultilegSimulation();
		
		buyReturnMultilegSimulation  = new ReturnMultilegSimulation();
		sellReturnMultilegSimulation = new ReturnMultilegSimulation();
		
		this.LastQty = null;
		this.LastPx  = null;
		this.BuyQty  = null;
		this.BuyPx   = null;
		this.SellQty = null;
		this.SellPx  = null;
	}
	
	public boolean isOnlySymbol()
	{
		return onlySymbol;
	}
	
	public void setOnlySymbol(boolean onlySymbol)
	{
		this.onlySymbol = onlySymbol;
	}
	
	public InputMultilegSimulation getBuyInputMultilegSimulationList()
	{
		return buyInputMultilegSimulationList;
	}
	
	public void setBuyInputMultilegSimulationList(InputMultilegSimulation buyInputMultilegSimulationList)
	{
		this.buyInputMultilegSimulationList = buyInputMultilegSimulationList;
	}
	
	public InputMultilegSimulation getSellInputMultilegSimulationList()
	{
		return sellInputMultilegSimulationList;
	}
	
	public void setSellInputMultilegSimulationList(InputMultilegSimulation sellInputMultilegSimulationList)
	{
		this.sellInputMultilegSimulationList = sellInputMultilegSimulationList;
	}
	
	public Long getLastQty()
	{
		return LastQty;
	}
	
	public void setLastQty(Long lastQty)
	{
		LastQty = lastQty;
	}
	
	public Double getLastPx()
	{
		return LastPx;
	}
	
	public void setLastPx(Double lastPx)
	{
		LastPx = lastPx;
	}
	
	public String getBuyQty()
	{
		return BuyQty;
	}
	
	public void setBuyQty(Long buyQty)
	{		
		if( null != buyQty) { BuyQty = buyQty.toString(); return; }
		
		BuyQty = "";
	}
	
	public Double getBuyPx()
	{
		return BuyPx;
	}
	
	public void setBuyPx(Double buyPx)
	{
		BuyPx = buyPx;
	}
	
	public String getSellQty()
	{
		return SellQty;
	}
	
	public void setSellQty(Long sellQty)
	{
		if( null != sellQty) { SellQty = sellQty.toString(); return; }
		
		SellQty = "";
	}
	
	public Double getSellPx()
	{
		return SellPx;
	}
	
	public void setSellPx(Double sellPx)
	{
		SellPx = sellPx;
	}
	
	public ReturnMultilegSimulation getBuyReturnMultilegSimulation()
    {
		return buyReturnMultilegSimulation;
	}
	
	public void setBuyReturnMultilegSimulation(ReturnMultilegSimulation buyReturnMultilegSimulation)
	{
		this.buyReturnMultilegSimulation = buyReturnMultilegSimulation;
	}
	
	public ReturnMultilegSimulation getSellReturnMultilegSimulation()
	{
		return sellReturnMultilegSimulation;
	}
	
	public void setSellReturnMultilegSimulation(ReturnMultilegSimulation sellReturnMultilegSimulation)
	{
		this.sellReturnMultilegSimulation = sellReturnMultilegSimulation;
	}
	
	@Override
	public String toString()
	{
		return "SimulationItem [onlySymbol=" + onlySymbol
				+ ", buyInputMultilegSimulationList=" + buyInputMultilegSimulationList
				+ ", sellInputMultilegSimulationList=" + sellInputMultilegSimulationList
				+ ", LastQty=" + LastQty
				+ ", LastPx=" + LastPx
				+ ", BuyQty=" + BuyQty
				+ ", BuyPx=" + BuyPx
				+ ", SellQty=" + SellQty
				+ ", SellPx=" + SellPx
				+ "] \n";
	}
}