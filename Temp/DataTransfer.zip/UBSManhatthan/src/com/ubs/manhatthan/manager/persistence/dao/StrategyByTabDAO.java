package com.ubs.manhatthan.manager.persistence.dao;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IStrategyByTabAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IStrategyByTabDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IStrategyByTabLegAuditDAO;
import com.ubs.manhatthan.manager.persistence.entities.StrategyByTab;
import com.ubs.manhatthan.manager.persistence.entities.StrategyByTabLeg;
import com.ubs.manhatthan.manager.persistence.entities.audit.StrategyByTabAudit;
import com.ubs.manhatthan.manager.persistence.entities.audit.StrategyByTabLegAudit;

@Repository
@Scope("singleton")
public class StrategyByTabDAO extends GenericDAO<StrategyByTab, Long> implements IStrategyByTabDAO, Serializable {
	private static final long serialVersionUID = 1L;
	@Autowired
	private IStrategyByTabAuditDAO strategyByTabAuditDAO;
	
	@Autowired
	private IStrategyByTabLegAuditDAO strategyByTabLegAuditDAO;
	
	@Autowired
	private User user;
	
	@Override
	public StrategyByTab saveStrategyByTab( StrategyByTab strategyByTab ) throws DAOExceptionManhattan {
		try{
		
			ActionTypeEnum action = strategyByTab.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;
			ActionTypeEnum actionLeg = ActionTypeEnum.INSERT;
			
			if (strategyByTab!=null && strategyByTab.getStrategyByTabLegs()!=null && !strategyByTab.getStrategyByTabLegs().isEmpty()) {				
				actionLeg = strategyByTab.getStrategyByTabLegs().get(0).getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;
			}			
	
			strategyByTab = update( strategyByTab );
	
			StrategyByTabAudit sta = new StrategyByTabAudit( strategyByTab, action, user.getLogin(), new Date() );
			
			strategyByTabAuditDAO.update( sta );
			
			if (strategyByTab.getStrategyByTabLegs()!=null) {
				
				for (StrategyByTabLeg strategyByTabLeg : strategyByTab.getStrategyByTabLegs()) {	
					
					StrategyByTabLegAudit staLeg = new StrategyByTabLegAudit( strategyByTabLeg, actionLeg, user.getLogin(), new Date() );					
					strategyByTabLegAuditDAO.update(staLeg);
				}				
			}
		}
		catch(Exception e){
			throw new DAOExceptionManhattan(e);	
		}
		
		return strategyByTab;
	}
	
	@Override
	public StrategyByTab getStrategyByTab(StrategyByTab strategyByTab) throws DAOExceptionManhattan{
		StrategyByTab obj = null;
		try {
			CriteriaBuilder criteriaBuilder = getEm().getCriteriaBuilder();
	
			CriteriaQuery<StrategyByTab> criteriaQuery = criteriaBuilder.createQuery(StrategyByTab.class);
			Root<StrategyByTab> root = criteriaQuery.from(StrategyByTab.class);
			criteriaQuery.where( criteriaBuilder.equal( root.get( "instrument" ), strategyByTab.getInstrument() ) );
			criteriaQuery.where( criteriaBuilder.equal( root.get( "tab" ), strategyByTab.getTab() ) );		
			criteriaQuery.where( criteriaBuilder.equal( root.get( "strategyType" ), strategyByTab.getStrategyType() == null ? null :  strategyByTab.getStrategyType() ) );		
	
	
			
			criteriaQuery.select( root );
	
			obj = getEm().createQuery(criteriaQuery).getSingleResult();
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return obj;
	}

	public void setStrategyByTabAuditDAO(IStrategyByTabAuditDAO strategyByTabAuditDAO) {
		this.strategyByTabAuditDAO = strategyByTabAuditDAO;
	}

	public void setUser(User user) {
		this.user = user;
	}
}