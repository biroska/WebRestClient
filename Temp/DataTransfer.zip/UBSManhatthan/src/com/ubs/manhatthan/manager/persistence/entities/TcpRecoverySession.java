package com.ubs.manhatthan.manager.persistence.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name="TB_TCP_RECOVERY_SESSIONS",
	   uniqueConstraints={
		   @UniqueConstraint(columnNames={"HOST", "PORT"}, name = "CK_TCP_RECOVER_SESS_HOST_PORT"),
		   @UniqueConstraint(columnNames={"TARGET_COMP_ID", "SENDER_COMP_ID"}, name = "CK_TCP_RECOVER_TARGET_SENDER")
		})
public class TcpRecoverySession implements Serializable {
	private static final long serialVersionUID = 1L;
	public TcpRecoverySession(){}

    public TcpRecoverySession(Long id, Exchange exchange, String host, Long port,
            String targetCompId, String senderCompId, Integer idEngine, Long engineId) {
     super();
     this.id = id;
     this.exchange = exchange;
     this.host = host;
     this.port = port;
     this.targetCompId = targetCompId;
     this.senderCompId = senderCompId;
     this.idEngine = idEngine;
     this.engineId = engineId;
    }

    public TcpRecoverySession(Exchange exchange, String host, Long port,
			String targetCompId, String senderCompId) {
		super();
		this.exchange = exchange;
		this.host = host;
		this.port = port;
		this.targetCompId = targetCompId;
		this.senderCompId = senderCompId;
	}
	
	public TcpRecoverySession(Exchange exchange, String host, Long port,
			String targetCompId, String senderCompId, Long engineId) {
		super();
		this.exchange = exchange;
		this.host = host;
		this.port = port;
		this.targetCompId = targetCompId;
		this.senderCompId = senderCompId;
		this.engineId = engineId;
	}

	@Id
	@Column ( name = "ID")
	@SequenceGenerator(name = "TB_TCP_RECOVERY_SESSIONS_ID_GENERATOR", sequenceName = "SEQ_TCP_RECOVERY_SESSIONS", allocationSize = 1)
	@GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "TB_TCP_RECOVERY_SESSIONS_ID_GENERATOR" )
	private Long id;
	
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name = "EXCHANGE", nullable = false )
	private Exchange exchange;
	
	@Column(name = "HOST", nullable = false, length = 256 )
	private String host;
	
	@Column(name = "PORT", nullable = false )
	private Long port;
	
	@Column(name = "TARGET_COMP_ID", nullable = false, length = 256 )
	private String targetCompId = "BVMF";
	
	@Column(name = "SENDER_COMP_ID", nullable = false, length = 256 )
	private String senderCompId;
	
	@Transient
	private Integer idEngine;
	
	@Transient
	private Long engineId;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Exchange getExchange() {
		return exchange;
	}

	public void setExchange(Exchange exchange) {
		this.exchange = exchange;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public Long getPort() {
		return port;
	}

	public void setPort(Long port) {
		this.port = port;
	}

	public String getTargetCompId() {
		return targetCompId;
	}

	public void setTargetCompId(String targetCompId) {
		this.targetCompId = targetCompId;
	}

	public String getSenderCompId() {
		return senderCompId;
	}

	public void setSenderCompId(String senderCompId) {
		this.senderCompId = senderCompId;
	}
	
	public Long getEngineId() {
		return engineId;
	}

	public void setEngineId(Long engineId) {
		this.engineId = engineId;
	}

	public Integer getIdEngine() {
		return idEngine;
	}

	public void setIdEngine(Integer idEngine) {
		this.idEngine = idEngine;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((exchange == null) ? 0 : exchange.hashCode());
		result = prime * result + ((host == null) ? 0 : host.hashCode());
		result = prime * result + ((port == null) ? 0 : port.hashCode());
		result = prime * result
				+ ((senderCompId == null) ? 0 : senderCompId.hashCode());
		result = prime * result
				+ ((targetCompId == null) ? 0 : targetCompId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TcpRecoverySession other = (TcpRecoverySession) obj;
		if (exchange == null) {
			if (other.exchange != null)
				return false;
		} else if (!exchange.equals(other.exchange))
			return false;
		if (host == null) {
			if (other.host != null)
				return false;
		} else if (!host.equals(other.host))
			return false;
		if (port == null) {
			if (other.port != null)
				return false;
		} else if (!port.equals(other.port))
			return false;
		if (senderCompId == null) {
			if (other.senderCompId != null)
				return false;
		} else if (!senderCompId.equals(other.senderCompId))
			return false;
		if (targetCompId == null) {
			if (other.targetCompId != null)
				return false;
		} else if (!targetCompId.equals(other.targetCompId))
			return false;
		return true;
	}
}