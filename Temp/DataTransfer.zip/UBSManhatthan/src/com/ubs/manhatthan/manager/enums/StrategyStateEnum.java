package com.ubs.manhatthan.manager.enums;

public enum StrategyStateEnum{
	
	UNKNOWN               	   ( 0 ),
	INITIALIZING               ( 1 ),
	PAUSING                    ( 2 ),
	RESUMING                   ( 3 ),
	CANCELLING                 ( 4 ),
	SCHEDULED                  ( 5 ),
	PAUSED                     ( 6 ),
	RUNNING                    ( 7 ),
	COMPLETED                  ( 8 ),
	CANCELLED                  ( 9 ),
	ERROR                      ( 10 ),
	DISCONNECT                 ( 11 );
    
    private final Integer code;
    
    private StrategyStateEnum( Integer code ) {
        this.code = code;
    }

    public Integer getCode() {
        return code;
    }
    
    public static StrategyStateEnum fromValue( Integer value ){
    	
		for (StrategyStateEnum item : StrategyStateEnum.values() ) {
			if ( item.getCode().equals( value ) ){
				return item;
			}
		}
		return null;
    }
}