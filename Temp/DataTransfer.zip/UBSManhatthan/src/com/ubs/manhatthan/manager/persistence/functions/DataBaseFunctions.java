/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.functions;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.manager.persistence.dao.GenericDAO;
import com.ubs.manhatthan.manager.utils.Util;

/**
 * @author galdinoa
 *
 */
@Repository
@Scope("singleton")
public class DataBaseFunctions extends GenericDAO<Object, Long> implements IDataBaseFunctions, Serializable {
	 
	private static final long serialVersionUID = 3225719604206818998L;

	@Override
	public Integer businessDayTotal2( Date beginningDt, Date endingDt ){
		
		return  callBusinessDays( beginningDt, endingDt, "INTEGRACAO.BUSINESDAYTOTAL2" );
	}
	
	@Override
	public Integer businessDayTotal( Date beginningDt, Date endingDt ){
		
		return  callBusinessDays( beginningDt, endingDt, "INTEGRACAO.BUSINESDAYTOTAL" );
	}
	
	@SuppressWarnings("rawtypes")
	private Integer callBusinessDays( Date beginningDt, Date endingDt, String function ){
		
		EntityManager em = getEm();
		List result = null;
		
		String sdfBeginningDt = Util.convertDatePattern( beginningDt, "yyyy/MM/dd" );
		String sdfendingDt = Util.convertDatePattern( endingDt, "yyyy/MM/dd" );
		
		try {
			
//			Query qye sera executada:
//			select INTEGRACAO."BUSINESDAYTOTAL2" ( TO_DATE('2015/10/12', 'yyyy/mm/dd HH:MI:SS' ) , TO_DATE('2015/10/16', 'yyyy/mm/dd HH:MI:SS') ) from dual;
			
			String datePattern = Util.getPropertyFromFile("manhattan.database.date.configuration");
			result = em.createNativeQuery("select " + function + " ( TO_DATE( :beginningDt , '" + datePattern + "' ) , " +
			                                                       " TO_DATE( :endingDt , '" + datePattern + "') ) from dual ")
					.setParameter( "beginningDt", sdfBeginningDt )
					.setParameter( "endingDt", sdfendingDt)
					.getResultList();
		} catch (Exception e){
			e.printStackTrace();
			return null;
		}
		
		if ( result == null || result.isEmpty()  )
			return null;
		
		int dias = ( (BigDecimal) result.get( 0 ) ).intValue();
		
		return dias;
	}
}