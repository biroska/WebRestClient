/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import java.util.Date;
import java.util.List;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.persistence.entities.StrategyReport;
import com.ubs.manhatthan.manager.persistence.entities.id.StrategyReportPK;

/**
 * @author galdinoa
 *
 */
public interface IStrategyReportDAO extends IGenericDAO<StrategyReport, StrategyReportPK> {

	public StrategyReport saveReport(StrategyReport report) throws DAOExceptionManhattan;

	public List<StrategyReport> getStrategyReportsByDate(Date date) throws DAOExceptionManhattan;
}
