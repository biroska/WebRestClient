/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import java.util.List;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.persistence.entities.StrategyByTab;
import com.ubs.manhatthan.manager.persistence.entities.TraderWatchTab;

/**
 * @author galdinoa
 *
 */
public interface ITraderWatchTabDAO extends IGenericDAO<TraderWatchTab, Long> {

	TraderWatchTab saveTraderWatchTab(TraderWatchTab traderWatchTab) throws DAOExceptionManhattan;
		
	List<TraderWatchTab> getListTraderWatchsTabsByLogin(String login) throws DAOExceptionManhattan;

	List<StrategyByTab> getListStrategyOrInstrumentByTab(
			TraderWatchTab traderWatchTab) throws DAOExceptionManhattan;
}
