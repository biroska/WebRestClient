package com.ubs.manhatthan.manager.utils;


import com.ubs.manhatthan.manager.enums.FilePropertiesEnum_remover;

public class EnvironmentVariables {
	
	private static Properties manhattanProperties;
	
	private static Properties messageProperties;
	
    public static Properties getManhattanProperties() {
		
		if (manhattanProperties == null) {
			manhattanProperties = new Properties( FilePropertiesEnum_remover.MANHATTAN_PROPERTIES.getPath() );
		}
		
		return manhattanProperties;
		
    }
    
    public static Properties getMessageProperties() {
		
		if (messageProperties == null) {
			messageProperties = new Properties( FilePropertiesEnum_remover.MESSAGE_PROPERTIES.getPath() );
		}
		
		return messageProperties;
		
    }
}
