/**
 * 
 */
package com.ubs.manhatthan.manager.converters;

import java.util.ArrayList;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeansException;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.persistence.entities.StrategyOrders;
import com.ubs.manhatthan.manager.persistence.entities.StrategyReport;
import com.ubs.manhatthan.manager.utils.Util;
import com.ubs.manhatthan.model.Account;

@Component
@Scope("singleton")
public class ConverterToModel {

    public static com.ubs.manhatthan.model.StrategyReport convertStrategyReportToModel(StrategyReport strategyReportEntity) throws BeansException, DAOExceptionManhattan {

		com.ubs.manhatthan.model.StrategyReport strategyReportModel = null;	
		
		if (strategyReportEntity != null) {
			strategyReportModel = new com.ubs.manhatthan.model.StrategyReport();
		
			BeanUtils.copyProperties(strategyReportEntity, strategyReportModel);
			
			strategyReportModel.setStrategyTimestamp(strategyReportEntity.getId().getStrategyDate());
			strategyReportModel.setStrategyId(strategyReportEntity.getId().getStrategyId());
			strategyReportModel.setEngineId(strategyReportEntity.getId().getEngineId());
			strategyReportModel.setStatus(strategyReportEntity.getStrategyState()==null?0:strategyReportEntity.getStrategyState().getCode());
			strategyReportModel.setStrategyType(new com.ubs.manhatthan.model.StrategyType());
			BeanUtils.copyProperties(strategyReportEntity.getStrategyType(), strategyReportModel.getStrategyType());
					
			strategyReportModel.getStrategyType().setStart(Util.convertDatePattern(strategyReportEntity.getStartTime(), "HH:mm"));
			strategyReportModel.getStrategyType().setEnd(Util.convertDatePattern(strategyReportEntity.getEndTime(), "HH:mm"));
						
			strategyReportModel.getStrategyType().setStrategyTypeLegList(new ArrayList<com.ubs.manhatthan.model.StrategyTypeLeg>());
			BeanUtils.copyProperties(strategyReportEntity.getStrategyType().getStrategyTypeLegList(), strategyReportModel.getStrategyType()
					.getStrategyTypeLegList());

			strategyReportModel.setStartPaused( strategyReportEntity.getStartPaused() );
			strategyReportModel.setRiskLevel( strategyReportEntity.getRiskLevel() );
			strategyReportModel.setRestingLevel( strategyReportEntity.getRestingLevel() );
			
			strategyReportModel.setStartTimeText(strategyReportEntity.getStartTime());
			strategyReportModel.setEndTimeText(strategyReportEntity.getEndTime());
			strategyReportModel.setText( strategyReportEntity.getText() );
			
			strategyReportModel.setLegStrategyList(new ArrayList<com.ubs.manhatthan.model.LegStrategyReport>());
			
			for (com.ubs.manhatthan.manager.persistence.entities.LegStrategyReport legStrategyReportEntity : strategyReportEntity.getLegStrategyList()) {
			
				com.ubs.manhatthan.model.LegStrategyReport legStrategyReportModel = convertLegStrategyReportEntityToReportModel(legStrategyReportEntity);
								
				legStrategyReportModel.setStrategyReport(strategyReportModel);
			
				strategyReportModel.getLegStrategyList().add(legStrategyReportModel);
			} 
		}
		
		return strategyReportModel;
	}
    
    public static com.ubs.manhatthan.model.LegStrategyReport convertLegStrategyReportEntityToReportModel(com.ubs.manhatthan.manager.persistence.entities.LegStrategyReport legStrategyReportEntity) throws BeansException, DAOExceptionManhattan {
    	com.ubs.manhatthan.model.LegStrategyReport legStrategyReportModel = null;
    	
    	if (legStrategyReportEntity != null) {
    		legStrategyReportModel = new com.ubs.manhatthan.model.LegStrategyReport();
    	
    		legStrategyReportModel.setEngineId(legStrategyReportEntity.getId().getEngineId());
    		legStrategyReportModel.setStrategyId(legStrategyReportEntity.getId().getStrategyId());
    		legStrategyReportModel.setLegSeq(legStrategyReportEntity.getId().getLegSeq());

    		com.ubs.manhatthan.model.StrategyReport strategyReportModel = new com.ubs.manhatthan.model.StrategyReport();
    		BeanUtils.copyProperties(legStrategyReportEntity.getStrategyReport(), strategyReportModel);
    		legStrategyReportModel.setStrategyReport(strategyReportModel);
    		
    		legStrategyReportModel.setSide(legStrategyReportEntity.getSide().getCode());
    		legStrategyReportModel.setTotalQuantity(legStrategyReportEntity.getTotalQuantity());
    		legStrategyReportModel.setExecutedQuantity(legStrategyReportEntity.getExecutedQuantity());
    		legStrategyReportModel.setRemainingQuantity(legStrategyReportEntity.getRemainingQuantity());
    		legStrategyReportModel.setText(legStrategyReportEntity.getText());
    		
    		legStrategyReportModel.setAveragePrice(legStrategyReportEntity.getAveragePrice());
    		legStrategyReportModel.setRestingQuantity(legStrategyReportEntity.getRestingQuantity());
    		legStrategyReportModel.setRestingPrice(legStrategyReportEntity.getRestingPrice());
    		legStrategyReportModel.setRestingRank(legStrategyReportEntity.getRestingRank());
    		legStrategyReportModel.setDuration(legStrategyReportEntity.getDuration());
    		legStrategyReportModel.setMaxQuantityDisplay(legStrategyReportEntity.getMaxQuantityDisplay());
    		legStrategyReportModel.setMinQuantityDisplay(legStrategyReportEntity.getMinQuantityDisplay());
    		legStrategyReportModel.setTimeInForce(legStrategyReportEntity.getTimeInForce());
    		legStrategyReportModel.setTimeOut(legStrategyReportEntity.getTimeOut());
    		legStrategyReportModel.setExecutedPercentage(legStrategyReportEntity.getExecutedPercentage());
    		legStrategyReportModel.setEnteringTrader(legStrategyReportEntity.getEnteringTrader());
    		legStrategyReportModel.setInvestorId(legStrategyReportEntity.getInvestorId());
    		legStrategyReportModel.setDuration(legStrategyReportEntity.getDuration());

    		//Nao eh necessario converter neste ponto pois a thread do subscriber convertera o instrumento para o contrato
    		//legStrategyReportModel.setContract(LmdsCache.getLmdsContractFromInstrument(legStrategyReportEntity.getInstrument()));
    		
    		legStrategyReportModel.setPassiveLeg(legStrategyReportEntity.getPassiveLeg());
    		
    		legStrategyReportModel.setClip( legStrategyReportEntity.getMaxQuantityDisplay() );
    		
    		Account account = new Account();
    		BeanUtils.copyProperties(legStrategyReportEntity.getAccount(), account);    		
    		legStrategyReportModel.setAccount(account);    		    		
    	}
    	
    	return legStrategyReportModel;
    }
    
    public static com.ubs.manhatthan.model.Unlegging convertStrategyOrderToUnleggingModel(StrategyOrders strategyOrderEntity) throws BeansException, DAOExceptionManhattan {
    	
    	com.ubs.manhatthan.model.Unlegging unleggingModel = null;
    	
    	if (strategyOrderEntity != null) {
    		unleggingModel = new com.ubs.manhatthan.model.Unlegging();
    		
    		unleggingModel.setStrategyId(strategyOrderEntity.getStrategyId());
    		unleggingModel.setLegSeq(strategyOrderEntity.getLegSeq());
    		unleggingModel.setOrderId(strategyOrderEntity.getId().getOrderId());
    		unleggingModel.setPrice(strategyOrderEntity.getPrice());
    		unleggingModel.setQty(strategyOrderEntity.getQuantity());
    		unleggingModel.setContract(strategyOrderEntity.getSymbol());
    		unleggingModel.setSide(strategyOrderEntity.getSide().getCode());
    		
    		if (strategyOrderEntity.getId()!=null) {
    			unleggingModel.setEngineId(strategyOrderEntity.getId().getEngineId());
			}
    	}
    	
    	return unleggingModel;
    }
}