/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import java.util.List;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.persistence.entities.EngineInstance;
import com.ubs.manhatthan.manager.persistence.entities.EngineUmdfChannel;
import com.ubs.manhatthan.manager.persistence.entities.UmdfChannelByEngine;

/**
 * @author galdinoa
 *
 */
public interface IUmdfChannelByEngineDAO extends IGenericDAO<UmdfChannelByEngine, Long> {

	UmdfChannelByEngine saveUmdfChannelByEngine(UmdfChannelByEngine umdfChannelByEngine) throws DAOExceptionManhattan;

	public List<EngineUmdfChannel> findByEngineId(Integer id)  throws DAOExceptionManhattan;

	public void deleteUmdfChanelByEngine(EngineInstance engine) throws DAOExceptionManhattan;
	
	public List<UmdfChannelByEngine> findUmdfByEngineId(Integer id) throws DAOExceptionManhattan;

}
