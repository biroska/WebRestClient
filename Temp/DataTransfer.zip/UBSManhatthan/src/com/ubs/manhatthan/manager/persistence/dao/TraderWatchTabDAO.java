package com.ubs.manhatthan.manager.persistence.dao;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.ITraderWatchTabAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.ITraderWatchTabDAO;
import com.ubs.manhatthan.manager.persistence.entities.StrategyByTab;
import com.ubs.manhatthan.manager.persistence.entities.TraderWatchTab;
import com.ubs.manhatthan.manager.persistence.entities.audit.TraderWatchTabAudit;

@Repository
@Scope("singleton")
public class TraderWatchTabDAO extends GenericDAO<TraderWatchTab, Long> implements ITraderWatchTabDAO, Serializable {
	private static final long serialVersionUID = 1L;
	@Autowired
	private ITraderWatchTabAuditDAO traderWatchTabAuditDAO;
	
	@Autowired
	private User user;
	
	@Override
	public TraderWatchTab saveTraderWatchTab( TraderWatchTab traderWatchTab ) throws DAOExceptionManhattan {
		try {
			ActionTypeEnum action = traderWatchTab.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;
	
			traderWatchTab = update( traderWatchTab );
	
			TraderWatchTabAudit sta = new TraderWatchTabAudit( traderWatchTab, action, traderWatchTab.getLogin(), new Date() );
			
			traderWatchTabAuditDAO.update( sta );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return traderWatchTab;
	}
	
	@Override
	public List<TraderWatchTab> getListTraderWatchsTabsByLogin(String login) throws DAOExceptionManhattan {
		List<TraderWatchTab> list = null;
		try {
			CriteriaBuilder criteriaBuilder = getEm().getCriteriaBuilder();
	
			CriteriaQuery<TraderWatchTab> criteriaQuery = criteriaBuilder.createQuery(TraderWatchTab.class);
			Root<TraderWatchTab> traderWatchTabRoot = criteriaQuery.from(TraderWatchTab.class);
			criteriaQuery.where( criteriaBuilder.equal( traderWatchTabRoot.get( "login" ), login.trim() ) );
			criteriaQuery.orderBy(criteriaBuilder.asc(traderWatchTabRoot.get( "id" )));
			
			criteriaQuery.select( traderWatchTabRoot );
	
			list = getEm().createQuery(criteriaQuery).getResultList();
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return list;
	}


	@Override
	public List<StrategyByTab> getListStrategyOrInstrumentByTab(
			TraderWatchTab traderWatchTab) throws DAOExceptionManhattan {
		List<StrategyByTab> list = null;
		try {
			CriteriaBuilder criteriaBuilder = getEm().getCriteriaBuilder();
	
			CriteriaQuery<StrategyByTab> criteriaQuery = criteriaBuilder.createQuery(StrategyByTab.class);
			Root<StrategyByTab> root = criteriaQuery.from(StrategyByTab.class);
			criteriaQuery.where( criteriaBuilder.equal( root.get( "tab" ), traderWatchTab ) );		
			
			criteriaQuery.select( root );
	
			list = getEm().createQuery(criteriaQuery).getResultList();
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		return list;
	}
	

	public void setTraderWatchTabAuditDAO(ITraderWatchTabAuditDAO traderWatchTabAuditDAO) {
		this.traderWatchTabAuditDAO = traderWatchTabAuditDAO;
	}

	public void setUser(User user) {
		this.user = user;
	}
}