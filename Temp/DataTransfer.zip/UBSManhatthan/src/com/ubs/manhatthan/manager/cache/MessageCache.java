package com.ubs.manhatthan.manager.cache;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;

import com.google.protobuf.GeneratedMessage;
import com.ubs.manhatthan.manager.logger.ManhattanLogger;
import com.ubs.manhatthan.manager.utils.Util;
import com.ubs.manhatthan.model.StrategyMessagePersistence;

public class MessageCache {
	
	private static int maxMessages;
	private static int activeIndexWriterMessage;
	private static int activeIndexReaderMessage;
	private static int activeLoopWriterCounter;
	private static int activeLoopReaderCounter;	
	
	private static StrategyMessagePersistence[] strategyMessagesTemporaryCache;

	public static void InitializeTemporaryCache(int numberOfTemporaryOrders) {
		maxMessages = numberOfTemporaryOrders;
	
		strategyMessagesTemporaryCache = new StrategyMessagePersistence[maxMessages];
	}
	
	public synchronized static void putMessage(long engineId, GeneratedMessage message) {
		
		if (message == null) {
			ManhattanLogger.log("" + Util.getManagerId(), "Message is null", Level.ERROR);
		
			return;
		}

		if ((activeIndexWriterMessage) >= maxMessages) {
			activeLoopWriterCounter++;
			
			activeIndexWriterMessage = 0;
		}
						
		strategyMessagesTemporaryCache[activeIndexWriterMessage] = new StrategyMessagePersistence(engineId, message, activeIndexWriterMessage);
		
		activeIndexWriterMessage++;
	}
		
	public static StrategyMessagePersistence getMessage() {
		
		StrategyMessagePersistence strategyMessagePersistence = null;
		
		if (activeLoopReaderCounter < activeLoopWriterCounter) {
			strategyMessagePersistence = strategyMessagesTemporaryCache[activeIndexReaderMessage];
			
			activeIndexReaderMessage++;
		} else {
			if (activeIndexReaderMessage < activeIndexWriterMessage) {
				strategyMessagePersistence = strategyMessagesTemporaryCache[activeIndexReaderMessage];
				
				activeIndexReaderMessage++;
			}
		}

		if ((activeIndexReaderMessage) >= maxMessages) {
			activeLoopReaderCounter++;
			
			activeIndexReaderMessage = 0;
		}

		return strategyMessagePersistence;
	}
	
	public static List<StrategyMessagePersistence> getMessages(int counter) {
		List<StrategyMessagePersistence> listStrategyMessagePersistence = new ArrayList<StrategyMessagePersistence>();
		
		if (counter > 0) {
			for (int i = 0; i < counter; i++) {
				StrategyMessagePersistence strategyMessagePersistence = getMessage();
				
				if (strategyMessagePersistence == null) break;
				
				listStrategyMessagePersistence.add(strategyMessagePersistence);
			}
		} else {
			StrategyMessagePersistence strategyMessagePersistence = getMessage();
			
			while (strategyMessagePersistence != null) {
				listStrategyMessagePersistence.add(strategyMessagePersistence);
				
				strategyMessagePersistence = getMessage();
			}
		}
		
		return listStrategyMessagePersistence;
	}
}