package com.ubs.manhatthan.manager.persistence.dao.audit;

import java.io.Serializable;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.manager.persistence.dao.GenericDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IStrategyByTabAuditDAO;
import com.ubs.manhatthan.manager.persistence.entities.audit.StrategyByTabAudit;

@Repository
@Scope("singleton")
public class StrategyByTabAuditDAO extends GenericDAO<StrategyByTabAudit, Long> implements IStrategyByTabAuditDAO, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;}
