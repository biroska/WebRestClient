package com.ubs.manhatthan.manager.persistence.entities.converters;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import com.ubs.manhatthan.manager.enums.ChannelTypeEnum;

@Converter(autoApply = true)
public class ChannelTypeEnumConverter implements AttributeConverter<ChannelTypeEnum, String> {

	@Override
	public String convertToDatabaseColumn(ChannelTypeEnum channelTypeEnum ) {
		return channelTypeEnum.getName();
	}

	@Override
	public ChannelTypeEnum convertToEntityAttribute(String dbData) {
		for ( ChannelTypeEnum channelType : ChannelTypeEnum.values() ) {
			if ( channelType.getName().equals(dbData) ) {
				return channelType;
			}
		}

		throw new IllegalArgumentException("Unknown database value:" + dbData );
	}
}