package com.ubs.manhatthan.manager.lmdsadapter.marketdata.lmds.handlers;

import java.io.Serializable;

import quickfix.FieldNotFound;
import quickfix.fix44.MarketDataIncrementalRefresh;
import quickfix.fix44.MarketDataIncrementalRefresh.NoMDEntries;

public class MarketDataIncrementalHandler implements
		Handler<MarketDataIncrementalRefresh>, Serializable
{
	private static final long serialVersionUID = 7154552423555354964L;
	private final MDEntryHandler entryHandler;

	public MarketDataIncrementalHandler()
	{
		this.entryHandler = new MDEntryHandler();
	}

	@Override
	public synchronized void handle(MarketDataIncrementalRefresh event)
	{
		//System.out.println("Received incremental");
		
		try
		{
			NoMDEntries incrementalGroup = new NoMDEntries();
			
			for (int i = 1; i <= event.getInt(quickfix.field.NoMDEntries.FIELD); i++)
			{
				event.getGroup(i, incrementalGroup);
				this.entryHandler.setManagerFromGroup(incrementalGroup);
				this.entryHandler.handle(incrementalGroup);
			}
		} catch (FieldNotFound e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
