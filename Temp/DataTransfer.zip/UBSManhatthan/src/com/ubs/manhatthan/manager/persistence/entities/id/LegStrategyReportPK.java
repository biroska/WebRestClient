package com.ubs.manhatthan.manager.persistence.entities.id;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Embeddable
public class LegStrategyReportPK implements Serializable {

	private static final long serialVersionUID = 8602767192178299001L;
	
	public LegStrategyReportPK() {
		super();
	}

	/**
	 * @param legSeq
	 * @param engineId
	 * @param strategyId
	 * @param strategyDate
	 */
	public LegStrategyReportPK(Long engineId, Long strategyId, Integer legSeq, Date strategyDate) {
		super();
		this.legSeq = legSeq;
		this.engineId = engineId;
		this.strategyId = strategyId;
		this.strategyDate = strategyDate;
	}

	@Column ( name = "LEG_SEQ", nullable=false)
	private Integer legSeq;
	
	@Column ( name = "ENGINE_ID", nullable=false)
	private Long engineId;
	
	@Column ( name = "STRATEGY_ID", nullable=false)
	private Long strategyId;
	
	@Temporal(TemporalType.DATE)
	@Column ( name = "STRATEGY_DATE", nullable=false)
	private Date strategyDate;
	
	public Integer getLegSeq() {
		return legSeq;
	}

	public void setLegSeq(Integer legSeq) {
		this.legSeq = legSeq;
	}

	public Long getEngineId() {
		return engineId;
	}

	public void setEngineId(Long engineId) {
		this.engineId = engineId;
	}

	public Long getStrategyId() {
		return strategyId;
	}

	public void setStrategyId(Long strategyId) {
		this.strategyId = strategyId;
	}

	public Date getStrategyDate() {
		return strategyDate;
	}

	public void setStrategyDate(Date strategyDate) {
		this.strategyDate = strategyDate;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((engineId == null) ? 0 : engineId.hashCode());
		result = prime * result + ((legSeq == null) ? 0 : legSeq.hashCode());
		result = prime * result
				+ ((strategyDate == null) ? 0 : strategyDate.hashCode());
		result = prime * result
				+ ((strategyId == null) ? 0 : strategyId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LegStrategyReportPK other = (LegStrategyReportPK) obj;
		if (engineId == null) {
			if (other.engineId != null)
				return false;
		} else if (!engineId.equals(other.engineId))
			return false;
		if (legSeq == null) {
			if (other.legSeq != null)
				return false;
		} else if (!legSeq.equals(other.legSeq))
			return false;
		if (strategyDate == null) {
			if (other.strategyDate != null)
				return false;
		} else if (!strategyDate.equals(other.strategyDate))
			return false;
		if (strategyId == null) {
			if (other.strategyId != null)
				return false;
		} else if (!strategyId.equals(other.strategyId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "LegStrategyReportPK [legSeq=" + legSeq + ", engineId="
				+ engineId + ", strategyId=" + strategyId + ", strategyDate="
				+ strategyDate + "]";
	}
}