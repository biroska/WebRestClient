package com.ubs.manhatthan.manager.simulator.multileg;

import java.util.ArrayList;
import java.util.List;

import com.ubs.manhatthan.manager.enums.SideEnum;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.SecurityDefinition;

public class InputMultilegSimulationItem
{
	private Long instrument;
	private Integer legSeq;
	private SideEnum side;
	private SecurityDefinition securityDefinition;
	
	private boolean byQuantity;
	private Long quantity;
	private Double div1;
	
	private boolean simulationLeg;
	
	//Setar no onTrade
	private Double lastPrice;
	private Long lastQuantity;

	private int bidDepth;
	private int askDepth;
	private List<Double> bidPrices;
	private List<Long> bidQuantities;
	private List<Double> askPrices;
	private List<Long> askQuantities;
	
	public InputMultilegSimulationItem()
	{
		this.instrument         = null;
		this.side               = SideEnum.NOT_DEFINED;
		this.securityDefinition = null;
		this.simulationLeg      = false;
		this.byQuantity         = false;
		this.quantity           = null;
		this.div1               = null;
		this.legSeq             = null;	
		this.bidDepth           = 0;
		this.askDepth           = 0;
		this.bidPrices          = new ArrayList<Double>(5);
		this.bidQuantities      = new ArrayList<Long>(5);
		this.askPrices          = new ArrayList<Double>(5);
		this.askQuantities      = new ArrayList<Long>(5);
		this.lastPrice          = null;
		this.lastQuantity       = null;
	}
	
	public Long getInstrument()
	{
		return instrument;
	}
	
	public void setInstrument(Long instrument)
	{
		this.instrument = instrument;
	}

	public SideEnum getSide()
	{
		return side;
	}

	public void setSide(SideEnum side)
	{
		this.side = side;
	}

	public boolean isSimulationLeg()
	{
		return simulationLeg;
	}

	public void setSimulationLeg(boolean simulationLeg)
	{
		this.simulationLeg = simulationLeg;
	}

	public boolean isByQuantity()
	{
		return byQuantity;
	}

	public Long getQuantity()
	{
		return quantity;
	}

	public void setQuantity(Long quantity)
	{
		this.div1 = null;
		this.quantity = quantity;
		this.byQuantity = true;
	}

	public Double getDiv1()
	{
		return div1;
	}

	public void setDiv1(Double div1)
	{
		this.div1 = div1;
		this.quantity = null;
		this.byQuantity = false;
	}

	public Integer getBusinessDays()
	{
		return securityDefinition.getBusinessDays();
	}

	public SecurityDefinition getSecurityDefinition()
	{
		return securityDefinition;
	}

	public void setSecurityDefinition(SecurityDefinition securityDefinition)
	{
		this.securityDefinition = securityDefinition;
	}

	public Integer getLegSeq()
	{
		return legSeq;
	}

	public void setLegSeq(Integer legSeq)
	{
		this.legSeq = legSeq;
	}
	
	public int getBidDepth()
	{
		return bidDepth;
	}

	public void setBidDepth(int minBid)
	{
		this.bidDepth = minBid;
	}

	public int getAskDepth()
	{
		return askDepth;
	}

	public void setAskDepth(int minAsk)
	{
		this.askDepth = minAsk;
	}

	public List<Double> getBidPrices()
	{
		return bidPrices;
	}

	public void setBidPrices(List<Double> bidPrices)
	{
		this.bidPrices = bidPrices;
	}

	public List<Long> getBidQuantities()
	{
		return bidQuantities;
	}

	public void setBidQuantities(List<Long> bidQuantities)
	{
		this.bidQuantities = bidQuantities;
	}

	public List<Double> getAskPrices()
	{
		return askPrices;
	}

	public void setAskPrices(List<Double> askPrices)
	{
		this.askPrices = askPrices;
	}

	public List<Long> getAskQuantities()
	{
		return askQuantities;
	}

	public void setAskQuantities(List<Long> askQuantities)
	{
		this.askQuantities = askQuantities;
	}

	public void setByQuantity(boolean byQuantity)
	{
		this.byQuantity = byQuantity;
	}
	
	public Double getLastPrice()
	{
		return lastPrice;
	}
	
	public Long getLastQuantity()
	{
		return lastQuantity;
	}

	public void setLastTrade(Double lastPrice, Long lastQuantity)
	{
		this.lastPrice = lastPrice;
		this.lastQuantity = lastQuantity;
	}

	@Override
	public String toString()
	{
		return "InputMultilegSimulationItem [instrument=" + instrument
				+ ", legSeq=" + legSeq
				+ ", side=" + side 
				+ ", lastPrice=" + lastPrice 
				+ ", lastQuantity=" + lastQuantity 
				+ ", bidDepth=" + bidDepth
				+ ", askDepth=" + askDepth
				+ ", bidPrices=" + bidPrices
				+ ", bidQuantities=" + bidQuantities
				+ ", askPrices=" + askPrices
				+ ", askQuantities=" + askQuantities
				+ ", securityDefinition=" + securityDefinition
				+ ", businessDays=" + securityDefinition.getBusinessDays()
				+ ", simulationLeg=" + simulationLeg
				+ ", byQuantity=" + byQuantity
				+ ", quantity=" + quantity
				+ ", div1=" + div1 + "]";
	}
}
