package com.ubs.manhatthan.manager.cache;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Level;
import org.springframework.beans.BeanUtils;

import com.ubs.manhatthan.common.enuns.StrategyStatusEnum;
import com.ubs.manhatthan.manager.enums.OrderTypeEnum;
import com.ubs.manhatthan.manager.enums.SideEnum;
import com.ubs.manhatthan.manager.enums.StrategyStateEnum;
import com.ubs.manhatthan.manager.enums.TimeInForceEnum;
import com.ubs.manhatthan.manager.logger.ManhattanLogger;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_legged_order;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_reject_create_modify_cancel_strategy_message;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_report_strategy_message;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_strategy_body_report_message;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_strategy_leg_report_message;
import com.ubs.manhatthan.manager.utils.Constant;
import com.ubs.manhatthan.manager.utils.Util;
import com.ubs.manhatthan.model.Account;
import com.ubs.manhatthan.model.LegStrategyReport;
import com.ubs.manhatthan.model.StrategyReport;
import com.ubs.manhatthan.model.StrategyType;
import com.ubs.manhatthan.model.Unlegging;

public class StrategyCache {

	private static int maxIndexEngines;
	private static int maxIndexEngineInstances;
	private static int maxIndexStrategies;

	private static StrategyReport[][][] strategyReportCache;

	private static Map<String, List<StrategyReportKey>> indexByUser; 
	
	private static long counterReport = 0;

	static {		
		//Create a new maps for indexes
		indexByUser = new HashMap<String, List<StrategyReportKey>>();
	}

	public static void InitializeCache(int numberOfEngines, int numberOfInstances, int numberOfStrategies) {
		maxIndexEngines = numberOfEngines + 1;
		maxIndexEngineInstances = numberOfInstances + 1;
		maxIndexStrategies = numberOfStrategies + 1;
	
		strategyReportCache = new StrategyReport[maxIndexEngines][maxIndexEngineInstances][maxIndexStrategies];
		
		for (int indexEngine = 0; indexEngine < maxIndexEngines; indexEngine++) {
			for (int indexEngineInstance = 0; indexEngineInstance < maxIndexEngineInstances; indexEngineInstance++) {
				for (int indexStrategy = 0; indexStrategy < maxIndexStrategies; indexStrategy++) {					
					ManhattanLogger.log(""+Util.getManagerId(), "Add engine " + indexEngine + ", instance " + indexEngineInstance + ", strategy " + indexStrategy + " in strategy cache", Level.DEBUG);
					
					strategyReportCache[indexEngine][indexEngineInstance][indexStrategy] = new StrategyReport();
				}
			}
		}
	}
	
	// Load a strategy in cache, used in deploy initialize on load strategies in database
	public static void loadStrategy(StrategyReport strategyReport) {
		
		if (strategyReport == null) {
			ManhattanLogger.log( ""+Util.getManagerId(), "Strategy report is null", Level.ERROR );
			
			return;
		}

		int indexEngine = (int) strategyReport.getEngineId().longValue() / 1000;
		int indexEngineInstance = (int) strategyReport.getEngineId().longValue() % 1000;
		int indexStrategyReport = (int) strategyReport.getStrategyId().longValue();
	
		if (!checkIfStrategyExistsInCache(indexEngine, indexEngineInstance, indexStrategyReport))
			return;
		
		strategyReportCache[indexEngine][indexEngineInstance][indexStrategyReport] = strategyReport;
	}
	
	// process a strategy in cache from NetworkClientManager call back
	public static void processStrategy(long engineId, long requestId, pb_report_strategy_message message) {
		
		if (!message.isInitialized()) {
			ManhattanLogger.log( ""+Util.getManagerId(), "Protobuffer message 'pb_report_strategy_message' is not initialized", Level.ERROR );
			
			return;
		}

		// Build the Strategy Report and Legs
		if (message.isInitialized()) {
			
			int indexEngine = (int) engineId / 1000;
			int indexEngineInstance = (int) engineId % 1000;
			int indexStrategyReport = (int) message.getStrategyId();
		
			if (!checkIfStrategyExistsInCache(indexEngine, indexEngineInstance, indexStrategyReport))
				return;
			
			// Translate the pb_strategy_body_report_message message to StrategyReport
			buildStrategyReport(strategyReportCache[indexEngine][indexEngineInstance][indexStrategyReport], 
						message.getBody() );
			
			// Define the id of Strategy and setting counter
			strategyReportCache[indexEngine][indexEngineInstance][indexStrategyReport].setStrategyId(message.getStrategyId());
			strategyReportCache[indexEngine][indexEngineInstance][indexStrategyReport].setEngineId(engineId);
			strategyReportCache[indexEngine][indexEngineInstance][indexStrategyReport].setStrategyTimestamp(Util.dateWhitoutTime(new Date()));
			strategyReportCache[indexEngine][indexEngineInstance][indexStrategyReport].setRequestId(requestId);
			strategyReportCache[indexEngine][indexEngineInstance][indexStrategyReport].setMessage("");
			
			// Build legsStrategyReport from pb_strategy_leg_report_message
			for (int i = 0; i < message.getLegsList().size(); i++) {
				buildLegStrategyReport(engineId, 
						strategyReportCache[indexEngine][indexEngineInstance][indexStrategyReport], 
						message.getLegsList().get(i));
			}
	
			//build indexes for strategy
			buildUserIndex(strategyReportCache[indexEngine][indexEngineInstance][indexStrategyReport]);

			//adjust counter
			strategyReportCache[indexEngine][indexEngineInstance][indexStrategyReport].setCounter(++counterReport);
		} 
	}
	
	// process a reject order in cache from NetworkClientManager call back
	public static void rejectOrder(long engineId, long requestId, pb_reject_create_modify_cancel_strategy_message message) { 

		if (!message.isInitialized()) {
			ManhattanLogger.log( ""+Util.getManagerId(), "Protobuffer message 'pb_reject_create_modify_cancel_strategy_message' is not initialized", Level.ERROR );
			return;
		}
			
		int indexEngine = (int) engineId / 1000;
		int indexEngineInstance = (int) engineId % 1000;
		int indexStrategyReport = (int) message.getStrategyId();
	
		if (!checkIfStrategyExistsInCache(indexEngine, indexEngineInstance, indexStrategyReport))
			return;

		strategyReportCache[indexEngine][indexEngineInstance][indexStrategyReport].setRequestId(requestId);
		strategyReportCache[indexEngine][indexEngineInstance][indexStrategyReport].setMessage(message.getText());
		strategyReportCache[indexEngine][indexEngineInstance][indexStrategyReport].setPopup(true);
		
		//adjust counter
		strategyReportCache[indexEngine][indexEngineInstance][indexStrategyReport].setCounter(++counterReport);					
	}	
	
	// process a order legged in cache from NetworkClientManager call back
	public static void processOrderLegged(long engineId, long requestId, pb_legged_order message) {

		if (!message.isInitialized()) {
			ManhattanLogger.log( ""+Util.getManagerId(), "Protobuffer message 'pb_legged_order' is not initialized", Level.ERROR );
			return;
		}
			
		int indexEngine = (int) engineId / 1000;
		int indexEngineInstance = (int) engineId % 1000;
		int indexStrategyReport = (int) message.getStrategyId();
	
		if (!checkIfStrategyExistsInCache(indexEngine, indexEngineInstance, indexStrategyReport))
			return;
				
		int maxLegFor = strategyReportCache[indexEngine][indexEngineInstance][indexStrategyReport].getLegStrategyList().size(); 			
		
		boolean orderExistsInCache = false;
		int indexLeg = 0;
		int indexUnleg = 0;
		
		for (indexLeg = 0; indexLeg < maxLegFor; indexLeg++) {
			if (strategyReportCache[indexEngine][indexEngineInstance][indexStrategyReport].getLegStrategyList().get(indexLeg).getLegSeq().equals(message.getLegSeq())) {
				int maxUnlegFor = strategyReportCache[indexEngine][indexEngineInstance][indexStrategyReport].getLegStrategyList().get(indexLeg).getUnleggingList().size();
				for (indexUnleg = 0; indexUnleg < maxUnlegFor; indexUnleg++) {
					orderExistsInCache = strategyReportCache[indexEngine][indexEngineInstance][indexStrategyReport].getLegStrategyList().get(indexLeg).getUnleggingList().get(indexUnleg).getOrderId().equals(message.getOrderId());
						
					if (orderExistsInCache) break;
				}

				break;
			}
		}

		Unlegging unlegging = null;
		
		if (orderExistsInCache) {
			if (message.getQuantity() == 0) {
				//Remove order from cache
				strategyReportCache[indexEngine][indexEngineInstance][indexStrategyReport].getLegStrategyList().get(indexLeg).getUnleggingList().remove(indexUnleg);
			} else {
				//Reference to object must be updated in cache										
				unlegging = strategyReportCache[indexEngine][indexEngineInstance][indexStrategyReport].getLegStrategyList().get(indexLeg).getUnleggingList().get(indexUnleg);
			}
		} else {
			if (message.getQuantity() > 0) {
				//Instance new object and add in cache
				unlegging = new Unlegging();
				
				strategyReportCache[indexEngine][indexEngineInstance][indexStrategyReport].getLegStrategyList().get(indexLeg).getUnleggingList().add(unlegging);
			}
		}
		
		// Update values of unlegging object, if needed
		if (unlegging != null) {
			//Instrument and side get a leg information, message dont have this informations
			long instrument = strategyReportCache[indexEngine][indexEngineInstance][indexStrategyReport].getLegStrategyList().get(indexLeg).getInstrument();
			int side = strategyReportCache[indexEngine][indexEngineInstance][indexStrategyReport].getLegStrategyList().get(indexLeg).getSide();
			String contract = strategyReportCache[indexEngine][indexEngineInstance][indexStrategyReport].getLegStrategyList().get(indexLeg).getContract();
			
			unlegging.setEngineId((long) indexEngine);
			unlegging.setStrategyId(message.getStrategyId());
			unlegging.setLegSeq(message.getLegSeq());
			unlegging.setOrderId(message.getOrderId());
			unlegging.setPrice(message.getPrice());
			unlegging.setQty(message.getQuantity());
			unlegging.setContract(contract);
			unlegging.setInstrument(instrument);
			unlegging.setSide(side);
		}
		
		//adjust counter
		strategyReportCache[indexEngine][indexEngineInstance][indexStrategyReport].setCounter(++counterReport);			
	}
	
	private static StrategyReport buildStrategyReport(StrategyReport report, pb_strategy_body_report_message message ) {
		
		if ( !message.isInitialized() ){
			ManhattanLogger.log( ""+Util.getManagerId(), "Protobuffer message 'pb_strategy_body_parameters_message' is not initialized", Level.ERROR );
			return null;
		}
		
		report.setLogin(message.getLogin());
		report.setStartTime(Util.microSegundosToDate( message.getStartTime()));
		report.setEndTime(Util.microSegundosToDate( message.getEndTime()));
		report.setExecutedPercentage(message.getExecutedPercentage());
		report.setExecutedTarget(message.getTargetExecuted());
		
		com.ubs.manhatthan.manager.persistence.entities.StrategyType entityStrategyType = CacheHelper.strategyTypeCache.get( message.getStrategyType().getNumber());
		
		StrategyType strategyType = new StrategyType();
		

		strategyType.setId(entityStrategyType.getId());
		strategyType.setStrategyCode(message.getStrategyType().getNumber());
		strategyType.setDescription(entityStrategyType.getDescription());
		strategyType.setNumberOfLegs(entityStrategyType.getNumberOfLegs());
		//strategyType.set(entityStrategyType.getOrderBySecond());
		
		//convertDatePattern
		strategyType.setStart(Util.convertDatePattern(new Date(message.getStartTime()), "HH:mm"));
		strategyType.setEnd(Util.convertDatePattern(new Date(message.getEndTime()), "HH:mm"));
		
		BeanUtils.copyProperties(entityStrategyType.getStrategyTypeLegList(), strategyType
				.getStrategyTypeLegList());

		report.setStrategyType(strategyType);

		report.setStartPaused(message.getStartPaused());
		report.setText(message.getText());
		report.setPriceLimit(message.getPriceLimit());
		report.setTarget(message.getTarget());
		report.setAgressiviness(message.getAgressiviness());
		report.setRiskLevel(message.getRiskLevel());
		report.setRestingLevel(message.getRestingLevel());
		
		report.setStatus(message.getStrategyState().getNumber());
		
		return report;
	}
	
	private static void buildLegStrategyReport (long engineId, StrategyReport report, pb_strategy_leg_report_message pbLegMessage) {
		
		if ( !pbLegMessage.isInitialized() ){
			return;
		}
		
		LegStrategyReport leg = null;
		
		boolean legMustBeAdded = false;
		
		
		for (int i = 0; i < report.getLegStrategyList().size(); i++) {			
			if (report.getLegStrategyList().get(i).getLegSeq() == null ||
					report.getLegStrategyList().get(i).getLegSeq().equals(pbLegMessage.getLegSeq())) {

				leg = report.getLegStrategyList().get(i); 
				break;
			}
		} 
		
		if (leg == null)  {
			leg = new LegStrategyReport();
		
			legMustBeAdded = true;
		}
		
		leg.setStrategyId(report.getStrategyId());
		leg.setLegSeq(pbLegMessage.getLegSeq());
		leg.setEngineId(engineId);
		leg.setStrategyDate(Util.dateWhitoutTime( new Date()));
		
		leg.setLogin(report.getLogin());
		
		leg.setInstrument(pbLegMessage.getInstrument());
		leg.setTotalQuantity(pbLegMessage.getTotalQuantity());
		leg.setExecutedPercentage(pbLegMessage.getExecutedPercentage());
		leg.setRemainingQuantity(pbLegMessage.getRemainingQuantity());
		leg.setExecutedQuantity(pbLegMessage.getExecutedQuantity());
		leg.setAveragePrice(pbLegMessage.getAveragePrice());
		leg.setText(pbLegMessage.getText());
		leg.setSide(SideEnum.fromValue(SideEnum.integertoAscValue(pbLegMessage.getSide().getNumber())).getCode());
		leg.setRouteId(pbLegMessage.getRouteId());

		leg.setOrderType(OrderTypeEnum.fromValue(pbLegMessage.getOrderType().getNumber()));
		leg.setTimeInForce(TimeInForceEnum.fromValue(pbLegMessage.getTimeInForce().getNumber()));
		
		//create account object
		com.ubs.manhatthan.manager.persistence.entities.ClientAccount entityAccount = pbLegMessage.getAccount() == 0 ? null : CacheHelper.getClientAccount( pbLegMessage.getAccount());
		
		Account account = new Account();
		
		account.setCode(entityAccount.getCode());
		account.setName(entityAccount.getName());
		account.setDescription(entityAccount.getDescription());
		
		leg.setAccount(account);

		leg.setPassiveLeg(pbLegMessage.getPassiveLeg());
		leg.setMaxQuantityDisplay(pbLegMessage.getMaxQuantityDisplay());
		leg.setMinQuantityDisplay(pbLegMessage.getMinQuantityDisplay());
		leg.setRestingQuantity(pbLegMessage.getRestingQuantity());
		leg.setRestingPrice(pbLegMessage.getRestingPrice());
		leg.setRestingRank((long) pbLegMessage.getRestingRank());
		leg.setTimeOut((long) pbLegMessage.getTimeOut());
		leg.setInvestorId(pbLegMessage.getInvestorId());
		leg.setEnteringTrader(pbLegMessage.getEnteringTrader());
		leg.setDuration(pbLegMessage.getDuration());
		leg.setClip(pbLegMessage.getMaxQuantityDisplay());
				
		if (legMustBeAdded) report.getLegStrategyList().add(leg);
	}	
	
	//Build User index (Using on get messages by user (Push Process)
	private static void buildUserIndex(StrategyReport strategyReport) {
		
		StrategyReportKey strategyReportKey = null;
		
		if (!indexByUser.containsKey(strategyReport.getLogin())) {
			strategyReportKey = new StrategyReportKey(strategyReport.getIdEngineId(), 
					strategyReport.getInstanceEngineId(),
					strategyReport.getStrategyId());
			
			List<StrategyReportKey> listStrategyReportKey = new ArrayList<StrategyReportKey>(); 
			
			listStrategyReportKey.add(strategyReportKey);
			indexByUser.put(strategyReport.getLogin(), listStrategyReportKey);
		} else {
			boolean keyAlreadyExists = false;
			for (int i = 0; i < indexByUser.get(strategyReport.getLogin()).size(); i++) {
				keyAlreadyExists = (indexByUser.get(strategyReport.getLogin()).get(i).getEngineId() == strategyReport.getIdEngineId() &&
						indexByUser.get(strategyReport.getLogin()).get(i).getInstanceId() == strategyReport.getInstanceEngineId() &&
						indexByUser.get(strategyReport.getLogin()).get(i).getStrategyId() == strategyReport.getStrategyId());
				
				if (keyAlreadyExists) break;
			}
			
			if (!keyAlreadyExists) {
				strategyReportKey = new StrategyReportKey(strategyReport.getIdEngineId(), 
						strategyReport.getInstanceEngineId(),
						strategyReport.getStrategyId());

				indexByUser.get(strategyReport.getLogin()).add(strategyReportKey);
			}
		}
	}
	
	// Get a strategy by pk
	public static StrategyReport getStrategyById(long engineId, long strategyId) {
		
		int indexEngine = (int) engineId / 1000;
		int indexEngineInstance = (int) engineId % 1000;
		int indexStrategyReport = (int) strategyId;

		return strategyReportCache[indexEngine][indexEngineInstance][indexStrategyReport];
	}
	
	// Get all strategies in cache by login, after a pointer
	public static List<StrategyReport> getStrategiesByLogin(String login, long indexCounterReport) {
		List<StrategyReport> listStrategyReports = null;
		
		if (login != null) {
			if (indexByUser.containsKey(login)) {
				int maxFor = indexByUser.get(login).size();
				
				for (int i = 0; i < maxFor; i++) {
					int indexEngine = indexByUser.get(login).get(i).getEngineId();
					int indexEngineInstance = indexByUser.get(login).get(i).getInstanceId();
					int indexStrategyReport = (int) indexByUser.get(login).get(i).getStrategyId();
					
					if (strategyReportCache[indexEngine][indexEngineInstance][indexStrategyReport].getCounter() > indexCounterReport) {
						if (listStrategyReports == null) listStrategyReports = new ArrayList<StrategyReport>();
						
						listStrategyReports.add(strategyReportCache[indexEngine][indexEngineInstance][indexStrategyReport]);
					}
				}
			}
		}
		
		return listStrategyReports;
	}	
	
	//Get all strategies in cache, after a pointer
	public static List<StrategyReport> getAllStrategies(long indexCounterReport) {
		List<StrategyReport> listStrategyReports = null;
		
		Set<String> keySet = indexByUser.keySet();
		
		for (String login : keySet) {
			List<StrategyReportKey> listKeysInIndex =  indexByUser.get(login);
			
			if (listKeysInIndex != null) {
				int maxFor = listKeysInIndex.size();
				for (int i = 0; i < maxFor; i++) {
					int indexEngine = indexByUser.get(login).get(i).getEngineId();
					int indexEngineInstance = indexByUser.get(login).get(i).getInstanceId();
					int indexStrategyReport = (int) indexByUser.get(login).get(i).getStrategyId();
					
					if (strategyReportCache[indexEngine][indexEngineInstance][indexStrategyReport].getCounter() > indexCounterReport) {
						if (listStrategyReports == null) listStrategyReports = new ArrayList<StrategyReport>();
						
						listStrategyReports.add(strategyReportCache[indexEngine][indexEngineInstance][indexStrategyReport]);
					}
				}
			}
		}
		
		return listStrategyReports;
	}
	
	public static void invalidateStrategiesForInstance(long engineId,boolean engineIsDown) {
		
		//Get values of engine and instance
		int indexEngine = (int) engineId / 1000;
		int indexEngineInstance = (int) engineId % 1000;

		int maxFor = strategyReportCache[indexEngine][indexEngineInstance].length; 
		
		for (int i = 1; i < maxFor; i ++) {		
			if (strategyReportCache[indexEngine][indexEngineInstance][i].getStrategyId() == null) break;
		
			//Setting strategy status like disconnect or error if actual status not is (Error, Cancelled or Completed)
			if (strategyReportCache[indexEngine][indexEngineInstance][i].getStatus() != StrategyStatusEnum.ERROR.getCode() &&
					strategyReportCache[indexEngine][indexEngineInstance][i].getStatus() != StrategyStatusEnum.CANCELLED.getCode() &&
					strategyReportCache[indexEngine][indexEngineInstance][i].getStatus() != StrategyStatusEnum.COMPLETED.getCode()) {
			
				if (engineIsDown) {
					strategyReportCache[indexEngine][indexEngineInstance][i].setStatus(StrategyStateEnum.ERROR.getCode());
					strategyReportCache[indexEngine][indexEngineInstance][i].setText(Constant.MESSAGES_CONFIGURATION.ENGINE_IS_DOWN);
				} else {
					strategyReportCache[indexEngine][indexEngineInstance][i].setStatus(StrategyStateEnum.DISCONNECT.getCode());
					strategyReportCache[indexEngine][indexEngineInstance][i].setText(Constant.MESSAGES_CONFIGURATION.ENGINE_DISCONNECTED);
				}
				
				//adjust counter
				strategyReportCache[indexEngine][indexEngineInstance][i].setCounter(++counterReport);
			}
		}
	}
	
	// Invalidate a strategy with error status and text
	public static void invalidateStrategy(long engineId, long strategyId, String text) {

		//Get values of engine and instance
		int indexEngine = (int) engineId / 1000;
		int indexEngineInstance = (int) engineId % 1000;
		int indexStrategyReport = (int) strategyId;
		
		if (!checkIfStrategyExistsInCache(indexEngine, indexEngineInstance, indexStrategyReport))
			return;

		strategyReportCache[indexEngine][indexEngineInstance][indexStrategyReport].setStatus(StrategyStatusEnum.ERROR.getCode());
		strategyReportCache[indexEngine][indexEngineInstance][indexStrategyReport].setText(text);
		
		//adjust counter
		strategyReportCache[indexEngine][indexEngineInstance][indexStrategyReport].setCounter(++counterReport);
	}
	
	// Update a strategy with text
	public static void updateTextStrategy(long engineId, long strategyId, String text) {
		//Get values of engine and instance
		int indexEngine = (int) engineId / 1000;
		int indexEngineInstance = (int) engineId % 1000;
		int indexStrategyReport = (int) strategyId;
		
		if (!checkIfStrategyExistsInCache(indexEngine, indexEngineInstance, indexStrategyReport))
			return;
		
		strategyReportCache[indexEngine][indexEngineInstance][indexStrategyReport].setText(text);
		
		//adjust counter
		strategyReportCache[indexEngine][indexEngineInstance][indexStrategyReport].setCounter(++counterReport);
	}
	
	private static boolean checkIfStrategyExistsInCache(int indexEngine, int indexEngineInstance, int indexStrategyReport) {
		
		if (indexEngine == 0 || indexEngineInstance == 0 || indexStrategyReport == 0) {
			return false;
		}

		if (strategyReportCache.length < indexEngine) {
			ManhattanLogger.log(""+Util.getManagerId(), "EngineId " + indexEngine + " is not loaded in strategy cache", Level.ERROR);
			return false;
		}
		
		if (strategyReportCache[indexEngine].length < indexEngineInstance) {
			ManhattanLogger.log(""+Util.getManagerId(), "EngineId " + indexEngine + ", InstanceId " +  indexEngineInstance + " is not loaded in strategy cache", Level.ERROR);
			return false;
		}
		
		if (strategyReportCache[indexEngine][indexEngineInstance].length < indexStrategyReport) {
			ManhattanLogger.log(""+Util.getManagerId(), "EngineId " + indexEngine + ", InstanceId " +  indexEngineInstance + ", StrategyId " + indexStrategyReport + " is not loaded in strategy cache", Level.ERROR);
			return false;
		}
		
		return true;
	}
	
	private static class StrategyReportKey {
		private int engineId;
		private int instanceId;
		private long strategyId;
		
		public StrategyReportKey(int engineId, int instanceId, long strategyId) {
			this.engineId = engineId;
			this.instanceId = instanceId;
			this.strategyId = strategyId;
		}

		public int getEngineId() {
			return engineId;
		}

		public int getInstanceId() {
			return instanceId;
		}

		public long getStrategyId() {
			return strategyId;
		}

		@Override
		public String toString() {
			return "StrategyReportKey [engineId=" + engineId + ", instanceId="
					+ instanceId + ", strategyId=" + strategyId + "]";
		}				
	}
}