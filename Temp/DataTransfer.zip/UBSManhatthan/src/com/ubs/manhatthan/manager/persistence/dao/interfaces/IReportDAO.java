/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import java.util.List;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.persistence.entities.OrderTrade;

/**
 * @author galdinoa
 *
 */
public interface IReportDAO extends IGenericDAO<OrderTrade, Long> {

	List<OrderTrade> reportByStrategy(OrderTrade orderTrade) throws DAOExceptionManhattan;

	List<OrderTrade> reportByAverage(OrderTrade orderTrade) throws DAOExceptionManhattan;

	List<OrderTrade> reportByExecution(OrderTrade orderTrade) throws DAOExceptionManhattan;

	List<OrderTrade> reportByPrice(OrderTrade orderTrade) throws DAOExceptionManhattan;
}
