/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.enums.StrategyTypeEnum;
import com.ubs.manhatthan.manager.persistence.entities.StrategyType;

/**
 * @author galdinoa
 *
 */
public interface IStrategyTypeDAO extends IGenericDAO<StrategyType, Long> {

	StrategyType saveStrategyType(StrategyType strategyType) throws DAOExceptionManhattan;

	Integer getNumberOfLegsFromStrategyType(StrategyTypeEnum strategyType)
			throws DAOExceptionManhattan;
}
