package com.ubs.manhatthan.manager.lmdsadapter.marketdata.lmds;

import java.io.Serializable;
import java.util.Properties;

import quickfix.ConfigError;
import quickfix.RuntimeError;

import com.ubs.manhatthan.manager.lmdsadapter.adapter.Adapter;
import com.ubs.manhatthan.manager.lmdsadapter.adapter.AdapterConfigurationException;
import com.ubs.manhatthan.manager.lmdsadapter.adapter.AdapterRuntimeException;

public class LMDSAdapter implements Adapter, Serializable
{
	private static final long serialVersionUID = 6717783452335946786L;
	
	private final LMDSController controller;
	
	public LMDSAdapter()
	{
		this.controller = new LMDSController();
	}

	@Override
	public void configure(Properties config)
			throws AdapterConfigurationException
	{
		try
		{
			this.controller.onConfigure(config);
		} catch (ConfigError e)
		{
			throw new AdapterConfigurationException("Failed to instantiate QuickFix engine", e);
		}
	}

	@Override
	public void start() throws AdapterRuntimeException
	{
		try
		{
			this.controller.onStart();
		}
		catch (RuntimeError | ConfigError e)
		{
			throw new AdapterRuntimeException("Cannot start LMDS adapter",e);
		}		
		
	}

	@Override
	public void stop() throws AdapterRuntimeException
	{
		try
		{
			this.controller.onStop();
		} 
		catch (ConfigError e)
		{
			throw new AdapterRuntimeException("Cannot stop LMDS adapter",e);
		}
	}

}
