package com.ubs.manhatthan.manager.lmdsadapter;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.commons.lang.StringUtils;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.cache.CacheHelper;
import com.ubs.manhatthan.manager.cache.LmdsCache;
import com.ubs.manhatthan.manager.dto.ReceiveSymbolSyntheticItem;
import com.ubs.manhatthan.manager.dto.ReceiveSynthetic;
import com.ubs.manhatthan.manager.enums.SideEnum;
import com.ubs.manhatthan.manager.facade.Facade;
import com.ubs.manhatthan.manager.facade.FacadeService;
import com.ubs.manhatthan.manager.facade.FacadeServiceImpl;
import com.ubs.manhatthan.manager.lmdsadapter.adapter.AdapterConfigurationException;
import com.ubs.manhatthan.manager.lmdsadapter.adapter.AdapterRuntimeException;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.BookSnapshot;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.SecurityDefinition;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.Trade;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.lmds.LMDSAdapter;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.manager.MDManager;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.manager.MDManagerFactory;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.manager.MDSubscribeResponse;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.manager.MDSubscriberHandler;
import com.ubs.manhatthan.manager.logger.ApplicationLogger;
import com.ubs.manhatthan.manager.simulator.multileg.InputMultilegSimulation;
import com.ubs.manhatthan.manager.simulator.multileg.InputMultilegSimulationItem;
import com.ubs.manhatthan.manager.simulator.multileg.ReturnMultilegSimulation;
import com.ubs.manhatthan.manager.utils.Constant;

public class LmdsManager implements MDSubscriberHandler, Serializable {
	
	private static final long serialVersionUID = -3053418061509753485L;
	
	private final MDManager manager = MDManagerFactory.getManager("BVMF");
	private LMDSAdapter adapter = new LMDSAdapter();
	private SimulationItem simulationItem = new SimulationItem();
	private FacadeService fService = new FacadeServiceImpl();
	
	private Facade facade = CacheHelper.facade; // = new FacadeImpl();
	
//	Aux values to assign values in map using reference 
	private int bidDepth;
	private int askDepth;
	private List<Double> bidPrices;
	private List<Long> bidQuantities;
	private List<Double> askPrices;
	private List<Long> askQuantities;
	
	public LmdsManager(){}
	
	/**
	 * sintetic = symbol1|symbol2|...
	 * concurent map
	 */
//  	
	
	public boolean subscribeManager( ReceiveSynthetic synthetic )
	{
		if( synthetic == null || synthetic.getSyntheticList() == null || synthetic.getSyntheticList().isEmpty() ) { return false; }
		
		try
		{
			String syntheticKey = "";
					
			if( synthetic.getStrategyType().isSynthetic() )
			{
				Integer numberOfLegs = facade.getNumberOfLegsFromStrategyType( synthetic.getStrategyType() );
				
				if( numberOfLegs == null || numberOfLegs != synthetic.getSyntheticList().size() ) { return false; }
	
				syntheticKey = buildSyntheticKey( synthetic );
			}
			else
			{				
				if( synthetic.getSyntheticList().size() != 1 ) { return false; }
				
				syntheticKey = synthetic.getSyntheticList().get(0).getSymbol();
			}

			//If key is already on cache, return
			if ( LmdsCache.simulationItensMapContainsKey( syntheticKey ) ) { return true; }

			//Create simulation item
			simulationItem = initializeSimulationItem(synthetic);
			if( null == simulationItem ) { return false; }
			
			//First Simulation
			ReturnMultilegSimulation _ret = new ReturnMultilegSimulation();		
			_ret = fService.calculate(simulationItem.getBuyInputMultilegSimulationList());
			if( _ret.isValid() ) { simulationItem.setBuyReturnMultilegSimulation(_ret); }
			
			_ret = new ReturnMultilegSimulation();
			changeLastToAntepenultElementSimulationPosition(simulationItem.getSellInputMultilegSimulationList());
			_ret = fService.calculate(simulationItem.getSellInputMultilegSimulationList());
			if( _ret.isValid() ) { simulationItem.setSellReturnMultilegSimulation(_ret); }
			
			LmdsCache.putSimulationItem(syntheticKey, simulationItem);
			
		} catch (DAOExceptionManhattan e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
			
		return true;
	}
	
	private void changeLastToAntepenultElementSimulationPosition(InputMultilegSimulation inputMultilegSimulation){
			
		if ( inputMultilegSimulation!=null && inputMultilegSimulation.getInputItens()!=null 
				&& !inputMultilegSimulation.getInputItens().isEmpty() && inputMultilegSimulation.getInputItens().size()>=2) {
			
			
			SideEnum side1 = inputMultilegSimulation.getInputItens().get(inputMultilegSimulation.getInputItens().size()-1).getSide();
			SideEnum side2 = inputMultilegSimulation.getInputItens().get(inputMultilegSimulation.getInputItens().size()-2).getSide();
			
			inputMultilegSimulation.getInputItens().get(inputMultilegSimulation.getInputItens().size()-1).setSide(side2);
			inputMultilegSimulation.getInputItens().get(inputMultilegSimulation.getInputItens().size()-2).setSide(side1);
		}		
	}
	
	private static String buildSyntheticKey( ReceiveSynthetic synthetic ){
		
		String key = "";
		
		if ( synthetic.getSyntheticList() != null && !synthetic.getSyntheticList().isEmpty() ){
			for (ReceiveSymbolSyntheticItem item : synthetic.getSyntheticList()) {
				key += item.getSymbol() + Constant.SIMULATION.SEPARATOR_SYNTHETIC_KEYMAP; 
			}
			key = key.substring( 0, key.length() -1 );
			key += Constant.SIMULATION.SEPARATOR_SYNTHETIC_KEYMAP_STRATEGY_TYPE + synthetic.getStrategyType().toString();
		}
		
		return key;
	}
	
	private SimulationItem initializeSimulationItem( ReceiveSynthetic synthetic )
	{
		//Check values
		if( synthetic == null || synthetic.getSyntheticList() == null ||  synthetic.getSyntheticList().isEmpty() ) { return null; }
		
		//Create new simulation item
		SimulationItem _simulationItem = new SimulationItem();
		
		//Define is only symbol
		_simulationItem.setOnlySymbol(synthetic.getSyntheticList().size() == 1 ? true : false);
		
		//if is only symbol, set initial values and return
		if( _simulationItem.isOnlySymbol() )
		{
			//Get security definition (validate symbol)
			SecurityDefinition _secDefinition = null;
			try
			{
				_secDefinition = getIntrumentDefinitionBySymbol(synthetic.getSyntheticList().get(0).getSymbol());
				if( null == _secDefinition ) { return null; }
			}
			catch (DAOExceptionManhattan e)
			{
				return null;
			}
			
			MDSubscribeResponse _subscribeRet = this.subscribeSymbol(synthetic.getSyntheticList().get(0).getSymbol());
			
			Trade _trade = null;
			BookSnapshot book = null;
			
			if (_subscribeRet == null) {				
				_trade = this.getLastTrade(synthetic.getSyntheticList().get(0).getSymbol());	
				book = this.getLastBookSnapshot(synthetic.getSyntheticList().get(0).getSymbol());
			}else {
				_trade = _subscribeRet.getLastTrade();
				book = _subscribeRet.getSnapshot();
			}			
			
			if( null != _trade )
			{
				_simulationItem.setLastPx(_trade.getPrice().doubleValue());
				_simulationItem.setLastQty(_trade.getQuantity());
			}
			
			if( null != book )
			{
				if( 1 <= book.getBidSize() )
				{
					_simulationItem.setBuyPx(book.getBidAt(0).getPrice().doubleValue());
					_simulationItem.setBuyQty(book.getBidAt(0).getQuantity());
				}
				
				if( 1 <= book.getAskSize() )
				{
					_simulationItem.setSellPx(book.getAskAt(0).getPrice().doubleValue());
					_simulationItem.setSellQty(book.getAskAt(0).getQuantity());
				}
			}
			
			return _simulationItem;
		}
		
		//Define the if market watch obeject
		_simulationItem.getBuyInputMultilegSimulationList().setIsMarketWatch();
		_simulationItem.getSellInputMultilegSimulationList().setIsMarketWatch();
		
		//Define simulation mode
		_simulationItem.getBuyInputMultilegSimulationList().setSimulationMode(synthetic.getStrategyType());
		_simulationItem.getSellInputMultilegSimulationList().setSimulationMode(synthetic.getStrategyType());	
		
		String _simulationSymbol = "";
		Integer _lastLegSeq = null;
		for( ReceiveSymbolSyntheticItem symbol : synthetic.getSyntheticList() )
		{
			if( null == _lastLegSeq )
			{
				_lastLegSeq = symbol.getLegSeq();
				_simulationSymbol = symbol.getSymbol();
				continue;
			}
			
			if( symbol.getLegSeq() > _lastLegSeq )
			{
				_simulationSymbol = symbol.getSymbol();
			}
			
			_lastLegSeq = symbol.getLegSeq();
		}
		
		for( ReceiveSymbolSyntheticItem leg : synthetic.getSyntheticList() )
		{
			//Get security definition
			SecurityDefinition _secDefinition = null;
			try
			{
				_secDefinition = getIntrumentDefinitionBySymbol(leg.getSymbol());
				if( null == _secDefinition ) { return null; }
			}
			catch (DAOExceptionManhattan e)
			{
				return null;
			}
			
			InputMultilegSimulationItem _buyInputMultilegSimulationItem = new InputMultilegSimulationItem();
			InputMultilegSimulationItem _sellInputMultilegSimulationItem = new InputMultilegSimulationItem();
			
			//Simulation leg
			if( _simulationSymbol.equals(leg.getSymbol()) )
			{			
				_buyInputMultilegSimulationItem.setSimulationLeg(true);
				_sellInputMultilegSimulationItem.setSimulationLeg(true);		
			}
			
			//SecurityId
			_buyInputMultilegSimulationItem.setInstrument(Long.valueOf(_secDefinition.getSecurity().getSecurityID()));
			_sellInputMultilegSimulationItem.setInstrument(Long.valueOf(_secDefinition.getSecurity().getSecurityID()));
			
			//LegSeq
			_buyInputMultilegSimulationItem.setLegSeq(leg.getLegSeq());
			_sellInputMultilegSimulationItem.setLegSeq(leg.getLegSeq());
			
			//Side
			_buyInputMultilegSimulationItem.setSide(leg.getSide());
			_sellInputMultilegSimulationItem.setSide(leg.getSide() == SideEnum.BUY ? SideEnum.BUY:SideEnum.SELL);
			
			//Define security definition
			_buyInputMultilegSimulationItem.setSecurityDefinition(_secDefinition);
			_sellInputMultilegSimulationItem.setSecurityDefinition(_secDefinition);
			
			MDSubscribeResponse _subscribeRet = this.subscribeSymbol(leg.getSymbol());
			
			Trade _trade = null;
			BookSnapshot _book = null;
			
			if (_subscribeRet == null) {				
				_trade = this.getLastTrade(leg.getSymbol());	
				_book = this.getLastBookSnapshot(leg.getSymbol());
			}else {
				_trade = _subscribeRet.getLastTrade();
				_book = _subscribeRet.getSnapshot();
			}
			
			if( null != _trade )
			{
				_buyInputMultilegSimulationItem.setLastTrade(_trade.getPrice().doubleValue(), _trade.getQuantity());
				_sellInputMultilegSimulationItem.setLastTrade(_trade.getPrice().doubleValue(), _trade.getQuantity());
			}			
			
			if( null != _book && !_book.isEmpty() )
			{			
				int            _bidDepth 		= Math.min( _book.getBidSize(), Constant.SIMULATION.DEFAULT_BOOK_LEVEL );
				int            _askDepth 		= Math.min( _book.getAskSize(), Constant.SIMULATION.DEFAULT_BOOK_LEVEL );
				List<Double>   _bidPrices 		= new ArrayList<Double>(       Constant.SIMULATION.DEFAULT_BOOK_LEVEL );
				List<Long>     _bidQuantities 	= new ArrayList<Long>  (       Constant.SIMULATION.DEFAULT_BOOK_LEVEL );
				List<Double>   _askPrices 		= new ArrayList<Double>(       Constant.SIMULATION.DEFAULT_BOOK_LEVEL );
				List<Long>     _askQuantities 	= new ArrayList<Long>  (       Constant.SIMULATION.DEFAULT_BOOK_LEVEL );
				
				for(int i = 0; i < _bidDepth; i++)
				{
					if( _book.getBidAt(i).getPrice().doubleValue() >= 0.0 && _book.getBidAt(i).getQuantity() >= 0L )
					{
						_bidPrices.add( i , _book.getBidAt( i ).getPrice().doubleValue() );
						_bidQuantities.add( i , _book.getBidAt( i ).getQuantity() );
					}
					else
					{
						break;
					}
				}
				
				for(int i = 0; i < _askDepth; i++)
				{
					if( _book.getAskAt(i).getPrice().doubleValue() >= 0.0 && _book.getAskAt(i).getQuantity() >= 0L )
					{
						_askPrices.add( i , _book.getAskAt( i ).getPrice().doubleValue() );
						_askQuantities.add( i , _book.getAskAt( i ).getQuantity() );
					}
					else
					{
						break;
					}
				}
				
				_buyInputMultilegSimulationItem.setBidDepth(_bidDepth);
				_buyInputMultilegSimulationItem.setBidPrices(_bidPrices);
				_buyInputMultilegSimulationItem.setBidQuantities(_bidQuantities);
				
				_buyInputMultilegSimulationItem.setAskDepth(_askDepth);
				_buyInputMultilegSimulationItem.setAskPrices(_askPrices);
				_buyInputMultilegSimulationItem.setAskQuantities(_askQuantities);
				
				_sellInputMultilegSimulationItem.setBidDepth(_bidDepth);
				_sellInputMultilegSimulationItem.setBidPrices(_bidPrices);
				_sellInputMultilegSimulationItem.setBidQuantities(_bidQuantities);
				
				_sellInputMultilegSimulationItem.setAskDepth(_askDepth);
				_sellInputMultilegSimulationItem.setAskPrices(_askPrices);
				_sellInputMultilegSimulationItem.setAskQuantities(_askQuantities);
			}
			
			_simulationItem.getBuyInputMultilegSimulationList().getInputItens().add(_buyInputMultilegSimulationItem);
			_simulationItem.getSellInputMultilegSimulationList().getInputItens().add(_sellInputMultilegSimulationItem);
		}

		return _simulationItem;
	}
	
	//metodo para pegar resultados do marketwatch
	
	//metodo para calculate da estrategia
		//montar imput
		//chamar simulate
		//retornar resultado do simulate
	
	
	public void startLmdsAdapter(String configFile) throws FileNotFoundException,
									      				   IOException,
									    				   AdapterConfigurationException,
									    				   AdapterRuntimeException {
		
		Properties properties = new Properties();
		properties.load(new FileInputStream(configFile));
		
		this.adapter.configure(properties);
		this.adapter.start();
		
////		After start puts the instance in cache to be accessible in any part of the code 
//		CacheHelper.lmdsCommunicatorInstance.put( Util.getManagerId(), this ); feito no deployInitialize
		
	}
	
	
	public void startLmdsAdapter(InputStream configFile)
			throws FileNotFoundException, IOException,
			AdapterConfigurationException, AdapterRuntimeException {

		Properties properties = new Properties();
		properties.load(configFile);

		this.adapter.configure(properties);
		this.adapter.start();

		// After start puts the instance in cache to be accessible in any part
//		// of the code
//		CacheHelper.lmdsCommunicatorInstance.put(Util.getManagerId(), this); feito no deployInitialize

	}
	
	
	public void stopLmdsAdapter() throws AdapterRuntimeException
	{
		this.adapter.stop();
	}
	
	public MDSubscribeResponse subscribeSymbol(String symbol )
	{
		MDSubscribeResponse subscribe = this.manager.subscribe(symbol, this);
		
		if ( subscribe == null || !subscribe.isSuccess() ) { return null; }
		
		//updateBookValuesAndQuantitiesInCache( symbol, subscribe.getSnapshot() );
		
		return subscribe;
	}
	
	
	public void unsubscribeSymbol(String symbol) {
		
		this.manager.unsubscribe(symbol, this);
	}
	
	
	public SecurityDefinition getIntrumentDefinitionBySymbol(String symbol) throws DAOExceptionManhattan {
		
		SecurityDefinition instrumentDefinition = this.manager.getInstrumentDefinitionBySymbol(symbol);
		
		if ( instrumentDefinition == null ){
			ApplicationLogger.logInfo("[LmdsManager.getIntrumentDefinitionBySymbol] Nao foi possivel recuperar o instrumentDefinition pelo simbolo: " + symbol );
		}
		
		return instrumentDefinition;
	}
	
	
	public SecurityDefinition getIntrumentDefinitionBySecurityId(String securityId) throws DAOExceptionManhattan {
		
		return this.manager.getInstrumentDefinitionBySecurityID(securityId);
	}
	
	/**
	 * @brief This method will return the last valid book
	 * 
	 * @param symbol
	 * 
	 * @return BookSnapshot
	 */
	
	public BookSnapshot getLastBookSnapshot(String symbol) {

		return this.manager.getLastBooksnapshot(symbol);
	}

	/**
	 * @brief This method will return the last valid trade
	 * 
	 * @param symbol
	 * 
	 * @return Trade
	 */
	
	public Trade getLastTrade(String symbol)
	{
		return this.manager.getLastTrade(symbol);
	}
	
	public void onBookUpdate(String symbol, BookSnapshot book)
	{
		if( null == book ) { return; }
		
		if( CacheHelper.fowardDollar.equals(symbol) )
		{
			updateDollarSpotOnBook(book);
			return;
		}
		
//		ApplicationLogger.logInfo("Received on BOOK listener: " + symbol);
		
		if( !LmdsCache.listeningSimulationContainsKey( symbol ) ) { return; }
		
		updateBookValuesAndQuantitiesInCache( symbol, book );
	}

	
	public synchronized void onTrade(String symbol, Trade trade)
	{
		if( StringUtils.isBlank( symbol ) || trade == null || trade.getPrice().doubleValue() <= 0.000001 || trade.getQuantity() <= 0L ) { return; }
		
		if( CacheHelper.fowardDollar.equals(symbol) )
		{
			updateDollarSpotOnTrade(trade);
			return;
		}
		
//		String tradeLog = "Received TRADE."
//						  + " Symbol: " + symbol
//						  + ", Price: " + trade.getPrice()
//				          + ", Qty: " + trade.getQuantity()
//				          + ", Date: " + trade.getTradeDate();
//		System.out.println( tradeLog );
		
		//Busca nos caches os SimuationItens associados com o symbol informado
		List<SimulationItem> simulationList = LmdsCache.getSimulationListBySymbol( symbol );
		
		for(SimulationItem item : simulationList)
		{
			if( item.isOnlySymbol() )
			{
				item.setLastPx(trade.getPrice().doubleValue());
				item.setLastQty(trade.getQuantity());
			}
			else
			{
				List<InputMultilegSimulationItem> legBuyList = item.getBuyInputMultilegSimulationList().getInputItens();
				
				for(InputMultilegSimulationItem leg : legBuyList)
				{
					if( symbol.equals(leg.getSecurityDefinition().getSecurity().getSymbol()) )
					{
						leg.setLastTrade(trade.getPrice().doubleValue(), trade.getQuantity());
					}
				}
				
				List<InputMultilegSimulationItem> legSellList = item.getSellInputMultilegSimulationList().getInputItens();
				
				for(InputMultilegSimulationItem leg : legSellList)
				{
					if( symbol.equals(leg.getSecurityDefinition().getSecurity().getSymbol()) )
					{
						leg.setLastTrade(trade.getPrice().doubleValue(), trade.getQuantity());
					}
				}
				
				ReturnMultilegSimulation _ret = new ReturnMultilegSimulation();		
				_ret = fService.calculate(item.getBuyInputMultilegSimulationList());
				if( _ret.isValid() ) { item.setBuyReturnMultilegSimulation(_ret); }
				
				_ret = new ReturnMultilegSimulation();
				_ret = fService.calculate(item.getSellInputMultilegSimulationList());
				if( _ret.isValid() ) { item.setSellReturnMultilegSimulation(_ret); }
			}
		}
		
	}
	
	private void updateBookValuesAndQuantitiesInCache( String symbol, BookSnapshot book )
	{		
		try {
			if ( StringUtils.isBlank( symbol ) || book == null || book.isEmpty() ) { return; }
			
			bidDepth 		= Math.min( book.getBidSize(), Constant.SIMULATION.DEFAULT_BOOK_LEVEL );
			askDepth 		= Math.min( book.getAskSize(), Constant.SIMULATION.DEFAULT_BOOK_LEVEL );
			bidPrices 		= new ArrayList<>();
			bidQuantities 	= new ArrayList<>();
			askPrices 		= new ArrayList<>();
			askQuantities 	= new ArrayList<>();
			
			for(int i = 0; i < bidDepth; i++)
			{
				if( book.getBidAt(i).getPrice().doubleValue() >= 0.0 && book.getBidAt(i).getQuantity() >= 0L )
				{
					bidPrices.add( i , book.getBidAt( i ).getPrice().doubleValue() );
					bidQuantities.add( i , book.getBidAt( i ).getQuantity() );
				}
				else
				{
					return;
				}
			}
			
			for(int i = 0; i < askDepth; i++)
			{
				if( book.getAskAt(i).getPrice().doubleValue() >= 0.0 && book.getAskAt(i).getQuantity() >= 0L )
				{
					askPrices.add( i , book.getAskAt( i ).getPrice().doubleValue() );
					askQuantities.add( i , book.getAskAt( i ).getQuantity() );
				}
				else
				{
					return;
				}
			}
			
			//Busca nos caches os SimuationItens associados com o symbol informado
			List<SimulationItem> simulationList = LmdsCache.getSimulationListBySymbol( symbol );
			
			for(SimulationItem item : simulationList)
			{
				if( item.isOnlySymbol() )
				{
					if( book.getBidSize() > 0 && book.getBidAt(0).getPrice().doubleValue() >= 0.0 && book.getBidAt(0).getQuantity() >= 0L )
					{
						item.setBuyPx(book.getBidAt(0).getPrice().doubleValue());
						item.setBuyQty(book.getBidAt(0).getQuantity());
					}
					else
					{
						item.setBuyPx(null);
						item.setBuyQty(null);
					}

					if( book.getAskSize() > 0 && book.getAskAt(0).getPrice().doubleValue() >= 0.0 && book.getAskAt(0).getQuantity() >= 0L )
					{
						item.setSellPx(book.getAskAt(0).getPrice().doubleValue());
						item.setSellQty(book.getAskAt(0).getQuantity());
					}
					else
					{
						item.setSellPx(null);
						item.setSellQty(null);
					}
				}
				else
				{
//				if( null != CacheHelper.dollarValue)
//				{
//					item.getBuyInputMultilegSimulationList().setDollarSpot(CacheHelper.dollarValue);
//					item.getSellInputMultilegSimulationList().setDollarSpot(CacheHelper.dollarValue);
//				}
					
					List<InputMultilegSimulationItem> legBuyList = item.getBuyInputMultilegSimulationList().getInputItens();
					
					for(InputMultilegSimulationItem leg : legBuyList)
					{
						if( symbol.equals(leg.getSecurityDefinition().getSecurity().getSymbol()) )
						{
							leg.setBidDepth( bidDepth );
							leg.setAskDepth( askDepth );
							
							leg.setAskPrices( askPrices );
							leg.setAskQuantities( askQuantities );
							
							leg.setBidPrices( bidPrices );
							leg.setBidQuantities( bidQuantities );
						}
					}
					
					List<InputMultilegSimulationItem> legSellList = item.getSellInputMultilegSimulationList().getInputItens();
					
					for(InputMultilegSimulationItem leg : legSellList)
					{
						if( symbol.equals(leg.getSecurityDefinition().getSecurity().getSymbol()) )
						{
							leg.setBidDepth( bidDepth );
							leg.setAskDepth( askDepth );
							
							leg.setAskPrices( askPrices );
							leg.setAskQuantities( askQuantities );
							
							leg.setBidPrices( bidPrices );
							leg.setBidQuantities( bidQuantities );
						}
					}
					
					ReturnMultilegSimulation _ret = new ReturnMultilegSimulation();		
					_ret = fService.calculate(item.getBuyInputMultilegSimulationList());
					if( _ret.isValid() ) { item.setBuyReturnMultilegSimulation(_ret); }
					
					_ret = new ReturnMultilegSimulation();
					_ret = fService.calculate(item.getSellInputMultilegSimulationList());
					if( _ret.isValid() ) { item.setSellReturnMultilegSimulation(_ret); }
				}
				
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void setFacade(Facade facade)
	{
		this.facade = facade;
	}
	
	private void updateDollarSpotOnTrade(Trade trade)
	{		
		CacheHelper.dollarValue = (trade.getPrice().doubleValue())/Constant.SYMBOL.FOWARD_DOLLAR_CONTRACT_MULTIPLIER;
		//ApplicationLogger.logInfo("Dollar Spot updated: <" + CacheHelper.dollarValue + ">");
	}
	
	private void updateDollarSpotOnBook(BookSnapshot book)
	{			
		double _dollarSpot = 0.0;
		
		if( book.getAskSize() > 0 && book.getBidSize() > 0 )
		{			
			double ask = book.getAskAt( 0 ).getPrice().doubleValue();
			double bid = book.getBidAt( 0 ).getPrice().doubleValue();		
			if( ask >= 0.0 && bid >= 0.0 && (bid+0.0001) < ask )
			{
				_dollarSpot = ((ask+bid)/2.0)/Constant.SYMBOL.FOWARD_DOLLAR_CONTRACT_MULTIPLIER;
			}
			else
			{
				return;
			}
		}
		else if(book.getAskSize() > 0)
		{
			_dollarSpot = (book.getAskAt( 0 ).getPrice().doubleValue())/Constant.SYMBOL.FOWARD_DOLLAR_CONTRACT_MULTIPLIER;
		}
		else if(book.getBidSize() > 0)
		{
			_dollarSpot = (book.getBidAt( 0 ).getPrice().doubleValue())/Constant.SYMBOL.FOWARD_DOLLAR_CONTRACT_MULTIPLIER;
		}
		else
		{
			return;
		}
		
		CacheHelper.dollarValue = _dollarSpot;
		//ApplicationLogger.logInfo("Dollar Spot updated: <" + CacheHelper.dollarValue + ">");
	}
	
}