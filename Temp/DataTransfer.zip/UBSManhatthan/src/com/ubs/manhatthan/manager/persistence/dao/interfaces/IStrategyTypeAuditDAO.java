/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import com.ubs.manhatthan.manager.persistence.entities.audit.StrategyTypeAudit;

/**
 * @author galdinoa
 *
 */
public interface IStrategyTypeAuditDAO extends IGenericDAO<StrategyTypeAudit, Long> {}
