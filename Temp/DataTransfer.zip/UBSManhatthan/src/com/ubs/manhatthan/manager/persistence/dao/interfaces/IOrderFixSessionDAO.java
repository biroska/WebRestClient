/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import java.util.List;

import com.ubs.manhatthan.exception.BussinessExceptionManhattan;
import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.persistence.entities.OrderFixSession;

/**
 * @author galdinoa
 *
 */
public interface IOrderFixSessionDAO extends IGenericDAO<OrderFixSession, Integer> {

	OrderFixSession saveOrderFixSession(OrderFixSession orderFixSession, ActionTypeEnum action) throws DAOExceptionManhattan, BussinessExceptionManhattan;

	List<OrderFixSession> getOrderFixSessions() throws DAOExceptionManhattan;

	List<OrderFixSession> getOrderFixByAccount(Long accountId)
			throws DAOExceptionManhattan;
}
