package com.ubs.manhatthan.manager.utils;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Level;

public class Util implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6598376331488957617L;

	private static Date start;
	
	private static List<String> extractedKeyListAuxiliar;
	
	public Util(){
		reset();	
	}

	/**
	 * Returns exact number of milliseconds since timer was started.
	 * 
	 * @return Number of milliseconds since timer was started.
	 */
	public long getTime() {
		Date now = new Date();
		long millis = now.getTime() - start.getTime();
		return millis;
	}

	/**
	 * Restarts the timer.
	 */
	private void reset() {
		start = new Date(); // now
	}

	/**
	 * Returns a formatted string showing the elaspsed time suince the instance was created.
	 * 
	 * @return Formatted time string.
	 */
	public String toString(boolean mili) {
		long millis = getTime();
		long hours = millis / 1000 / 60 / 60;
		millis -= hours * 1000 * 60 * 60;
		long minutes = millis / 1000 / 60;
		millis -= minutes * 1000 * 60;
		long seconds = millis / 1000;
		millis -= seconds * 1000;
		StringBuffer time = new StringBuffer();
		if (hours > 0)
			time.append(hours + ":");
		if (hours > 0 && minutes < 10)
			time.append("0");
		time.append(minutes + ":");
		if (seconds < 10)
			time.append("0");
		time.append(seconds);
		if (mili) {
			time.append(".");
			if (millis < 100)
				time.append("0");
			if (millis < 10)
				time.append("0");
			time.append(millis);
		}
		return time.toString();
	}

	@Override
	public String toString() {
		return toString(true);
	}

	/**
	 * Testing this class.
	 * 
	 * @param args
	 *            Not used.
	 */

	private static SimpleDateFormat sdfH = new SimpleDateFormat("HH:mm");

	private static SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

	private static SimpleDateFormat sdfhour = new SimpleDateFormat("yyyyMMdd HH:mm:ss");

	private static SimpleDateFormat dateWhitoutTime = new SimpleDateFormat("dd-MMM-yyyy");
	
	public static String getHourFormat(Date date) {
		return sdfH.format(date);
	}

	public static String getDateFormated() {
		return sdf.format(new Date());
	}
	
	public static Date dateWhitoutTime( Date date ) {

		try {
			return dateWhitoutTime.parse( dateWhitoutTime.format( date ) );
		} catch (ParseException e) {
			e.printStackTrace();
			return null;
		}
	}

	public static String convertDatePattern(Date dt, String pattern) {

		if (pattern == null)
			return null;

		SimpleDateFormat formatter = new SimpleDateFormat(pattern);

		return formatter.format(dt);
	}

	public static Date convertDateHourNowPattern(String hour) {

		if (StringUtils.isBlank(hour))
			return null;
		try {
			return sdfhour.parse(getDateFormated() + " " + hour + ":00");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public static Date convertDatePattern(String dt, String pattern) {

		if (pattern == null || StringUtils.isBlank(dt))
			return null;

		SimpleDateFormat formatter = new SimpleDateFormat(pattern);

		try {
			return formatter.parse(dt);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public static long dateToMicroSegundos(Date date) {
		long time = date.getTime() * 1000;
		return time;
	}

	public static Date microSegundosToDate(long micro) {
		Date date = new Date(micro / 1000);
		return date;
	}

	public static Integer getManagerId() {
		/* Le do arquivo properties a o managerId */
		Integer retorno = getPropertyFromFile("manhattan.manager.id") == "" ? null : Integer.valueOf(getPropertyFromFile("manhattan.manager.id"));
		return retorno;
	}

	public static String getPropertyFromFile(String key) {
		/* Le do arquivo properties a localizacao do arquivo de log */
		return EnvironmentVariables.getManhattanProperties().getValue(key);
	}
	
	public static String getMessageFromFile(String key) {
		// Le do arquivo properties as mensagens da aplica��o
		return EnvironmentVariables.getMessageProperties().getValue(key);
	}

	// Extrai a lista de chaves do synthetico, usado na comunicacao com o LMDS
	public static List<String> extractKeyList(String key) {

		if (StringUtils.isBlank(key))
			return null;
		
		String[] splitTemp = StringUtils.split(key, Constant.SIMULATION.SEPARATOR_SYNTHETIC_KEYMAP_STRATEGY_TYPE);

		if (StringUtils.isBlank(splitTemp[0]))
			return null;
		
		String[] split = StringUtils.split(splitTemp[0], Constant.SIMULATION.SEPARATOR_SYNTHETIC_KEYMAP);

		if (split == null || split.length == 0)
			return null;
		
		if (extractedKeyListAuxiliar == null) {
			extractedKeyListAuxiliar = new ArrayList<>();
		}
		
		extractedKeyListAuxiliar = Arrays.asList(split);

		return extractedKeyListAuxiliar;
	}
	
    public static long getNewRequestId() {
        return Double.valueOf(Math.random() * (new Date()).getTime()).longValue();
    }
    
    public static Level convertToLevel( String paramLevel ){
		
		if ( StringUtils.isBlank( paramLevel) )
			return null;
		
		if ( paramLevel.equals( Level.DEBUG.toString() ) )
			return Level.DEBUG;
		else
			if ( paramLevel.equals( Level.ERROR.toString() ) )
				return Level.ERROR;
			else
				if ( paramLevel.equals( Level.INFO.toString() ) )
					return Level.INFO;
				else
					if ( paramLevel.equals( Level.WARN.toString() ) )
						return Level.WARN;
					else
						return Level.FATAL;
	}
}
