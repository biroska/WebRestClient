package com.ubs.manhatthan.manager.dispatcher.manager;

import java.io.Serializable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.exception.EngineExceptionManhattan;
import com.ubs.manhatthan.manager.cache.CacheHelper;
import com.ubs.manhatthan.manager.converters.ConvertToProtobuffer;
import com.ubs.manhatthan.manager.facade.Facade;
import com.ubs.manhatthan.manager.logger.ApplicationLogger;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_to_engine_message;
import com.ubs.manhatthan.manager.persistence.entities.CommandMessage;
import com.ubs.manhatthan.manager.persistence.entities.LegStrategyReport;
import com.ubs.manhatthan.manager.persistence.entities.Message;
import com.ubs.manhatthan.manager.persistence.entities.StrategyOrders;
import com.ubs.manhatthan.manager.persistence.entities.StrategyReport;

@Service("managerDispatcher")
@Scope("singleton")
public class Manager implements Serializable {
	
	private static final long serialVersionUID = -231889308526694072L;
	
	@Autowired
	private Facade facade;
	
	public pb_to_engine_message managerMessage(Message obj) throws Exception{
		
		pb_to_engine_message engineMessage = null;
		
		if ( obj == null )
			return null;
		
		if ( obj instanceof StrategyReport ){
			
			StrategyReport report = ( StrategyReport ) obj;
			Long engineId = null;
			
			if ( report != null && report.getLegStrategyList() != null && !report.getLegStrategyList().isEmpty() &&
				 report.getLegStrategyList().get(0) != null && report.getLegStrategyList().get(0).getAccount() != null &&
				 report.getLegStrategyList().get(0).getAccount().getCode() != null) {
				
				engineId = facade.getEngineIdByAccount(report.getLegStrategyList().get(0).getAccount().getCode());
			}
			
			Long engineIdView = report.getHeader().getEngineInstanceId() == null ? null : report.getHeader().getEngineInstanceId()/1000L;
			
			engineId = engineId == null ? engineIdView : engineId;
			
			if (engineId == null) {
				ApplicationLogger.logInfo("No engines associated for current customer [" + report.getLegStrategyList().get(0).getAccount().getCode() + "]");
				
				throw new EngineExceptionManhattan("No engines associated for current customer");
			}
			
			report.getHeader().setEngineInstanceId(engineId);
			
			// popula o cache de client account para posteriormente 
			// otimizar a reconstrucao da msg para a tela
			if (null != report.getLegStrategyList()) {
				for (LegStrategyReport leg : report.getLegStrategyList() ) {
					CacheHelper.putClientAccount( leg.getAccount() );
					leg.getId().setEngineId( engineId );
					leg.getId().setStrategyId( report.getId().getStrategyId() );
				}	
			}		

			switch (report.getHeader().getMessageType()) {
			
				case CREATE_STRATEGY:
					engineMessage = manageCreateStrategy(report);
					
					ApplicationLogger.logInfo("[CREATE_STRATEGY] sending messag: " + engineMessage );
					
					break;
					
				case MODIFY_STRATEGY:
					engineMessage = manageModifyCancelStrategy(report);
					
					ApplicationLogger.logInfo("[MODIFY_STRATEGY] sending messag: " + engineMessage );
					
					break;
					
				case RESUME_STRATEGY:
				case PAUSE_STRATEGY:
				case CANCEL_STRATEGY:
					engineMessage = manageCommandStrategy(report);
					
					//StrategyCache.StrategyReportMapByRequestId.put( report.getHeader().getManagerRequestId() , report );
					
					ApplicationLogger.logInfo("[RESUME_STRATEGY|PAUSE_STRATEGY|CANCEL_STRATEGY] sending messag: " + engineMessage );
					
					break;

			default:
				ApplicationLogger.logWarn("Tipo de mensagen desconhecido!!!!!" + obj );
			
				break;
			}
			
		} else
			
			if ( obj instanceof StrategyOrders ){
				
				StrategyOrders order = (StrategyOrders) obj;
				
				//order.getHeader().setManagerRequestId(StrategyCache.generateRequestId());
				
				switch (order.getHeader().getMessageType()) {
				
					case LEGGED_ORDER:
						engineMessage = manageLeggedMessage(order);
						
						ApplicationLogger.logInfo("[LEGGED_ORDER] sending messag: " + engineMessage);
						
						break;
						
					case REPORT_EXECUTION_ORDER:
						engineMessage = manageExecutionReportOrder(order);
						
						ApplicationLogger.logInfo("[REPORT_EXECUTION_ORDER] sending messag: " + engineMessage);
						
						break;
						
					case NEW_ORDER:
						engineMessage = manageNewOrderSingle(order);
						
						ApplicationLogger.logInfo("[NEW_ORDER] sending messag: " + engineMessage);
						
						break;

				default:
					ApplicationLogger.logWarn("Tipo de mensagen desconhecido!!!!!" + obj);
					break;
				}
				
			} else
				if (obj instanceof CommandMessage) {
					CommandMessage commandMessage = (CommandMessage) obj;
					
					engineMessage = manageCommandMessage(commandMessage);
					
					ApplicationLogger.logInfo("[CommandMessage] sending messag: " + engineMessage);
				}
		
		return engineMessage;
	}
	
	
	private pb_to_engine_message manageCreateStrategy(StrategyReport report) throws Exception {
		
		// Converter to protobuffer
		pb_to_engine_message engineMessage = ConvertToProtobuffer.convertToStrategy( report );
		
		return engineMessage;
	}
	
	private pb_to_engine_message manageModifyCancelStrategy(StrategyReport report) throws Exception {

		// Converter to protobuffer
		pb_to_engine_message engineMessage = ConvertToProtobuffer.convertToStrategy(report);
		
		return engineMessage;
	}
	
	private pb_to_engine_message manageCommandStrategy(StrategyReport report) throws Exception {
		
		// Converter to protobuffer
		pb_to_engine_message engineMessage = ConvertToProtobuffer.convertToCommandStrategy(report);
		
		return engineMessage;
	}
	
	private pb_to_engine_message manageLeggedMessage(StrategyOrders order) throws Exception{
		// Converter to protobuffer
		pb_to_engine_message engineMessage = ConvertToProtobuffer.convertToLeggedOrder ( order );
		
		return engineMessage;
	}

	private pb_to_engine_message manageExecutionReportOrder(StrategyOrders order) throws Exception {
		
//		Enricher
		try {
//			Nao precisa enriquecer, pois os campos obrigatorios (strategyId, legSeq, Instrument,) 
//			existem na tela ou serao setados com 0
//			order = enricher.enrichStrategyOrder( order );
//		Converter to protobuffer
			pb_to_engine_message engineMessage = ConvertToProtobuffer.convertToReportOrder( order );
			return engineMessage;
		} catch (Exception e) {
			e.printStackTrace();
			
			throw e;
		}
	}

	private pb_to_engine_message manageNewOrderSingle(StrategyOrders order) throws DAOExceptionManhattan {
//		e uma new order nao ha necessidade de enriquecer, apenas retransmitir a mensagem
		try {
//		Converter to protobuffer
			pb_to_engine_message engineMessage = ConvertToProtobuffer.convertToNewOrderSingle( order );
			return engineMessage;
		} catch (DAOExceptionManhattan e) {
			e.printStackTrace();
			
			throw e;
		}
		
	}
	
	private pb_to_engine_message manageCommandMessage(CommandMessage commandMessage) {
		
//		Enricher
		
//		Converter to protobuffer
		pb_to_engine_message engineMessage = ConvertToProtobuffer.convertToCommandMessage ( commandMessage );
		
		return engineMessage;
	}

	public void setFacade(Facade facade) {
		this.facade = facade;
	}
}