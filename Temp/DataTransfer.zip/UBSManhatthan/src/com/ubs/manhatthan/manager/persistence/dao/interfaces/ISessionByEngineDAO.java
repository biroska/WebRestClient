/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.persistence.entities.SessionByEngine;

/**
 * @author galdinoa
 *
 */
public interface ISessionByEngineDAO extends IGenericDAO<SessionByEngine, Long> {

	public SessionByEngine saveSessionByEngine(SessionByEngine sessionByEngine) throws DAOExceptionManhattan;

	public void deleteSessionByEngine(SessionByEngine sessionByEngine) throws DAOExceptionManhattan;
	
	public SessionByEngine getByEngineIdAndSessionId( Integer engineId, Integer sessionId ) throws DAOExceptionManhattan;
}