/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.persistence.entities.TraderExchangeCode;

/**
 * @author galdinoa
 *
 */
public interface ITraderExchangeCodeDAO extends IGenericDAO<TraderExchangeCode, Long> {

	TraderExchangeCode saveTraderExchangeCode(TraderExchangeCode traderExchangeCode) throws DAOExceptionManhattan;}
