package com.ubs.manhatthan.manager.enums;

public enum EnviromentEnum {
	
	LOCAL,
	DEV,
	UAT,
	PROD;
}
