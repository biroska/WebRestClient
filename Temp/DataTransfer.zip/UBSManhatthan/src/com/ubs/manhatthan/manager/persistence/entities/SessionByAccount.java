package com.ubs.manhatthan.manager.persistence.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name="TB_REL_SESSIONS_PER_ACCOUNT",
uniqueConstraints={
		   @UniqueConstraint(columnNames={"ACCOUNT_ID", "SESSION_ID"}, name = "CK_SESSIONS_PER_ACCOUNT")
		})
public class SessionByAccount implements Serializable {
	private static final long serialVersionUID = 1L;
	public SessionByAccount(){}
	
	public SessionByAccount(ClientAccount clientAccountId, OrderFixSession orderFixSessionId) {
		super();
		this.clientAccount = clientAccountId;
		this.orderFixSession = orderFixSessionId;
	}

	@Id
	@Column ( name = "ID")
	@SequenceGenerator(name = "TB_REL_SESSIONS_PER_ACCOUNT_ID_GENERATOR", sequenceName = "SEQ_REL_SESSIONS_PER_ACCOUNT", allocationSize = 1)
	@GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "TB_REL_SESSIONS_PER_ACCOUNT_ID_GENERATOR" )
	private Long id;
	
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name = "ACCOUNT_ID", nullable = false )
	private ClientAccount clientAccount;
	
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name = "SESSION_ID", nullable = false )
	private OrderFixSession orderFixSession;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public ClientAccount getClientAccount() {
		return clientAccount;
	}

	public void setClientAccount(ClientAccount clientAccount) {
		this.clientAccount = clientAccount;
	}

	public OrderFixSession getOrderFixSession() {
		return orderFixSession;
	}

	public void setOrderFixSession(OrderFixSession orderFixSession) {
		this.orderFixSession = orderFixSession;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((clientAccount == null) ? 0 : clientAccount.hashCode());
		result = prime
				* result
				+ ((orderFixSession == null) ? 0 : orderFixSession
						.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SessionByAccount other = (SessionByAccount) obj;
		if (clientAccount == null) {
			if (other.clientAccount != null)
				return false;
		} else if (!clientAccount.equals(other.clientAccount))
			return false;
		if (orderFixSession == null) {
			if (other.orderFixSession != null)
				return false;
		} else if (!orderFixSession.equals(other.orderFixSession))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "SessionByAccount [id=" + id + ", clientAccountId="
				+ clientAccount + ", orderFixSessionId=" + orderFixSession
				+ "]";
	}
}