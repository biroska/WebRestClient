package com.ubs.manhatthan.manager.persistence.dao;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IEngineInstanceDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IEngineUmdfChannelDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IUmdfChannelByEngineAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IUmdfChannelByEngineDAO;
import com.ubs.manhatthan.manager.persistence.entities.EngineInstance;
import com.ubs.manhatthan.manager.persistence.entities.EngineUmdfChannel;
import com.ubs.manhatthan.manager.persistence.entities.UmdfChannelByEngine;
import com.ubs.manhatthan.manager.persistence.entities.audit.UmdfChannelByEngineAudit;

@Repository
@Scope("singleton")
public class UmdfChannelByEngineDAO extends GenericDAO<UmdfChannelByEngine, Long> implements IUmdfChannelByEngineDAO, Serializable {
	
	private static final long serialVersionUID = 4267896992567626971L;

	String deleteQueryByEngine = "DELETE FROM UmdfChannelByEngine o WHERE o.engine.id = ?";
	
	@Autowired
	private IEngineInstanceDAO engineInstanceDAO;
	
	@Autowired
	private IEngineUmdfChannelDAO engineUmdfChannelDAO;
	
	@Autowired
	private IUmdfChannelByEngineAuditDAO umdfChannelByEngineAuditDAO;
	
	@Autowired
	private User user;
	
	@Override
	public UmdfChannelByEngine saveUmdfChannelByEngine( UmdfChannelByEngine umdfChannelByEngine ) throws DAOExceptionManhattan {
		try {
			ActionTypeEnum action = umdfChannelByEngine.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;
	
			umdfChannelByEngine  = update( umdfChannelByEngine );
	
			UmdfChannelByEngineAudit ofsa = new UmdfChannelByEngineAudit( umdfChannelByEngine, action, user.getLogin(), new Date() );
			
			umdfChannelByEngineAuditDAO.update( ofsa );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return umdfChannelByEngine;
	}

	public Long generate( int qtd ) throws DAOExceptionManhattan {
		
		List<EngineInstance> engineInstanceList = engineInstanceDAO.findAll();
		List<EngineUmdfChannel> engineUmdfChannelList = engineUmdfChannelDAO.findAll();
		
		Long qtRegs = 0L;
		
		for ( int i = 1; i<= qtd; i++ ){
			saveUmdfChannelByEngine( new UmdfChannelByEngine( engineInstanceList.get( i -1 ), engineUmdfChannelList.get( qtd -i ) ) );
			qtRegs++;
		}
		
		return qtRegs;
	}
	
	public boolean verifyExistByEngineId(Long engineId) throws DAOExceptionManhattan{		
		
		boolean exist = false;
		List<Long> resultList = null;
		try {
			
			if (engineId!=null) {
				String query = " SELECT  o.id " +
		            	   " FROM UmdfChannelByEngine o "
		            	   + " WHERE o.engine.engineId = :engineId ";
			
				TypedQuery<Long> typedQuery = getEm().createQuery( query, Long.class );
				typedQuery.setParameter("engineId", engineId);
				
				resultList = typedQuery.getResultList();
				if (resultList!=null && !resultList.isEmpty()) {
					exist = true;
				}
			}			
			
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return exist;		
	}
	
	public boolean verifyExistByChanelId(Long chanelId) throws DAOExceptionManhattan{		
		
		boolean exist = false;
		List<Long> resultList = null;
		try {
			
			if (chanelId!=null) {
				String query = " SELECT  o.id " +
		            	   " FROM UmdfChannelByEngine o "
		            	   + " WHERE o.engineUmdfChannel.channelId = "+chanelId;
			
				TypedQuery<Long> typedQuery = getEm().createQuery( query, Long.class );
				
				resultList = typedQuery.getResultList();
				if (resultList!=null && !resultList.isEmpty()) {
					exist = true;
				}
			}			
			
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return exist;		
	}
	
	public List<EngineUmdfChannel> findByEngineId(Integer id) throws DAOExceptionManhattan{
		List<EngineUmdfChannel> resultList = null;
		try {
			
			if (id!=null) {
				String query = "select engineUmdfChannel FROM UmdfChannelByEngine o WHERE o.engine.id = "+id;
				
				TypedQuery<EngineUmdfChannel> typedQuery = getEm().createQuery( query, EngineUmdfChannel.class );
				resultList = typedQuery.getResultList();
			}			
			
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		return resultList;
	}
	
	public List<UmdfChannelByEngine> findUmdfByEngineId(Integer id) throws DAOExceptionManhattan{
		List<UmdfChannelByEngine> resultList = null;
		try {
			
			if (id!=null) {
				String query = "select o FROM UmdfChannelByEngine o WHERE o.engine.id = "+id;
				
				TypedQuery<UmdfChannelByEngine> typedQuery = getEm().createQuery( query, UmdfChannelByEngine.class );
				resultList = typedQuery.getResultList();
			}			
			
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		return resultList;
	}
	
	@Override
	public void deleteUmdfChanelByEngine(EngineInstance engine) throws DAOExceptionManhattan {		
		if ((engine != null) && (engine.getId() != null)) {
			try {
				Query createQuery = getEm().createQuery(deleteQueryByEngine);
				createQuery.setParameter(1, engine.getId());
				
				createQuery.executeUpdate();
			} catch ( Exception e ) {
				throw new DAOExceptionManhattan( e );
			}
		}
	}

	public void setEngineInstanceDAO(IEngineInstanceDAO engineInstanceDAO) {
		this.engineInstanceDAO = engineInstanceDAO;
	}

	public void setEngineUmdfChannelDAO(IEngineUmdfChannelDAO engineUmdfChannelDAO) {
		this.engineUmdfChannelDAO = engineUmdfChannelDAO;
	}

	public void setUmdfChannelByEngineAuditDAO(IUmdfChannelByEngineAuditDAO umdfChannelByEngineAuditDAO) {
		this.umdfChannelByEngineAuditDAO = umdfChannelByEngineAuditDAO;
	}

	public void setUser(User user) {
		this.user = user;
	}
}