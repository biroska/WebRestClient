package com.ubs.manhatthan.manager.simulator.multileg;

import java.util.ArrayList;
import java.util.List;

import com.ubs.manhatthan.manager.enums.StrategyTypeEnum;

/**
 * For MarketWatch calculation must be defined the follow variables:
 *    ImputMultilegSimulation class:
 *       - onlyTarget = true
 *       - simulationMode
 *       - List<InputMultilegSimulationItem> (one for each leg)
 * 
 * @author rossir
 *
 */
public class InputMultilegSimulation
{
	private Double                             UserDefinedTarget; //field informed by user
	private boolean                            onlyTarget;        //flag to make the calculations only by the target attribute
	private boolean                            marketWatch;
	private Double                             dollarSpot;        //Used to calculate the DIV1
	private StrategyTypeEnum                   simulationMode;    //Type of simulation (Strategy type)
	private List<InputMultilegSimulationItem>  inputItens;        //List of rows in Strategy Parameters
	
	public InputMultilegSimulation()
	{
		this.UserDefinedTarget = null;
		this.dollarSpot        = null;
		
		this.inputItens        = new ArrayList<InputMultilegSimulationItem>();
		
		this.simulationMode    = StrategyTypeEnum.UNKNOWN;
		
		this.marketWatch       = false;
		this.onlyTarget        = false;
	}

	public List<InputMultilegSimulationItem> getInputItens()
	{
		return inputItens;
	}

	public void setInputItens(List<InputMultilegSimulationItem> itens)
	{
		this.inputItens = itens;
	}
	
	public boolean isOnlyTarget()
	{
		return onlyTarget;
	}

	public void setOnlyTarget(boolean onlyTarget)
	{
		this.onlyTarget = onlyTarget;
	}
	
	public Double getUserDefinedTarget()
	{
		return UserDefinedTarget;
	}

	public void setUserDefinedTarget(Double userDefinedTarget)
	{
		UserDefinedTarget = userDefinedTarget;
	}

	public StrategyTypeEnum getSimulationMode()
	{
		return simulationMode;
	}
	
	public Double getDollarSpot()
	{
		return dollarSpot;
	}

	public void setDollarSpot(Double dollarSpot)
	{
		this.dollarSpot = dollarSpot;
	}

	public void setSimulationMode(StrategyTypeEnum simulationMode)
	{
		this.simulationMode = simulationMode;
	}
	
	public boolean isMarketWatch() {
		return marketWatch;
	}

	public void setIsMarketWatch() {
		this.marketWatch = true;
	}

	@Override
	public String toString()
	{
		return "InputMultilegSimulation [UserDefinedTarget=" + UserDefinedTarget
				+ ", onlyTarget=" + onlyTarget
				+ ", marketWatch=" + marketWatch
				+ ", dollarSpot=" + dollarSpot
				+ ", simulationMode=" + simulationMode
				+ ", inputItens=" + inputItens + "]";
	}
}