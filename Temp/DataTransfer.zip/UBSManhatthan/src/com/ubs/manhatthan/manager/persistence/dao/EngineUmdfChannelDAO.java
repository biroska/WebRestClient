package com.ubs.manhatthan.manager.persistence.dao;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.exception.BussinessExceptionManhattan;
import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.enums.ChannelTypeEnum;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IEngineUmdfChannelAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IEngineUmdfChannelDAO;
import com.ubs.manhatthan.manager.persistence.entities.EngineUmdfChannel;
import com.ubs.manhatthan.manager.persistence.entities.Exchange;
import com.ubs.manhatthan.manager.persistence.entities.audit.EngineUmdfChannelAudit;

@Repository
@Scope("singleton")
public class EngineUmdfChannelDAO extends GenericDAO<EngineUmdfChannel, Long> implements IEngineUmdfChannelDAO, Serializable {
	
	private static final long serialVersionUID = -1448549024920110230L;

	private ExchangeDAO exchangeDAO = new ExchangeDAO();
	
	@Autowired
	private IEngineUmdfChannelAuditDAO engineUmdfChannelAuditDAO;
	
	@Autowired
	private UmdfChannelByEngineDAO umdfChannelByEngineDAO;
	
	@Autowired
	private User user;
	
	@Override
	public EngineUmdfChannel saveEngineUmdfChannel( EngineUmdfChannel engineUmdfChannel ) throws DAOExceptionManhattan {
		
		try {
			ActionTypeEnum action = engineUmdfChannel.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;
	
			engineUmdfChannel  = update( engineUmdfChannel );
	
			EngineUmdfChannelAudit euca = new EngineUmdfChannelAudit( engineUmdfChannel, action, user.getLogin(), new Date() );
			
			engineUmdfChannelAuditDAO.save( euca );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return engineUmdfChannel;
	}

	@Override
	public void deleteUmdfInstance( EngineUmdfChannel engineUmdfChannel ) throws DAOExceptionManhattan, BussinessExceptionManhattan
	{
		try {
			boolean existUmdfChannelByEngine = umdfChannelByEngineDAO.verifyExistByChanelId(engineUmdfChannel.getChannelId());
			
			if(!existUmdfChannelByEngine){
				deleteById(engineUmdfChannel.getId());
				EngineUmdfChannelAudit pa = new EngineUmdfChannelAudit( engineUmdfChannel, ActionTypeEnum.DELETE, user.getLogin(), new Date() );
				
				engineUmdfChannelAuditDAO.update( pa );
			}else{
				throw new BussinessExceptionManhattan("Cannot delete Umdf Channel Instance "+ engineUmdfChannel.getChannelId()+" associated with Engine");
			}
		} catch ( BussinessExceptionManhattan e ) {
			throw e;
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
	}

	public Long generate( int qtd ) throws DAOExceptionManhattan {
		
		List<Exchange> exchangeList = exchangeDAO.findAll();
		
		long idGenerico = System.currentTimeMillis();
		
		Long qtRegs = 0L;
		
		for ( int i = 1; i<= qtd; i++ ){
			saveEngineUmdfChannel( new EngineUmdfChannel( idGenerico +i, exchangeList.get( i % 2),
																		"incrementalIp_"+i, (long) 8079 +i,
																		"marketRecIp_"+i, (long) 9089 +i,
																		"instrDefIp_"+i, (long) 7069 + i, ChannelTypeEnum.MBO  ) );
			qtRegs++;
		}
		
		return qtRegs;
	}
	
	public EngineUmdfChannel getByIndex( int index ) throws DAOExceptionManhattan  {
		return findAll().get( index );
	}

	public void setEngineUmdfChannelAuditDAO(
			IEngineUmdfChannelAuditDAO engineUmdfChannelAuditDAO) {
		this.engineUmdfChannelAuditDAO = engineUmdfChannelAuditDAO;
	}

	public void setUser(User user) {
		this.user = user;
	}
}