/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import java.util.List;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.persistence.entities.TcpRecoverySession;

/**
 * @author galdinoa
 *
 */
public interface ITcpRecoverySessionDAO extends IGenericDAO<TcpRecoverySession, Long> {

	TcpRecoverySession saveTcpRecoverySession(TcpRecoverySession tcpRecoverySession) throws DAOExceptionManhattan;

	List<TcpRecoverySession> getTcpRecoveries() throws DAOExceptionManhattan;

	
}
