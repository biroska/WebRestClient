package com.ubs.manhatthan.manager.persistence.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;

import com.ubs.manhatthan.manager.enums.OrderStatusEnum;
import com.ubs.manhatthan.manager.enums.SideEnum;
import com.ubs.manhatthan.manager.utils.Util;

@Entity
@Table(name="TB_ORDER_TRADES",
uniqueConstraints={
		   @UniqueConstraint(columnNames={"SIDE", "SYMBOL", "UNIQUE_TRADE_ID", "ORDER_DATE"}, name = "CK_ORDER_TRADES_UNIQUE_TRADE")
		})
public class OrderTrade implements Serializable {
	
	private static final long serialVersionUID = 2685305232928004340L;

	public OrderTrade(){}
	
	public OrderTrade(StrategyOrders strategyOrder,
			OrderStatusEnum orderStatus, String symbol, SideEnum side,
			ClientAccount account, String tradeId, Long quantity, Double price) {
		super();
		this.strategyOrder = strategyOrder;
		this.orderStatus = orderStatus;
		this.symbol = symbol;
		this.side = side;
		this.account = account;
		this.tradeId = tradeId;
		this.quantity = quantity;
		this.price = price;
	}
	
/* Constructor utilized by "report by strategy, by average, and By Price" - OrderTradeDAO.reportByUser
 * Don't modify - create your own!
 * */
	public OrderTrade( Long strategyId, String strategyDescription, String buySellDesc, String symbol, Long quantitySum, Double priceAverage /*,Double volume*/ ) {
		super();
		this.strategyId = strategyId; 
		this.strategyDescription = String.valueOf( strategyId + " - " + strategyDescription ); 
		this.symbol = symbol;
		this.buySellDesc = buySellDesc;
		this.quantitySum = quantitySum;
		this.priceAverage = priceAverage;
//		this.volume = volume;
	}
	
	
	/* Constructor utilized by "report by execution" - OrderTradeDAO.reportByUser 
	 * Don't modify - create your own!
	 * */
	public OrderTrade( Long strategyId, String strategyDescription, String buySellDesc, String symbol, 
			           Date dtExecution, Long quantitySum, Double priceAverage, String clientDescription ) {
		super();
		this.strategyId = strategyId; 
		this.strategyDescription = String.valueOf( strategyId + " - " + strategyDescription );
		this.symbol = symbol;
		this.buySellDesc = buySellDesc;
		this.quantitySum = quantitySum;
		this.priceAverage = priceAverage;
		this.orderTimestamp = dtExecution;
		this.clientDescription = clientDescription;
		this.hrExecution = Util.convertDatePattern( orderTimestamp, "HH:mm:ss" );
	}
	
//	Construtor para copy
	public OrderTrade( OrderTrade orderTrade ) {
		super();
		this.id = orderTrade.id;
		this.strategyOrder = orderTrade.strategyOrder;
		this.orderTimestamp = orderTrade.orderTimestamp;
		this.orderStatus = orderTrade.orderStatus;
		this.symbol = orderTrade.symbol;
		this.side = orderTrade.side;
		this.account = orderTrade.account;
		this.tradeId = orderTrade.tradeId;
		this.quantity = orderTrade.quantity;
		this.price = orderTrade.price;
		this.login = orderTrade.login;
		this.buySellDesc = orderTrade.buySellDesc;
		this.quantitySum = orderTrade.quantitySum;
		this.priceAverage = orderTrade.priceAverage;
		this.strategyDescription = orderTrade.strategyDescription;
		this.strategyId = orderTrade.strategyId;
		this.startDt = orderTrade.startDt;
		this.endDt = orderTrade.endDt;
	}

	@Id
	@Column ( name = "ID") // composto por data, engine e order da estrategyOrder 
	private Long id;
	
	@ManyToOne(fetch=FetchType.LAZY, cascade = CascadeType.REFRESH )
	@JoinColumns({
		  @JoinColumn( name = "ENGINE_ID", referencedColumnName = "ENGINE_ID", nullable = false ),
		  @JoinColumn( name = "ORDER_ID", referencedColumnName = "ORDER_ID" , nullable = false ),
		  @JoinColumn( name = "ORDER_DATE", referencedColumnName = "ORDER_DATE" , nullable = false )
		})
	private StrategyOrders strategyOrder;
	
	@Temporal ( TemporalType.TIMESTAMP )
	@Column ( name = "ORDER_TIMESTAMP", nullable=false )
	private Date orderTimestamp;
	
	@Column ( name = "ORDER_STATUS", nullable=false )
	private OrderStatusEnum orderStatus;
	
	@Column ( name = "SYMBOL", nullable=false )
	private String symbol;
	
	@Column ( name = "SIDE", nullable=false )
	private SideEnum side;
	
	@ManyToOne(fetch=FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn( name = "ACCOUNT", nullable=false )
	private ClientAccount account;
	
	@Column ( name = "UNIQUE_TRADE_ID", nullable=false, length = 10 )
	private String tradeId;
	
	@Column ( name = "QUANTITY", nullable=false )
	private Long quantity;
	
	@Column ( name = "PRICE", columnDefinition= "Decimal(13,7)" )
	private Double price;
	
	@Column ( name = "LOGIN", length = 64)
	private String login;
	
	@Transient
	private String buySellDesc;
	
	@Transient
	private Long quantitySum;
	
	@Transient
	private Double priceAverage;
	
//	@Transient
//	private Double volume;
	
	@Transient
	private String strategyDescription;
	
	@Transient
	private Long strategyId;
	
	@Transient
	private Date startDt;
	
	@Transient
	private Date endDt;
	
	@Transient
	private String hrExecution;
	
	@Transient
	private String clientDescription;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public StrategyOrders getStrategyOrder() {
		return strategyOrder;
	}

	public void setStrategyOrder(StrategyOrders strategyOrder) {
		this.strategyOrder = strategyOrder;
	}

	public Date getOrderTimestamp() {
		return orderTimestamp;
	}

	public void setOrderTimestamp(Date orderTimestamp) {
		this.orderTimestamp = orderTimestamp;
	}

	public OrderStatusEnum getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(OrderStatusEnum orderStatus) {
		this.orderStatus = orderStatus;
	}

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	public SideEnum getSide() {
		return side;
	}

	public void setSide(SideEnum side) {
		this.side = side;
	}

	public ClientAccount getAccount() {
		return account;
	}

	public void setAccount(ClientAccount account) {
		this.account = account;
	}

	public String getTradeId() {
		return tradeId;
	}

	public void setTradeId(String tradeId) {
		this.tradeId = tradeId;
	}

	public Long getQuantity() {
		return quantity;
	}

	public void setQuantity(Long quantity) {
		this.quantity = quantity;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}
	
	public String getBuySellDesc() {
		return buySellDesc;
	}

	public void setBuySellDesc(String buySellDesc) {
		this.buySellDesc = buySellDesc;
	}

	public Long getQuantitySum() {
		return quantitySum;
	}

	public void setQuantitySum(Long quantitySum) {
		this.quantitySum = quantitySum;
	}

	public Double getPriceAverage() {
		return priceAverage;
	}

	public void setPriceAverage(Double priceAverage) {
		this.priceAverage = priceAverage;
	}

//	public Double getVolume() {
//		return volume;
//	}
//
//	public void setVolume(Double volume) {
//		this.volume = volume;
//	}

	public Long getStrategyId() {
		return strategyId;
	}

	public void setStrategyId(Long strategyId) {
		this.strategyId = strategyId;
	}
	
	public String getStrategyDescription() {
		return strategyDescription;
	}

	public void setStrategyDescription(String strategyDescription) {
		this.strategyDescription = strategyDescription;
	}
	
	public Date getStartDt() {
		return startDt;
	}

	public void setStartDt(Date startDt) {
		this.startDt = startDt;
	}

	public Date getEndDt() {
		return endDt;
	}

	public void setEndDt(Date endDt) {
		this.endDt = endDt;
	}
	
	public String getHrExecution( Date orderTimestamp ){
		return hrExecution;
	}

	public String getClientDescription() {
		return clientDescription;
	}

	public void setClientDescription(String clientDescription) {
		this.clientDescription = clientDescription;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((account == null) ? 0 : account.hashCode());
		result = prime * result
				+ ((orderStatus == null) ? 0 : orderStatus.hashCode());
		result = prime * result + ((price == null) ? 0 : price.hashCode());
		result = prime * result
				+ ((quantity == null) ? 0 : quantity.hashCode());
		result = prime * result + ((side == null) ? 0 : side.hashCode());
		result = prime * result
				+ ((strategyOrder == null) ? 0 : strategyOrder.hashCode());
		result = prime * result + ((symbol == null) ? 0 : symbol.hashCode());
		result = prime * result + ((tradeId == null) ? 0 : tradeId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OrderTrade other = (OrderTrade) obj;
		if (account == null) {
			if (other.account != null)
				return false;
		} else if (!account.equals(other.account))
			return false;
		if (orderStatus != other.orderStatus)
			return false;
		if (price == null) {
			if (other.price != null)
				return false;
		} else if (!price.equals(other.price))
			return false;
		if (quantity == null) {
			if (other.quantity != null)
				return false;
		} else if (!quantity.equals(other.quantity))
			return false;
		if (side != other.side)
			return false;
		if (strategyOrder == null) {
			if (other.strategyOrder != null)
				return false;
		} else if (!strategyOrder.equals(other.strategyOrder))
			return false;
		if (symbol == null) {
			if (other.symbol != null)
				return false;
		} else if (!symbol.equals(other.symbol))
			return false;
		if (tradeId == null) {
			if (other.tradeId != null)
				return false;
		} else if (!tradeId.equals(other.tradeId))
			return false;
		return true;
	}


	public String toContigenciaLog() {
        
        String order_trader = "|order_trader|";  
                     
        order_trader += "ID=" + id;
        
        if (strategyOrder!=null && strategyOrder.getId()!=null) {                  
               order_trader += ",ENGINE_ID=" + strategyOrder.getId().getEngineId()               
               + ",ORDER_ID=" + strategyOrder.getId().getOrderId()    
               + ",ORDER_DATE=" + strategyOrder.getId().getOrderDate();
        }else{
               order_trader += ",ENGINE_ID="            
               + ",ORDER_ID="
               + ",ORDER_DATE=";
        }
        
        order_trader += ",ORDER_TIMESTAMP=" + orderTimestamp
        + ",ORDER_STATUS=" + orderStatus
        + ",SYMBOL=" + getSymbol()
        + ",SIDE=" + side;
        
        if (account!= null) {
               order_trader += ",ACCOUNT=" + account.getCode();
        }else{
               order_trader += ",ACCOUNT=";
        }
        
        order_trader += ",UNIQUE_TRADE_ID=" + getTradeId()
        + ",QUANTITY=" + quantity
        + ",PRICE=" + price
        + ",LOGIN=" + login + "|\n";      
        
        return order_trader;
	}

	@Override
	public String toString() {
		return "OrderTrade [id=" + id + ", strategyOrder=" + strategyOrder
				+ ", orderTimestamp=" + orderTimestamp + ", orderStatus="
				+ orderStatus + ", symbol=" + symbol + ", side=" + side
				+ ", account=" + account + ", tradeId=" + tradeId
				+ ", quantity=" + quantity + ", price=" + price + ", login="
				+ login + ", buySellDesc=" + buySellDesc + ", quantitySum="
				+ quantitySum + ", priceAverage=" + priceAverage
				+ ", strategyDescription=" + strategyDescription
				+ ", strategyId=" + strategyId + ", startDt=" + startDt
				+ ", endDt=" + endDt + ", hrExecution=" + hrExecution
				+ ", clientDescription=" + clientDescription + "]\n";
	}

	public String getHrExecution() {
		return hrExecution;
	}

	public void setHrExecution(String hrExecution) {
		this.hrExecution = hrExecution;
	}
}