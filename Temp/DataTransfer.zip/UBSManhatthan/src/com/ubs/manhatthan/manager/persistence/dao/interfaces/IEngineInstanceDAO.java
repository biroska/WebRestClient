/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import java.util.List;

import com.ubs.manhatthan.exception.BussinessExceptionManhattan;
import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.persistence.entities.EngineInstance;
import com.ubs.manhatthan.manager.persistence.entities.UmdfChannelByEngine;


/**
 * @author galdinoa
 *
 */
public interface IEngineInstanceDAO extends IGenericDAO<EngineInstance, Integer> {

	EngineInstance saveEngineInstance(EngineInstance engine) throws DAOExceptionManhattan;
	
	void deleteEngineInstance(EngineInstance engine, List<UmdfChannelByEngine> umdfChannelByEngineList) throws DAOExceptionManhattan, BussinessExceptionManhattan;

	List<EngineInstance> getEngineByAccount(Long accountId) throws DAOExceptionManhattan;
}
