package com.ubs.manhatthan.manager.persistence.dao;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IExchangeDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.ITraderExchangeCodeAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.ITraderExchangeCodeDAO;
import com.ubs.manhatthan.manager.persistence.entities.Exchange;
import com.ubs.manhatthan.manager.persistence.entities.TraderExchangeCode;
import com.ubs.manhatthan.manager.persistence.entities.audit.TraderExchangeCodeAudit;

@Repository
@Scope("singleton")
public class TraderExchangeCodeDAO extends GenericDAO<TraderExchangeCode, Long> implements ITraderExchangeCodeDAO , Serializable {
	private static final long serialVersionUID = 1L;
	@Autowired
	private IExchangeDAO exchangeDAO;

	@Autowired
	private ITraderExchangeCodeAuditDAO traderExchangeCodeAuditDAO;
	
	@Autowired
	private User user;
	
	@Override
	public TraderExchangeCode saveTraderExchangeCode( TraderExchangeCode traderExchangeCode ) throws DAOExceptionManhattan {
		try {
			ActionTypeEnum action = traderExchangeCode.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;
	
			traderExchangeCode  = save( traderExchangeCode );
	
			TraderExchangeCodeAudit teca = new TraderExchangeCodeAudit( traderExchangeCode, action, user.getLogin(), new Date() );
			
			traderExchangeCodeAuditDAO.save( teca );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return traderExchangeCode;
	}
	
	public Long generate( int qtd ) throws DAOExceptionManhattan {
		
		List<Exchange> exchangeList = exchangeDAO.findAll();
//		List<Trader> traderList = traderDAO.findAll();
		
		Long qtRegs = 0L;
		
		for ( int i = 1; i<= qtd; i++ ){
			saveTraderExchangeCode( new TraderExchangeCode( "AIM*", exchangeList.get( i % 2 ), "Code_" + i) );
			qtRegs++;
		}
		
		return qtRegs;
	}


	public void setExchangeDAO(IExchangeDAO exchangeDAO) {
		this.exchangeDAO = exchangeDAO;
	}

	public void setTraderExchangeCodeAuditDAO(ITraderExchangeCodeAuditDAO traderExchangeCodeAuditDAO) {
		this.traderExchangeCodeAuditDAO = traderExchangeCodeAuditDAO;
	}

	public void setUser(User user) {
		this.user = user;
	}
}