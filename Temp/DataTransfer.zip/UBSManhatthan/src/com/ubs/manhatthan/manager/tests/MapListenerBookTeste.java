/**
 * 
 */
package com.ubs.manhatthan.manager.tests;

import java.util.List;

import com.ubs.manhatthan.manager.cache.LmdsCache;
import com.ubs.manhatthan.manager.dto.ReceiveSynthetic;
import com.ubs.manhatthan.manager.enums.StrategyTypeEnum;
import com.ubs.manhatthan.manager.lmdsadapter.LmdsManager;
import com.ubs.manhatthan.manager.lmdsadapter.SimulationItem;
import com.ubs.manhatthan.manager.mocks.SyntheticMock;

/**
 * @author galdinoa
 *
 */
public class MapListenerBookTeste {

	private static LmdsManager lmds = new LmdsManager();

	public static void main(String[] args) {
		
		ReceiveSynthetic synthetic = SyntheticMock.mockReceiveSynthetic( StrategyTypeEnum.MULTILEG_FRA, "DI1F17", "DI1F18" );
		lmds.subscribeManager( synthetic );
		
		synthetic = SyntheticMock.mockReceiveSynthetic( StrategyTypeEnum.MULTILEG_FRA, "DI1F18", "DI1F19" );
		lmds.subscribeManager( synthetic );
		
		synthetic = SyntheticMock.mockReceiveSynthetic( StrategyTypeEnum.UNKNOWN, "DI1F19" );
		lmds.subscribeManager( synthetic );
		
		synthetic = SyntheticMock.mockReceiveSynthetic( StrategyTypeEnum.UNKNOWN, "DI1F21" );
		lmds.subscribeManager( synthetic );
		
		List<SimulationItem> simulationListBySymbol = LmdsCache.getSimulationListBySymbol( "DI1F19" );
		
		System.out.println( "\n\n\n simulationListBySymbol: " + simulationListBySymbol );
	}
	
}
