package com.ubs.manhatthan.manager.persistence.dao;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.exception.BussinessExceptionManhattan;
import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IEngineInstanceAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IEngineInstanceDAO;
import com.ubs.manhatthan.manager.persistence.entities.EngineInstance;
import com.ubs.manhatthan.manager.persistence.entities.UmdfChannelByEngine;
import com.ubs.manhatthan.manager.persistence.entities.audit.EngineInstanceAudit;

@Repository
@Scope("singleton")
public class EngineInstanceDAO extends GenericDAO<EngineInstance, Integer> implements IEngineInstanceDAO, Serializable {
	
	private static final long serialVersionUID = 8632484491703636992L;

	@Autowired
	private IEngineInstanceAuditDAO engineInstanceAudit;
	
	@Autowired
	private SessionByEngineDAO sessionByEngineDAO;
	
	@Autowired
	private UmdfChannelByEngineDAO umdfChannelByEngineDAO;
	
	@Autowired
	private RecoverySessionByEngineDAO recoverySessionByEngineDAO;
	
	@Autowired
	private User user;
	
	@Override
	public EngineInstance saveEngineInstance( EngineInstance engine ) throws DAOExceptionManhattan {
		try{
			ActionTypeEnum action = engine.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;
	
			engine = update( engine );
	
			EngineInstanceAudit pa = new EngineInstanceAudit( engine, action, user.getLogin(), new Date() );
			
			engineInstanceAudit.update( pa );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return engine;
	}
	
	@Override
	public void deleteEngineInstance( EngineInstance engine, List<UmdfChannelByEngine> umdfChannelByEngineList) throws DAOExceptionManhattan, BussinessExceptionManhattan {
		try{			
			boolean existSessionByEngine =  sessionByEngineDAO.verifyExistByEngineId(engine.getEngineId());
			
			boolean existRecoverySessionByEngine = recoverySessionByEngineDAO.verifyExistByEngineId(engine.getEngineId());
			
			if (!existSessionByEngine && !existRecoverySessionByEngine) {
				if (umdfChannelByEngineList !=null && !umdfChannelByEngineList.isEmpty()) {
					for (UmdfChannelByEngine umdfChannelByEngine : umdfChannelByEngineList) {
						umdfChannelByEngineDAO.deleteById(umdfChannelByEngine.getId());
					}				
				}
				deleteById(engine.getId());
				
				EngineInstanceAudit pa = new EngineInstanceAudit( engine, ActionTypeEnum.DELETE, user.getLogin(), new Date() );
				
				engineInstanceAudit.update( pa );
			}else {
				throw new BussinessExceptionManhattan("Cannot delete Engine Instance: "+ engine.getEngineId()+"   Association found.");
			}			
			
		} catch ( BussinessExceptionManhattan e ) {
			throw e;
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<EngineInstance> getEngineByAccount( Long accountId ) throws DAOExceptionManhattan {
		
		String query = " SELECT ENG.ID, ENG.DESCRIPTION, ENG.ENGINE_ID, ENG.HOST, " +
					   "		ENG.PORT, ENG.CONFIG_PATH, ENG.LOG_PATH " +
					   "   FROM VW_SINACOR_BMF_ACCOUNTS V , " +
					   "        TB_ORDER_FIX_SESSION FIX_SES , " +
					   "        TB_ENGINE_INSTANCES ENG , " +
					   "        TB_REL_SESSIONS_PER_ACCOUNT REL_SA , " +
					   "        TB_REL_SESSIONS_PER_ENGINE REL_SEENG " +
					   "  WHERE REL_SA.ACCOUNT_ID = V.CLIENT_ACCOUNT " +
					   "    AND REL_SA.SESSION_ID = FIX_SES.ID " +
					   "    AND REL_SEENG.SESSION_ID = FIX_SES.ID " +
					   "    AND REL_SEENG.ENGINE_ID = ENG.ID " +
					   "    AND V.CLIENT_ACCOUNT = :accountId ";
		
		List<EngineInstance> resultList = null;
		try {
			Query createNativeQuery = getEm().createNativeQuery( query, EngineInstance.class);
			createNativeQuery.setParameter("accountId", accountId);
			
			resultList = createNativeQuery.getResultList();
			
		} catch ( Exception e ){
			e.printStackTrace();
			throw new DAOExceptionManhattan( e );
		}
		return resultList;
	}
	
	
	public Long generateEngine( int qtd ) throws DAOExceptionManhattan {
		
		Long qtRegs = 0L;
		
		for ( int i = 1; i<= qtd; i++ ){
			saveEngineInstance(  new EngineInstance( (long) i, " 255.255.255." + i, (long) 8079 + i, "EngDesc") );
			qtRegs++;
		}
		return qtRegs;
	}
	
	public EngineInstance getByIndex( int index ) throws DAOExceptionManhattan  {
		return findAll().get( index );
	}

	public void setUser(User user) {
		this.user = user;
	}

	public void setEngineInstanceAudit(IEngineInstanceAuditDAO engineInstanceAudit) {
		this.engineInstanceAudit = engineInstanceAudit;
	}
}