package com.ubs.manhatthan.manager.utils;

import org.apache.log4j.Level;

public interface Constant {

	public class COMUNICATION {

		public static String ADDRESS = "xsap6552vdap.sap.swissbank.com";
//		public static String ADDRESS = "localhost";
		public static int PORT = 6000;
		public static int MAX_NUMBER_PORT = 65535;
	}
	
	public class MESSAGES_CONFIGURATION {
		public static int HEARTBEAT_DELAY = 3;
		public static int HEARTBEAT_FAIL =  3;
		public static int STATISTICS_DEELAY = 3;
		
		//Random values for tests
//		public static long MANAGER_INSTANCE = new Random().nextInt(999) + 1;
//		final public static long MANAGER_INSTANCE = Long.valueOf( Util.getManagerId() );
		public static int HEARBEAT_DELAY_S = 5;
		public static int HEARBEAT_FAILOUT_C = 3;
		public static int DELAY_STATISTICS_S = 10;
		public static int DELAY_RECONNECTION_S = 10;
		public static double SOCKET_BUFFER_SIZE_MB = 1.;
		public static String REPORT_MODIFIED = "modified";
		public static String ENGINE_DISCONNECTED = "Engine is offline";
		public static String ENGINE_IS_DOWN = "Engine is offline.";
	}
	
	public class LOG_CONFIGURATION {
		public static String FILE_NAME  = "applicationLog";
		public static String FILE_EXTENSION  = ".log";
		public static Level LOG_LEVEL  = Level.INFO;
	}
	
	public class SIMULATION {
		public static Integer INITIAL_QUANTITY      	 = -1000;
		public static Double  INITIAL_PRICE      	     = -1000D;
		public static Double  INITIAL_DIV1          	 = -1000.0;
		public static Integer INITIAL_BUSINESS_DAYS 	 = -1000;
		public static String  INITIAL_MATURITY_DATE 	 = "99991231";
		public static Integer INITIAL_RANK          	 = -1000;
		public static Integer INITIAL_LEG_SEQ       	 = -1000;
		//public static Double  INITIAL_TARGET        	 = -1000000.0;
		public static Long INITIAL_INSTRUMENT    	 	 = -1000L;
		public static Integer INITIAL_AVAILABLE_QUANTITY = -1000;
		public static Integer INITIAL_MIN_BOOK_SIZE 	 = -1000;
		public static Integer DEFAULT_BOOK_LEVEL 		 = 5;
		public static Long    DEFAULT_BOOK_QUANTITY 	 = 0L;
		public static Double  DEFAULT_BOOK_PRICE 	     = 0D;
		public static Double  DEFAULT_DOLLAR_SPOT	     = 0D;
		public static String  SEPARATOR_SYNTHETIC_KEYMAP = "|";
		public static String  SEPARATOR_SYNTHETIC_KEYMAP_STRATEGY_TYPE = "#";
	}
	
	public class SYMBOL {
		
		public static String SPOT_DOLLAR                = "USDP0002";
		
		public static String FOWARD_DOLLAR_UNKNOWN      = "0";
		public static String FOWARD_DOLLAR_JANUARY      = "F";
		public static String FOWARD_DOLLAR_FEBRUARY     = "G";
		public static String FOWARD_DOLLAR_MARCH        = "H";
		public static String FOWARD_DOLLAR_APRIL        = "J";
		public static String FOWARD_DOLLAR_MAY          = "K";
		public static String FOWARD_DOLLAR_JUNE         = "M";
		public static String FOWARD_DOLLAR_JULY         = "N";
		public static String FOWARD_DOLLAR_AUGUST       = "Q";
		public static String FOWARD_DOLLAR_SEPTEMBER    = "U";
		public static String FOWARD_DOLLAR_OCTOBER      = "V";
		public static String FOWARD_DOLLAR_NOVEMBER     = "X";
		public static String FOWARD_DOLLAR_DECEMBER     = "Z";
		
		public static String FOWARD_DOLLAR_PREFIX       = "DOL";
		
		//public static double FOWARD_DOLLAR_CONTRACT_MULTIPLIER = 1000.0;
		public static double FOWARD_DOLLAR_CONTRACT_MULTIPLIER = 1.0;
	}
	
	public class DEFAULT {
		public static Integer RISK_LEVEL = null;
		public static Integer RESTING_LEVEL = 1;
	}
	
	public class USER_PROFILE_TYPE {
		public static String ADMIN = "admin";
		public static String SUPER = "supervisor";
	}
	
	public class ENVIRONMENT {
		public static String SIT = "SIT";
		public static String UAT = "UAT";
		public static String PRD = "PRD";
	}
}