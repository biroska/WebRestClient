package com.ubs.manhatthan.manager.persistence.dao.audit;

import java.io.Serializable;
import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.persistence.dao.GenericDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IStrategyOrdersAuditDAO;
import com.ubs.manhatthan.manager.persistence.entities.audit.StrategyOrdersAudit;

@Repository
@Scope("singleton")
public class StrategyOrdersAuditDAO extends GenericDAO<StrategyOrdersAudit, Long> implements IStrategyOrdersAuditDAO, Serializable {
	private static final long serialVersionUID = 1L;
	@Override
	public List<StrategyOrdersAudit> save(List<StrategyOrdersAudit> list) throws DAOExceptionManhattan  {

		for (StrategyOrdersAudit item : list) {
			item = update(item);
		}
		return list;
	}
	
}
