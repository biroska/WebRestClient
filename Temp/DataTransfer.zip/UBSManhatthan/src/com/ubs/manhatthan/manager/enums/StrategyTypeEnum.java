package com.ubs.manhatthan.manager.enums;

public enum StrategyTypeEnum{
	
	/*Attention! Every new register in the database must be created here with same Code*/
	
	UNKNOWN			        ( 0 ),
	MULTILEG_SPREAD         ( 1 ),
	MULTILEG_FRA         	( 2 ),
	MULTILEG_INCLINATION    ( 3 ),
	MULTILEG_FINANCIAL 		( 4 ),
	MORNING_TEST 			( 99 );
    
    private final Integer code;
    
    private StrategyTypeEnum( Integer code ) {
        this.code = code;
    }

    public Integer getCode() {
        return code;
    }
    
    public static StrategyTypeEnum fromValue( Integer value ){
    	
		for (StrategyTypeEnum item : StrategyTypeEnum.values() ) {
			if ( item.getCode().equals( value ) ){
				return item;
			}
		}
		return null;
    }
    
    public boolean isSynthetic( ){
    	
    	if ( this.equals( UNKNOWN ) )
    		return false;
    	
    	return true;
    }
}