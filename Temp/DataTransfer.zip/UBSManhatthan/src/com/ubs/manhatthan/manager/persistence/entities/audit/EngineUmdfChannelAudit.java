package com.ubs.manhatthan.manager.persistence.entities.audit;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.persistence.entities.EngineUmdfChannel;

@Entity
@Table(name="TB_AUDIT_ENGINE_UMDF_CHANNELS")
public class EngineUmdfChannelAudit {
	
	public EngineUmdfChannelAudit() {
		super();
	}
	
	public EngineUmdfChannelAudit( EngineUmdfChannel engineChannel, ActionTypeEnum action, String user, Date registryDate ) {
		this.action = action;
		this.user = user;
		this.registryDate = registryDate;
		
		this.origId = engineChannel.getId();
		this.channelId = engineChannel.getChannelId();
		this.exchange = engineChannel.getExchange().getId();
		this.incrementalIp = engineChannel.getIncrementalIp();
		this.incrementalPort = engineChannel.getIncrementalPort();
		this.marketRecoveryIp = engineChannel.getMarketRecoveryIp();
		this.marketRecoveryPort = engineChannel.getMarketRecoveryPort();
		this.instrumentDefinitionIp = engineChannel.getInstrumentDefinitionIp();
		this.instrumentDefinitionPort = engineChannel.getInstrumentDefinitionPort();
	}
	
	@Id
	@Column ( name = "ID")
	@SequenceGenerator(name = "TB_AUDIT_ENGINE_UMDF_CHANNEL_ID_GENERATOR", sequenceName = "SEQ_AUDIT_ENGINE_UMDF_CHANNEL", allocationSize = 1)
	@GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "TB_AUDIT_ENGINE_UMDF_CHANNEL_ID_GENERATOR" )
	private Long id;
	
	@Enumerated(EnumType.STRING)
	@Column( name = "ACTION", nullable=false )
	private ActionTypeEnum action;
	
	@Column( name = "REGISTRY_USER", nullable=false )
	private String user;
	
	@Column( name = "REGISTRY_DATE", nullable=false )
	private Date registryDate;

	@Column (name = "ORIG_ID", nullable = false )
	private Long origId;
	
	@Column(name = "CHANNEL_ID", nullable = false )
	private Long channelId;
	
//	@ManyToOne
	@Column(name = "EXCHANGE", nullable = false )
	private Long exchange;
	
	@Column(name = "INCREMENTAL_IP", nullable = false, length = 16  )
	private String incrementalIp;
	
	@Column(name = "INCREMENTAL_PORT", nullable = false  )
	private Long incrementalPort;
	
	@Column(name = "MARKET_RECOVERY_IP", nullable = false, length = 16  )
	private String marketRecoveryIp;
	
	@Column(name = "MARKET_RECOVERY_PORT", nullable = false  )
	private Long marketRecoveryPort;
	
	@Column(name = "INSTRUMENT_DEFINITION_IP", nullable = false, length = 16  )
	private String instrumentDefinitionIp;
	
	@Column(name = "INSTRUMENT_DEFINITION_PORT", nullable = false  )
	private Long instrumentDefinitionPort;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public ActionTypeEnum getAction() {
		return action;
	}

	public void setAction(ActionTypeEnum action) {
		this.action = action;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public Date getRegistryDate() {
		return registryDate;
	}

	public void setRegistryDate(Date registryDate) {
		this.registryDate = registryDate;
	}

	public Long getOrigId() {
		return origId;
	}

	public void setOrigId(Long origId) {
		this.origId = origId;
	}

	public Long getChannelId() {
		return channelId;
	}

	public void setChannelId(Long channelId) {
		this.channelId = channelId;
	}

//	public Exchange getExchange() {
//		return exchange;
//	}
//
//	public void setExchange(Exchange exchange) {
//		this.exchange = exchange;
//	}

	public String getIncrementalIp() {
		return incrementalIp;
	}

	public Long getExchange() {
		return exchange;
	}

	public void setExchange(Long exchange) {
		this.exchange = exchange;
	}

	public void setIncrementalIp(String incrementalIp) {
		this.incrementalIp = incrementalIp;
	}

	public Long getIncrementalPort() {
		return incrementalPort;
	}

	public void setIncrementalPort(Long incrementalPort) {
		this.incrementalPort = incrementalPort;
	}

	public String getMarketRecoveryIp() {
		return marketRecoveryIp;
	}

	public void setMarketRecoveryIp(String marketRecoveryIp) {
		this.marketRecoveryIp = marketRecoveryIp;
	}

	public Long getMarketRecoveryPort() {
		return marketRecoveryPort;
	}

	public void setMarketRecoveryPort(Long marketRecoveryPort) {
		this.marketRecoveryPort = marketRecoveryPort;
	}

	public String getInstrumentDefinitionIp() {
		return instrumentDefinitionIp;
	}

	public void setInstrumentDefinitionIp(String instrumentDefinitionIp) {
		this.instrumentDefinitionIp = instrumentDefinitionIp;
	}

	public Long getInstrumentDefinitionPort() {
		return instrumentDefinitionPort;
	}

	public void setInstrumentDefinitionPort(Long instrumentDefinitionPort) {
		this.instrumentDefinitionPort = instrumentDefinitionPort;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((action == null) ? 0 : action.hashCode());
		result = prime * result + ((origId == null) ? 0 : origId.hashCode());
		result = prime * result
				+ ((registryDate == null) ? 0 : registryDate.hashCode());
		result = prime * result + ((user == null) ? 0 : user.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EngineUmdfChannelAudit other = (EngineUmdfChannelAudit) obj;
		if (action != other.action)
			return false;
		if (origId == null) {
			if (other.origId != null)
				return false;
		} else if (!origId.equals(other.origId))
			return false;
		if (registryDate == null) {
			if (other.registryDate != null)
				return false;
		} else if (!registryDate.equals(other.registryDate))
			return false;
		if (user == null) {
			if (other.user != null)
				return false;
		} else if (!user.equals(other.user))
			return false;
		return true;
	}
}