/**
 * 
 */
package com.ubs.manhatthan.manager.simulator.multileg.fra;

import com.ubs.manhatthan.manager.enums.SideEnum;
import com.ubs.manhatthan.manager.simulator.multileg.Common;
import com.ubs.manhatthan.manager.simulator.multileg.Common.CalculationInnerResult;
import com.ubs.manhatthan.manager.simulator.multileg.InputMultilegSimulation;
import com.ubs.manhatthan.manager.simulator.multileg.InputMultilegSimulationItem;

public class FraTwoLegs
{
	private Common common;
	CalculationInnerResult calculationInner;
	private InputMultilegSimulationItem simulationLeg;
	private InputMultilegSimulationItem firstLeg;
	private Double firstLegPU;
	private Double simulationLegPU;
	
	public FraTwoLegs(Common common)
	{
		this.common             = common;
		this.calculationInner   = common.new CalculationInnerResult(1);
		this.simulationLeg      = new InputMultilegSimulationItem();
		this.firstLeg           = new InputMultilegSimulationItem();
		this.firstLegPU         = null;
		this.simulationLegPU    = null;
	}

	public CalculationInnerResult calculateTwoLegs(InputMultilegSimulation input)
	{
		if(input.getUserDefinedTarget()!=null && Math.abs(input.getUserDefinedTarget()) > 99) { return null; }
		
		//Restarting global variables
		this.calculationInner   = common.new CalculationInnerResult(input.getInputItens().size());
		this.simulationLeg      = new InputMultilegSimulationItem();
		this.firstLeg           = new InputMultilegSimulationItem();
		this.firstLegPU         = null;
		this.simulationLegPU    = null;

		//Local variables
		Double  _firstLegPU              = null;
		Double  _simulationLegPU         = null;
		Long    _simulationLegQuantity   = null;
		Long    _firstLegQuantity        = null;
		Double  _simulationLegDivOneQty  = null;
		Double  _firstLegDivOneQty       = null;
		
		//Defining Legs
		if( input.getInputItens().get(0).isSimulationLeg() )
		{
			this.simulationLeg  = input.getInputItens().get(0);
			this.firstLeg       = input.getInputItens().get(1);
		}
		else
		{
			this.simulationLeg  = input.getInputItens().get(1);
			this.firstLeg       = input.getInputItens().get(0);
		}
		
		if( null == this.simulationLeg.getBusinessDays() || 0 >= this.simulationLeg.getBusinessDays() ) { return null; }
		if( null == this.firstLeg.getBusinessDays()      || 0 >= this.firstLeg.getBusinessDays()      ) { return null; }
		if( this.simulationLeg.getBusinessDays() == this.firstLeg.getBusinessDays()                   ) { return null; }
		
		//Calculating Market Target
		this.calculationInner.target = calculateTwoLegsTarget(this.firstLeg, this.simulationLeg);
		
		if( null == this.calculationInner.target || 99 <= Math.abs(this.calculationInner.target) ) { return null; }
		
		if( input.isMarketWatch() )
		{
			Long _simulationLegAvailableQty = null;
			Long _firstLegAvailableQty      = null;

			if( SideEnum.BUY == simulationLeg.getSide() )
			{
				_simulationLegAvailableQty = firstLeg.getBidQuantities().get(0);      //(long) (firstLeg.getBidQuantities().get(0)/_quantitiesProportion);
				_firstLegAvailableQty      = simulationLeg.getAskQuantities().get(0); //(long) (simulationLeg.getAskQuantities().get(0)*_quantitiesProportion);
			}
			else
			{
				_simulationLegAvailableQty = firstLeg.getAskQuantities().get(0);      //(long) (firstLeg.getAskQuantities().get(0)/_quantitiesProportion);
				_firstLegAvailableQty      = simulationLeg.getBidQuantities().get(0); //(long) (simulationLeg.getBidQuantities().get(0)*_quantitiesProportion);
			}

			this.calculationInner.availableQuantityArray[0]  = _firstLegAvailableQty;
			this.calculationInner.availableQuantityArray[1]  = _simulationLegAvailableQty;

			return this.calculationInner;
		}
		
		//Calculating TargetDiff
		if( null != input.getUserDefinedTarget() )
		{
			this.calculationInner.targetDiff =  this.calculationInner.target - input.getUserDefinedTarget();
		}		
		
		if( input.isOnlyTarget() ) { return this.calculationInner; }
		
		//Calculating Rank
		if( null != input.getUserDefinedTarget() )
		{
			this.calculationInner.rankArray = calculateTwoLegsPriceRank(this.firstLeg, this.simulationLeg, input.getUserDefinedTarget());
		}

		if( null == this.simulationLeg.getLastPrice()    || 0.0 >= this.simulationLeg.getLastPrice()  ) { return null; }
		if( null == this.firstLeg.getLastPrice()         || 0.0 >= this.firstLeg.getLastPrice()       ) { return null; }

		//Calculating Quantities
		_simulationLegPU = common.calculatePu(this.simulationLeg.getLastPrice() , this.simulationLeg.getBusinessDays() );
		_firstLegPU      = common.calculatePu(this.firstLeg.getLastPrice() , this.firstLeg.getBusinessDays());
		
		if( 0.0 >= _firstLegPU ) { return null; }

		//Calculating quantities proportion and _puWithFraLessOne		
		Double _quantitiesProportion = _simulationLegPU/_firstLegPU;
		
		if( 0.0 == _quantitiesProportion ) { return null; }

		if( this.simulationLeg.isByQuantity() )
		{
			_simulationLegQuantity = this.simulationLeg.getQuantity();
			_firstLegQuantity = (long) (this.simulationLeg.getQuantity()*_quantitiesProportion);

			//Need to calculate
			_simulationLegDivOneQty = 0.0;
			_firstLegDivOneQty = 0.0;
		}
		else
		{
			if( null == input.getDollarSpot() || 0.0 >= input.getDollarSpot() ) { return null; }
			
			//_simulationLegQuantity = calculateQtyDivOne(this.firstLeg, this.simulationLeg, _firstLegPU, _simulationLegPU, input.getDollarSpot() );
			//if( null == _simulationLegQuantity ) { return null; }
			
			Double _simulationLegDivOne = (common.calculatePuLessOnePoint(this.simulationLeg.getLastPrice(), this.simulationLeg.getBusinessDays()) - _simulationLegPU)/input.getDollarSpot();
			Double _firstLegDivOne      = (common.calculatePuLessOnePoint(this.firstLeg.getLastPrice(), this.firstLeg.getBusinessDays()) - _firstLegPU)/input.getDollarSpot();
			
			if( 0.0 == _simulationLegDivOne ||  0.0 == _firstLegDivOne) { return null; }

			_simulationLegQuantity = (long) (simulationLeg.getDiv1()/_simulationLegDivOne);
			_firstLegQuantity = (long) (_simulationLegQuantity*_quantitiesProportion);

			_simulationLegDivOneQty = this.simulationLeg.getDiv1();
			_firstLegDivOneQty = _firstLegQuantity*_firstLegDivOne;
		}

		this.simulationLeg.getSecurityDefinition().getRoundLot();
		
		this.calculationInner.quantityArray[0] = _firstLegQuantity - (_firstLegQuantity%this.firstLeg.getSecurityDefinition().getRoundLot());
		this.calculationInner.quantityArray[1] = _simulationLegQuantity - (_simulationLegQuantity%this.simulationLeg.getSecurityDefinition().getRoundLot());
		this.calculationInner.divOneArray[0]   = _firstLegDivOneQty;
		this.calculationInner.divOneArray[1]   = _simulationLegDivOneQty;
		
		return this.calculationInner;
	}
	
	/**
	 * @brief This method calculates the market target by Spread
	 * 
	 * @return Double target
	 */
	private Double calculateTwoLegsTarget(InputMultilegSimulationItem firstLeg,
										  InputMultilegSimulationItem simulationLeg)
	{		
		if( SideEnum.BUY == simulationLeg.getSide() )
		{			
			if( 0 >= simulationLeg.getAskDepth() || null == simulationLeg.getAskPrices().get(0) || 0.0 >= simulationLeg.getAskPrices().get(0) ) { return null; }
			if( 0 >= firstLeg.getBidDepth()      || null == firstLeg.getBidPrices().get(0)      || 0.0 >= firstLeg.getBidPrices().get(0)      ) { return null; }
			
			//Leg1 = SELL = Leg1Bid | Leg2 = BUY = Leg2Ask		
			this.firstLegPU      = common.calculatePu(this.firstLeg.getBidPrices().get(0), this.firstLeg.getBusinessDays());
			this.simulationLegPU = common.calculatePu(simulationLeg.getAskPrices().get(0), this.simulationLeg.getBusinessDays());
		}
		else
		{
			if( 0 >= simulationLeg.getBidDepth() || null == simulationLeg.getBidPrices().get(0) || 0.0 >= simulationLeg.getBidPrices().get(0) ) { return null; }
			if( 0 >= firstLeg.getAskDepth()      || null == firstLeg.getAskPrices().get(0)      || 0.0 >= firstLeg.getAskPrices().get(0)      ) { return null; }

			//Leg1 = BUY = Leg1Ask | Leg2 = SELL = Leg2Bid
			this.firstLegPU = common.calculatePu(this.firstLeg.getAskPrices().get(0), this.firstLeg.getBusinessDays());
			this.simulationLegPU = common.calculatePu(simulationLeg.getBidPrices().get(0), this.simulationLeg.getBusinessDays());
		}

		Long _businessDaysDiff = (long) (this.simulationLeg.getBusinessDays() - this.firstLeg.getBusinessDays());		
		if( 0 == _businessDaysDiff ) { return null; }
		Double _exponent = common.ANUAL_WORKING_DAYS/(double)_businessDaysDiff;
		Double _puRatio  = this.firstLegPU/this.simulationLegPU;
		
		return (Math.pow(_puRatio, _exponent)-1.0)*common.PU_TO_PERCENTAGE_CONST;
	}
	
	/**
	 *
	 * @param firstLeg
	 * @param lastleg
	 * @param userDefinedTarget
	 * 
	 * @return Long[]
	 */
	private Long[] calculateTwoLegsPriceRank(InputMultilegSimulationItem firstLeg,
			  							     InputMultilegSimulationItem simulationLeg,
			  							     Double userDefinedTarget)
	{			
		Long[] _ret_vector = new Long[2];
		
		Double _businessDaysRatio = null;
		Double _fraInverseExp = null;
		Double _rate = null;
		
		if( SideEnum.BUY == simulationLeg.getSide() )
		{
			//Simulation Leg
			_businessDaysRatio = (double)this.firstLeg.getBusinessDays()/(double)this.simulationLeg.getBusinessDays();
			_fraInverseExp = Math.exp( _businessDaysRatio * Math.log( (firstLeg.getBidPrices().get(0)/100.0) + 1 ) );
			_rate = 100.0 * (_fraInverseExp * Math.exp( (1-_businessDaysRatio) * Math.log((userDefinedTarget/100.0) + 1) ) - 1.0);
			if( _rate <= 0.0 || _rate >= 99.9 || _rate.isNaN() || _rate.isInfinite() ) { return _ret_vector; }
			
			_ret_vector[1] = common.searchBuyPriceRank(simulationLeg, _rate);
			
			//First Leg
			_businessDaysRatio = (double)this.simulationLeg.getBusinessDays()/(double)this.firstLeg.getBusinessDays();
			_fraInverseExp = Math.exp( _businessDaysRatio * Math.log( (simulationLeg.getAskPrices().get(0)/100.0) + 1 ) );
			_rate = 100.0 * (_fraInverseExp * Math.exp( (1-_businessDaysRatio) * Math.log((userDefinedTarget/100.0) + 1) ) - 1.0);
			if( _rate <= 0.0 || _rate >= 99.9 || _rate.isNaN() || _rate.isInfinite() ) { _ret_vector[1] = null; return _ret_vector; }
			
			_ret_vector[0] = common.searchSellPriceRank(firstLeg, _rate);
		}
		else if( SideEnum.SELL == simulationLeg.getSide() )
		{
			//Simulation Leg
			_businessDaysRatio = (double)this.firstLeg.getBusinessDays()/(double)this.simulationLeg.getBusinessDays();
			_fraInverseExp = Math.exp( _businessDaysRatio * Math.log( (firstLeg.getAskPrices().get(0)/100.0) + 1 ) );
			_rate = 100.0 * (_fraInverseExp * Math.exp( (1-_businessDaysRatio) * Math.log((userDefinedTarget/100.0) + 1) ) - 1.0);
			if( _rate <= 0.0 || _rate >= 99.9 || _rate.isNaN() || _rate.isInfinite() ) { return _ret_vector; }
			
			_ret_vector[1] = common.searchSellPriceRank(simulationLeg, _rate);
			
			//First Leg
			_businessDaysRatio = (double)this.simulationLeg.getBusinessDays()/(double)this.firstLeg.getBusinessDays();
			_fraInverseExp = Math.exp( _businessDaysRatio * Math.log( (simulationLeg.getBidPrices().get(0)/100.0) + 1 ) );
			_rate = 100.0 * (_fraInverseExp * Math.exp( (1-_businessDaysRatio) * Math.log((userDefinedTarget/100.0) + 1) ) - 1.0);
			if( _rate <= 0.0 || _rate >= 99.9 || _rate.isNaN() || _rate.isInfinite() ) { _ret_vector[1] = null; return _ret_vector; }
			
			_ret_vector[0] = common.searchBuyPriceRank(firstLeg, _rate);			
		}
		
		return _ret_vector;
	}
	
//	private Long calculateQtyDivOne(InputMultilegSimulationItem firstLeg,
//		        					InputMultilegSimulationItem simulationLeg,
//		        					Double firstLegPU,
//									Double simulationLegPU,
//		        					Double dollarSpot)
//	{
//		Long _businessDaysDiff = (long) (this.simulationLeg.getBusinessDays() - this.firstLeg.getBusinessDays());
//		if( 0 == _businessDaysDiff || 0.0 == simulationLegPU ) { return null; }
//		
//		Double _fra = (Math.pow((firstLegPU/simulationLegPU), (common.ANUAL_WORKING_DAYS/(double)_businessDaysDiff))-1.0)*common.PU_TO_PERCENTAGE_CONST;	
//		Double _puWithFraLessOne = this.firstLeg.getLastPrice()/(Math.pow((((_fra-0.01)/common.PU_TO_PERCENTAGE_CONST)+1), (common.ANUAL_WORKING_DAYS/(double)_businessDaysDiff)));
//		
//		return (long) ((this.simulationLeg.getDiv1()*dollarSpot)/(_puWithFraLessOne - this.simulationLeg.getLastPrice()));
//	}

}
