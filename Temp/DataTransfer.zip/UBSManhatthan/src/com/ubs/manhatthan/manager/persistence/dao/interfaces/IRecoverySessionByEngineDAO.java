/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.persistence.entities.RecoverySessionByEngine;

/**
 * @author galdinoa
 *
 */
public interface IRecoverySessionByEngineDAO extends IGenericDAO<RecoverySessionByEngine, Long> {

	public RecoverySessionByEngine saveRecoverySessionByEngine(RecoverySessionByEngine umdfRecoverySessionByEngine) throws DAOExceptionManhattan;

	public void deleteEngineRecoverySession(RecoverySessionByEngine recoverySessionByEngine) throws DAOExceptionManhattan;

	public void deleteEngineByRecoveryId(Long recoveryId) throws DAOExceptionManhattan;

}
