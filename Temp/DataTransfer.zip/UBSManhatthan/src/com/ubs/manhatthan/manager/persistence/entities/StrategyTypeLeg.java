package com.ubs.manhatthan.manager.persistence.entities;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.ubs.manhatthan.manager.enums.SideEnum;

@Entity
@Table(name="TB_DOMAIN_STRATEGY_TYPE_LEGS")
public class StrategyTypeLeg implements Serializable {
	private static final long serialVersionUID = 1L;
	public StrategyTypeLeg(){}
	
	public StrategyTypeLeg(StrategyType strategyType, Integer defaultSide,
			Integer legSeq) {
		super();
		this.strategyType = strategyType;
		this.defaultSide = SideEnum.fromValue( defaultSide );
		this.legSeq = legSeq;
	}


	@Id
	@Column ( name = "PROFILE")
	@SequenceGenerator(name = "TB_DOMAIN_STRATEGY_TYPE_LEGS_ID_GENERATOR", sequenceName = "SEQ_STRATEGY_TYPE_LEGS", allocationSize = 1)
	@GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "TB_DOMAIN_STRATEGY_TYPE_LEGS_ID_GENERATOR" )
	private Long id;
	
	@ManyToOne(fetch=FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "STRATEGY_TYPE", nullable = false )
	private StrategyType strategyType;
	
	@Column ( name = "DEFAULT_SIDE", nullable=false )
	private SideEnum defaultSide;
	
	@Column ( name = "LEG_SEQ", nullable=false )
	private Integer legSeq;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public StrategyType getStrategyType() {
		return strategyType;
	}

	public void setStrategyType(StrategyType strategyType) {
		this.strategyType = strategyType;
	}

	public SideEnum getDefaultSide() {
		return defaultSide;
	}

	public void setDefaultSide(SideEnum defaultSide) {
		this.defaultSide = defaultSide;
	}

	public Integer getLegSeq() {
		return legSeq;
	}

	public void setLegSeq(Integer legSeq) {
		this.legSeq = legSeq;
	}
	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((defaultSide == null) ? 0 : defaultSide.hashCode());
		result = prime * result + ((legSeq == null) ? 0 : legSeq.hashCode());
		result = prime * result
				+ ((strategyType == null) ? 0 : strategyType.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StrategyTypeLeg other = (StrategyTypeLeg) obj;
		if (defaultSide == null) {
			if (other.defaultSide != null)
				return false;
		} else if (!defaultSide.equals(other.defaultSide))
			return false;
		if (legSeq == null) {
			if (other.legSeq != null)
				return false;
		} else if (!legSeq.equals(other.legSeq))
			return false;
		if (strategyType == null) {
			if (other.strategyType != null)
				return false;
		} else if (!strategyType.equals(other.strategyType))
			return false;
		return true;
	}

	@Override
	public String toString() {
		
		String strategyTypeStr = "StrategyType [id=" + strategyType.getId() + ", strategyCode=" + strategyType.getStrategyCode() + 
				              	 ", description=" + strategyType.getDescription() +
				              	 ", numberOfLegs= " + strategyType.getNumberOfLegs() + "]";
		
		return "StrategyType [id=" + id + ", defaultSide=" + defaultSide + ", legSeq=" + legSeq +
				             ", strategyType= " + strategyTypeStr + "]";
	}
}