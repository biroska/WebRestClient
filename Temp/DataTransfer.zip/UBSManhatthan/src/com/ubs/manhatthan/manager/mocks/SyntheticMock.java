/**
 * 
 */
package com.ubs.manhatthan.manager.mocks;

import com.ubs.manhatthan.manager.dto.ReceiveSymbolSyntheticItem;
import com.ubs.manhatthan.manager.dto.ReceiveSynthetic;
import com.ubs.manhatthan.manager.enums.SideEnum;
import com.ubs.manhatthan.manager.enums.StrategyTypeEnum;


/**
 * @author galdinoa
 *
 */
public class SyntheticMock {
	
	public static ReceiveSynthetic mockReceiveSynthetic( StrategyTypeEnum type, String... symbolList  ){
		
		ReceiveSynthetic synthetic = new ReceiveSynthetic();
		synthetic.setStrategyType( type );
		
		for (int i = 0; i < symbolList.length; i++) {
			ReceiveSymbolSyntheticItem item = new ReceiveSymbolSyntheticItem();
			item.setLegSeq( i );
			item.setSide( i % 2 == 0 ? SideEnum.BUY : SideEnum.SELL );
			item.setSymbol( symbolList[ i ] );
			synthetic.getSyntheticList().add( item );
		}
		
		return synthetic;
	}
}