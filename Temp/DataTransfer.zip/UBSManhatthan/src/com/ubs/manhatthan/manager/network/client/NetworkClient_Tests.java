/*
 * NetworkClient_Test.java
 *
 *  Created on: Set 25, 2015
 *      Author: vanputtg
 */

//ABSTRACT: this class aims at testing communication with engine.
//WARNING: it is not a correct implementation for the java manager !!

//Package
package com.ubs.manhatthan.manager.network.client;

//Import Java
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Vector;

import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_command_message;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_command_type_enum;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_create_modify_cancel_strategy_message;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_header_message;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_legged_order;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_message_type_enum;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_order_type_enum;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_reject_create_modify_cancel_strategy_message;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_report_order_message;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_report_strategy_message;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_side_enum;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_statistics_message;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_strategy_body_parameters_message;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_strategy_body_report_message;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_strategy_leg_parameters_message;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_strategy_leg_report_message;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_strategy_type_enum;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_time_in_force_enum;
//Import Manhattan
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_to_engine_message;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_warning_message;

//Test network client
@SuppressWarnings("unused")
public class NetworkClient_Tests implements NetworkClient.NetworkClientCallback{

	//Util
	private class Order_Reference{
		
		public Long 					strategy = null;
		public Long 					order = null;
		public int 						leg = 0;
	}
	
	//Strategy Leg
	private class NetworkClient_Strategy_Leg {
		
		public pb_strategy_leg_report_message 					leg = null;
		public LinkedHashMap<Long, pb_report_order_message> 	order_report = null;
		public LinkedHashMap<Long, pb_legged_order> 			order_legged = null;
	}
	
	//Strategy State
	private class NetworkClient_Strategy {
		
		long												id;
		public pb_strategy_body_report_message				body = null;
		public Vector<NetworkClient_Strategy_Leg>	 		legs = null;	
	}
	
	//Comparator
	public class CustomComparator implements Comparator<Instruments> {
	    @Override
	    public int compare(Instruments o1, Instruments o2) {
	        return o1.maturity - o2.maturity;
	    }
	}
	
	//Instrument
	private class Instruments{
		
		long				security_id;
		int					maturity;
		int					duration;
		String				symbol = null;	
	}
	
	//Private members
	final private NetworkClient 							m_client;
	private Thread 											m_thread_user = null;
	private long											m_request_id = 1;
	private LinkedHashMap<Long, NetworkClient_Strategy>		m_strategy_map = null;
	private ArrayList<Order_Reference>						m_order = null;
	private boolean											m_logged = false;
	private ArrayList <Instruments>							m_instruments = null;
	private ArrayList <Long>								m_client_list = null;
	private Random											m_random = null;
	private int												m_max_leg = 2;
	private	long											m_message_sent = 0;
	private	long											m_message_receive_success = 0;
	private	long											m_message_receive_reject = 0;
	private	long											m_report_strategy_id = 0;
	
	//Constructor
	public NetworkClient_Tests(String address, int port){
		
		m_random = new Random();
		m_order = new ArrayList <Order_Reference>();
		m_strategy_map = new LinkedHashMap<Long, NetworkClient_Strategy>();
		m_client = new NetworkClient(this, address, port);
		set_list();
	}
	
	//Function
	public NetworkClient getService(){
		
		return m_client;
	}
	
	private boolean sleep(long milli){
		
		//Sleep
		try {

			Thread.sleep(milli);
			
		} catch (InterruptedException e) {
		
			//Failure - Interruption
			return false;
		}
		
		//Success
		return true;
	}
	
	private void process_user(){
		
		//Print
		System.out.println("Start processing user");

		boolean goahead = true;
		long counter = 0;
		
		//Loop
		while (goahead && !Thread.interrupted()) {
			
			//Various
			//goahead = false;
			
			//Sleep
			if(!sleep(2000)){
				
				System.out.println("Stop processing user");
				break;
			}
			
			//Check Logged on
			if(!m_logged) continue;
			
			
			//Random Value
			int random_value = -1;
			random_value = m_random.nextInt(8);
			random_value = m_random.nextInt(2);
			//random_value = (m_logged ? m_random.nextInt(2) : -1);
			random_value = m_random.nextInt(4);
			random_value = 0;
			
			
			
			//Switch
			switch(random_value){
				case 0:{
					
					send_create_strategy(2);
					//send_report_execution_order();
					//send_report_order();
		
					//send_create_strategy();
					/*for(int i=0; i<1; ++i){

						send_resume_strategy();
						send_create_strategy(2);
						send_resume_strategy();
						send_resume_strategy();
						send_create_strategy(3);
						send_resume_strategy();
						send_create_strategy(2);
						send_resume_strategy();
					}*/
					
					//goahead = false;
					
				}break;
				case 1:{
					
					send_modify_strategy(); 				
				}break;
				case 2:{
					
					send_pause_strategy();	
				}break;
				case 3:{
					
					send_resume_strategy();					
				}break;
				case 4:{
					
					//send_pause_all();  
				}break;
				case 5:{
					
					send_report_execution_order();
				}break;
				case 6:{
					
					//send_legged_order();
				}break;
				case 7:{
					
					//send_cancel_strategy();		 
				}break;
				case 8:{
					
					//send_cancel_all(); 
				}break;
				default: break;
			}
			
			++counter;
		}
		
		//Print
		System.out.println("Stop processing user");	
	}
	
	@Override
	public void onStart(){
		
		System.out.println("On Start");
	}
	
	@Override
	public void onStop(){

		System.out.println("On Stop");
		if(null != m_thread_user) m_thread_user.interrupt();
	}
	
	@Override
	public void onLoad(){
		
		System.out.println("On Load");
	}
	
	@Override
	public void onUnLoad(){
		
		System.out.println("On UnLoad");
	}

	@Override
	public void onConnect() {
		
		System.out.println("On Connect");
	}
	
	@Override
	public void onPrint(String msg){
		
		System.out.println(msg);
	}
	
	@Override
	public void onLogon() {
		
		//Update
		m_logged = true;
		
		//Print
		System.out.println("On Logon from engine " + m_client.engineId());
		
		//Reset Map
		m_strategy_map.clear();

		//Launch Thread
		if(m_thread_user == null){
			
			m_thread_user = new Thread(new Runnable() { public void run() { process_user(); }}, "### Manhatthan Thread - NetworkClient_Tests User engine " + m_client.engineId());
			m_thread_user.start();
		}
	}
	
	@Override
	public void onLogoff(String str){
		
		//Update
		m_logged = false;
		
		System.out.println("On Logoff from engine " + m_client.engineId() + ": " + str);
	}

	@Override
	public void onDisconnect() {
		
		//Update
		m_logged = false;
		
		System.out.println("On Disconnect");
	}
	
	@Override
	public synchronized void onMessage_ReportStrategy(long manager_id, long request_id, pb_report_strategy_message msg){
		
		
		//System.out.println("RECEIVED: " + msg.toString());
		
		
		//Variable
		NetworkClient_Strategy strat = null;
		long strategy_id = msg.getStrategyId();
		
		//Update
		if(m_strategy_map.containsKey(strategy_id)){
			
			System.out.println("On Update ReportStrategy: " + manager_id + "/" + msg.getStrategyId() + " --> " + msg.getBody().getStrategyState().toString() + " --> " + msg.getBody().getText());
			strat = m_strategy_map.get(strategy_id);
			strat.body = NetworkProtobuf.pb_strategy_body_report_message.newBuilder().mergeFrom(msg.getBody()).build();
			for(int i = 0; i < msg.getLegsCount(); ++i){
				pb_strategy_leg_report_message leg = msg.getLegs(i);
				if(strat.legs.size() > leg.getLegSeq() && leg.getLegSeq() >= 0)
					strat.legs.get(leg.getLegSeq()).leg = leg;
				else System.out.println("On New ReportStrategy for: ERROR --> leg id not found");	
			}
			m_strategy_map.put(strategy_id, strat);
		}
			
		//New Strategy
		else{

			System.out.println("On New ReportStrategy: " + manager_id + "/" + msg.getStrategyId() + " --> " + msg.getBody().getStrategyState().toString() + " --> " + msg.getBody().getText());
			strat = new NetworkClient_Strategy();
			strat.id = strategy_id;
			strat.legs = new Vector<NetworkClient_Strategy_Leg>(msg.getLegsCount());
			strat.body = NetworkProtobuf.pb_strategy_body_report_message.newBuilder().mergeFrom(msg.getBody()).build();
			for(int i = 0; i < msg.getLegsCount(); ++i){
				NetworkClient_Strategy_Leg leg = new NetworkClient_Strategy_Leg();
				leg.order_report = new LinkedHashMap<Long, pb_report_order_message>();
				leg.order_legged = new LinkedHashMap<Long, pb_legged_order>();
				leg.leg = msg.getLegs(i);
				strat.legs.add(i, leg);
			}
			m_strategy_map.put(strategy_id, strat);	
			
			//Increment
			++m_message_receive_success;
			//System.out.println("Counter: " + m_message_sent + "  " + (m_message_receive_reject+ m_message_receive_success));
			
			//Resume case was paused
			//System.out.println("Sending Resume: " + strategy_id);
			//send_pausecancel_strategy(strategy_id, pb_message_type_enum.PB_RESUME_STRATEGY);
		}
	
	}

	@Override
	public void onMessage_RejectExecutionOrder(long manager_id, long request_id, pb_reject_create_modify_cancel_strategy_message msg){
		
		System.out.println("On RejectOrder: " + msg.getText() + " --> " + manager_id + "/" + msg.getStrategyId());
	}
	
	@Override
	public void onMessage_RejectStrategy(long manager_id, long request_id, pb_message_type_enum msg_type, pb_reject_create_modify_cancel_strategy_message msg){
		
		//Increment
		++m_message_receive_reject;
		//System.out.println("Counter: " + m_message_sent + "  " + (m_message_receive_reject+ m_message_receive_success));
		System.out.println("On RejectStrategy: " + msg.getText() + " --> " + manager_id + "/" + msg.getStrategyId());
	}
	
	@Override
	public void onMessage_ReportOrder(long manager_id, long request_id, pb_report_order_message msg){
		
		//Variable
		NetworkClient_Strategy strat = null;
		long strategy_id = msg.getStrategyId();
		
		
		System.out.println("On Report Order for: " + manager_id + " --> Strategy_id: " + msg.getStrategyId() + "\n" + msg.toString());
		
		
		//Update/Create
		if(m_strategy_map.containsKey(strategy_id)){
			
			int leg_index = msg.getLegSeq();
			strat = m_strategy_map.get(strategy_id);
			if(strat.legs.size() >= leg_index && leg_index >= 0){

				NetworkClient_Strategy_Leg leg = strat.legs.get(leg_index);
				Long order_id = msg.getOrderId();
				
				//Update list
				if(!leg.order_report.containsKey(order_id)){
					
					Order_Reference ref = new Order_Reference();
					ref.strategy = strategy_id;
					ref.order = order_id;
					ref.leg = leg_index;
					m_order.add(ref);
				}
				
				leg.order_report.put(order_id, msg);
				
				//Print
				//System.out.println("On Report Order for: " + manager_id + " --> Strategy_id: " + msg.getStrategyId());
			}
			
			//Error
			//else  System.out.println("On Report Order ERROR 2 for: " + manager_id + " --> Strategy_id: " + msg.getStrategyId());
		}
			
		//Error
		//else System.out.println("On Report Order ERROR 1 for: " + manager_id + " --> Strategy_id: " + msg.getStrategyId());
	}
	
	@Override
	public void onMessage_LeggedOrder(long manager_id, long request_id, pb_legged_order msg){
		
		//Variable
		NetworkClient_Strategy strat = null;
		long strategy_id = msg.getStrategyId();
		
		//Update/Create
		if(m_strategy_map.containsKey(strategy_id)){
			
			int leg_index = msg.getLegSeq();
			strat = m_strategy_map.get(strategy_id);
			if(strat.legs.size() >= leg_index && leg_index >= 0){

				NetworkClient_Strategy_Leg leg = strat.legs.get(leg_index);
				Long order_id = msg.getOrderId();
				leg.order_legged.put(order_id, msg);
				
				//Print
				System.out.println("Order Trade " + msg.getOrderId() + "@" + msg.getPrice() + " --> Strategy_id: " + msg.getStrategyId());
			}
			
			//Error
			else  System.out.println("On Report Legged ERROR 2 for: " + manager_id + " --> Strategy_id: " + msg.getStrategyId());
		}
			
		//Error
		else System.out.println("On Report Legged ERROR 1 for: " + manager_id + " --> Strategy_id: " + msg.getStrategyId());
	}		
	
	@Override
	public void onMessage_Statistics(long manager_id, long request_id, pb_statistics_message msg){
		
		System.out.println("On Statistics for: " + manager_id);
	}
	
	@Override
	public void onMessage_Warning(long manager_id, long request_id, pb_warning_message msg){
		
		System.out.println("On Warning for: " + manager_id);
	}
	

	//TESTS METHODS HERE
	private void send_cancel_all(){
		

		if(get_size() == 0) return;
		
		pb_header_message header = m_client.getHeader(pb_message_type_enum.PB_COMMANDE_MESSAGE, m_request_id++);
		
		pb_command_message msg_command = NetworkProtobuf.pb_command_message.newBuilder()
				.setCommandType(pb_command_type_enum.PB_COMMAND_TYPE_CANCEL_ALL_STRATEGIES)
				.build();
		
		pb_to_engine_message msg = NetworkProtobuf.pb_to_engine_message.newBuilder()
				 .setHeader(header)
		         .setCommandMessage(msg_command)
		         .build();	
		
		//Send Message
		try {
			
			//Send
			m_client.send(msg);
			
			//Success
			System.out.println("send_cancel_all");
			
		} catch (Exception e) {
			
			System.out.println("Error while sending send_cancel_all: " + e.toString());
		}
	}
	
	private void send_pause_all(){
		
		if(get_size() == 0) return;
		
		pb_header_message header = m_client.getHeader(pb_message_type_enum.PB_COMMANDE_MESSAGE, m_request_id++);
		pb_command_message msg_command = NetworkProtobuf.pb_command_message.newBuilder()
				.setCommandType(pb_command_type_enum.PB_COMMAND_TYPE_PAUSE_ALL_STRATEGIES)
				.build();
		
		pb_to_engine_message msg = NetworkProtobuf.pb_to_engine_message.newBuilder()
				 .setHeader(header)
		         .setCommandMessage(msg_command)
		         .build();	
		
		//Send Message
		try {
			
			//Send
			m_client.send(msg);
			
			//Success
			System.out.println("send_pause_all");
			
		} catch (Exception e) {
			
			System.out.println("Error while sending send_pause_all: " + e.toString());
		}
	}
		
	private long send_pause_strategy(){
		
		return send_pausecancel_strategy(pb_message_type_enum.PB_PAUSE_STRATEGY);
	}
	
	private long send_cancel_strategy(){
		
		return send_pausecancel_strategy(pb_message_type_enum.PB_CANCEL_STRATEGY);
	}
	
	private long send_resume_strategy(){
		
		return send_pausecancel_strategy(pb_message_type_enum.PB_RESUME_STRATEGY);
	}
	private synchronized long send_pausecancel_strategy(long strategy_id, pb_message_type_enum type){
		

		//Set Header
		pb_header_message header = m_client.getHeader(type, m_request_id++);
		
		pb_create_modify_cancel_strategy_message msgStrat = NetworkProtobuf.pb_create_modify_cancel_strategy_message.newBuilder()
				.setStrategyId(strategy_id)
				.build();
		
		pb_to_engine_message msg = NetworkProtobuf.pb_to_engine_message.newBuilder()
				 .setHeader(header)
		         .setStrategy(msgStrat)
		         .build();	
		
		//Send Message
		try {
			
			//Send
			m_client.send(msg);
			
			//Success
			System.out.println("send_pausecancel_strategy: " + type.toString());
			
		} catch (Exception e) {
			
			System.out.println("Error while sending " + type.toString() + ": " + e.toString());
		}
				
		return m_request_id;
	}
	
	private synchronized long send_pausecancel_strategy(pb_message_type_enum type){
		
		//Get
		NetworkClient_Strategy strat = get_random_strategy();
		if(null == strat) return 0;
		long strategy_id = strat.id;
		return send_pausecancel_strategy(strategy_id, type);
		
	}
	
	private synchronized long get_size(){
		
		return m_strategy_map.size();
	}
	
	private synchronized NetworkClient_Strategy get_random_strategy(){
		
		int size_map = m_strategy_map.size();
		if(0 == size_map) return null; 
		Map.Entry<Long, NetworkClient_Strategy> entry = null;
		int index = m_random.nextInt(size_map);
		int index_stop = index; 
		Iterator<Entry<Long, NetworkClient_Strategy>> iterator = m_strategy_map.entrySet().iterator();
		while (iterator.hasNext()){
			
			entry = iterator.next();
			if(index_stop-- == 0) return entry.getValue();
		}
		return null;
	}
	
	private synchronized pb_report_order_message get_random_order(){
		
		int size_list = m_order.size();
		if(0 == size_list) return null; 
		int index = m_random.nextInt(size_list);
		Order_Reference ref = m_order.get(index);
		NetworkClient_Strategy strat = m_strategy_map.get(ref.strategy);
		if(null == strat) return null;
		NetworkClient_Strategy_Leg leg = strat.legs.get(ref.leg);
		if(null == leg || leg.order_report == null) return null;
		pb_report_order_message order = leg.order_report.get(ref.order);
		return order;
	}
	
	private long send_modify_strategy(){
		
		//Get
		NetworkClient_Strategy strat = get_random_strategy();
		if(null == strat) return 0;
		
		//Set Header
		pb_header_message header = m_client.getHeader(pb_message_type_enum.PB_MODIFY_STRATEGY, m_request_id++);

		long timeStart = new Date().getTime() * 1000 + (m_random.nextInt(20) - 5) * 1000000;
		long timeStop = timeStart + m_random.nextInt(500) * 1000000;
		
		//Set Message
		pb_strategy_body_parameters_message msgBody = NetworkProtobuf.pb_strategy_body_parameters_message.newBuilder()
					.setLogin(strat.body.getLogin())
					.setStartTime(timeStart)
					.setEndTime(timeStop)
					//.setStrategyType(pb_strategy_type_enum.valueOf(m_random.nextInt(2) + 1))
					.setStrategyType(strat.body.getStrategyType())
					.setStartPaused((0 == m_random.nextInt(2) ? false : true))
					.setRestingLevel(m_random.nextInt(5) + 1)
					.setOrderPerSecond(m_random.nextInt(30) + 10)
					//.setRestingLevel(strat.body.getRestingLevel()) 
					.build();
		NetworkProtobuf.pb_create_modify_cancel_strategy_message.Builder msgCreateBuilder = NetworkProtobuf.pb_create_modify_cancel_strategy_message.newBuilder().setBody(msgBody);
		msgCreateBuilder.setStrategyId(strat.id);				
		
		for(int i = 0; i < strat.legs.size(); ++i ){

			 NetworkClient_Strategy_Leg leg_original = strat.legs.get(i);
			 
			 pb_strategy_leg_parameters_message leg = NetworkProtobuf.pb_strategy_leg_parameters_message.newBuilder()
					 .setLegSeq(i)
					 
					 .setInstrument(leg_original.leg.getInstrument())
					 .setTotalQuantity((m_random.nextInt(100) + 1) * 5)
					 .setMaxQuantityDisplay((m_random.nextInt(100) + 1) * 5)
					 //.setSide(pb_side_enum.valueOf(m_random.nextInt(2) + 1)) 
					 .setSide(leg_original.leg.getSide()) 
					 .setRouteId(leg_original.leg.getRouteId())
					 //.setOrderType(pb_order_type_enum.valueOf(m_random.nextInt(4) + 49))
					 //.setTimeInForce(pb_time_in_force_enum.valueOf(m_random.nextInt(2) + 48))					 
					 .setOrderType(leg_original.leg.getOrderType())
					 .setTimeInForce(leg_original.leg.getTimeInForce())
					 .setAccount(leg_original.leg.getAccount())
					 .setDuration(leg_original.leg.getDuration())
					 .setPassiveLeg((0 == m_random.nextInt(2) ? false : true))
					 .setInvestorId("investor_id")
					 .setEnteringTrader("trader_id")
					 .build();
			 msgCreateBuilder.addLegs(i, leg);
		}
		
		pb_create_modify_cancel_strategy_message msgCreate = msgCreateBuilder.build();
		pb_to_engine_message msg = NetworkProtobuf.pb_to_engine_message.newBuilder()
				 .setHeader(header)
		         .setStrategy(msgCreate)
		         .build();	
		
		//Send Message
		try {
			
			//Send
			m_client.send(msg);
			
			//Success
			System.out.println("send_modify_strategy");
			
		} catch (Exception e) {
			
			System.out.println("Error while sending send_modify_strategy: " + e.toString());
		}
		
		
		return m_request_id;
	}
	
	private long send_create_strategy(){
		
		return send_create_strategy(-1);
	}
	
	private long send_create_strategy(int legs){
		
		//Number of legs
		int num_legs = (m_max_leg <=2 ? 0 : m_random.nextInt(m_max_leg - 2)) + 2;
		if(legs >= 0) num_legs = legs;

		//Set Header
		pb_header_message header = m_client.getHeader(pb_message_type_enum.PB_CREATE_STRATEGY, m_request_id++);

		//Get Tine
		long timeCurrent = new Date().getTime() * 1000 ;
		long timeStart = timeCurrent + (m_random.nextInt(20) - 5) * 1000000;
		long timeStop = timeStart + (m_random.nextInt(500) + 100) * 1000000;
		
		
		//System.out.println("Time: " + timeCurrent + " | start: " + timeStart + " | stop: " + timeStop );
		
		//Set Message
		pb_strategy_body_parameters_message msgBody = NetworkProtobuf.pb_strategy_body_parameters_message.newBuilder()
					.setLogin(m_client_list.get(m_random.nextInt(m_client_list.size())).toString())
					.setStartTime(timeStart)
					.setEndTime(timeStop)
					.setStrategyType(pb_strategy_type_enum.valueOf(m_random.nextInt(2) + 1))
					.setStartPaused(false /*(0 == m_random.nextInt(2) ? false : true)*/)
					.setRestingLevel(m_random.nextInt(5) + 1)
					.setOrderPerSecond(200/*m_random.nextInt(30) + 10*/)
					.build();

		NetworkProtobuf.pb_create_modify_cancel_strategy_message.Builder msgCreateBuilder = NetworkProtobuf.pb_create_modify_cancel_strategy_message.newBuilder().setBody(msgBody);
						
		//Sort by duration
		ArrayList<Instruments>	instrument_list = new ArrayList<Instruments>();
		for(int i = 0; i < num_legs; ++i )instrument_list.add(get_random_instrument());
		
		//Collections.sort(instrument_list, new CustomComparator());
		//Get Accountid
		
		long account_id = m_client_list.get(m_random.nextInt(m_client_list.size()));
		
		for(int i = 0; i < num_legs; ++i ){
			
			 Instruments instrument = instrument_list.get(i);
			 
			 //System.out.println(instrument.symbol + " " + instrument.duration);

			 pb_strategy_leg_parameters_message leg = NetworkProtobuf.pb_strategy_leg_parameters_message.newBuilder()
					 .setLegSeq(i)
					 .setInstrument(instrument.security_id)
					 .setTotalQuantity((m_random.nextInt(100) + 1) * 5)
					 .setMaxQuantityDisplay((m_random.nextInt(100) + 1) * 5)
					 .setSide(pb_side_enum.valueOf(i % 2 + 49)) //pb_side_enum.valueOf(m_random.nextInt(2) + 1)
					 .setRouteId(1/*m_random.nextInt(10) + 1*/)
					 .setOrderType(pb_order_type_enum.valueOf(m_random.nextInt(4) + 49))
					 .setTimeInForce(pb_time_in_force_enum.valueOf(m_random.nextInt(2) + 48))
					 .setAccount(account_id)
					 .setDuration(instrument.duration)
					 .setPassiveLeg((0 == m_random.nextInt(2) ? false : true))
					 .setInvestorId("")
					 .setEnteringTrader("UBS")
					 .build();
			 msgCreateBuilder.addLegs(i, leg);
		}
		
		pb_create_modify_cancel_strategy_message msgCreate = msgCreateBuilder.build();
		pb_to_engine_message msg = NetworkProtobuf.pb_to_engine_message.newBuilder()
				 .setHeader(header)
		         .setStrategy(msgCreate)
		         .build();	
		
		//Send Message
		try {
			
			//Send
			m_client.send(msg);
			
			//Increment
			++m_message_sent;
			
			//Success
			System.out.println("send_create_strategy");
			
		} catch (Exception e) {
			
			System.out.println("Error while sending send_create_strategy: " + e.toString());
		}
		
		
		return m_request_id;
	}
	
	private long send_report_execution_order(){
	
		
		NetworkClient_Strategy strat = get_random_strategy();
		if(null == strat || strat.legs.size() == 0) return 0;
		pb_strategy_leg_report_message leg = strat.legs.get(m_random.nextInt(strat.legs.size())).leg;
		
		
		//Set Header
		pb_header_message header = m_client.getHeader(pb_message_type_enum.PB_REPORT_EXECUTION_ORDER, m_request_id++);

		pb_report_order_message msgBody = NetworkProtobuf.pb_report_order_message.newBuilder()
				.setStrategyId(strat.id)
				.setLegSeq(leg.getLegSeq())
				.setInstrument(leg.getInstrument())
				.setExecutedQuantity((m_random.nextInt(3) + 1) * 5)
				.setSide(leg.getSide())
				//.setSide(pb_side_enum.valueOf(m_random.nextInt(2) + 1))
				.setAveragePrice(leg.getAveragePrice() * (1. + ((double)(m_random.nextInt(4) - 2))/100.))
				.build();
		
		pb_to_engine_message msg = NetworkProtobuf.pb_to_engine_message.newBuilder()
				 .setHeader(header)
		         .setReportOrder(msgBody)
		         .build();	
		
		//Send Message
		try {
			
			//Send
			m_client.send(msg);
			
			//Success
			System.out.println("send_report_order");
			
		} catch (Exception e) {
			
			System.out.println("Error while sending send_report_order: " + e.toString());
		}
		
		//Success
		return m_request_id;
	}
	
	private long send_legged_order(){
		
		//Get
		pb_report_order_message order = get_random_order();
		if(null == order) return 0;
		
		//Set Header
		pb_header_message header = m_client.getHeader(pb_message_type_enum.PB_LEGGED_ORDER, m_request_id++);
		
		pb_legged_order msgBody = NetworkProtobuf.pb_legged_order.newBuilder()
				.setStrategyId(order.getStrategyId())
				.setLegSeq(order.getLegSeq())
				.setOrderId(order.getOrderId())
				.setPrice(order.getPrice() * (1. + ((double)(m_random.nextInt(4) - 2))/100.))
				.setMarket((0 == m_random.nextInt(2) ? false : true))
				.build();
		
		pb_to_engine_message msg = NetworkProtobuf.pb_to_engine_message.newBuilder()
				 .setHeader(header)
		         .setLeggedMessage(msgBody)
		         .build();	
		
		//Send Message
		try {
			
			//Send
			m_client.send(msg);
			
			//Success
			System.out.println("send_legged_order");
			
		} catch (Exception e) {
			
			System.out.println("Error while sending send_legged_order: " + e.toString());
		}
		
		//Success
		System.out.println("send_legged_order");
		return m_request_id;
	}
	
	private Instruments get_random_instrument(){
		

		if(m_instruments.size() == 0){
			
			Instruments instrument = new Instruments(); 
			instrument.symbol = "UNKNOWN";
			instrument.maturity = 0;
			instrument.duration = 0;
			instrument.security_id = 0;
			return instrument;
		}
		return m_instruments.get(m_random.nextInt(m_instruments.size()));
		
	}
	
	private void set_list(){
		
		//Instruments
		m_instruments = new ArrayList <Instruments>();
		{Instruments instrument = new Instruments(); instrument.security_id =701663 ; instrument.symbol = "DI1F21";  instrument.maturity =20210104 ;m_instruments.add(instrument);}
		{Instruments instrument = new Instruments(); instrument.security_id =701325 ; instrument.symbol = "DI1F19";  instrument.maturity =20190102 ;m_instruments.add(instrument);}
		{Instruments instrument = new Instruments(); instrument.security_id =701259 ; instrument.symbol = "DI1F18";  instrument.maturity =20180102 ;m_instruments.add(instrument);}
		{Instruments instrument = new Instruments(); instrument.security_id =700020 ; instrument.symbol = "DI1F17";  instrument.maturity =20170102 ;m_instruments.add(instrument);}
		{Instruments instrument = new Instruments(); instrument.security_id =701200 ; instrument.symbol = "DI1F22";  instrument.maturity =20220103 ;m_instruments.add(instrument);}
		{Instruments instrument = new Instruments(); instrument.security_id =700012 ; instrument.symbol = "DI1F16";  instrument.maturity =20160104 ;m_instruments.add(instrument);}
		
		/*
		{Instruments instrument = new Instruments(); instrument.security_id =244276 ; instrument.symbol = "DI1X15";  instrument.maturity =20151103 ;m_instruments.add(instrument);}
		{Instruments instrument = new Instruments(); instrument.security_id =244284 ; instrument.symbol = "DI1Z15";  instrument.maturity =20151201 ;m_instruments.add(instrument);}
		{Instruments instrument = new Instruments(); instrument.security_id =244292 ; instrument.symbol = "DI1G16";  instrument.maturity =20160201 ;m_instruments.add(instrument);}
		{Instruments instrument = new Instruments(); instrument.security_id =244300 ; instrument.symbol = "DI1H16";  instrument.maturity =20160301 ;m_instruments.add(instrument);}
		{Instruments instrument = new Instruments(); instrument.security_id =701895 ; instrument.symbol = "DI1J16";  instrument.maturity =20160401 ;m_instruments.add(instrument);}
		{Instruments instrument = new Instruments(); instrument.security_id =278241 ; instrument.symbol = "DI1K16";  instrument.maturity =20160502 ;m_instruments.add(instrument);}
		{Instruments instrument = new Instruments(); instrument.security_id =247170 ; instrument.symbol = "DI1M16";  instrument.maturity =20160601 ;m_instruments.add(instrument);}
		{Instruments instrument = new Instruments(); instrument.security_id =701747 ; instrument.symbol = "DI1N16";  instrument.maturity =20160701 ;m_instruments.add(instrument);}
		{Instruments instrument = new Instruments(); instrument.security_id =321504 ; instrument.symbol = "DI1Q16";  instrument.maturity =20160801 ;m_instruments.add(instrument);}
		{Instruments instrument = new Instruments(); instrument.security_id =335348 ; instrument.symbol = "DI1U16";  instrument.maturity =20160901 ;m_instruments.add(instrument);}
		{Instruments instrument = new Instruments(); instrument.security_id =701903 ; instrument.symbol = "DI1V16";  instrument.maturity =20161003 ;m_instruments.add(instrument);}
		{Instruments instrument = new Instruments(); instrument.security_id =324607 ; instrument.symbol = "DI1Z16";  instrument.maturity =20161201 ;m_instruments.add(instrument);}
		{Instruments instrument = new Instruments(); instrument.security_id =345883 ; instrument.symbol = "DI1G17";  instrument.maturity =20170201 ;m_instruments.add(instrument);}
		{Instruments instrument = new Instruments(); instrument.security_id =345891 ; instrument.symbol = "DI1H17";  instrument.maturity =20170301 ;m_instruments.add(instrument);}
		{Instruments instrument = new Instruments(); instrument.security_id =701804 ; instrument.symbol = "DI1J17";  instrument.maturity =20170403 ;m_instruments.add(instrument);}
		{Instruments instrument = new Instruments(); instrument.security_id =701952 ; instrument.symbol = "DI1N17";  instrument.maturity =20170703 ;m_instruments.add(instrument);}
		{Instruments instrument = new Instruments(); instrument.security_id =701960 ; instrument.symbol = "DI1V17";  instrument.maturity =20171002 ;m_instruments.add(instrument);}
		{Instruments instrument = new Instruments(); instrument.security_id =702018 ; instrument.symbol = "DI1J18";  instrument.maturity =20180402 ;m_instruments.add(instrument);}
		{Instruments instrument = new Instruments(); instrument.security_id =701994 ; instrument.symbol = "DI1N18";  instrument.maturity =20180702 ;m_instruments.add(instrument);}
		{Instruments instrument = new Instruments(); instrument.security_id =702042 ; instrument.symbol = "DI1V18";  instrument.maturity =20181001 ;m_instruments.add(instrument);}
		{Instruments instrument = new Instruments(); instrument.security_id =702158 ; instrument.symbol = "DI1V19";  instrument.maturity =20191001 ;m_instruments.add(instrument);}
		{Instruments instrument = new Instruments(); instrument.security_id =701655 ; instrument.symbol = "DI1F20";  instrument.maturity =20200102 ;m_instruments.add(instrument);}
		{Instruments instrument = new Instruments(); instrument.security_id =702166 ; instrument.symbol = "DI1J20";  instrument.maturity =20200401 ;m_instruments.add(instrument);}
		{Instruments instrument = new Instruments(); instrument.security_id =702000 ; instrument.symbol = "DI1N20";  instrument.maturity =20200701 ;m_instruments.add(instrument);}
		{Instruments instrument = new Instruments(); instrument.security_id =701846 ; instrument.symbol = "DI1V20";  instrument.maturity =20201001 ;m_instruments.add(instrument);}
		{Instruments instrument = new Instruments(); instrument.security_id =702174 ; instrument.symbol = "DI1J21";  instrument.maturity =20210401 ;m_instruments.add(instrument);}
		{Instruments instrument = new Instruments(); instrument.security_id =702109 ; instrument.symbol = "DI1N21";  instrument.maturity =20210701 ;m_instruments.add(instrument);}
		{Instruments instrument = new Instruments(); instrument.security_id =702182 ; instrument.symbol = "DI1V21";  instrument.maturity =20211001 ;m_instruments.add(instrument);}
		{Instruments instrument = new Instruments(); instrument.security_id =702117 ; instrument.symbol = "DI1N22";  instrument.maturity =20220701 ;m_instruments.add(instrument);}
		{Instruments instrument = new Instruments(); instrument.security_id =701838 ; instrument.symbol = "DI1F23";  instrument.maturity =20230102 ;m_instruments.add(instrument);}
		{Instruments instrument = new Instruments(); instrument.security_id =702190 ; instrument.symbol = "DI1N23";  instrument.maturity =20230703 ;m_instruments.add(instrument);}
		{Instruments instrument = new Instruments(); instrument.security_id =701820 ; instrument.symbol = "DI1F24";  instrument.maturity =20240102 ;m_instruments.add(instrument);}
		{Instruments instrument = new Instruments(); instrument.security_id =702208 ; instrument.symbol = "DI1N24";  instrument.maturity =20240701 ;m_instruments.add(instrument);}
		{Instruments instrument = new Instruments(); instrument.security_id =701770 ; instrument.symbol = "DI1F25";  instrument.maturity =20250102 ;m_instruments.add(instrument);}
		{Instruments instrument = new Instruments(); instrument.security_id =702299 ; instrument.symbol = "DI1F26";  instrument.maturity =20260102 ;m_instruments.add(instrument);}
		{Instruments instrument = new Instruments(); instrument.security_id =146687 ; instrument.symbol = "DI1F29";  instrument.maturity =20290102 ;m_instruments.add(instrument);}
		{Instruments instrument = new Instruments(); instrument.security_id =320100 ; instrument.symbol = "DI1F30";  instrument.maturity =20300102 ;m_instruments.add(instrument);}
*/
		SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
		Date today = new Date(); 
		Instruments instrument = new Instruments();
		for(int i=0; i < m_instruments.size(); ++i){
			instrument = m_instruments.get(i);
			instrument.duration = 0;
			try {
				Date date = format.parse(Integer.toString(instrument.maturity));
				//System.out.println("Date is: " + date.toString());
				instrument.duration = (int)( (date.getTime() - today.getTime()) / (1000 * 60 * 60 * 24) );	
				
			} catch (ParseException e) {}
			m_instruments.set(i, instrument);
		}
		
		
		//Client
		m_client_list =  new ArrayList <Long>();
		m_client_list.add(1896L);
		m_client_list.add(1899L);
		m_client_list.add(1901L);
		m_client_list.add(2056L);
		m_client_list.add(2168L);
		m_client_list.add(2193L);
		m_client_list.add(2199L);
		m_client_list.add(2204L);
		m_client_list.add(2216L);
		m_client_list.add(2287L);
		m_client_list.add(2313L);
		m_client_list.add(2344L);
		m_client_list.add(2398L);
		m_client_list.add(2449L);
		m_client_list.add(2509L);
		m_client_list.add(2618L);
		m_client_list.add(2672L);
		m_client_list.add(2722L);
		m_client_list.add(2818L);
		m_client_list.add(3879L);
		m_client_list.add(3880L);
		m_client_list.add(4070L);
		m_client_list.add(4489L);
		m_client_list.add(4536L);
		m_client_list.add(4575L);
		m_client_list.add(7072L);
		m_client_list.add(7875L);
		m_client_list.add(8390L);
		m_client_list.add(8391L);
		m_client_list.add(8846L);
		m_client_list.add(8847L);
		m_client_list.add(18385L);
		m_client_list.add(22565L);
		m_client_list.add(22566L);
		m_client_list.add(23000L);
		m_client_list.add(29747L);
		m_client_list.add(36144L);
		m_client_list.add(36255L);
		m_client_list.add(37046L);
		m_client_list.add(37099L);
		m_client_list.add(38006L);
		m_client_list.add(38045L);
		m_client_list.add(38126L);
		m_client_list.add(38131L);
		m_client_list.add(38140L);
		m_client_list.add(38154L);
		m_client_list.add(38170L);
		m_client_list.add(38198L);
		m_client_list.add(38215L);
		m_client_list.add(38219L);
		m_client_list.add(38222L);
		m_client_list.add(38232L);
		m_client_list.add(38235L);
		m_client_list.add(38259L);
		m_client_list.add(38260L);
		m_client_list.add(38261L);
		m_client_list.add(38262L);
		m_client_list.add(38279L);
		m_client_list.add(38780L);
		m_client_list.add(38781L);
		m_client_list.add(39184L);
		m_client_list.add(39257L);
		m_client_list.add(39734L);
		m_client_list.add(39746L);
		m_client_list.add(39750L);
		m_client_list.add(39777L);
		m_client_list.add(39963L);
		m_client_list.add(104462L);
		m_client_list.add(172502L);



	}
	
	
}
