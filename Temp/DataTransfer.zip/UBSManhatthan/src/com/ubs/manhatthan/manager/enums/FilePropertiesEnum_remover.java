package com.ubs.manhatthan.manager.enums;

public enum FilePropertiesEnum_remover {
	
	MESSAGE_PROPERTIES("/Message.properties"),
	MANHATTAN_PROPERTIES("/Manhattan.properties"),
    MANHATTAN_PROPERTIES_DEV("C:\\UBS\\Dev\\projects\\UBS\\Manhattan\\Manager\\Manhattan.properties"),
    MANHATTAN_PROPERTIES_UAT("/opt/middleware/setup/investor/appdata/dat/PrecogBroker.properties"),
    MANHATTAN_PROPERTIES_PROD("/opt/middleware/setup/investor/appdata/dat/PrecogBroker.properties");

    String path;

    FilePropertiesEnum_remover(String path) {
            this.path = path;
    }

    public String getPath() {
            return path;
    }
}