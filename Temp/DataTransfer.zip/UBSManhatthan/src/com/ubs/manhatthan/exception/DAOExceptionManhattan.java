/**
 * 
 */
package com.ubs.manhatthan.exception;

/**
 * @author galdinoa
 *
 */
public class DAOExceptionManhattan extends Exception {

	private static final long serialVersionUID = -7927476035244602452L;

	public DAOExceptionManhattan(){}
	
	public DAOExceptionManhattan( String message ){
		super( message );
	}
	
	public DAOExceptionManhattan( Throwable cause ){
		super( cause );
	}
	
	public DAOExceptionManhattan( String message, Throwable cause ){
		super( message, cause );
	}
	
	public DAOExceptionManhattan( String message, Throwable cause, 
			                      boolean enableSuppression, boolean writableStackTrace ){
		super( message, cause, enableSuppression, writableStackTrace );
	}
}
