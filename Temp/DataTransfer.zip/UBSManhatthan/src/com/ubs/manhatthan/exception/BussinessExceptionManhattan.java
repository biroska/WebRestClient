/**
 * 
 */
package com.ubs.manhatthan.exception;

/**
 * @author galdinoa
 *
 */
public class BussinessExceptionManhattan extends Exception {

	private static final long serialVersionUID = -7927476035244602452L;

	public BussinessExceptionManhattan(){}
	
	public BussinessExceptionManhattan( String message ){
		super( message );
	}
	
	public BussinessExceptionManhattan( Throwable cause ){
		super( cause );
	}
	
	public BussinessExceptionManhattan( String message, Throwable cause ){
		super( message, cause );
	}
	
	public BussinessExceptionManhattan( String message, Throwable cause, 
			                      boolean enableSuppression, boolean writableStackTrace ){
		super( message, cause, enableSuppression, writableStackTrace );
	}
}
