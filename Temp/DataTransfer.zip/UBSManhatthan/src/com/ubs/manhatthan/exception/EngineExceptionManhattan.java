/**
 * 
 */
package com.ubs.manhatthan.exception;

/**
 * @author galdinoa
 *
 */
public class EngineExceptionManhattan extends Exception {

	private static final long serialVersionUID = -2447454268260087242L;

	public EngineExceptionManhattan(){}
	
	public EngineExceptionManhattan( String message ){
		super( message );
	}
	
	public EngineExceptionManhattan( Throwable cause ){
		super( cause );
	}
	
	public EngineExceptionManhattan( String message, Throwable cause ){
		super( message, cause );
	}
	
	public EngineExceptionManhattan( String message, Throwable cause, 
			                      boolean enableSuppression, boolean writableStackTrace ){
		super( message, cause, enableSuppression, writableStackTrace );
	}
}
