package com.ubs.manhatthan.admin.beans;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.event.ActionEvent;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ubs.manhatthan.manager.persistence.entities.EngineInstance;
import com.ubs.manhatthan.manager.persistence.entities.Exchange;
import com.ubs.manhatthan.manager.persistence.entities.RecoverySessionByEngine;
import com.ubs.manhatthan.manager.persistence.entities.TcpRecoverySession;
import com.ubs.manhatthan.manager.utils.Util;

@SuppressWarnings("serial")
@Component("recoveryBean")
@Scope("session")
@ViewScoped
@ManagedBean(name="recoveryBean")
public class RecoveryBean extends BaseBean {

	private List<TcpRecoverySession> recoveries;
	private TcpRecoverySession selectedRecovery;

	private List<TcpRecoverySession> filteredRecoveries;

	@Autowired
	private EngineBean engineBean;
		
	private EngineInstance selectedEngine;
		
	private List<Exchange> exchanges;
	

	@PostConstruct
	public void init() {
		try {
			selectedRecovery = new TcpRecoverySession();
			selectedEngine = new EngineInstance();
			
			if (recoveries == null)
				recoveries = new ArrayList<TcpRecoverySession>(facade.getTcpRecoveries());
		
			if (exchanges == null)
				exchanges = new ArrayList<Exchange>(facade.getExchanges());
			
		} catch (Exception ex) {
			ex.printStackTrace();
			
			logError(ex.getMessage());
		}
	}
	
	public void loadRecovery() {
		
		try {
			recoveries = new ArrayList<TcpRecoverySession>(facade.getTcpRecoveries());
			exchanges = new ArrayList<Exchange>(facade.getExchanges());
			
		} catch (Exception ex) {
			ex.printStackTrace();			
			logError(ex.getMessage());
		}
	}

	public List<TcpRecoverySession> getRecoveries() {
		return recoveries;
	}

	public void setRecoveries(List<TcpRecoverySession> recoveries) {
		this.recoveries = recoveries;
	}

	public TcpRecoverySession getSelectedRecovery() {
		return selectedRecovery;
	}

	public void setSelectedRecovery(TcpRecoverySession selectedRecovery) {
		this.selectedRecovery = selectedRecovery;
	}
	
	public List<TcpRecoverySession> getFilteredRecoveries() {
		return filteredRecoveries;
	}

	public void setFilteredRecoveries(List<TcpRecoverySession> filteredRecoveries) {
		this.filteredRecoveries = filteredRecoveries;
	}
		
	public Exchange getExchange() {
		return this.selectedRecovery.getExchange();
	}
	
	public void setExchange(Exchange exchange) {
		this.selectedRecovery.setExchange(exchange);
	}
	
	public List<Exchange> getExchanges() {
		return exchanges;
	}

	public void newRecovery(ActionEvent actionEvent) {
		cleanFields();
		this.selectedRecovery = new TcpRecoverySession();
		this.selectedEngine = engineBean.getEngines().get(0);
	}
	
	public void openEdit(TcpRecoverySession selectedRecovery) {
		cleanFields();
		BeanUtils.copyProperties(selectedRecovery, this.selectedRecovery);
		for (EngineInstance engine : engineBean.getEngines()) {
			if (this.selectedRecovery.getEngineId()!=null && this.selectedRecovery.getEngineId().equals(engine.getEngineId())){				
				BeanUtils.copyProperties(engine, this.selectedEngine);
				break;
			}
		}
	}
	
	public void addRecovery(ActionEvent actionEvent) {		
		boolean recordExists = false;
		
		try {
			if (this.selectedRecovery != null){
				
				TcpRecoverySession selectedRecovery = new TcpRecoverySession();
				BeanUtils.copyProperties(this.selectedRecovery, selectedRecovery);
				
				if(selectedRecovery.getSenderCompId()!=null 
					&& !selectedRecovery.getSenderCompId().trim().isEmpty()) {
				
					if ( selectedEngine != null ){
						selectedRecovery.setEngineId( selectedEngine.getEngineId() );
						selectedRecovery.setIdEngine( selectedEngine.getId() );
					}
					
					recordExists = validation(selectedRecovery);
					
					if (!recordExists) {				
						selectedRecovery = facade.saveTcpRecoverySession(selectedRecovery, this.selectedEngine);
						
						this.recoveries.add(selectedRecovery);						
						refreshView();						
						hideDialog("dlgTcpRecoveryAdd");
					}
				}else{
					errorMessage( Util.getMessageFromFile( "msg.admin.tcprecovery.error.sendercompid.required") );		
					addValidationBorder( "tabViewMain:tabViewMarketData:tabTcpRecovery:formTCPRecoveryAdd:senderCompId" );
				}
			}
		} catch (Exception ex) {			
			ex.printStackTrace();
			
			this.errorMessage(Util.getMessageFromFile( "msg.admin.tcprecovery.error.add"));
		}
	}

	public void deleteRecovery(ActionEvent actionEvent) {		
		try {
			EngineInstance engineToDelete = new EngineInstance();
			
			engineToDelete.setId(this.selectedRecovery.getIdEngine());
						
			RecoverySessionByEngine recoverySessionByEngine = new RecoverySessionByEngine(engineToDelete, this.selectedRecovery);
						
			facade.deleteEngineRecoverySession(recoverySessionByEngine);

			this.recoveries.remove(this.selectedRecovery);
			refreshView();
		} catch (Exception ex) {
			ex.printStackTrace();
			
			this.errorMessage(Util.getMessageFromFile( "msg.admin.tcprecovery.error.delete"));
		}
	}

	public void saveRecovery(ActionEvent actionEvent) {
		boolean recordExists = false;
		
		try {
			if (this.selectedRecovery != null) {
				
				TcpRecoverySession selectedRecovery = new TcpRecoverySession();
				BeanUtils.copyProperties(this.selectedRecovery, selectedRecovery);
				
				
				if(selectedRecovery.getSenderCompId()!=null 
						&& !selectedRecovery.getSenderCompId().trim().isEmpty()) {
				
					if ( selectedEngine != null ){
						selectedRecovery.setEngineId( selectedEngine.getEngineId() );
						selectedRecovery.setIdEngine( selectedEngine.getId() );
					}
					
					recordExists = validation(selectedRecovery);
					
					if (!recordExists) {						
						facade.saveTcpRecoverySession(selectedRecovery, selectedEngine);
						
						for (int i = 0; i < recoveries.size(); i++) {
							if (recoveries.get(i).getId().equals(selectedRecovery.getId())) {
								recoveries.set(i, selectedRecovery);
								break;
							}
						}
						
						refreshView();
						hideDialog("dlgTcpRecoveryEdit");
					} 
				}else{
					errorMessage( Util.getMessageFromFile( "msg.admin.tcprecovery.error.sendercompid.required") );		
					addValidationBorder( "tabViewMain:tabViewMarketData:tabTcpRecovery:formTCPRecoveryEdit:senderCompId" );
				}
			}
		} catch (Exception ex) {			
			this.errorMessage(Util.getMessageFromFile( "msg.admin.tcprecovery.error.save"));
		}
	}
	
	
	private boolean validation(TcpRecoverySession selectedRecovery){
		
		boolean recordExists = false;
		
		for (TcpRecoverySession item: this.recoveries) {
			
			if ( !item.getId().equals( selectedRecovery.getId() ) ){
			
				if(selectedRecovery.getExchange().getId().equals(item.getExchange().getId()) && 
						selectedRecovery.getEngineId().equals(item.getEngineId())){
					recordExists = true;
					this.errorMessage(Util.getMessageFromFile( "msg.admin.tcprecovery.error.exchangeengine.exist"));
				}else if(selectedRecovery.getHost().equals(item.getHost()) && 
						selectedRecovery.getPort().equals(item.getPort())
						&& selectedRecovery.getSenderCompId().equals(item.getSenderCompId())){
					recordExists = true;
					String messageDynamic = MessageFormat.format(Util.getMessageFromFile( "msg.admin.tcprecovery.error.hostportsendercompid.exist"), selectedRecovery.getHost(),selectedRecovery.getPort(), selectedRecovery.getSenderCompId() );
					this.errorMessage(messageDynamic);
				}
			}
		}
		
		return recordExists;
		
	}
	
	public void cleanFields(){
		removeValidationBorder( "tabViewMain:tabViewMarketData:tabTcpRecovery:formTCPRecoveryEdit:exchange" );
		removeValidationBorder( "tabViewMain:tabViewMarketData:tabTcpRecovery:formTCPRecoveryEdit:engine" );
		removeValidationBorder( "tabViewMain:tabViewMarketData:tabTcpRecovery:formTCPRecoveryEdit:host" );
		removeValidationBorder( "tabViewMain:tabViewMarketData:tabTcpRecovery:formTCPRecoveryEdit:port" );
		removeValidationBorder( "tabViewMain:tabViewMarketData:tabTcpRecovery:formTCPRecoveryEdit:senderCompId" );
		
		removeValidationBorder( "tabViewMain:tabViewMarketData:tabTcpRecovery:formTCPRecoveryAdd:exchange" );
		removeValidationBorder( "tabViewMain:tabViewMarketData:tabTcpRecovery:formTCPRecoveryAdd:engine" );
		removeValidationBorder( "tabViewMain:tabViewMarketData:tabTcpRecovery:formTCPRecoveryAdd:host" );
		removeValidationBorder( "tabViewMain:tabViewMarketData:tabTcpRecovery:formTCPRecoveryAdd:port" );
		removeValidationBorder( "tabViewMain:tabViewMarketData:tabTcpRecovery:formTCPRecoveryAdd:senderCompId" );
	}

	public EngineBean getEngineBean() {
		return engineBean;
	}

	public void setEngineBean(EngineBean engineBean) {
		this.engineBean = engineBean;
	}

	public EngineInstance getSelectedEngine() {
		return selectedEngine;
	}

	public void setSelectedEngine(EngineInstance selectedEngine) {
		this.selectedEngine = selectedEngine;
	}
}