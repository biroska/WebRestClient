package com.ubs.manhatthan.admin.beans;


import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.event.ActionEvent;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.persistence.entities.ClientAccount;
import com.ubs.manhatthan.manager.persistence.entities.OrderFixSession;
import com.ubs.manhatthan.manager.persistence.entities.SessionByAccount;
import com.ubs.manhatthan.manager.utils.Util;

@SuppressWarnings("serial")
@Component("accountBean")
@Scope("session")
@ViewScoped
@ManagedBean(name="accountBean")
public class AccountBean extends BaseBean {

	private List<SessionByAccount> accounts;
	private List<SessionByAccount> filteredAccounts;
	private SessionByAccount selectedAccount;
	
	private List<ClientAccount> clientAccounts;
	private List<OrderFixSession> orderFixSessions;
			
	@PostConstruct
	public void init() {		
		if (accounts == null) {
			try {
				accounts = facade.getAccountSessions();
				orderFixSessions = facade.getOrderFixSessions();
			} catch (DAOExceptionManhattan e) {
				e.printStackTrace();
			}
		}
	}
	
	public void loadAccount() {
		
		try {
			accounts = facade.getAccountSessions();
			orderFixSessions = facade.getOrderFixSessions();
			
		} catch (Exception ex) {
			ex.printStackTrace();			
			logError(ex.getMessage());
		}
	}
	
			
	public List<SessionByAccount> getAccounts() {
		return accounts;
	}

	public void setAccounts(List<SessionByAccount> accounts) {
		this.accounts = accounts;
	}

	public SessionByAccount getSelectedAccount() {
		return selectedAccount;
	}

	public void setSelectedAccount(SessionByAccount selectedAccount) {
		this.selectedAccount = selectedAccount;
	}

	public List<SessionByAccount> getFilteredAccounts() {
		return filteredAccounts;
	}

	public void setFilteredAccounts(List<SessionByAccount> filteredAccounts) {
		this.filteredAccounts = filteredAccounts;
	}

	public List<OrderFixSession> getOrderFixSessions() {
		return orderFixSessions;
	}

	public List<ClientAccount> completeAccount(String account) {
		ClientAccount searchClientAccount = new ClientAccount();
		
		searchClientAccount.setDescription("%" + account + "%");

		try {
			clientAccounts = facade.FindClientAccount(searchClientAccount);
		} catch (DAOExceptionManhattan e) {
			e.printStackTrace();
		}
		
		return clientAccounts;
	}
		
	public void newAccount(ActionEvent actionEvent) {	
		cleanFields();
		this.selectedAccount = new SessionByAccount();
	}
	
	public void deleteAccount(ActionEvent actionEvent) {		
		try {
			facade.deleteSessionByAccount(this.selectedAccount);
			
			this.accounts.remove(this.selectedAccount);
			refreshView();
		} catch (Exception ex) {			
			ex.printStackTrace();
			
			this.errorMessage(Util.getMessageFromFile( "msg.admin.engine.error.delete"));
		}
	}
	
	public void addAccount(ActionEvent actionEvent) {
		boolean recordExists = false;
		
		try {
			if (this.selectedAccount != null) {
				for (SessionByAccount item: this.accounts) {
					recordExists = (selectedAccount.getClientAccount().getCode().equals(item.getClientAccount().getCode()));
		
					if (recordExists) break;
				}
				
				if (recordExists) {
					this.warnMessage(Util.getMessageFromFile( "msg.admin.engine.error.exist"));
				} else {
					
					this.selectedAccount = facade.saveSessionByAccount(this.selectedAccount);
					
					this.accounts.add(this.selectedAccount);	
					refreshView();
					hideDialog("dlgAccountAdd");
				}
			}
		} catch (Exception ex) {			
			ex.printStackTrace();
			
			this.errorMessage(Util.getMessageFromFile( "msg.admin.engine.error.add"));
		}
	}

	public void saveAccount(ActionEvent actionEvent) {
		boolean recordExists = false;

		try {
			if (this.selectedAccount != null) {
				for (SessionByAccount item: this.accounts) {
					recordExists = (selectedAccount.getClientAccount().getCode().equals(item.getClientAccount().getCode())) &&
							(selectedAccount.getOrderFixSession().getId().equals(item.getOrderFixSession().getId()));
					
					if (recordExists) break;
				}
				
				if (recordExists) {
					facade.saveSessionByAccount(this.selectedAccount);
					refreshView();
					hideDialog("dlgAccountEdit");
				} else {
					this.errorMessage(Util.getMessageFromFile( "msg.admin.engine.error.save"));
				}
			}
						
		} catch (Exception ex) {
			logError(ex.getMessage());

			this.errorMessage(Util.getMessageFromFile( "msg.admin.engine.error.save"));
		}
	}
	
	public void cleanFields(){
		try {
			orderFixSessions = facade.getOrderFixSessions();
		} catch (DAOExceptionManhattan e) {
			this.errorMessage(Util.getMessageFromFile( "msg.admin.engine.error.load.order.entrys"));
		}
		removeValidationBorder( "tabViewMain:tabAccount:formAccountAdd:accountCode" );
		removeValidationBorder( "tabViewMain:tabAccount:formAccountEdit:accountCode" );
	}
}