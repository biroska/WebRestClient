/**
 * 
 */
package com.ubs.manhatthan.admin.validator;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.FacesValidator;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

import com.ubs.manhatthan.manager.utils.Constant;

/**
 * @author galdinoa
 *
 */

@FacesValidator(value="portValidator")
public class PortValidator implements Validator {

	//Valida se a parta e menor que o valor maximo padrao do TCP.
    @Override
    public void validate(FacesContext context, UIComponent component, Object value) throws ValidatorException {
    	
    	Long port = null;
    	if (value != null) {
    		port = (Long) value;
		}
    	
    	
        if(port == null || port == 0L){
        	value = null;
        	FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Port field is required!", null);
    		throw new ValidatorException(message);
        }else {
            if (port!=null && port > Constant.COMUNICATION.MAX_NUMBER_PORT) {
                FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Port number must be minor than " + Constant.COMUNICATION.MAX_NUMBER_PORT + " !", null);
        		throw new ValidatorException(message);
            }
		}
    }

}
