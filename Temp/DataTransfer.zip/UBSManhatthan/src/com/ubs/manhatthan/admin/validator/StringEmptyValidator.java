/**
 * 
 */
package com.ubs.manhatthan.admin.validator;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.FacesValidator;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

/**
 * @author galdinoa
 *
 */

@FacesValidator(value="stringEmptyValidator")
public class StringEmptyValidator implements Validator {
    @Override
    public void validate(FacesContext context, UIComponent component, Object value) throws ValidatorException {
    	String string = null;
        if (value!=null) {
        	string = (String) value.toString();
        }
        if (string==null || (string.trim().isEmpty())) {
            FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Description is required !", null);
    		throw new ValidatorException(message);
        }
    }
}
