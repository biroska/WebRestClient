package com.ubs.manhatthan.admin.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;

import org.apache.log4j.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ubs.manhatthan.manager.facade.Facade;
import com.ubs.manhatthan.manager.logger.ManhattanLogger;
import com.ubs.manhatthan.manager.persistence.entities.ClientAccount;
import com.ubs.manhatthan.manager.utils.Util;

@Component(value="clientAccountConverter")
public class ClientAccountConverter implements Converter {

	@Autowired
	protected Facade facade;

    public Object getAsObject(FacesContext context, UIComponent component, String value) {
    	ClientAccount c = null;
    	
    	try {
    		c = facade.findClientAccountByCode(new Long(value));
    	} catch (Exception ex) {
    		ManhattanLogger.log(Util.getManagerId().toString(), ex.getMessage(), Level.ERROR);
    	}
    	
    	return c;
    }

    public String getAsString(FacesContext context, UIComponent component, Object object) {
    	if (object != null) {
    		return String.valueOf(((ClientAccount) object).getCode());
    	} else {
    		return null;    	
    	}
    }
    
    public void setFacade(Facade facade) {
    	this.facade = facade;
    }  
}