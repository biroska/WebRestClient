package com.ubs.manhatthan.admin.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import org.apache.log4j.Level;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import com.ubs.manhatthan.manager.cache.CacheHelper;
import com.ubs.manhatthan.manager.logger.ManhattanLogger;
import com.ubs.manhatthan.manager.persistence.entities.EngineUmdfChannel;
import com.ubs.manhatthan.manager.utils.Util;

@Component
@Scope(WebApplicationContext.SCOPE_REQUEST)
@FacesConverter(value="umdfChanelConverter")
public class UmdfChanelConverter implements Converter {
	
    public Object getAsObject(FacesContext context, UIComponent component, String value) {
    	EngineUmdfChannel c = null;
    	
		try {			
			c = CacheHelper.facade.getUmdfChanelById(Long.parseLong(value));
		} catch (Exception ex) {
			ex.printStackTrace();
			
    		ManhattanLogger.log(Util.getManagerId().toString(), ex.getMessage(), Level.ERROR);
		}

		return c;
    }

    public String getAsString(FacesContext context, UIComponent component, Object object) {
    	if (object != null) {
    		return String.valueOf(((EngineUmdfChannel) object).getId());
    	} else {
    		return null;    	
    	}
    }

}