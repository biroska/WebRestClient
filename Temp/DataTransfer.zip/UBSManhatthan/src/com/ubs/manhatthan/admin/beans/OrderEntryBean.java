package com.ubs.manhatthan.admin.beans;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.event.ActionEvent;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ubs.manhatthan.exception.BussinessExceptionManhattan;
import com.ubs.manhatthan.manager.cache.CacheHelper;
import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.persistence.entities.EngineInstance;
import com.ubs.manhatthan.manager.persistence.entities.Exchange;
import com.ubs.manhatthan.manager.persistence.entities.OrderFixSession;
import com.ubs.manhatthan.manager.persistence.entities.SessionByEngine;
import com.ubs.manhatthan.manager.utils.Util;

@SuppressWarnings("serial")
@Component("orderEntryBean")
@Scope("session")
@ViewScoped
@ManagedBean(name="orderEntryBean")
public class OrderEntryBean extends BaseBean {

	private List<OrderFixSession> orderEntries;
	private OrderFixSession selectedOrderEntry;
		
	private List<OrderFixSession> filteredOrderEntries;
	
	private EngineInstance selectedEngine;
	
	@Autowired
	private EngineBean engineBean;
	
	
	@PostConstruct
	public void init() {
		try {
			this.selectedOrderEntry = new OrderFixSession();
			this.selectedEngine = new EngineInstance();
			
			if (orderEntries == null){
				orderEntries = new ArrayList<OrderFixSession>();
				
				List<OrderFixSession> orderFixSessions = facade.getOrderFixSessions();
				
				if ( orderFixSessions != null ){
					orderEntries.addAll( orderFixSessions );
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();			
			logError(ex.getMessage());
		}
	}
	
	
	public void loadOrderEntries() {
		
		try {
			orderEntries = facade.getOrderFixSessions();
		} catch (Exception ex) {
			ex.printStackTrace();			
			logError(ex.getMessage());
		}
	}
	
	public List<OrderFixSession> getOrderEntries() {
		return orderEntries;
	}

	public void setOrderEntries(List<OrderFixSession> orderEntries) {
		this.orderEntries = orderEntries;
	}

	public OrderFixSession getSelectedOrderEntry() {
		return selectedOrderEntry;
	}

	public void setSelectedOrderEntry(OrderFixSession selectedOrderEntry) {
		this.selectedOrderEntry = selectedOrderEntry;
	}

	public List<OrderFixSession> getFilteredOrderEntries() {
		return filteredOrderEntries;
	}

	public void setFilteredOrderEntries(List<OrderFixSession> filteredOrderEntries) {
		this.filteredOrderEntries = filteredOrderEntries;
	}
	
	public Exchange getExchange() {
		return this.selectedOrderEntry.getExchange();
	}
	
	public void setExchange(Exchange exchange) {
		this.selectedOrderEntry.setExchange(exchange);
	}
	
	public List<Exchange> getExchanges() {
		return CacheHelper.exchangeListCache;
	}

	public void newOrderEntry(ActionEvent actionEvent) {
		cleanFields(false);
		this.selectedOrderEntry = new OrderFixSession();
	}
	
	public boolean hasEmptyFields(String formTCPRecovery){
		
		boolean hasEmptyFields = false;
		
		if(this.selectedOrderEntry.getTargetCompId()==null 
					|| this.selectedOrderEntry.getTargetCompId().trim().isEmpty()) {
			
			hasEmptyFields = true;
			errorMessage( Util.getMessageFromFile( "msg.admin.orderentry.error.targetcompid.required") );		
			addValidationBorder( "tabViewMain:tabOrderEntry:" + formTCPRecovery + ":targetCompId" );
			
				
		}
		
		if(this.selectedOrderEntry.getSenderCompId()==null 
				|| this.selectedOrderEntry.getSenderCompId().trim().isEmpty()) {
		
			hasEmptyFields = true;
			errorMessage( Util.getMessageFromFile( "msg.admin.orderentry.error.sendercompid.required") );		
			addValidationBorder( "tabViewMain:tabOrderEntry:" + formTCPRecovery + ":senderCompId" );
				
		}
			
		if(this.selectedOrderEntry.getDescription()==null 
				|| this.selectedOrderEntry.getDescription().trim().isEmpty()) {
			
			hasEmptyFields = true;
			errorMessage( Util.getMessageFromFile( "msg.admin.orderentry.error.description.required") );		
			addValidationBorder( "tabViewMain:tabOrderEntry:" + formTCPRecovery + ":description" );
				
		}
			
		if(this.selectedOrderEntry.getPassword()==null 
				|| this.selectedOrderEntry.getPassword().trim().isEmpty()) {
			
			hasEmptyFields = true;
			errorMessage( Util.getMessageFromFile( "msg.admin.orderentry.error.password.required") );		
			addValidationBorder( "tabViewMain:tabOrderEntry:" + formTCPRecovery + ":password" );
				
		}
		
		return hasEmptyFields;
	}

	public void deleteOrderEntry(ActionEvent actionEvent) {		
		try {
			EngineInstance engineToDelete = new EngineInstance();
			
			engineToDelete.setId(this.selectedOrderEntry.getIdEngine());
						
			SessionByEngine sessionByEngine = new SessionByEngine(engineToDelete, this.selectedOrderEntry);						
			
			facade.deleteOrderEntry(sessionByEngine, this.selectedOrderEntry);
			
			this.orderEntries.remove(this.selectedOrderEntry);
			refreshView();
		}  catch (BussinessExceptionManhattan ex) {
			logError(ex.getMessage());
			
			this.errorMessage(ex.getMessage());
		} catch (Exception ex) {
			logError(ex.getMessage());
			String messageDynamic = MessageFormat.format(Util.getMessageFromFile( "msg.admin.orderentry.error.delete.constraint"), this.selectedOrderEntry.getId());
			this.errorMessage(messageDynamic);
		}
	}
	
	public void openEdit(OrderFixSession selectedOrderEntry) {
		cleanFields(true);
		BeanUtils.copyProperties(selectedOrderEntry, this.selectedOrderEntry);
		for (EngineInstance engine : engineBean.getEngines()) {
			if (this.selectedOrderEntry.getEngineId()!=null && this.selectedOrderEntry.getEngineId().equals(engine.getEngineId())){
				
				BeanUtils.copyProperties(engine, this.selectedEngine);
				break;
			}
		}
	}

	public void saveOrderEntry(ActionEvent actionEvent) {
		boolean recordExists = false;
		try {
			if (this.selectedOrderEntry != null) {
				
				if (!hasEmptyFields("formOrderEntryEdit")) {
					
					OrderFixSession selectedOrderEntry = new OrderFixSession();
					BeanUtils.copyProperties(this.selectedOrderEntry, selectedOrderEntry);
					
					if ( selectedEngine != null && this.selectedEngine.getEngineId() != null ){
						selectedOrderEntry.setEngineId( selectedEngine.getEngineId() );
						selectedOrderEntry.setIdEngine( selectedEngine.getId() );
					}
					
					recordExists = validation(selectedOrderEntry);
					
					if (!recordExists) {
						selectedOrderEntry.setEngineId(selectedEngine.getEngineId());
						selectedOrderEntry.setIdEngine(selectedEngine.getId());
						facade.saveOrderFixSession(selectedEngine, selectedOrderEntry, ActionTypeEnum.UPDATE);
						
						
						for (int i = 0; i < orderEntries.size(); i++) {
							if (orderEntries.get(i).getId().equals(selectedOrderEntry.getId())) {
								orderEntries.set(i, selectedOrderEntry);
								break;
							}
						}

						refreshView();
						
						hideDialog("fixSessionEdit");
					} else {
						this.warnMessage(Util.getMessageFromFile( "msg.admin.orderentry.error.exist"));
					}
				}
			}
		} catch (Exception ex) {
			logError(ex.getMessage());

			this.errorMessage(Util.getMessageFromFile( "msg.admin.orderentry.error.save"));
		}			
	}
	
	public void addOrderEntry(ActionEvent actionEvent) {		
		boolean recordExists = false;
		
		try {
			if (this.selectedOrderEntry != null) {
				
				if (!hasEmptyFields("formOrderEntryAdd")) {
					
					OrderFixSession selectedOrderEntry = new OrderFixSession();
					BeanUtils.copyProperties(this.selectedOrderEntry, selectedOrderEntry);
					
					if ( selectedEngine != null && this.selectedEngine.getEngineId() != null ){
						selectedOrderEntry.setEngineId( selectedEngine.getEngineId() );
						selectedOrderEntry.setIdEngine( selectedEngine.getId() );
					}
					
					recordExists = validation(selectedOrderEntry);
					
					if (!recordExists) {
						selectedOrderEntry.setEngineId(selectedEngine.getEngineId());					
						selectedOrderEntry = facade.saveOrderFixSession(selectedEngine, selectedOrderEntry, ActionTypeEnum.INSERT);						
						selectedOrderEntry.setEngineId( selectedEngine.getEngineId() );
						selectedOrderEntry.setIdEngine( selectedEngine.getId() );
						
						this.orderEntries.add(selectedOrderEntry);		
						
						refreshView();
						
						hideDialog("fixSessionAdd");
					} else {
						this.warnMessage(Util.getMessageFromFile( "msg.admin.orderentry.error.exist"));
					}
				}
			}
		} catch (BussinessExceptionManhattan ex) {
			this.errorMessage(ex.getMessage());
		} catch (Exception ex) {
			ex.printStackTrace();
			
			logError(ex.getMessage());

			this.errorMessage(Util.getMessageFromFile( "msg.admin.orderentry.error.add"));
		}			
	}
	
	private boolean validation(OrderFixSession selectedOrderEntry){
		
 		boolean recordExists = false;
		
		for (OrderFixSession item: this.orderEntries) {
			
			if ( !item.getId().equals( selectedOrderEntry.getId() ) ){
											
				recordExists = (selectedOrderEntry.getId().equals(item.getId()));
		
				if (recordExists) return recordExists;
				
				recordExists = (selectedOrderEntry.getHost().equals(item.getHost()) && 
								selectedOrderEntry.getPort().equals(item.getPort()));
				
				if (recordExists) return recordExists;
				
				recordExists = (selectedOrderEntry.getSenderCompId().equals(item.getSenderCompId()));
				
				if (recordExists) return recordExists;
			}
		}
		
		return recordExists;
	}
	
	public void cleanFields(boolean isEdit){
		if (isEdit) {
			removeValidationBorder( "tabViewMain:tabOrderEntry:formOrderEntryEdit:fixSessionId" );
			removeValidationBorder( "tabViewMain:tabOrderEntry:formOrderEntryEdit:host" );
			removeValidationBorder( "tabViewMain:tabOrderEntry:formOrderEntryEdit:port" );
			removeValidationBorder( "tabViewMain:tabOrderEntry:formOrderEntryEdit:targetCompId" );
			removeValidationBorder( "tabViewMain:tabOrderEntry:formOrderEntryEdit:senderCompId" );
			removeValidationBorder( "tabViewMain:tabOrderEntry:formOrderEntryEdit:description" );
			removeValidationBorder( "tabViewMain:tabOrderEntry:formOrderEntryEdit:password" );
		}else{
			removeValidationBorder( "tabViewMain:tabOrderEntry:formOrderEntryAdd:fixSessionId" );
			removeValidationBorder( "tabViewMain:tabOrderEntry:formOrderEntryAdd:host" );
			removeValidationBorder( "tabViewMain:tabOrderEntry:formOrderEntryAdd:port" );
			removeValidationBorder( "tabViewMain:tabOrderEntry:formOrderEntryAdd:targetCompId" );
			removeValidationBorder( "tabViewMain:tabOrderEntry:formOrderEntryAdd:senderCompId" );
			removeValidationBorder( "tabViewMain:tabOrderEntry:formOrderEntryAdd:description" );
			removeValidationBorder( "tabViewMain:tabOrderEntry:formOrderEntryAdd:password" );
		}		
	}

	public EngineInstance getSelectedEngine() {
		return selectedEngine;
	}

	public void setSelectedEngine(EngineInstance selectedEngine) {
		this.selectedEngine = selectedEngine;
	}

	public EngineBean getEngineBean() {
		return engineBean;
	}

	public void setEngineBean(EngineBean engineBean) {
		this.engineBean = engineBean;
	}
	
}