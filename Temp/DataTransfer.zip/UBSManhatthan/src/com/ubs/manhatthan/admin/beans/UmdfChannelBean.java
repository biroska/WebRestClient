package com.ubs.manhatthan.admin.beans;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;

import org.springframework.beans.BeanUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ubs.manhatthan.admin.model.ChannelType;
import com.ubs.manhatthan.exception.BussinessExceptionManhattan;
import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.cache.CacheHelper;
import com.ubs.manhatthan.manager.enums.ChannelTypeEnum;
import com.ubs.manhatthan.manager.persistence.entities.EngineUmdfChannel;
import com.ubs.manhatthan.manager.persistence.entities.Exchange;
import com.ubs.manhatthan.manager.persistence.entities.UmdfChannelByEngine;
import com.ubs.manhatthan.manager.utils.Util;

@SuppressWarnings("serial")
@Component("umdfChannelBean")
@Scope("session")
@ViewScoped
@ManagedBean(name="umdfChannelBean")
public class UmdfChannelBean extends BaseBean {

	private List<EngineUmdfChannel> umdfChannels;
	private EngineUmdfChannel selectedUmdfChannel;

	private List<EngineUmdfChannel> filteredUmdfChannels;
	
	
	private List<ChannelType> channelTypes;	
	private String idSelectType;
	
	@PostConstruct
	public void init() {
		try {
			selectedUmdfChannel = new EngineUmdfChannel();
			
			if (umdfChannels == null)
				umdfChannels = facade.getUmdfChannels();
		
			if (channelTypes == null)
				channelTypes = ChannelTypeEnum.convertToList();
			
			idSelectType = channelTypes.get(0).getName();
		} catch (DAOExceptionManhattan ex) {
			ex.printStackTrace();
			
			logError(ex.getMessage());
		}
	}
	
	public void loadUmdfChannel() {
		
		try {

			umdfChannels = facade.getUmdfChannels();
			channelTypes = ChannelTypeEnum.convertToList();			
			idSelectType = channelTypes.get(0).getName();
			
		} catch (Exception ex) {
			ex.printStackTrace();			
			logError(ex.getMessage());
		}
	}

	public List<EngineUmdfChannel> getUmdfChannels() {
		return umdfChannels;
	}

	public void setUmdfChannels(List<EngineUmdfChannel> umdfChannels) {
		this.umdfChannels = umdfChannels;
	}

	public EngineUmdfChannel getSelectedUmdfChannel() {
		return  selectedUmdfChannel;
	}

	public void setSelectedUmdfChannel(EngineUmdfChannel selectedUmdfChannel) {
		this.selectedUmdfChannel = selectedUmdfChannel;
	}

	public List<EngineUmdfChannel> getFilteredUmdfChannels() {
		return filteredUmdfChannels;
	}

	public void setFilteredUmdfChannels(List<EngineUmdfChannel> filteredUmdfChannels) {
		this.filteredUmdfChannels = filteredUmdfChannels;
	}
	
	public List<ChannelType> getChannelTypes() {
		return channelTypes;
	}
	
	public Exchange getExchange() {
		return this.selectedUmdfChannel.getExchange();
	}
	
	public void setExchange(Exchange exchange) {
		this.selectedUmdfChannel.setExchange(exchange);;
	}
	
	public List<Exchange> getExchanges() {
		return CacheHelper.exchangeListCache;
	}

	public void newUmdfChannel(ActionEvent actionEvent) {
		cleanFields(false);
		this.selectedUmdfChannel = new EngineUmdfChannel();
	}
	
	public void openEdit(EngineUmdfChannel selectedUmdfChannel) {
		cleanFields(true);
		BeanUtils.copyProperties(selectedUmdfChannel, this.selectedUmdfChannel);
	}
	
	public void addUmdfChannel(ActionEvent actionEvent) {		
		boolean recordExists = false;
		
		try {
			if (this.selectedUmdfChannel != null) {
				
				EngineUmdfChannel selectedUmdfChannel = new EngineUmdfChannel();
				BeanUtils.copyProperties(this.selectedUmdfChannel, selectedUmdfChannel);
								
				for (EngineUmdfChannel item: this.umdfChannels) {
					if (selectedUmdfChannel.getId() == item.getId()
							|| selectedUmdfChannel.getChannelId().equals(item.getChannelId())
							|| (selectedUmdfChannel.getChannelId().equals(item.getChannelId()) 
									&& selectedUmdfChannel.getExchange().getCode().equals(item.getExchange().getCode()))) {
						recordExists = true;
					}
					
					if (recordExists) break;
				}
				
				if (recordExists) {
					this.warnMessage(Util.getMessageFromFile( "msg.admin.umdfChannel.error.exist"));
				} else {					
					selectedUmdfChannel.setChannelType(ChannelTypeEnum.fromValue(idSelectType));
					
					selectedUmdfChannel = facade.saveEngineUmdfChannel(selectedUmdfChannel);
					
					UmdfChannelByEngine umdfChannelByEngine = new UmdfChannelByEngine();
					
					umdfChannelByEngine.setEngineUmdfChannel(selectedUmdfChannel);
					
					this.umdfChannels.add(selectedUmdfChannel);
					refreshView();
					hideDialog("dlgUmdfChannelAdd");
				}
			}
		} catch (Exception ex) {
			logError(ex.getMessage());
			
			this.errorMessage(Util.getMessageFromFile( "msg.admin.umdfChannel.error.add"));
		}
	}

	public void deleteUmdfChannel(ActionEvent actionEvent) {		
		try {
			facade.deleteUmdfChannel(this.selectedUmdfChannel);
			this.umdfChannels.remove(this.selectedUmdfChannel);
			refreshView();
		} catch (BussinessExceptionManhattan ex) {
			logError(ex.getMessage());
			this.errorMessage(ex.getMessage());
		} catch (Exception ex) {
			logError(ex.getMessage());
			this.errorMessage(Util.getMessageFromFile( "msg.admin.umdfChannel.error.remove"));
		}
	}

	public void saveUmdfChannel(ActionEvent actionEvent) {
		boolean recordExists = false;
		
		try {
			if (this.selectedUmdfChannel != null) {
				
				EngineUmdfChannel selectedUmdfChannel = new EngineUmdfChannel();
				BeanUtils.copyProperties(this.selectedUmdfChannel, selectedUmdfChannel);
				
				
				for (EngineUmdfChannel item: this.umdfChannels) {
					recordExists = (selectedUmdfChannel.getId().equals(item.getId()));
					
					if (recordExists) break;
				}
				
				if (recordExists) {
					selectedUmdfChannel.setChannelType(ChannelTypeEnum.fromValue(idSelectType));
					
					facade.saveEngineUmdfChannel(selectedUmdfChannel);
					
					for (int i = 0; i < this.umdfChannels.size(); i++) {
						if (umdfChannels.get(i).getId().equals(selectedUmdfChannel.getId())) {
							umdfChannels.set(i, selectedUmdfChannel);
							break;
						}
					}
					
					refreshView();
					hideDialog("dlgUmdfChannelEdit");
				} else {
					this.errorMessage(Util.getMessageFromFile( "msg.admin.umdfChannel.error.save"));
				}
			}
		} catch (Exception ex) {
			logError(ex.getMessage());
			
			this.errorMessage(Util.getMessageFromFile( "msg.admin.umdfChannel.error.save"));
		}
	}
	
	public void changeComboType(ValueChangeEvent event) {
		String tw = (String) event.getNewValue();
		idSelectType = tw;
		refreshView();
	}
	
	public void cleanFields(boolean isEdit){
		
		if (isEdit) {
			removeValidationBorder( "tabViewMain:tabViewMarketData:tabUmdfChannels:formUMDFChannelEdit:exchange" );
			removeValidationBorder( "tabViewMain:tabViewMarketData:tabUmdfChannels:formUMDFChannelEdit:type" );
			removeValidationBorder( "tabViewMain:tabViewMarketData:tabUmdfChannels:formUMDFChannelEdit:incrementalIp" );
			removeValidationBorder( "tabViewMain:tabViewMarketData:tabUmdfChannels:formUMDFChannelEdit:incrementalPort" );
			removeValidationBorder( "tabViewMain:tabViewMarketData:tabUmdfChannels:formUMDFChannelEdit:marketRecoveryIp" );
			removeValidationBorder( "tabViewMain:tabViewMarketData:tabUmdfChannels:formUMDFChannelEdit:marketRecoveryPort" );
			removeValidationBorder( "tabViewMain:tabViewMarketData:tabUmdfChannels:formUMDFChannelEdit:instrumentDefinitionIp" );
			removeValidationBorder( "tabViewMain:tabViewMarketData:tabUmdfChannels:formUMDFChannelEdit:instrumentDefinitionPort" );
		}else{
			removeValidationBorder( "tabViewMain:tabViewMarketData:tabUmdfChannels:formUMDFChannelAdd:channelId" );
			removeValidationBorder( "tabViewMain:tabViewMarketData:tabUmdfChannels:formUMDFChannelAdd:exchange" );
			removeValidationBorder( "tabViewMain:tabViewMarketData:tabUmdfChannels:formUMDFChannelAdd:type" );
			removeValidationBorder( "tabViewMain:tabViewMarketData:tabUmdfChannels:formUMDFChannelAdd:incrementalIp" );
			removeValidationBorder( "tabViewMain:tabViewMarketData:tabUmdfChannels:formUMDFChannelAdd:incrementalPort" );
			removeValidationBorder( "tabViewMain:tabViewMarketData:tabUmdfChannels:formUMDFChannelAdd:marketRecoveryIp" );
			removeValidationBorder( "tabViewMain:tabViewMarketData:tabUmdfChannels:formUMDFChannelAdd:marketRecoveryPort" );
			removeValidationBorder( "tabViewMain:tabViewMarketData:tabUmdfChannels:formUMDFChannelAdd:instrumentDefinitionIp" );
			removeValidationBorder( "tabViewMain:tabViewMarketData:tabUmdfChannels:formUMDFChannelAdd:instrumentDefinitionPort" );
		}
	}

	/**
	 * @return the idSelectType
	 */
	public String getIdSelectType() {
		return idSelectType;
	}

	/**
	 * @param idSelectType the idSelectType to set
	 */
	public void setIdSelectType(String idSelectType) {
		this.idSelectType = idSelectType;
	}
}