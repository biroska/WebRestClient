package com.ubs.manhatthan.admin.beans;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.event.ActionEvent;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ubs.manhatthan.exception.BussinessExceptionManhattan;
import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.persistence.entities.EngineInstance;
import com.ubs.manhatthan.manager.persistence.entities.EngineUmdfChannel;
import com.ubs.manhatthan.manager.utils.Util;

@SuppressWarnings("serial")
@Component("engineBean")
@Scope("session")
@ViewScoped
@ManagedBean(name = "engineBean")
public class EngineBean extends BaseBean {

	private List<EngineInstance> engines;
	private EngineInstance selectedEngine;

	private List<EngineInstance> filteredEngines;

	private List<EngineUmdfChannel> availableUmdfChanels;
	private EngineUmdfChannel selectedUmdfChanel;
	private List<EngineUmdfChannel> umdfChanels = new ArrayList<EngineUmdfChannel>();
	

	@PostConstruct
	public void init() {
		if (engines == null)
			try {
				engines = facade.getEngines();
				loadAvailableRecoveries();
			} catch (DAOExceptionManhattan e) {
				e.printStackTrace();
			}
	}
	
	public void loadEngines() {
		
		try {
			engines = facade.getEngines();
			loadAvailableRecoveries();
		} catch (Exception ex) {
			ex.printStackTrace();			
			logError(ex.getMessage());
		}
	}

	public void loadAvailableRecoveries() {
		try {
			availableUmdfChanels = new ArrayList<EngineUmdfChannel>(facade.getUmdfChannels());
		} catch (DAOExceptionManhattan e) {
			e.printStackTrace();
		}
	}
	
	public List<EngineUmdfChannel> getAvailableUmdfChanels() {
		return availableUmdfChanels;
	}

	public void setAvailableUmdfChanels(List<EngineUmdfChannel> availableUmdfChanels) {
		this.availableUmdfChanels = availableUmdfChanels;
	}

	public EngineUmdfChannel getSelectedUmdfChanel() {
		return selectedUmdfChanel;
	}

	public void setSelectedUmdfChanel(EngineUmdfChannel selectedUmdfChanel) {
		this.selectedUmdfChanel = selectedUmdfChanel;
	}

	public List<EngineUmdfChannel> getUmdfChanels() {
		return umdfChanels;
	}

	public void setUmdfChanels(List<EngineUmdfChannel> umdfChanels) {
		this.umdfChanels = umdfChanels;
	}
	
	public EngineUmdfChannel getSelectedRecovery() {
		return selectedUmdfChanel;
	}

	public void setSelectedRecovery(EngineUmdfChannel selectedUmdfChanel) {
		this.selectedUmdfChanel = selectedUmdfChanel;
	}
	
	public List<EngineInstance> getEngines() {
		return engines;
	}

	public void setEngines(List<EngineInstance> engines) {
		this.engines = engines;
	}

	public List<EngineInstance> getFilteredEngines() {
		return filteredEngines;
	}

	public void setFilteredEngines(List<EngineInstance> filteredEngines) {
		this.filteredEngines = filteredEngines;
	}

	public EngineInstance getSelectedEngine() {
		return selectedEngine;
	}

	public void setSelectedEngine(EngineInstance selectedEngine) {
		this.selectedEngine = selectedEngine;
		loadAvailableRecoveries();
		try {
			this.umdfChanels = facade.getUmdfChanelsByEngine(selectedEngine);
		} catch (DAOExceptionManhattan e) {
			e.printStackTrace();
		}
	}

	public void newEngine(ActionEvent actionEvent) {
		cleanFields(false);
		this.selectedEngine = new EngineInstance();
		loadAvailableRecoveries();
		umdfChanels.clear();
	}
	
	public void openEdit() {
		cleanFields(true);
	}

	public void deleteEngine(ActionEvent actionEvent) {
		try {
			facade.deleteEngineInstance(this.selectedEngine);
			this.engines.remove(this.selectedEngine);
			refreshView();
		} catch (BussinessExceptionManhattan ex) {
			logError(ex.getMessage());
			this.errorMessage(ex.getMessage());
		} catch (Exception ex) {
			logError(ex.getMessage());
			this.errorMessage(Util.getMessageFromFile( "msg.admin.engine.error.delete"));
		}
	}

	public void addEngine(ActionEvent actionEvent) {
		boolean recordExists = false;

		try {
			if (this.selectedEngine != null) {
				if (this.umdfChanels == null || this.umdfChanels.isEmpty()) {
					this.errorMessage("At least 1 UMDF Channel is required!");
				}else{
					for (EngineInstance item : this.engines) {
						if(selectedEngine.getEngineId().equals(item.getEngineId())){
							recordExists = true;
							String messageDynamic = MessageFormat.format(Util.getMessageFromFile( "msg.admin.engine.error.engineid.exist"), selectedEngine.getEngineId());
							this.errorMessage(messageDynamic);
						}else if(selectedEngine.getHost().equals(item.getHost()) && selectedEngine.getPort().equals(item.getPort())){
							recordExists = true;
							String messageDynamic = MessageFormat.format(Util.getMessageFromFile( "msg.admin.engine.error.hostport.exist"), selectedEngine.getHost(), selectedEngine.getPort());
							this.errorMessage(messageDynamic);
						}
						if (recordExists)
							break;
					}
	
					if (!recordExists) {
						this.selectedEngine = facade.saveEngineInstance(this.selectedEngine, this.umdfChanels);
						this.engines.add(this.selectedEngine);
						refreshView();
						hideDialog("dlgEngineAdd");
					}else{
						engines = facade.getEngines();
					}
				}				
			}

		} catch (Exception ex) {
			logError(ex.getMessage());
			this.errorMessage(Util.getMessageFromFile( "msg.admin.engine.error.add"));
		}
	}

	public void saveEngine(ActionEvent actionEvent) {
		try {
			boolean recordRepeat = false;

			if (this.selectedEngine != null) {
				if (this.umdfChanels == null || this.umdfChanels.isEmpty()) {
					this.errorMessage("At least 1 UMDF Channel is required!");
				}else{
					for (EngineInstance item : this.engines) {
						if(item.getEngineId()!=selectedEngine.getEngineId()){
							if(selectedEngine.getHost().equals(item.getHost()) && selectedEngine.getPort().equals(item.getPort())){
								String messageDynamic = MessageFormat.format(Util.getMessageFromFile( "msg.admin.engine.error.hostport.exist"), selectedEngine.getHost(), selectedEngine.getPort());
								this.errorMessage(messageDynamic);
								recordRepeat = true;
							}
						}
						if (recordRepeat)
							break;
					}
					if(!recordRepeat){
						facade.saveEngineInstance(this.selectedEngine, this.umdfChanels);
						refreshView();
						hideDialog("dlgEngineEdit");
					}else{
						engines = facade.getEngines();
					}
				}				
			}
		} catch (Exception ex) {
			logError(ex.getMessage());
			this.errorMessage(Util.getMessageFromFile( "msg.admin.engine.error.edit"));
		}
	}

	public void addUmdfChanel(ActionEvent actionEvent) {
		try {
			if(selectedUmdfChanel!=null){
				if(!umdfChanels.contains(selectedUmdfChanel))
					umdfChanels.add(selectedUmdfChanel);
			}
		} catch (Exception ex) {
			logError(ex.getMessage());
			this.errorMessage(Util.getMessageFromFile( "msg.admin.engine.recovery.error.add"));
		}
	}
	
	public void removeUmdfChanel(ActionEvent actionEvent) {
		try {
			if(selectedUmdfChanel!=null){
				if(umdfChanels.contains(selectedUmdfChanel))
					umdfChanels.remove(selectedUmdfChanel);
			}
		} catch (Exception ex) {
			logError(ex.getMessage());
			this.errorMessage(Util.getMessageFromFile( "msg.admin.engine.recovery.error.remove"));
		}
	}
	
	public void cleanFields(boolean isEdit){
		
		if (isEdit) {
			removeValidationBorder( "tabViewMain:tabMain:formEngineEdit:description" );
			removeValidationBorder( "tabViewMain:tabMain:formEngineEdit:host" );
			removeValidationBorder( "tabViewMain:tabMain:formEngineEdit:port" );
			removeValidationBorder( "tabViewMain:tabMain:formEngineEdit:logPath" );
		}else{
			removeValidationBorder( "tabViewMain:tabMain:formEngineAdd:id" );
			removeValidationBorder( "tabViewMain:tabMain:formEngineAdd:description" );
			removeValidationBorder( "tabViewMain:tabMain:formEngineAdd:host" );
			removeValidationBorder( "tabViewMain:tabMain:formEngineAdd:port" );
			removeValidationBorder( "tabViewMain:tabMain:formEngineAdd:logPath" );
		}
	}
	
}