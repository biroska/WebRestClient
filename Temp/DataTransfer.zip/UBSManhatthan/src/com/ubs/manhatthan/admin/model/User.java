package com.ubs.manhatthan.admin.model;

import java.io.Serializable;
import java.util.List;

import com.ubs.manhatthan.common.enuns.SecurityActionEnum;
import com.ubs.manhatthan.manager.logger.ApplicationLogger;

public class User implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 4965869943488668869L;
	private String login;
	private String password;
	private String profile;
	private String sessionId;
	private long requestId;
	private boolean logged;

	private List<SecurityActionEnum> securityActions; 
	
	public User() {
	}

	public User(String login, String profile, boolean logged) {
		super();

		this.login = login;
		this.profile = profile;
		this.logged = logged;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getProfile() {
		return profile;
	}

	public void setProfile(String profile) {
		this.profile = profile;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public long getRequestId() {
		return requestId;
	}

	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}

	public boolean isLogged() {
		return logged;
	}

	public void setLogged(boolean logged) {
		this.logged = logged;
	}

	public List<SecurityActionEnum> getSecurityActions() {
		return securityActions;
	}
	
	public boolean getCanViewCustomerInformation() {
		boolean userCanViewCustomers = false;
		
    	for (SecurityActionEnum securityAction: getSecurityActions()) {
    		userCanViewCustomers = securityAction.getCode().equals(SecurityActionEnum.VIEW_CUSTOMERS.getCode());
    		
    		if (userCanViewCustomers) break;
    	}    	
    	
    	return userCanViewCustomers;
	}
	
	public boolean getCanViewMarketWhatch() {
		boolean userCanViewMarketWhatch = false;
		
    	for (SecurityActionEnum securityAction: getSecurityActions()) {
    		userCanViewMarketWhatch = securityAction.getCode().equals(SecurityActionEnum.MARKETWHATCH_SELF_MANAGEMENT.getCode());
    		
    		if (userCanViewMarketWhatch) break;
    	}
    	
    	return userCanViewMarketWhatch;
	}

	public boolean getCanManagementMarketWhatch() {
		return getCanViewMarketWhatch();
	}

	public boolean getCanEditStrategy() {
		boolean userCanEditRecord = false;
		
    	for (SecurityActionEnum securityAction: getSecurityActions()) {
    		userCanEditRecord = securityAction.getCode().equals(SecurityActionEnum.MANAGER_SELF_MANAGEMENT.getCode()) ||
    				getCanEditAllStrategies();
    		
    		if (userCanEditRecord) break;
    	}
    	
    	return userCanEditRecord;
	}

	public boolean getCanEditAllStrategies() {
		boolean userCanEditAllRecords = false;
		
    	for (SecurityActionEnum securityAction: getSecurityActions()) {
    		userCanEditAllRecords = securityAction.getCode().equals(SecurityActionEnum.MANAGER_FULL_MANAGEMENT.getCode());
    		
    		if (userCanEditAllRecords) break;
    	}
    	
    	return userCanEditAllRecords;
	}

	public boolean getCanViewAllManagerRecords() {
		boolean userCanViewAllRecords = false;
		
    	for (SecurityActionEnum securityAction: getSecurityActions()) {
    		userCanViewAllRecords = securityAction.getCode().equals(SecurityActionEnum.MANAGER_FULL_VIEW.getCode()) ||
    				securityAction.getCode().equals(SecurityActionEnum.MANAGER_FULL_MANAGEMENT.getCode());
    		
    		if (userCanViewAllRecords) break;
    	}
    	
    	return userCanViewAllRecords;
	}
	
	public boolean getCanViewManagerRecords() {
		boolean userCanViewRecords = false;
		
    	for (SecurityActionEnum securityAction: getSecurityActions()) {
    		userCanViewRecords = securityAction.getCode().equals(SecurityActionEnum.MANAGER_SELF_MANAGEMENT.getCode()) ||
    				getCanViewAllManagerRecords();
    		
    		if (userCanViewRecords) break;
    	}
    	
    	return userCanViewRecords;
	}

	public boolean getCanPauseAllManagerRecords() {
		boolean userCanPauseRecords = false;
		
    	for (SecurityActionEnum securityAction: getSecurityActions()) {
    		userCanPauseRecords = securityAction.getCode().equals(SecurityActionEnum.MANAGER_FULL_MANAGEMENT.getCode());
    		
    		if (userCanPauseRecords) break;
    	}
    	
    	return userCanPauseRecords;
	}

	public boolean getCanPauseManagerRecords() {
		boolean userCanPauseRecords = false;
		
    	for (SecurityActionEnum securityAction: getSecurityActions()) {
    		userCanPauseRecords = securityAction.getCode().equals(SecurityActionEnum.MANAGER_SELF_MANAGEMENT.getCode()) ||
    				getCanPauseAllManagerRecords();
    		
    		if (userCanPauseRecords) break;
    	}
    	
    	return userCanPauseRecords;
	}

	public boolean getCanResumeAllManagerRecords() {
		boolean userCanResumeRecords = false;
		
    	for (SecurityActionEnum securityAction: getSecurityActions()) {
    		userCanResumeRecords = securityAction.getCode().equals(SecurityActionEnum.MANAGER_FULL_MANAGEMENT.getCode());
    		
    		if (userCanResumeRecords) break;
    	}
    	
    	return userCanResumeRecords;
	}

	public boolean getCanResumeManagerRecords() {
		boolean userCanResumeRecords = false;
		
    	for (SecurityActionEnum securityAction: getSecurityActions()) {
    		userCanResumeRecords = securityAction.getCode().equals(SecurityActionEnum.MANAGER_SELF_MANAGEMENT.getCode()) ||
    				getCanResumeAllManagerRecords();
    		
    		if (userCanResumeRecords) break;
    	}
    	
    	return userCanResumeRecords;
	}
	
	public boolean getCanCancelAllManagerRecords() {
		boolean userCanCancelRecords = false;
		
    	for (SecurityActionEnum securityAction: getSecurityActions()) {
    		userCanCancelRecords = securityAction.getCode().equals(SecurityActionEnum.MANAGER_FULL_MANAGEMENT.getCode());
    		
    		if (userCanCancelRecords) break;
    	}
    	
    	return userCanCancelRecords;
	}

	public boolean getCanCancelManagerRecords() {
		boolean userCanCancelRecords = false;
		
    	for (SecurityActionEnum securityAction: getSecurityActions()) {
    		userCanCancelRecords = securityAction.getCode().equals(SecurityActionEnum.MANAGER_SELF_MANAGEMENT.getCode()) ||
    				getCanCancelAllManagerRecords();
    		
    		if (userCanCancelRecords) break;
    	}
    	
    	return userCanCancelRecords;
	}

	public boolean getCanViewReports() {
		boolean userCanCancelRecords = false;
		
    	for (SecurityActionEnum securityAction: getSecurityActions()) {
    		userCanCancelRecords = securityAction.getCode().equals(SecurityActionEnum.MANAGER_FULL_VIEW.getCode());
    		
    		if (userCanCancelRecords) break;
    	}
    	
    	return userCanCancelRecords;
	}
	
	public boolean getCanViewAdminEngine() {
		boolean userPermission = false;
		
    	for (SecurityActionEnum securityAction: getSecurityActions()) {
    		userPermission = securityAction.getCode().equals(SecurityActionEnum.ADMIN_ENGINE_VIEW.getCode());
    		
    		if (userPermission) break;
    	}
    	
    	return userPermission;
	}

	public boolean getCanManagementAdminEngine() {
		boolean userPermission = false;
		
    	for (SecurityActionEnum securityAction: getSecurityActions()) {
    		userPermission = securityAction.getCode().equals(SecurityActionEnum.ADMIN_ENGINE_MANAGEMENT.getCode());
    		
    		if (userPermission) break;
    	}
    	
    	return userPermission;
	}
	
	public boolean getCanManagementAdminMarketWatch() {
		boolean userPermission = false;
		
    	for (SecurityActionEnum securityAction: getSecurityActions()) {
    		userPermission = securityAction.getCode().equals(SecurityActionEnum.ADMIN_UMDF_VIEW.getCode()) || securityAction.getCode().equals(SecurityActionEnum.ADMIN_TCP_RECOVERY_VIEW.getCode());
    		
    		if (userPermission) break;
    	}
    	
    	return userPermission;
	}

	public boolean getCanViewAdminUMDF() {
		boolean userPermission = false;
		
    	for (SecurityActionEnum securityAction: getSecurityActions()) {
    		userPermission = securityAction.getCode().equals(SecurityActionEnum.ADMIN_UMDF_VIEW.getCode());
    		
    		if (userPermission) break;
    	}
    	
    	return userPermission;
	}

	public boolean getCanManagementAdminUMDF() {
		boolean userPermission = false;
		
    	for (SecurityActionEnum securityAction: getSecurityActions()) {
    		userPermission = securityAction.getCode().equals(SecurityActionEnum.ADMIN_UMDF_MANAGEMENT.getCode());
    		
    		if (userPermission) break;
    	}
    	
    	return userPermission;
	}

	public boolean getCanViewAdminTCPRecovery() {
		boolean userPermission = false;
		
    	for (SecurityActionEnum securityAction: getSecurityActions()) {
    		userPermission = securityAction.getCode().equals(SecurityActionEnum.ADMIN_TCP_RECOVERY_VIEW.getCode());
    		
    		if (userPermission) break;
    	}
    	
    	return userPermission;
	}

	public boolean getCanManagementAdminTCPRecovery() {
		boolean userPermission = false;
		
    	for (SecurityActionEnum securityAction: getSecurityActions()) {
    		userPermission = securityAction.getCode().equals(SecurityActionEnum.ADMIN_TCP_RECOVERY_MANAGEMENT.getCode());
    		
    		if (userPermission) break;
    	}
    	
    	return userPermission;
	}

	public boolean getCanViewAdminOrderEntry() {
		boolean userPermission = false;
		
    	for (SecurityActionEnum securityAction: getSecurityActions()) {
    		userPermission = securityAction.getCode().equals(SecurityActionEnum.ADMIN_ORDER_ENTRY_VIEW.getCode());
    		
    		if (userPermission) break;
    	}
    	
    	return userPermission;
	}

	public boolean getCanManagementAdminOrderEntry() {
		boolean userPermission = false;
		
    	for (SecurityActionEnum securityAction: getSecurityActions()) {
    		userPermission = securityAction.getCode().equals(SecurityActionEnum.ADMIN_ORDER_ENTRY_MANAGEMENT.getCode());
    		
    		if (userPermission) break;
    	}
    	
    	return userPermission;
	}

	public boolean getCanViewAdminAccount() {
		boolean userPermission = false;
		
    	for (SecurityActionEnum securityAction: getSecurityActions()) {
    		userPermission = securityAction.getCode().equals(SecurityActionEnum.ADMIN_ACCOUNT_VIEW.getCode());
    		
    		if (userPermission) break;
    	}
    	
    	return userPermission;
	}

	public boolean getCanManagementAdminAccount() {
		boolean userPermission = false;
		
    	for (SecurityActionEnum securityAction: getSecurityActions()) {
    		userPermission = securityAction.getCode().equals(SecurityActionEnum.ADMIN_ACCOUNT_MANAGEMENT.getCode());
    		
    		if (userPermission) break;
    	}
    	
    	return userPermission;
	}
	
    public boolean getHasAccesToAdmin() {
        return (getCanViewAdminAccount() || getCanViewAdminEngine() || getCanViewAdminOrderEntry() ||
                     getCanViewAdminTCPRecovery() || getCanViewAdminUMDF() ||
                     getCanManagementAdminAccount() || getCanManagementAdminEngine() ||
                     getCanManagementAdminOrderEntry() || getCanManagementAdminTCPRecovery() ||
                     getCanManagementAdminUMDF());
    }
    
    public boolean getHasAccessToTrader() {
        return ( getCanViewCustomerInformation() || getCanViewMarketWhatch() || getCanViewAllManagerRecords());
    }


	public void setSecurityActions(List<SecurityActionEnum> securityActions) {
		this.securityActions = securityActions;
	}

	public void destroy() {

		ApplicationLogger.logInfo("======================================================================================");
		ApplicationLogger.logInfo("User Spring Destroy");
		ApplicationLogger.logInfo("======================================================================================");
	}

	@Override
	public String toString() {
		return "User [login=" + login + ", password=" + password + ", profile=" + profile + 
				 ", logged=" + logged + "]";
	}
}
