
package com.ubs.manhatthan.kerberos.methods;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.ubs.manhatthan.kerberos.ws.model.UserParameterDTO;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="GetUserParameterResult" type="{http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs}UserParameterDTO" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "getUserParameterResult"
})
@XmlRootElement(name = "GetUserParameterResponse")
public class GetUserParameterResponse {

    @XmlElementRef(name = "GetUserParameterResult", namespace = "http://tempuri.org/", type = JAXBElement.class, required = false)
    protected JAXBElement<UserParameterDTO> getUserParameterResult;

    /**
     * Gets the value of the getUserParameterResult property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link UserParameterDTO }{@code >}
     *     
     */
    public JAXBElement<UserParameterDTO> getGetUserParameterResult() {
        return getUserParameterResult;
    }

    /**
     * Sets the value of the getUserParameterResult property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link UserParameterDTO }{@code >}
     *     
     */
    public void setGetUserParameterResult(JAXBElement<UserParameterDTO> value) {
        this.getUserParameterResult = value;
    }

}
