
package com.ubs.manhatthan.kerberos.ws.model;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for MenuDTO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MenuDTO">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Assembly" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FormPath" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FunctionName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IconURL" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MenuID" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="OrderNumber" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="ParentMenuID" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="ProfileName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SystemName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Title" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Tooltip" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MenuDTO", propOrder = {
    "assembly",
    "formPath",
    "functionName",
    "iconURL",
    "menuID",
    "orderNumber",
    "parentMenuID",
    "profileName",
    "systemName",
    "title",
    "tooltip"
})
public class MenuDTO {

    @XmlElementRef(name = "Assembly", namespace = "http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", type = JAXBElement.class, required = false)
    protected JAXBElement<String> assembly;
    @XmlElementRef(name = "FormPath", namespace = "http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", type = JAXBElement.class, required = false)
    protected JAXBElement<String> formPath;
    @XmlElementRef(name = "FunctionName", namespace = "http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", type = JAXBElement.class, required = false)
    protected JAXBElement<String> functionName;
    @XmlElementRef(name = "IconURL", namespace = "http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", type = JAXBElement.class, required = false)
    protected JAXBElement<String> iconURL;
    @XmlElement(name = "MenuID")
    protected Integer menuID;
    @XmlElement(name = "OrderNumber")
    protected Integer orderNumber;
    @XmlElementRef(name = "ParentMenuID", namespace = "http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", type = JAXBElement.class, required = false)
    protected JAXBElement<Integer> parentMenuID;
    @XmlElementRef(name = "ProfileName", namespace = "http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", type = JAXBElement.class, required = false)
    protected JAXBElement<String> profileName;
    @XmlElementRef(name = "SystemName", namespace = "http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", type = JAXBElement.class, required = false)
    protected JAXBElement<String> systemName;
    @XmlElementRef(name = "Title", namespace = "http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", type = JAXBElement.class, required = false)
    protected JAXBElement<String> title;
    @XmlElementRef(name = "Tooltip", namespace = "http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", type = JAXBElement.class, required = false)
    protected JAXBElement<String> tooltip;

    /**
     * Gets the value of the assembly property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAssembly() {
        return assembly;
    }

    /**
     * Sets the value of the assembly property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAssembly(JAXBElement<String> value) {
        this.assembly = value;
    }

    /**
     * Gets the value of the formPath property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getFormPath() {
        return formPath;
    }

    /**
     * Sets the value of the formPath property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setFormPath(JAXBElement<String> value) {
        this.formPath = value;
    }

    /**
     * Gets the value of the functionName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getFunctionName() {
        return functionName;
    }

    /**
     * Sets the value of the functionName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setFunctionName(JAXBElement<String> value) {
        this.functionName = value;
    }

    /**
     * Gets the value of the iconURL property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getIconURL() {
        return iconURL;
    }

    /**
     * Sets the value of the iconURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setIconURL(JAXBElement<String> value) {
        this.iconURL = value;
    }

    /**
     * Gets the value of the menuID property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getMenuID() {
        return menuID;
    }

    /**
     * Sets the value of the menuID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setMenuID(Integer value) {
        this.menuID = value;
    }

    /**
     * Gets the value of the orderNumber property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getOrderNumber() {
        return orderNumber;
    }

    /**
     * Sets the value of the orderNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setOrderNumber(Integer value) {
        this.orderNumber = value;
    }

    /**
     * Gets the value of the parentMenuID property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public JAXBElement<Integer> getParentMenuID() {
        return parentMenuID;
    }

    /**
     * Sets the value of the parentMenuID property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public void setParentMenuID(JAXBElement<Integer> value) {
        this.parentMenuID = value;
    }

    /**
     * Gets the value of the profileName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getProfileName() {
        return profileName;
    }

    /**
     * Sets the value of the profileName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setProfileName(JAXBElement<String> value) {
        this.profileName = value;
    }

    /**
     * Gets the value of the systemName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSystemName() {
        return systemName;
    }

    /**
     * Sets the value of the systemName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSystemName(JAXBElement<String> value) {
        this.systemName = value;
    }

    /**
     * Gets the value of the title property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTitle() {
        return title;
    }

    /**
     * Sets the value of the title property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTitle(JAXBElement<String> value) {
        this.title = value;
    }

    /**
     * Gets the value of the tooltip property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTooltip() {
        return tooltip;
    }

    /**
     * Sets the value of the tooltip property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTooltip(JAXBElement<String> value) {
        this.tooltip = value;
    }

}
