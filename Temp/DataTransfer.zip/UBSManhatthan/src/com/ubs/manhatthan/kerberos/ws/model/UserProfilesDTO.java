
package com.ubs.manhatthan.kerberos.ws.model;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for UserProfilesDTO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="UserProfilesDTO">
 *   &lt;complexContent>
 *     &lt;extension base="{http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs}BaseDTO">
 *       &lt;sequence>
 *         &lt;element name="ProfilesDTO" type="{http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs}ArrayOfProfileDTO" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UserProfilesDTO", propOrder = {
    "profilesDTO"
})
public class UserProfilesDTO
    extends BaseDTO
{

    @XmlElementRef(name = "ProfilesDTO", namespace = "http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", type = JAXBElement.class, required = false)
    protected JAXBElement<ArrayOfProfileDTO> profilesDTO;

    /**
     * Gets the value of the profilesDTO property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfProfileDTO }{@code >}
     *     
     */
    public JAXBElement<ArrayOfProfileDTO> getProfilesDTO() {
        return profilesDTO;
    }

    /**
     * Sets the value of the profilesDTO property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfProfileDTO }{@code >}
     *     
     */
    public void setProfilesDTO(JAXBElement<ArrayOfProfileDTO> value) {
        this.profilesDTO = value;
    }

}
