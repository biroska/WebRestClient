package com.ubs.manhatthan.kerberos.test;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.xml.bind.JAXBElement;

import com.ubs.manhatthan.common.enuns.SecurityActionEnum;
import com.ubs.manhatthan.kerberos.methods.ISecurityGatewayService;
import com.ubs.manhatthan.kerberos.methods.SgServiceHttp_UAT;
import com.ubs.manhatthan.kerberos.ws.model.ArrayOfMenuDTO;
import com.ubs.manhatthan.kerberos.ws.model.ArrayOfProfileDTO;
import com.ubs.manhatthan.kerberos.ws.model.AuthenticatedUserDTO;
import com.ubs.manhatthan.kerberos.ws.model.MenuDTO;
import com.ubs.manhatthan.kerberos.ws.model.ProfileDTO;
import com.ubs.manhatthan.kerberos.ws.model.UserMenusDTO;
import com.ubs.manhatthan.kerberos.ws.model.UserProfilesDTO;

public class Main {

	public static void main(String[] args) {
			JPanel panel = new JPanel();
			JLabel labelLogin = new JLabel("Login:");
			JTextField login = new JTextField(10);
			JLabel labelPass = new JLabel("Password:");
			JPasswordField pass = new JPasswordField(10);
			panel.add(labelLogin);
			panel.add(login);
			panel.add(labelPass);
			panel.add(pass);
			JPanel panel2 = new JPanel();
			JTextArea jta = new JTextArea(30,35);
			jta.setEditable(false);
			JScrollPane scroll = new JScrollPane ( jta );
			panel2.add(scroll);
			String output = "";
			String[] options = new String[]{"OK", "Cancel"};
			
			int option = JOptionPane.showOptionDialog(null, panel, "Login Kerberos", JOptionPane.NO_OPTION, JOptionPane.PLAIN_MESSAGE, null, options, options[0]);
			
			if(option == 0){
			    String loginVal = login.getText();
			    String password = new String(pass.getPassword());
				try{
//					SgServiceHttps_SIT sgHttp = new SgServiceHttps_SIT();
			
//					SgServiceHttp_SIT sgHttp = new SgServiceHttp_SIT();

					SgServiceHttp_UAT sgHttp = new SgServiceHttp_UAT();
					
					ISecurityGatewayService proxyHttp = sgHttp.getBasicHttpBindingISecurityGatewayService();

					List<SecurityActionEnum> securityActions = new ArrayList<SecurityActionEnum>();
					AuthenticatedUserDTO authenticatedUserDTO = proxyHttp.authenticateUser("testapp",loginVal, password);
					
					if (authenticatedUserDTO.isStatusSuccess()) {
						output = output +"User: "+loginVal+" : success authenticated by KERBEROS!\n\nWSDL: "+sgHttp.getWSDLDocumentLocation()+"\n\n";
						//PROFILES
						UserProfilesDTO profDto =proxyHttp.getUserProfiles("testapp", loginVal);
						JAXBElement<ArrayOfProfileDTO> 	arrayProfiles = profDto.getProfilesDTO();
						for(ProfileDTO dto : arrayProfiles.getValue().getProfileDTO()){
							output = output + "### Profile\nID: "+dto.getID()+"\nName: "+dto.getName().getValue()+"\n\n";
						}
						//FUNCTIONS
						UserMenusDTO userMenusDTO = proxyHttp.getUserMenus("testapp", loginVal);
						JAXBElement<ArrayOfMenuDTO> arrayMenu =  userMenusDTO.getMenusDTO();
						for(MenuDTO dto : arrayMenu.getValue().getMenuDTO()){
							output = output +"### Function\nSystemID: "+dto.getSystemName().getValue()+"\n"
									+ "Profile: "+dto.getProfileName().getValue()+"\n"
									+ "Name: " + dto.getFunctionName().getValue()+"\n"
									+ "MenuID: "+dto.getMenuID().toString()+"\n\n";
							for(SecurityActionEnum enm : SecurityActionEnum.values()){
								if(enm.getDescription().equals(dto.getFunctionName().getValue())){
									securityActions.add(enm);
									break;
								}
							}
						}
					}else{
						output = output +"Invalid Credentials";
					}
					jta.setText(output);
					JOptionPane.showOptionDialog(null, panel2, "output", JOptionPane.NO_OPTION, JOptionPane.PLAIN_MESSAGE, null, options, options[1]);
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		}
}
