package com.ubs.manhatthan.kerberos.test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.bind.JAXBElement;

import com.ubs.manhatthan.common.enuns.SecurityActionEnum;
import com.ubs.manhatthan.kerberos.methods.ISecurityGatewayService;
import com.ubs.manhatthan.kerberos.methods.SgServiceHttp_SIT;
import com.ubs.manhatthan.kerberos.ws.model.ArrayOfMenuDTO;
import com.ubs.manhatthan.kerberos.ws.model.ArrayOfProfileDTO;
import com.ubs.manhatthan.kerberos.ws.model.AuthenticatedUserDTO;
import com.ubs.manhatthan.kerberos.ws.model.MenuDTO;
import com.ubs.manhatthan.kerberos.ws.model.ProfileDTO;
import com.ubs.manhatthan.kerberos.ws.model.UserMenusDTO;
import com.ubs.manhatthan.kerberos.ws.model.UserProfilesDTO;

public class MainLoop {
	public static void main(String[] args) throws IOException {
		String output = "";
		
		String login = "";
		String pass = "";
		
		SgServiceHttp_SIT sgHttp = new SgServiceHttp_SIT();

//		SgServiceHttp_UAT sgHttp = new SgServiceHttp_UAT();
		
		ISecurityGatewayService proxyHttp = sgHttp.getBasicHttpBindingISecurityGatewayService();

		while(true){
		List<SecurityActionEnum> securityActions = new ArrayList<SecurityActionEnum>();
		AuthenticatedUserDTO authenticatedUserDTO = proxyHttp.authenticateUser("testapp",login,pass);
			if (authenticatedUserDTO.isStatusSuccess()) {
				output = output +new Date()+" User: "+login+" : success authenticated by KERBEROS!\n\nWSDL: "+sgHttp.getWSDLDocumentLocation()+"\n\n";
				//PROFILES
				UserProfilesDTO profDto =proxyHttp.getUserProfiles("testapp", login);
				JAXBElement<ArrayOfProfileDTO> 	arrayProfiles = profDto.getProfilesDTO();
				for(ProfileDTO dto : arrayProfiles.getValue().getProfileDTO()){
					output = output + "### Profile\nID: "+dto.getID()+"\nName: "+dto.getName().getValue()+"\n\n";
				}
				//FUNCTIONS
				UserMenusDTO userMenusDTO = proxyHttp.getUserMenus("testapp", login);
				JAXBElement<ArrayOfMenuDTO> arrayMenu =  userMenusDTO.getMenusDTO();
				for(MenuDTO dto : arrayMenu.getValue().getMenuDTO()){
					output = output +"### Function\nSystemID: "+dto.getSystemName().getValue()+"\n"
							+ "Profile: "+dto.getProfileName().getValue()+"\n"
							+ "Name: " + dto.getFunctionName().getValue()+"\n"
							+ "MenuID: "+dto.getMenuID().toString()+"\n\n";
					for(SecurityActionEnum enm : SecurityActionEnum.values()){
						if(enm.getDescription().equals(dto.getFunctionName().getValue())){
							securityActions.add(enm);
							break;
						}
					}
				}
			}else{
				output = output +"Invalid Credentials";
			}
			System.out.println(output);
			output ="";
		}
	}
}
