
package com.ubs.manhatthan.kerberos.ws.model;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for UserMenusProfilesDTO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="UserMenusProfilesDTO">
 *   &lt;complexContent>
 *     &lt;extension base="{http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs}BaseDTO">
 *       &lt;sequence>
 *         &lt;element name="UserMenusDTO" type="{http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs}UserMenusDTO" minOccurs="0"/>
 *         &lt;element name="UserProfilesDTO" type="{http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs}UserProfilesDTO" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UserMenusProfilesDTO", propOrder = {
    "userMenusDTO",
    "userProfilesDTO"
})
public class UserMenusProfilesDTO
    extends BaseDTO
{

    @XmlElementRef(name = "UserMenusDTO", namespace = "http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", type = JAXBElement.class, required = false)
    protected JAXBElement<UserMenusDTO> userMenusDTO;
    @XmlElementRef(name = "UserProfilesDTO", namespace = "http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", type = JAXBElement.class, required = false)
    protected JAXBElement<UserProfilesDTO> userProfilesDTO;

    /**
     * Gets the value of the userMenusDTO property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link UserMenusDTO }{@code >}
     *     
     */
    public JAXBElement<UserMenusDTO> getUserMenusDTO() {
        return userMenusDTO;
    }

    /**
     * Sets the value of the userMenusDTO property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link UserMenusDTO }{@code >}
     *     
     */
    public void setUserMenusDTO(JAXBElement<UserMenusDTO> value) {
        this.userMenusDTO = value;
    }

    /**
     * Gets the value of the userProfilesDTO property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link UserProfilesDTO }{@code >}
     *     
     */
    public JAXBElement<UserProfilesDTO> getUserProfilesDTO() {
        return userProfilesDTO;
    }

    /**
     * Sets the value of the userProfilesDTO property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link UserProfilesDTO }{@code >}
     *     
     */
    public void setUserProfilesDTO(JAXBElement<UserProfilesDTO> value) {
        this.userProfilesDTO = value;
    }

}
