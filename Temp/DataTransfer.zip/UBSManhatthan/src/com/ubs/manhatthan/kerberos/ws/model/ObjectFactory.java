
package com.ubs.manhatthan.kerberos.ws.model;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the org.datacontract.schemas._2004._07.ubs_securitygateway_domain package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ArrayOfMenuDTO_QNAME = new QName("http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", "ArrayOfMenuDTO");
    private final static QName _UserProfilesDTO_QNAME = new QName("http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", "UserProfilesDTO");
    private final static QName _ArrayOfProfileDTO_QNAME = new QName("http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", "ArrayOfProfileDTO");
    private final static QName _UserMenusProfilesDTO_QNAME = new QName("http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", "UserMenusProfilesDTO");
    private final static QName _UserParameterDTO_QNAME = new QName("http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", "UserParameterDTO");
    private final static QName _BaseDTO_QNAME = new QName("http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", "BaseDTO");
    private final static QName _UserMenusDTO_QNAME = new QName("http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", "UserMenusDTO");
    private final static QName _AuthenticatedUserDTO_QNAME = new QName("http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", "AuthenticatedUserDTO");
    private final static QName _ProfileDTO_QNAME = new QName("http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", "ProfileDTO");
    private final static QName _MenuDTO_QNAME = new QName("http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", "MenuDTO");
    private final static QName _MenuDTOTitle_QNAME = new QName("http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", "Title");
    private final static QName _MenuDTOFunctionName_QNAME = new QName("http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", "FunctionName");
    private final static QName _MenuDTOAssembly_QNAME = new QName("http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", "Assembly");
    private final static QName _MenuDTOProfileName_QNAME = new QName("http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", "ProfileName");
    private final static QName _MenuDTOSystemName_QNAME = new QName("http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", "SystemName");
    private final static QName _MenuDTOTooltip_QNAME = new QName("http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", "Tooltip");
    private final static QName _MenuDTOParentMenuID_QNAME = new QName("http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", "ParentMenuID");
    private final static QName _MenuDTOIconURL_QNAME = new QName("http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", "IconURL");
    private final static QName _MenuDTOFormPath_QNAME = new QName("http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", "FormPath");
    private final static QName _UserParameterDTOParameterName_QNAME = new QName("http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", "ParameterName");
    private final static QName _UserParameterDTOParameterValue_QNAME = new QName("http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", "ParameterValue");
    private final static QName _UserParameterDTOLogin_QNAME = new QName("http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", "Login");
    private final static QName _ProfileDTOName_QNAME = new QName("http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", "Name");
    private final static QName _AuthenticatedUserDTOUsername_QNAME = new QName("http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", "Username");
    private final static QName _UserProfilesDTOProfilesDTO_QNAME = new QName("http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", "ProfilesDTO");
    private final static QName _UserMenusDTOMenusDTO_QNAME = new QName("http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", "MenusDTO");
    private final static QName _BaseDTOStatusReason_QNAME = new QName("http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", "StatusReason");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: org.datacontract.schemas._2004._07.ubs_securitygateway_domain
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link AuthenticatedUserDTO }
     * 
     */
    public AuthenticatedUserDTO createAuthenticatedUserDTO() {
        return new AuthenticatedUserDTO();
    }

    /**
     * Create an instance of {@link UserParameterDTO }
     * 
     */
    public UserParameterDTO createUserParameterDTO() {
        return new UserParameterDTO();
    }

    /**
     * Create an instance of {@link UserProfilesDTO }
     * 
     */
    public UserProfilesDTO createUserProfilesDTO() {
        return new UserProfilesDTO();
    }

    /**
     * Create an instance of {@link UserMenusDTO }
     * 
     */
    public UserMenusDTO createUserMenusDTO() {
        return new UserMenusDTO();
    }

    /**
     * Create an instance of {@link UserMenusProfilesDTO }
     * 
     */
    public UserMenusProfilesDTO createUserMenusProfilesDTO() {
        return new UserMenusProfilesDTO();
    }

    /**
     * Create an instance of {@link ProfileDTO }
     * 
     */
    public ProfileDTO createProfileDTO() {
        return new ProfileDTO();
    }

    /**
     * Create an instance of {@link MenuDTO }
     * 
     */
    public MenuDTO createMenuDTO() {
        return new MenuDTO();
    }

    /**
     * Create an instance of {@link BaseDTO }
     * 
     */
    public BaseDTO createBaseDTO() {
        return new BaseDTO();
    }

    /**
     * Create an instance of {@link ArrayOfMenuDTO }
     * 
     */
    public ArrayOfMenuDTO createArrayOfMenuDTO() {
        return new ArrayOfMenuDTO();
    }

    /**
     * Create an instance of {@link ArrayOfProfileDTO }
     * 
     */
    public ArrayOfProfileDTO createArrayOfProfileDTO() {
        return new ArrayOfProfileDTO();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfMenuDTO }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", name = "ArrayOfMenuDTO")
    public JAXBElement<ArrayOfMenuDTO> createArrayOfMenuDTO(ArrayOfMenuDTO value) {
        return new JAXBElement<ArrayOfMenuDTO>(_ArrayOfMenuDTO_QNAME, ArrayOfMenuDTO.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UserProfilesDTO }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", name = "UserProfilesDTO")
    public JAXBElement<UserProfilesDTO> createUserProfilesDTO(UserProfilesDTO value) {
        return new JAXBElement<UserProfilesDTO>(_UserProfilesDTO_QNAME, UserProfilesDTO.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfProfileDTO }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", name = "ArrayOfProfileDTO")
    public JAXBElement<ArrayOfProfileDTO> createArrayOfProfileDTO(ArrayOfProfileDTO value) {
        return new JAXBElement<ArrayOfProfileDTO>(_ArrayOfProfileDTO_QNAME, ArrayOfProfileDTO.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UserMenusProfilesDTO }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", name = "UserMenusProfilesDTO")
    public JAXBElement<UserMenusProfilesDTO> createUserMenusProfilesDTO(UserMenusProfilesDTO value) {
        return new JAXBElement<UserMenusProfilesDTO>(_UserMenusProfilesDTO_QNAME, UserMenusProfilesDTO.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UserParameterDTO }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", name = "UserParameterDTO")
    public JAXBElement<UserParameterDTO> createUserParameterDTO(UserParameterDTO value) {
        return new JAXBElement<UserParameterDTO>(_UserParameterDTO_QNAME, UserParameterDTO.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BaseDTO }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", name = "BaseDTO")
    public JAXBElement<BaseDTO> createBaseDTO(BaseDTO value) {
        return new JAXBElement<BaseDTO>(_BaseDTO_QNAME, BaseDTO.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UserMenusDTO }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", name = "UserMenusDTO")
    public JAXBElement<UserMenusDTO> createUserMenusDTO(UserMenusDTO value) {
        return new JAXBElement<UserMenusDTO>(_UserMenusDTO_QNAME, UserMenusDTO.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AuthenticatedUserDTO }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", name = "AuthenticatedUserDTO")
    public JAXBElement<AuthenticatedUserDTO> createAuthenticatedUserDTO(AuthenticatedUserDTO value) {
        return new JAXBElement<AuthenticatedUserDTO>(_AuthenticatedUserDTO_QNAME, AuthenticatedUserDTO.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ProfileDTO }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", name = "ProfileDTO")
    public JAXBElement<ProfileDTO> createProfileDTO(ProfileDTO value) {
        return new JAXBElement<ProfileDTO>(_ProfileDTO_QNAME, ProfileDTO.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MenuDTO }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", name = "MenuDTO")
    public JAXBElement<MenuDTO> createMenuDTO(MenuDTO value) {
        return new JAXBElement<MenuDTO>(_MenuDTO_QNAME, MenuDTO.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", name = "Title", scope = MenuDTO.class)
    public JAXBElement<String> createMenuDTOTitle(String value) {
        return new JAXBElement<String>(_MenuDTOTitle_QNAME, String.class, MenuDTO.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", name = "FunctionName", scope = MenuDTO.class)
    public JAXBElement<String> createMenuDTOFunctionName(String value) {
        return new JAXBElement<String>(_MenuDTOFunctionName_QNAME, String.class, MenuDTO.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", name = "Assembly", scope = MenuDTO.class)
    public JAXBElement<String> createMenuDTOAssembly(String value) {
        return new JAXBElement<String>(_MenuDTOAssembly_QNAME, String.class, MenuDTO.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", name = "ProfileName", scope = MenuDTO.class)
    public JAXBElement<String> createMenuDTOProfileName(String value) {
        return new JAXBElement<String>(_MenuDTOProfileName_QNAME, String.class, MenuDTO.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", name = "SystemName", scope = MenuDTO.class)
    public JAXBElement<String> createMenuDTOSystemName(String value) {
        return new JAXBElement<String>(_MenuDTOSystemName_QNAME, String.class, MenuDTO.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", name = "Tooltip", scope = MenuDTO.class)
    public JAXBElement<String> createMenuDTOTooltip(String value) {
        return new JAXBElement<String>(_MenuDTOTooltip_QNAME, String.class, MenuDTO.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", name = "ParentMenuID", scope = MenuDTO.class)
    public JAXBElement<Integer> createMenuDTOParentMenuID(Integer value) {
        return new JAXBElement<Integer>(_MenuDTOParentMenuID_QNAME, Integer.class, MenuDTO.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", name = "IconURL", scope = MenuDTO.class)
    public JAXBElement<String> createMenuDTOIconURL(String value) {
        return new JAXBElement<String>(_MenuDTOIconURL_QNAME, String.class, MenuDTO.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", name = "FormPath", scope = MenuDTO.class)
    public JAXBElement<String> createMenuDTOFormPath(String value) {
        return new JAXBElement<String>(_MenuDTOFormPath_QNAME, String.class, MenuDTO.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", name = "ParameterName", scope = UserParameterDTO.class)
    public JAXBElement<String> createUserParameterDTOParameterName(String value) {
        return new JAXBElement<String>(_UserParameterDTOParameterName_QNAME, String.class, UserParameterDTO.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", name = "ParameterValue", scope = UserParameterDTO.class)
    public JAXBElement<String> createUserParameterDTOParameterValue(String value) {
        return new JAXBElement<String>(_UserParameterDTOParameterValue_QNAME, String.class, UserParameterDTO.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", name = "Login", scope = UserParameterDTO.class)
    public JAXBElement<String> createUserParameterDTOLogin(String value) {
        return new JAXBElement<String>(_UserParameterDTOLogin_QNAME, String.class, UserParameterDTO.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", name = "Name", scope = ProfileDTO.class)
    public JAXBElement<String> createProfileDTOName(String value) {
        return new JAXBElement<String>(_ProfileDTOName_QNAME, String.class, ProfileDTO.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", name = "Username", scope = AuthenticatedUserDTO.class)
    public JAXBElement<String> createAuthenticatedUserDTOUsername(String value) {
        return new JAXBElement<String>(_AuthenticatedUserDTOUsername_QNAME, String.class, AuthenticatedUserDTO.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfProfileDTO }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", name = "ProfilesDTO", scope = UserProfilesDTO.class)
    public JAXBElement<ArrayOfProfileDTO> createUserProfilesDTOProfilesDTO(ArrayOfProfileDTO value) {
        return new JAXBElement<ArrayOfProfileDTO>(_UserProfilesDTOProfilesDTO_QNAME, ArrayOfProfileDTO.class, UserProfilesDTO.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfMenuDTO }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", name = "MenusDTO", scope = UserMenusDTO.class)
    public JAXBElement<ArrayOfMenuDTO> createUserMenusDTOMenusDTO(ArrayOfMenuDTO value) {
        return new JAXBElement<ArrayOfMenuDTO>(_UserMenusDTOMenusDTO_QNAME, ArrayOfMenuDTO.class, UserMenusDTO.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", name = "StatusReason", scope = BaseDTO.class)
    public JAXBElement<String> createBaseDTOStatusReason(String value) {
        return new JAXBElement<String>(_BaseDTOStatusReason_QNAME, String.class, BaseDTO.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UserProfilesDTO }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", name = "UserProfilesDTO", scope = UserMenusProfilesDTO.class)
    public JAXBElement<UserProfilesDTO> createUserMenusProfilesDTOUserProfilesDTO(UserProfilesDTO value) {
        return new JAXBElement<UserProfilesDTO>(_UserProfilesDTO_QNAME, UserProfilesDTO.class, UserMenusProfilesDTO.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UserMenusDTO }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", name = "UserMenusDTO", scope = UserMenusProfilesDTO.class)
    public JAXBElement<UserMenusDTO> createUserMenusProfilesDTOUserMenusDTO(UserMenusDTO value) {
        return new JAXBElement<UserMenusDTO>(_UserMenusDTO_QNAME, UserMenusDTO.class, UserMenusProfilesDTO.class, value);
    }

}
