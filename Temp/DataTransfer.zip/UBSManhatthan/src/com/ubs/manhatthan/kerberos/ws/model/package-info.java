@javax.xml.bind.annotation.XmlSchema(namespace = "http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.ubs.manhatthan.kerberos.ws.model;
