
package com.ubs.manhatthan.kerberos.methods;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;

import com.ubs.manhatthan.kerberos.ws.model.AuthenticatedUserDTO;
import com.ubs.manhatthan.kerberos.ws.model.UserMenusDTO;
import com.ubs.manhatthan.kerberos.ws.model.UserMenusProfilesDTO;
import com.ubs.manhatthan.kerberos.ws.model.UserParameterDTO;
import com.ubs.manhatthan.kerberos.ws.model.UserProfilesDTO;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the org.tempuri package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _GetUserProfilesResponseGetUserProfilesResult_QNAME = new QName("http://tempuri.org/", "GetUserProfilesResult");
    private final static QName _GetUserMenusAppKey_QNAME = new QName("http://tempuri.org/", "appKey");
    private final static QName _GetUserMenusUserName_QNAME = new QName("http://tempuri.org/", "userName");
    private final static QName _AuthenticateUserResponseAuthenticateUserResult_QNAME = new QName("http://tempuri.org/", "AuthenticateUserResult");
    private final static QName _GetUserMenusResponseGetUserMenusResult_QNAME = new QName("http://tempuri.org/", "GetUserMenusResult");
    private final static QName _AuthenticateUserPassword_QNAME = new QName("http://tempuri.org/", "password");
    private final static QName _GetUserParameterResponseGetUserParameterResult_QNAME = new QName("http://tempuri.org/", "GetUserParameterResult");
    private final static QName _GetUserMenusAndProfilesResponseGetUserMenusAndProfilesResult_QNAME = new QName("http://tempuri.org/", "GetUserMenusAndProfilesResult");
    private final static QName _GetUserParameterParameterName_QNAME = new QName("http://tempuri.org/", "parameterName");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: org.tempuri
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetUserProfiles }
     * 
     */
    public GetUserProfiles createGetUserProfiles() {
        return new GetUserProfiles();
    }

    /**
     * Create an instance of {@link GetUserParameter }
     * 
     */
    public GetUserParameter createGetUserParameter() {
        return new GetUserParameter();
    }

    /**
     * Create an instance of {@link AuthenticateUser }
     * 
     */
    public AuthenticateUser createAuthenticateUser() {
        return new AuthenticateUser();
    }

    /**
     * Create an instance of {@link AuthenticateUserResponse }
     * 
     */
    public AuthenticateUserResponse createAuthenticateUserResponse() {
        return new AuthenticateUserResponse();
    }

    /**
     * Create an instance of {@link GetUserParameterResponse }
     * 
     */
    public GetUserParameterResponse createGetUserParameterResponse() {
        return new GetUserParameterResponse();
    }

    /**
     * Create an instance of {@link GetUserProfilesResponse }
     * 
     */
    public GetUserProfilesResponse createGetUserProfilesResponse() {
        return new GetUserProfilesResponse();
    }

    /**
     * Create an instance of {@link GetUserMenusResponse }
     * 
     */
    public GetUserMenusResponse createGetUserMenusResponse() {
        return new GetUserMenusResponse();
    }

    /**
     * Create an instance of {@link GetUserMenus }
     * 
     */
    public GetUserMenus createGetUserMenus() {
        return new GetUserMenus();
    }

    /**
     * Create an instance of {@link GetUserMenusAndProfiles }
     * 
     */
    public GetUserMenusAndProfiles createGetUserMenusAndProfiles() {
        return new GetUserMenusAndProfiles();
    }

    /**
     * Create an instance of {@link GetUserMenusAndProfilesResponse }
     * 
     */
    public GetUserMenusAndProfilesResponse createGetUserMenusAndProfilesResponse() {
        return new GetUserMenusAndProfilesResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UserProfilesDTO }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://tempuri.org/", name = "GetUserProfilesResult", scope = GetUserProfilesResponse.class)
    public JAXBElement<UserProfilesDTO> createGetUserProfilesResponseGetUserProfilesResult(UserProfilesDTO value) {
        return new JAXBElement<UserProfilesDTO>(_GetUserProfilesResponseGetUserProfilesResult_QNAME, UserProfilesDTO.class, GetUserProfilesResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://tempuri.org/", name = "appKey", scope = GetUserMenus.class)
    public JAXBElement<String> createGetUserMenusAppKey(String value) {
        return new JAXBElement<String>(_GetUserMenusAppKey_QNAME, String.class, GetUserMenus.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://tempuri.org/", name = "userName", scope = GetUserMenus.class)
    public JAXBElement<String> createGetUserMenusUserName(String value) {
        return new JAXBElement<String>(_GetUserMenusUserName_QNAME, String.class, GetUserMenus.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AuthenticatedUserDTO }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://tempuri.org/", name = "AuthenticateUserResult", scope = AuthenticateUserResponse.class)
    public JAXBElement<AuthenticatedUserDTO> createAuthenticateUserResponseAuthenticateUserResult(AuthenticatedUserDTO value) {
        return new JAXBElement<AuthenticatedUserDTO>(_AuthenticateUserResponseAuthenticateUserResult_QNAME, AuthenticatedUserDTO.class, AuthenticateUserResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://tempuri.org/", name = "appKey", scope = GetUserMenusAndProfiles.class)
    public JAXBElement<String> createGetUserMenusAndProfilesAppKey(String value) {
        return new JAXBElement<String>(_GetUserMenusAppKey_QNAME, String.class, GetUserMenusAndProfiles.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://tempuri.org/", name = "userName", scope = GetUserMenusAndProfiles.class)
    public JAXBElement<String> createGetUserMenusAndProfilesUserName(String value) {
        return new JAXBElement<String>(_GetUserMenusUserName_QNAME, String.class, GetUserMenusAndProfiles.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UserMenusDTO }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://tempuri.org/", name = "GetUserMenusResult", scope = GetUserMenusResponse.class)
    public JAXBElement<UserMenusDTO> createGetUserMenusResponseGetUserMenusResult(UserMenusDTO value) {
        return new JAXBElement<UserMenusDTO>(_GetUserMenusResponseGetUserMenusResult_QNAME, UserMenusDTO.class, GetUserMenusResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://tempuri.org/", name = "appKey", scope = AuthenticateUser.class)
    public JAXBElement<String> createAuthenticateUserAppKey(String value) {
        return new JAXBElement<String>(_GetUserMenusAppKey_QNAME, String.class, AuthenticateUser.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://tempuri.org/", name = "password", scope = AuthenticateUser.class)
    public JAXBElement<String> createAuthenticateUserPassword(String value) {
        return new JAXBElement<String>(_AuthenticateUserPassword_QNAME, String.class, AuthenticateUser.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://tempuri.org/", name = "userName", scope = AuthenticateUser.class)
    public JAXBElement<String> createAuthenticateUserUserName(String value) {
        return new JAXBElement<String>(_GetUserMenusUserName_QNAME, String.class, AuthenticateUser.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://tempuri.org/", name = "appKey", scope = GetUserProfiles.class)
    public JAXBElement<String> createGetUserProfilesAppKey(String value) {
        return new JAXBElement<String>(_GetUserMenusAppKey_QNAME, String.class, GetUserProfiles.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://tempuri.org/", name = "userName", scope = GetUserProfiles.class)
    public JAXBElement<String> createGetUserProfilesUserName(String value) {
        return new JAXBElement<String>(_GetUserMenusUserName_QNAME, String.class, GetUserProfiles.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UserParameterDTO }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://tempuri.org/", name = "GetUserParameterResult", scope = GetUserParameterResponse.class)
    public JAXBElement<UserParameterDTO> createGetUserParameterResponseGetUserParameterResult(UserParameterDTO value) {
        return new JAXBElement<UserParameterDTO>(_GetUserParameterResponseGetUserParameterResult_QNAME, UserParameterDTO.class, GetUserParameterResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UserMenusProfilesDTO }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://tempuri.org/", name = "GetUserMenusAndProfilesResult", scope = GetUserMenusAndProfilesResponse.class)
    public JAXBElement<UserMenusProfilesDTO> createGetUserMenusAndProfilesResponseGetUserMenusAndProfilesResult(UserMenusProfilesDTO value) {
        return new JAXBElement<UserMenusProfilesDTO>(_GetUserMenusAndProfilesResponseGetUserMenusAndProfilesResult_QNAME, UserMenusProfilesDTO.class, GetUserMenusAndProfilesResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://tempuri.org/", name = "appKey", scope = GetUserParameter.class)
    public JAXBElement<String> createGetUserParameterAppKey(String value) {
        return new JAXBElement<String>(_GetUserMenusAppKey_QNAME, String.class, GetUserParameter.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://tempuri.org/", name = "parameterName", scope = GetUserParameter.class)
    public JAXBElement<String> createGetUserParameterParameterName(String value) {
        return new JAXBElement<String>(_GetUserParameterParameterName_QNAME, String.class, GetUserParameter.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://tempuri.org/", name = "userName", scope = GetUserParameter.class)
    public JAXBElement<String> createGetUserParameterUserName(String value) {
        return new JAXBElement<String>(_GetUserMenusUserName_QNAME, String.class, GetUserParameter.class, value);
    }

}
