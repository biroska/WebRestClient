
package com.ubs.manhatthan.kerberos.ws.model;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for BaseDTO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BaseDTO">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CalledAt" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="StatusCode" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="StatusReason" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="StatusSuccess" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BaseDTO", propOrder = {
    "calledAt",
    "statusCode",
    "statusReason",
    "statusSuccess"
})
@XmlSeeAlso({
    AuthenticatedUserDTO.class,
    UserParameterDTO.class,
    UserProfilesDTO.class,
    UserMenusDTO.class,
    UserMenusProfilesDTO.class
})
public class BaseDTO {

    @XmlElement(name = "CalledAt")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar calledAt;
    @XmlElement(name = "StatusCode")
    protected Integer statusCode;
    @XmlElementRef(name = "StatusReason", namespace = "http://schemas.datacontract.org/2004/07/UBS.SecurityGateway.Domain.DTOs", type = JAXBElement.class, required = false)
    protected JAXBElement<String> statusReason;
    @XmlElement(name = "StatusSuccess")
    protected Boolean statusSuccess;

    /**
     * Gets the value of the calledAt property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCalledAt() {
        return calledAt;
    }

    /**
     * Sets the value of the calledAt property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCalledAt(XMLGregorianCalendar value) {
        this.calledAt = value;
    }

    /**
     * Gets the value of the statusCode property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getStatusCode() {
        return statusCode;
    }

    /**
     * Sets the value of the statusCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setStatusCode(Integer value) {
        this.statusCode = value;
    }

    /**
     * Gets the value of the statusReason property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getStatusReason() {
        return statusReason;
    }

    /**
     * Sets the value of the statusReason property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setStatusReason(JAXBElement<String> value) {
        this.statusReason = value;
    }

    /**
     * Gets the value of the statusSuccess property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isStatusSuccess() {
        return statusSuccess;
    }

    /**
     * Sets the value of the statusSuccess property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setStatusSuccess(Boolean value) {
        this.statusSuccess = value;
    }

}
