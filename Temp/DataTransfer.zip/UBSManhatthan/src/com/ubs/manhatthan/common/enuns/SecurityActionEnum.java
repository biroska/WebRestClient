package com.ubs.manhatthan.common.enuns;

public enum SecurityActionEnum {
	
	VIEW_CUSTOMERS (0, "Manhattan.Trading.CID.View"),
	MARKETWHATCH_SELF_MANAGEMENT (1,"Manhattan.Trading.MarketWatch.SelfManagement"),
	MANAGER_SELF_MANAGEMENT (2,"Manhattan.Trading.StrategyManager.SelfManagement"),
	MANAGER_FULL_VIEW (3,"Manhattan.Trading.StrategyManager.FullView"),
	MANAGER_FULL_MANAGEMENT (4,"Manhattan.Trading.StrategyManager.FullManagement"),
	ADMIN_ENGINE_VIEW (5, "Manhattan.Admin.Engine.View"),
	ADMIN_ENGINE_MANAGEMENT ( 6, "Manhattan.Admin.Engine.Manage"),
	ADMIN_UMDF_VIEW (7, "Manhattan.Admin.MarketData.UMDF.View"),
	ADMIN_UMDF_MANAGEMENT (8, "Manhattan.Admin.MarketData.UMDF.Manage"),
	ADMIN_TCP_RECOVERY_VIEW (9, "Manhattan.Admin.MarketData.TCPRecovery.View"),
	ADMIN_TCP_RECOVERY_MANAGEMENT (10, "Manhattan.Admin.MarketData.TCPRecovery.Manage"),
	ADMIN_ORDER_ENTRY_VIEW (11, "Manhattan.Admin.OrderEntry.View"),
	ADMIN_ORDER_ENTRY_MANAGEMENT (12, "Manhattan.Admin.OrderEntry.Manage"),
	ADMIN_ACCOUNT_VIEW (13, "Manhattan.Admin.Account.View"),
	ADMIN_ACCOUNT_MANAGEMENT (14, "Manhattan.Admin.Account.Manage");
	
    SecurityActionEnum(Integer code) {
        this.code = code;
    }

    SecurityActionEnum(Integer code, String description) {
		this.code = code;
		this.description = description;
	}

	private Integer code;
    
    private String description;

    public Integer getCode( ) {
    	return code;
    }

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
    public static SecurityActionEnum fromValue( Integer value ){
    	
		for (SecurityActionEnum item : SecurityActionEnum.values() ) {
			if ( item.getCode().equals( value ) ){
				return item;
			}
		}
		return null;
    }	
}