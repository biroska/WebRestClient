package com.ubs.manhatthan.service;

import java.util.List;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.persistence.entities.StrategyByTab;
import com.ubs.manhatthan.model.Market;
import com.ubs.manhatthan.model.MarketWhatchTab;
import com.ubs.manhatthan.model.StrategyType;

public interface MarketWatchFacade {

	public List<MarketWhatchTab> getWatchTabMarkets(String userLogin) throws DAOExceptionManhattan;

	public void addInstrument(MarketWhatchTab marketWhatchTab);

	public List<StrategyType> getStrategyTypesDomain() throws DAOExceptionManhattan;

	public StrategyType convertEntityStrategyTypeToVO(com.ubs.manhatthan.manager.persistence.entities.StrategyType strategyType);

	public StrategyType getStrategyVOById(String id) throws DAOExceptionManhattan;

	public StrategyByTab populateStrategyByTab(StrategyType vo, MarketWhatchTab marketWhatchTab) throws DAOExceptionManhattan;

	public Market populateMarketVO(StrategyType strategyType);

	public void deleteTabMarketWatch(Long id) throws DAOExceptionManhattan;
	
	public void deleteMarketWatchList(List<MarketWhatchTab> marketWhatchTabsUnsave) throws DAOExceptionManhattan;

	public void saveStrategiesByTabMarket(List<MarketWhatchTab> marketWhatchTabsUnsave, List<StrategyByTab> strategyByTabsUnsave) throws DAOExceptionManhattan;

	public List<MarketWhatchTab> saveViewTabsMarket(List<MarketWhatchTab> marketWhatchTabsUnsave) throws DAOExceptionManhattan;

	public StrategyByTab getStrategyByTab(StrategyType strategyType, MarketWhatchTab marketWhatchTab) throws DAOExceptionManhattan;

	public void deleteMarketsByList(List<Market> markets) throws DAOExceptionManhattan;

	public void addSynthetic(MarketWhatchTab marketWhatchTab);
	
	public void saveSession(List<MarketWhatchTab> marketWhatchTabsUnSave, List<Market> marketByTabsToDelete, 
			List<MarketWhatchTab> marketWhatchTabs, List<StrategyByTab> strategyByTabsUnSave) throws DAOExceptionManhattan;

}
