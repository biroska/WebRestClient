package com.ubs.manhatthan.service;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.cache.CacheHelper;
import com.ubs.manhatthan.manager.facade.Facade;
import com.ubs.manhatthan.manager.persistence.entities.StrategyByTab;
import com.ubs.manhatthan.manager.persistence.entities.StrategyByTabLeg;
import com.ubs.manhatthan.manager.persistence.entities.TraderWatchTab;
import com.ubs.manhatthan.model.Market;
import com.ubs.manhatthan.model.MarketWhatchTab;
import com.ubs.manhatthan.model.StrategyType;
import com.ubs.manhatthan.model.StrategyTypeLeg;

@Service
@Scope("singleton")
@Transactional
public class MarketWatchFacadeImpl implements MarketWatchFacade, Serializable {

	private static final long serialVersionUID = -3731932450994430008L;

	@Autowired
	private Facade facade;

	@Override
	public List<MarketWhatchTab> getWatchTabMarkets(String userLogin) throws DAOExceptionManhattan {

		List<TraderWatchTab> traderWatchTabs = facade.getListTraderWatchsTabsByLogin(userLogin);

		List<MarketWhatchTab> marketWhatchTabs = new ArrayList<MarketWhatchTab>();

		for (TraderWatchTab traderWatchTab : traderWatchTabs) {
			MarketWhatchTab tab = new MarketWhatchTab();
			tab.setId(traderWatchTab.getId());
			tab.setDescription(traderWatchTab.getDescription());
			tab.setLogin(userLogin);
			tab.setSaved(true);

			List<StrategyByTab> list = facade.getListStrategyOrInstrumentByTab(traderWatchTab);
			tab.setMarkets(convertListStrategyByTabToMarket(list));

			marketWhatchTabs.add(tab);
		}

		return marketWhatchTabs;
	}

	public List<com.ubs.manhatthan.model.Market> convertListStrategyByTabToMarket(List<StrategyByTab> strategyByTabs) {
		List<com.ubs.manhatthan.model.Market> markets = new ArrayList<com.ubs.manhatthan.model.Market>();
		for (StrategyByTab strategyByTab : strategyByTabs) {
			if (null == strategyByTab.getStrategyType()) {
				Market market = new Market();
				market.setId(strategyByTab.getId());
				market.setStratagyTabId(strategyByTab.getId());
				market.setTabViewId(strategyByTab.getTab().getId());
				StrategyType strategyType = new StrategyType();
				strategyType.setStrategyTypeLegList(new ArrayList<StrategyTypeLeg>());
				strategyType.setId(strategyByTab.getStrategyType() == null ? null : strategyByTab.getStrategyType().getId());
				strategyType.setInstrument(strategyByTab.getInstrument());
				market.setStrategyType(strategyType);
				markets.add(market);
			} else {
				Market market = new Market();
				market.setStratagyTabId(strategyByTab.getId());
				market.setId(strategyByTab.getId());
				market.setTabViewId(strategyByTab.getTab().getId());
				StrategyType strategyType = new StrategyType();
				strategyType.setStrategyTypeLegList(new ArrayList<StrategyTypeLeg>());
				strategyType.setId(strategyByTab.getStrategyType().getId());
				strategyType.setInstrument(strategyByTab.getInstrument());
				strategyType.setDescription(strategyByTab.getStrategyType().getDescription());
				strategyType.setNumberOfLegs(strategyByTab.getStrategyType().getNumberOfLegs());
				strategyType.setStrategyCode(strategyByTab.getStrategyType().getStrategyCode());
				market.setStrategyType(strategyType);
				for (com.ubs.manhatthan.manager.persistence.entities.StrategyByTabLeg typeLeg : strategyByTab.getStrategyByTabLegs()) {
					StrategyTypeLeg st = new StrategyTypeLeg();
					st.setDefaultSide(typeLeg.getStrategyTypeLeg().getDefaultSide().getCode());
					st.setLegSeq(typeLeg.getStrategyTypeLeg().getLegSeq());
					st.setInstrument(typeLeg.getInstrument());
					strategyType.getStrategyTypeLegList().add(st);

				}
				market.setStrategyType(strategyType);
				markets.add(market);

			}

		}
		return markets;

	}

	@Override
	public StrategyByTab getStrategyByTab(StrategyType strategyType, MarketWhatchTab marketWhatchTab) throws DAOExceptionManhattan {
		StrategyByTab strategyByTab = populateStrategyByTab(strategyType, marketWhatchTab);
		return facade.getStrategyByTab(strategyByTab);
	}

	@Override
	public List<StrategyType> getStrategyTypesDomain() throws DAOExceptionManhattan {
		return CacheHelper.strategyTypeVOList;
	}

	@Override
	public void saveStrategiesByTabMarket(List<MarketWhatchTab> marketWhatchTabs, List<StrategyByTab> strategyByTabsUnsave) throws DAOExceptionManhattan {
		try {
			for (MarketWhatchTab marketWhatch : marketWhatchTabs) {
				for (StrategyByTab strategyByTab : strategyByTabsUnsave) {
					if ((marketWhatch.getTemporaryId()!=null && marketWhatch.getTemporaryId().equals(strategyByTab.getTab().getId()))
						|| (marketWhatch.getTemporaryId()==null && marketWhatch.getId().equals(strategyByTab.getTab().getId()))) {
						BeanUtils.copyProperties(marketWhatch, strategyByTab.getTab());
						facade.saveStrategyByTab(strategyByTab);
					}
				}
			}
		} catch (Exception e) {
			throw new DAOExceptionManhattan(e);
		}

	}

	@Override
	public List<MarketWhatchTab> saveViewTabsMarket(List<MarketWhatchTab> marketWhatchTabsUnsave) throws DAOExceptionManhattan {
				
		List<MarketWhatchTab> marketWhatchTabsSaved = new ArrayList<MarketWhatchTab>();
		for (MarketWhatchTab tab : marketWhatchTabsUnsave) {
			Long temporaryId = null;
			//Caso a Tab ainda nao esteja salva, limpa o Id gerado, para que o Banco gere via Sequence.
			if (!tab.isSaved()) {
				temporaryId = tab.getId();
				tab.setId(null);
			}
			TraderWatchTab watchTab = new TraderWatchTab();
			BeanUtils.copyProperties(tab, watchTab);
			watchTab = facade.saveTraderWatchTab(watchTab);
			BeanUtils.copyProperties(watchTab, tab);
			tab.setTemporaryId(temporaryId);
			marketWhatchTabsSaved.add(tab);
		}
		return marketWhatchTabsSaved;
	}

	@Override
	public void deleteTabMarketWatch(Long id) throws DAOExceptionManhattan {
		facade.deleteTraderWatchTabById(id);
	}

	@Override
	public void deleteMarketsByList(List<Market> list) throws DAOExceptionManhattan {
		for (Market mk : list) {
			if (null != mk.getStratagyTabId()) {
				facade.deleteStrategyTabById(mk.getStratagyTabId());
			}
		}
	}

	@Override
	public void addInstrument(MarketWhatchTab marketWhatchTab) {
		// TODO Auto-generated method stub

	}

	@Override
	public void addSynthetic(MarketWhatchTab marketWhatchTab) {
		// TODO Auto-generated method stub

	}

	@Override
	public StrategyByTab populateStrategyByTab(StrategyType vo, MarketWhatchTab marketWhatchTab) throws DAOExceptionManhattan {
		StrategyByTab strategyByTab = new StrategyByTab();
		BeanUtils.copyProperties(vo, strategyByTab);
		strategyByTab.setTab(new TraderWatchTab());
		BeanUtils.copyProperties(marketWhatchTab, strategyByTab.getTab());
		if (null != vo.getId()) {
			strategyByTab.setStrategyType(new com.ubs.manhatthan.manager.persistence.entities.StrategyType());
			BeanUtils.copyProperties(vo, strategyByTab.getStrategyType());
		}
		if (null != vo.getStrategyTypeLegList() && !vo.getStrategyTypeLegList().isEmpty()) {
			strategyByTab.setStrategyByTabLegs(new ArrayList<StrategyByTabLeg>());
			for (StrategyTypeLeg legVO : vo.getStrategyTypeLegList()) {
				StrategyByTabLeg byTabLeg = new StrategyByTabLeg();
				byTabLeg.setStrategyByTab(strategyByTab);
				com.ubs.manhatthan.manager.persistence.entities.StrategyTypeLeg tl = new com.ubs.manhatthan.manager.persistence.entities.StrategyTypeLeg();
				tl.setId(legVO.getId());
				byTabLeg.setStrategyTypeLeg(facade.findStrategyTypeLegById(tl));
				byTabLeg.setInstrument(legVO.getInstrument());
				strategyByTab.getStrategyByTabLegs().add(byTabLeg);
			}
		}
		return strategyByTab;
	}

	@Override
	public StrategyType convertEntityStrategyTypeToVO(com.ubs.manhatthan.manager.persistence.entities.StrategyType strategyType) {
		StrategyType vo = new StrategyType();
		vo.setStrategyTypeLegList(new ArrayList<StrategyTypeLeg>());
		vo.setId(strategyType.getId());
		vo.setDescription(strategyType.getDescription());
		vo.setNumberOfLegs(strategyType.getNumberOfLegs());
		vo.setStrategyCode(strategyType.getStrategyCode());
		for (com.ubs.manhatthan.manager.persistence.entities.StrategyTypeLeg leg : strategyType.getStrategyTypeLegList()) {
			StrategyTypeLeg legVO = new StrategyTypeLeg();
			legVO.setId(leg.getId());
			legVO.setDefaultSide(leg.getDefaultSide().getCode());
			legVO.setLegSeq(leg.getLegSeq());
			vo.getStrategyTypeLegList().add(legVO);
		}
		return vo;
	}

	@Override
	public StrategyType getStrategyVOById(String id) throws DAOExceptionManhattan {
		com.ubs.manhatthan.manager.persistence.entities.StrategyType strategyType = facade.getStrategyTypeById(Long.valueOf(id));
		return convertEntityStrategyTypeToVO(strategyType);
	}

	@Override
	public Market populateMarketVO(StrategyType strategyType) {
		Market vo = new Market();		
		StrategyType strategyType2 = new StrategyType();
		BeanUtils.copyProperties(strategyType, strategyType2);
		vo.setStrategyType(strategyType2);
		return vo;
	}

	public void setFacade(Facade facade) {
		this.facade = facade;
	}

	@Override
	public void deleteMarketWatchList(List<MarketWhatchTab> marketWhatchTabsUnsave) throws DAOExceptionManhattan {
		for (MarketWhatchTab marketWhatchTab : marketWhatchTabsUnsave) {
			if (marketWhatchTab.getId()!=null) {
				this.deleteTabMarketWatch(marketWhatchTab.getId());
			}			
		}
	}

	@Override
	public void saveSession(List<MarketWhatchTab> marketWhatchTabsUnSave, List<Market> marketByTabsToDelete, 
			List<MarketWhatchTab> marketWhatchTabs, List<StrategyByTab> strategyByTabsUnSave) throws DAOExceptionManhattan {
		deleteMarketWatchList(marketWhatchTabsUnSave);
		deleteMarketsByList(marketByTabsToDelete);
		marketWhatchTabs = saveViewTabsMarket(marketWhatchTabs);			
		saveStrategiesByTabMarket(marketWhatchTabs, strategyByTabsUnSave);
	}

}