package com.ubs.manhatthan.helper;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.util.Locale;

import com.ubs.manhatthan.manager.lmdsadapter.SimulationItem;
import com.ubs.manhatthan.manager.simulator.multileg.InputMultilegSimulationItem;
import com.ubs.manhatthan.model.Market;
import com.ubs.manhatthan.model.StrategyTypeLeg;

public class PushHelper {
	
	public static boolean checkIfInstrumentIsChanged(Market market, SimulationItem simulationItem) {
		
		if ( market.getBp() == null & market.getBq() == null 
    			& market.getSp() == null & market.getSq() == null 
    			& market.getLp() == null & market.getLq() == null) {	
			
			if (simulationItem.getBuyQty()!=null) {
				market.setBq(simulationItem.getBuyQty());
			}			
			
			if (simulationItem.getBuyPx()!=null) {
				market.setBp(getPriceFormated( simulationItem.getBuyPx()));
			}
			
			if (simulationItem.getSellQty()!=null) {
				market.setSq(simulationItem.getSellQty());
			}
    		
    		if (simulationItem.getSellPx()!=null) {
    			market.setSp(getPriceFormated( simulationItem.getSellPx()));
    		}
    		
    		if (simulationItem.getLastQty()!=null) {
    			market.setLq(simulationItem.getLastQty().toString());
    		}
    		
    		if (simulationItem.getLastPx()!=null) {
    			market.setLp(getPriceFormated( simulationItem.getLastPx()));
    		}
    		
    		return true;
		}else {
			
			if ( !(("" + market.getBp()).equals("" + simulationItem.getBuyPx())
					& (("" + market.getBq()).equals(simulationItem.getBuyQty()))
					& (("" + market.getSp()).equals("" + simulationItem.getSellPx()))
					& (("" + market.getSq()).equals(simulationItem.getSellQty()))
					& (("" + market.getLp()).equals("" + simulationItem.getLastPx()))
					& (("" + market.getLq()).equals("" + simulationItem.getLastQty())))) {
				
				if (simulationItem.getBuyQty()!=null) {
					market.setBq(simulationItem.getBuyQty());
				}
				
				if (simulationItem.getBuyPx()!=null) {
					market.setBp(getPriceFormated( simulationItem.getBuyPx()));
				}
				
				if (simulationItem.getSellQty()!=null) {
					market.setSq(simulationItem.getSellQty());
				}
	    		
	    		if (simulationItem.getSellPx()!=null) {
	    			market.setSp(getPriceFormated( simulationItem.getSellPx()));
	    		}
	    		
	    		if (simulationItem.getLastQty()!=null) {
	    			market.setLq(simulationItem.getLastQty().toString());
	    		}
	    		
	    		if (simulationItem.getLastPx()!=null) {
	    			market.setLp(getPriceFormated( simulationItem.getLastPx()));
	    		}
				
				return true;
			}			
		}
			
		return false;
    }
        
	public static boolean checkIfSyntheticIsChanged(Market market, SimulationItem simulationItem) {
		
		if (market!=null && market.getStrategyType()!=null && market.getStrategyType().getStrategyTypeLegList()!=null) {
	    	    	    		
			if ( market.getBp() == null & market.getBq() == null 
	    			& market.getSp() == null & market.getSq() == null 
	    			& market.getLp() == null & market.getLq() == null) {	
								
				if (simulationItem.getBuyReturnMultilegSimulation().getAvailableQuantity()!=null) {
					market.setBq(simulationItem.getBuyReturnMultilegSimulation().getAvailableQuantity());
				}
				
				if (simulationItem.getBuyReturnMultilegSimulation().getMarketTarget()!=null) {
					market.setBp(getPriceFormated( simulationItem.getBuyReturnMultilegSimulation().getMarketTarget()));
				}
				
				if (simulationItem.getSellReturnMultilegSimulation().getAvailableQuantity()!=null) {
					market.setSq(simulationItem.getSellReturnMultilegSimulation().getAvailableQuantity());
				}
	    		
	    		if (simulationItem.getSellReturnMultilegSimulation().getMarketTarget()!=null) {
	    			market.setSp(getPriceFormated( simulationItem.getSellReturnMultilegSimulation().getMarketTarget()));
	    		}
	    		
	    		return true;
			}else {
				
				if ( !(("" + market.getBp()).equals("" + simulationItem.getBuyReturnMultilegSimulation().getMarketTarget())
						& (("" + market.getBq()).equals(simulationItem.getBuyReturnMultilegSimulation().getAvailableQuantity()))
						& (("" + market.getSp()).equals("" + simulationItem.getSellReturnMultilegSimulation().getMarketTarget()))
						& (("" + market.getSq()).equals(simulationItem.getSellReturnMultilegSimulation().getAvailableQuantity())))) {
							    		
		    		if (simulationItem.getBuyReturnMultilegSimulation().getAvailableQuantity()!=null) {
						market.setBq(simulationItem.getBuyReturnMultilegSimulation().getAvailableQuantity());
					}
					
					if (simulationItem.getBuyReturnMultilegSimulation().getMarketTarget()!=null) {
						market.setBp(getPriceFormated( simulationItem.getBuyReturnMultilegSimulation().getMarketTarget()));
					}
					
					if (simulationItem.getSellReturnMultilegSimulation().getAvailableQuantity()!=null) {
						market.setSq(simulationItem.getSellReturnMultilegSimulation().getAvailableQuantity());
					}
		    		
		    		if (simulationItem.getSellReturnMultilegSimulation().getMarketTarget()!=null) {
		    			market.setSp(getPriceFormated( simulationItem.getSellReturnMultilegSimulation().getMarketTarget()));
		    		}
					
					return true;
				}			
			}
		}
			
		return false;
    }
	
	public static boolean checkIfNeedUpdate(Market market, SimulationItem simulationItem){
		 
		if( simulationItem.isOnlySymbol() && (market.getStrategyType().getStrategyTypeLegList()==null 
				|| market.getStrategyType().getStrategyTypeLegList().isEmpty())){
			//Retorna true e nao valida, porque lista de simulationItem, so vem um do mesmo simbolo
			return checkIfInstrumentIsChanged(market, simulationItem);
		}else if( !simulationItem.isOnlySymbol() && (market.getStrategyType().getStrategyTypeLegList()!=null 
				|| !market.getStrategyType().getStrategyTypeLegList().isEmpty())
				&& market.getStrategyType().getStrategyTypeLegList().size() == simulationItem.getBuyInputMultilegSimulationList().getInputItens().size()
				&& market.getStrategyType().getStrategyCode().equals(simulationItem.getBuyInputMultilegSimulationList().getSimulationMode().getCode())){
										
			int qtdEquals = 0;
			
			for (StrategyTypeLeg strategyTypeLeg : market.getStrategyType().getStrategyTypeLegList()) {
				
				for (InputMultilegSimulationItem inputMultilegSimulationItem : simulationItem.getBuyInputMultilegSimulationList().getInputItens()) {
					if (strategyTypeLeg.getInstrument().equals(inputMultilegSimulationItem.getInstrument().intValue())) {
						qtdEquals +=1;
					}
				}							
			}
			if (qtdEquals == market.getStrategyType().getStrategyTypeLegList().size()) {
				return checkIfSyntheticIsChanged(market, simulationItem);
			}			
		}		
		return false;
	}
	
	public static String getPriceFormated(Double value){
    	
    	String valueFormated = "";
    	
    	if (value!=null) {
    		DecimalFormatSymbols dfs = new DecimalFormatSymbols (Locale.US);
    		NumberFormat nf = new DecimalFormat ("#.###", dfs);
    		nf.setMinimumFractionDigits(3);
    		valueFormated = nf.format(value);
		}
		
		return valueFormated;
    }
}