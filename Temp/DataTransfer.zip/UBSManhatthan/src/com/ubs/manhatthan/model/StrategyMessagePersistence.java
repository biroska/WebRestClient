package com.ubs.manhatthan.model;

import java.io.Serializable;

import com.google.protobuf.GeneratedMessage;

public class StrategyMessagePersistence implements Serializable {

	private static final long serialVersionUID = -903445872499854882L;

	private final int counter;
	private final long engineId;
	private final GeneratedMessage message;

	public StrategyMessagePersistence(long engineId, GeneratedMessage message, int counter) {
		super();
		this.engineId = engineId;
		this.message = message;
		this.counter = counter;
	}

	public long getEngineId() {
		return engineId;
	}

	public GeneratedMessage getMessage() {
		return message;
	}

	public int getCounter() {
		return counter;
	}
}
