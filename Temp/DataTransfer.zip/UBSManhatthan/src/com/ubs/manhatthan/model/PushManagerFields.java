package com.ubs.manhatthan.model;

import java.io.Serializable;

import com.ubs.manhatthan.manager.enums.StrategyStateEnum;

@SuppressWarnings("serial")
public class PushManagerFields implements Serializable {

	private Long engineId;

	private Long strategyId;

	private Integer legSeq;
	
	private boolean isALeg;
		
	private Integer status;
	
	private String instrument;
	
	private int executedPercent;
		
	private Double target;
	
	private Double executedTarget;
		
	private Long leggedQuantity;
		
	private Double leggedPrice;
		
	private Long totalQuantity;
		
	private Long quantityRemain;
		
	private Long quantityExecuted;
	
	private Double averagePrice;
		
	private Long otcQuantity;
		
	private Double otcPrice;
		
	private Long poQuantity;
		
	private Double poPrice;
	
	private Long rank;
	
	private String startTime;
	
	private String endTime;
		
	private String text;
	
	public PushManagerFields() {
		
	}

	public PushManagerFields(StrategyReport strategyReport) {
		if (strategyReport != null) {
			this.engineId = strategyReport.getEngineId();
			this.strategyId = strategyReport.getStrategyId();
			this.legSeq = strategyReport.getLegSeq();
			this.isALeg = false;
			this.status = strategyReport.getStatus();
			this.instrument = strategyReport.getContractsDisplayText();
			this.executedPercent =  (int) strategyReport.getExecutedPercentage().doubleValue();
			this.executedTarget = strategyReport.getExecutedTarget();
			this.target = strategyReport.getTarget();
			this.leggedQuantity = Long.valueOf(strategyReport.getLeggedQtd());
			this.leggedPrice = 0.00;
			this.totalQuantity = Long.valueOf(strategyReport.getTotalQtd());
			this.quantityRemain = Long.valueOf(strategyReport.getTotalRemainingQtd());
			this.quantityExecuted = Long.valueOf(strategyReport.getTotalExecutedQtd());
			this.averagePrice = 0.00;
			this.otcQuantity = Long.valueOf(strategyReport.getTotalOtcQtd());
			this.otcPrice = 0.00;
			this.poQuantity = Long.valueOf(strategyReport.getTotalRestingQuantity());
			this.poPrice = 0.00;
			this.rank = strategyReport.getTotalRestingRank();
			this.startTime = strategyReport.getStrategyType().getStart();
			this.endTime = strategyReport.getStrategyType().getEnd();
			this.text = strategyReport.getText();
		}
	}

	public PushManagerFields(LegStrategyReport legStrategyReport) {
		if (legStrategyReport != null) {			
			this.engineId = legStrategyReport.getEngineId();
			this.strategyId = legStrategyReport.getStrategyId();
			this.legSeq = legStrategyReport.getLegSeq();
			this.isALeg = true;
			this.instrument = legStrategyReport.getContract();
			this.executedPercent = (int) legStrategyReport.getExecutedPercentage().doubleValue();
			
			if (legStrategyReport.getStrategyReport() != null) {
				this.status = legStrategyReport.getStrategyReport().getStatus();
				this.executedTarget = legStrategyReport.getStrategyReport().getExecutedTarget();
				this.target = legStrategyReport.getStrategyReport().getTarget();
			}

			this.leggedQuantity = legStrategyReport.getLeggedQuantity();
			this.leggedPrice = legStrategyReport.getLeggedPrice();
			this.totalQuantity = legStrategyReport.getTotalQuantity();
			this.quantityRemain = legStrategyReport.getRemainingQuantity();
			this.quantityExecuted = legStrategyReport.getExecutedQuantity();
			this.averagePrice = legStrategyReport.getAveragePrice();
			this.otcQuantity = legStrategyReport.getOtcQuantity();
			this.otcPrice = legStrategyReport.getOtcPrice();
			this.poQuantity = legStrategyReport.getRestingQuantity(); 
			this.poPrice = legStrategyReport.getRestingPrice();
			this.text = legStrategyReport.getText();
			this.rank = legStrategyReport.getRestingRank();
		}
	}

	public Long getEngineId() {
		return engineId;
	}

	public void setEngineId(Long engineId) {
		this.engineId = engineId;
	}

	public Long getStrategyId() {
		return strategyId;
	}

	public void setStrategyId(Long strategyId) {
		this.strategyId = strategyId;
	}

	public Integer getLegSeq() {
		return legSeq;
	}

	public void setLegSeq(Integer legSeq) {
		this.legSeq = legSeq;
	}
	
	public boolean getIsALeg() {
		return this.isALeg;
	}

	private String getHtmlRowParentId() {
		if (this.legSeq == null) {
			return null;
		} else {
			return "." + this.engineId.toString() + "_" +
					this.strategyId.toString() + "_";
		}
	}
	
	private String getHtmlRowdId() {
		if (this.legSeq == null) {
			return "." + this.engineId.toString() + "_" +
					this.strategyId.toString() + "_";
		} else {
			return "." + this.engineId.toString() + "_" +
				this.strategyId.toString() + "_" + 
				this.legSeq.toString() + "_";
		}
	}

	public String getRowKey() {
		if (this.legSeq == null) {
			return "." + this.engineId.toString() + "_" +
					this.strategyId.toString();
		} else {
			return "." + this.engineId.toString() + "_" +
				this.strategyId.toString() + "_" + 
				this.legSeq.toString();
		}		
	}
	
	public String getCancelHtmlId() {
		return (getHtmlRowdId() + "cancel");
	}
	
	public String getCancelColumnHtmlId() {
		return (getHtmlRowdId() + "columnCancel");
	}
	
	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getStatusHtmlId() {
		return (getHtmlRowdId() + "status");
	}

	public String getStatusDisplayHtmlId() {
		return (getHtmlRowdId() + "statusDisplay");
	}

	public String getParentColumnCancelHtmlId() {
		if (getHtmlRowParentId() != null) {
			return getHtmlRowParentId() + "columnCancel";
		} else {
			return null;
		}
	}

	public String getStatusDisplayText() {
		if (status != null)
			return StrategyStateEnum.fromValue(status).name();
		else
			return null;
	}
	
	public String getInstrument() {
		return instrument;
	}

	public void setInstrument(String instrument) {
		this.instrument = instrument;
	}

	public String getInstrumentHtmlId() {
		return (getHtmlRowdId() + "instrument");
	}

	public int getExecutedPercent() {
		return executedPercent;
	}

	public void setExecutedPercent(int executedPercent) {
		this.executedPercent = executedPercent;
	}

	public String getExecutedPercentHtmlId() {
		return (getHtmlRowdId() + "executedPercentage");
	}

	public Double getExecutedTarget() {
		return executedTarget;
	}

	public void setExecutedTarget(Double executedTarget) {
		this.executedTarget = executedTarget;
	}

	public String getExecutedTargetHtmlId() {
		return (getHtmlRowdId() + "executedTarget");
	}
	
	public Double getTarget() {
		return target;
	}

	public void setTarget(Double target) {
		this.target = target;
	}

	public String getTargetHtmlId() {
		return (getHtmlRowdId() + "target");
	}

	public Long getLeggedQuantity() {
		return leggedQuantity;
	}

	public void setLeggedQuantity(Long leggedQuantity) {
		this.leggedQuantity = leggedQuantity;
	}

	public String getLeggedQuantityHtmlId() {
		return (getHtmlRowdId() + "leggedQuantity");
	}

	public Double getLeggedPrice() {
		return leggedPrice;
	}

	public void setLeggedPrice(Double leggedPrice) {
		this.leggedPrice = leggedPrice;
	}

	public String getLeggedPriceHtmlId() {
		return (getHtmlRowdId() + "leggedPrice");
	}

	public Long getTotalQuantity() {
		return totalQuantity;
	}

	public void setTotalQuantity(Long totalQuantity) {
		this.totalQuantity = totalQuantity;
	}

	public String getTotalQuantityHtmlId() {
		return (getHtmlRowdId() + "totalQuantity");
	}

	public Long getQuantityRemain() {
		return quantityRemain;
	}

	public void setQuantityRemain(Long quantityRemain) {
		this.quantityRemain = quantityRemain;
	}

	public String getQuantityRemainHtmlId() {
		return (getHtmlRowdId() + "remainingQuantity");
	}

	public Long getQuantityExecuted() {
		return quantityExecuted;
	}

	public void setQuantityExecuted(Long quantityExecuted) {
		this.quantityExecuted = quantityExecuted;
	}

	public String getQuantityExecutedHtmlId() {
		return (getHtmlRowdId() + "executedQuantity");
	}

	public Double getAveragePrice() {
		return averagePrice;
	}

	public void setAveragePrice(Double averagePrice) {
		this.averagePrice = averagePrice;
	}

	public String getAveragePriceHtmlId() {
		return (getHtmlRowdId() + "averagePrice");
	}

	public Long getOtcQuantity() {
		return otcQuantity;
	}

	public void setOtcQuantity(Long otcQuantity) {
		this.otcQuantity = otcQuantity;
	}

	public String getOtcQuantityHtmlId() {
		return (getHtmlRowdId() + "otcQuantity");
	}

	public Double getOtcPrice() {
		return otcPrice;
	}

	public void setOtcPrice(Double otcPrice) {
		this.otcPrice = otcPrice;
	}

	public String getOtcPriceHtmlId() {
		return (getHtmlRowdId() + "otcPrice");
	}

	public Long getPoQuantity() {
		return poQuantity;
	}

	public void setPoQuantity(Long poQuantity) {
		this.poQuantity = poQuantity;
	}

	public String getPoQuantityHtmlId() {
		return (getHtmlRowdId() + "poQuantity");
	}

	public Double getPoPrice() {
		return poPrice;
	}

	public void setPoPrice(Double poPrice) {
		this.poPrice = poPrice;
	}

	public String getPoPriceHtmlId() {
		return (getHtmlRowdId() + "poPrice");
	}

	public Long getRank() {
		return rank;
	}

	public void setRank(Long rank) {
		this.rank = rank;
	}

	public String getRankHtmlId() {
		return (getHtmlRowdId() + "rank");
	}
		
	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getStartTimeHtmlId() {
		return (getHtmlRowdId() + "startTime");
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getEndTimeHtmlId() {
		return (getHtmlRowdId() + "endTime");
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getTextHtmlId() {
		return (getHtmlRowdId() + "text");
	}
}