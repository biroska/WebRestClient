package com.ubs.manhatthan.model;

import java.io.Serializable;

import org.apache.commons.lang.StringUtils;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.cache.CacheHelper;
import com.ubs.manhatthan.manager.lmdsadapter.LmdsManager;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.SecurityDefinition;
import com.ubs.manhatthan.manager.utils.Util;

public class StrategyTypeLeg implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long id;
		
	private Integer defaultSide;
	
	private Integer legSeq;
	
	private Legged legged;

	private Integer instrument;
	
	private String instrumentByName;

	private LmdsManager lmds; 

	public StrategyTypeLeg(){
		lmds = CacheHelper.lmdsCommunicatorInstance.get( Util.getManagerId() );
	}

	public StrategyTypeLeg(Long id,  Integer defaultSide, Integer legSeq, Legged legged) {
		super();
		this.id = id;
		this.defaultSide = defaultSide;
		this.legSeq = legSeq;
		this.legged = legged;
	}
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	

	public Integer getDefaultSide() {
		return defaultSide;
	}

	public void setDefaultSide(Integer defaultSide) {
		this.defaultSide = defaultSide;
	}

	public Integer getLegSeq() {
		return legSeq;
	}

	public void setLegSeq(Integer legSeq) {
		this.legSeq = legSeq;
	}
	
	public Legged getLegged() {
		return legged;
	}

	public void setLegged(Legged legged) {
		this.legged = legged;
	}
	
	public Integer getInstrument() {
		return instrument;
	}

	public void setInstrument(Integer instrument) {
		this.instrument = instrument;
	}

	public String getInstrumentByName() {
		return instrumentByName;
	}
	
	public String getInstrumentNameById() throws DAOExceptionManhattan {
		String name = null;
			
		SecurityDefinition intrumentDefinition = lmds.getIntrumentDefinitionBySecurityId( ""+instrument );
		
		if ( intrumentDefinition == null || intrumentDefinition.getSecurity() == null || StringUtils.isBlank( intrumentDefinition.getSecurity().getSymbol() ) ){
			name = "";	
		} else {
			name = intrumentDefinition.getSecurity().getSymbol();
		}	
			
		return name;
	}

	public void setInstrumentByName(String instrumentByName) {
		if (null != instrumentByName && !instrumentByName.trim().equals("")) {
			
			instrumentByName = instrumentByName.toUpperCase();
			
			try {
				SecurityDefinition intrumentDefinition = lmds.getIntrumentDefinitionBySymbol( instrumentByName.trim() );
				
				if ( intrumentDefinition == null || intrumentDefinition.getSecurity() == null || intrumentDefinition.getSecurity().getSecurityID() == null ){
					setInstrument( 0 );
				} else {
					setInstrument( Integer.valueOf( intrumentDefinition.getSecurity().getSecurityID() ) );
				}
			} catch (DAOExceptionManhattan e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
//			setInstrument(MarketDataMock.getInstrument(instrumentByName.trim()) == null ? 0 : Integer.valueOf(MarketDataMock.getInstrument(instrumentByName).toString()));	
		}
		this.instrumentByName = instrumentByName;
	}
}