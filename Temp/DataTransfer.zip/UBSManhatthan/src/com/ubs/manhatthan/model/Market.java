package com.ubs.manhatthan.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.cache.CacheHelper;
import com.ubs.manhatthan.manager.dto.ReceiveSymbolSyntheticItem;
import com.ubs.manhatthan.manager.enums.SideEnum;
import com.ubs.manhatthan.manager.lmdsadapter.LmdsManager;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.SecurityDefinition;
import com.ubs.manhatthan.manager.logger.ApplicationLogger;
import com.ubs.manhatthan.manager.utils.Util;

@SuppressWarnings("serial")
public class Market implements Serializable {

	private long id;
	private String lq;
	private String lp;
	private String bq;
	private String bp;
	private String sp;
	private String sq;
	private boolean subscribed = false;
	
	private Long tabViewId;
	private Long stratagyTabId;
	private Account account;
	private StrategyType strategyType;
	private String errorOnSubscribe;
	
	private LmdsManager lmds;

	public Market() {
		super();
	}

	public Market(long id, String lq, String lp, String bq, String bp, String sp, String sq, StrategyType strategyType) {
		super();
		this.id = id;
		this.lq = lq;
		this.lp = lp;
		this.bq = bq;
		this.bp = bp;
		this.sp = sp;
		this.sq = sq;
		this.strategyType = strategyType;
	}
	
	private void initLmds(){
		if ( lmds == null ) {
			lmds = CacheHelper.lmdsCommunicatorInstance.get( Util.getManagerId() );
		}
	}

	public String getContracts() throws DAOExceptionManhattan {
		StringBuffer listContractsByName = new StringBuffer();
		initLmds();
		if (null != strategyType) {
			if (null != strategyType.getStrategyTypeLegList() && !strategyType.getStrategyTypeLegList().isEmpty()) {
				for (Iterator<StrategyTypeLeg> iterator = strategyType.getStrategyTypeLegList().iterator(); iterator.hasNext();) {
					StrategyTypeLeg strategyTypeLeg = (StrategyTypeLeg) iterator.next();
					if (null != strategyTypeLeg.getInstrument()) {
						long instrument = strategyTypeLeg.getInstrument();
						SecurityDefinition intrumentDefinition = lmds.getIntrumentDefinitionBySecurityId( ""+instrument );
						
						if ( intrumentDefinition == null || intrumentDefinition.getSecurity() == null || StringUtils.isBlank( intrumentDefinition.getSecurity().getSymbol() ) ){
							if (iterator.hasNext()) {
								listContractsByName.append( "Instrument not found in LMDS" + " / ");
							} else {
								listContractsByName.append( "Instrument not found in LMDS" );
							}
						} else {
							if (iterator.hasNext()) {
								listContractsByName.append( intrumentDefinition.getSecurity().getSymbol() + " / ");
							} else {
								listContractsByName.append( intrumentDefinition.getSecurity().getSymbol() );
							}
						}
					}
				}
			} else {
				
				try {
					
					if (lmds!=null) {
						SecurityDefinition intrumentDefinition = lmds.getIntrumentDefinitionBySecurityId( ""+strategyType.getInstrument() );
						
						if ( intrumentDefinition == null || intrumentDefinition.getSecurity() == null || StringUtils.isBlank( intrumentDefinition.getSecurity().getSymbol() ) ){
							listContractsByName.append( "Instrument not found in LMDS" );
						} else {
							listContractsByName.append( intrumentDefinition.getSecurity().getSymbol() );
						}
					}					
					
				} catch (DAOExceptionManhattan e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					ApplicationLogger.logError("Nao foi possivel recuperar o simbolo pelo instrumento: " + strategyType.getInstrument() );
					throw e;
				}
			}
		}
		return listContractsByName.toString();
	}
	
	public List<ReceiveSymbolSyntheticItem> getContractsList() throws DAOExceptionManhattan {
		List<ReceiveSymbolSyntheticItem> strategyLegList = null;
		
		initLmds();
		
		if (null != strategyType ) {
			strategyLegList = new ArrayList<ReceiveSymbolSyntheticItem>();
			
			try {
			
				if (null != strategyType.getStrategyTypeLegList() && !strategyType.getStrategyTypeLegList().isEmpty()) {
					for (Iterator<StrategyTypeLeg> iterator = strategyType.getStrategyTypeLegList().iterator(); iterator.hasNext();) {
						StrategyTypeLeg strategyTypeLeg = (StrategyTypeLeg) iterator.next();
						
						
						if (null != strategyTypeLeg.getInstrument()) {
							String instrument = strategyTypeLeg.getInstrument().toString();
							
							SecurityDefinition intrumentDefinition = lmds.getIntrumentDefinitionBySecurityId( ""+instrument );
							
							ReceiveSymbolSyntheticItem syntheticItem = new ReceiveSymbolSyntheticItem();
							syntheticItem.setLegSeq(strategyTypeLeg.getLegSeq());
							if (strategyTypeLeg.getDefaultSide()!=null) {
								syntheticItem.setSide(SideEnum.fromValue(strategyTypeLeg.getDefaultSide()));
							}										
							
							if ( intrumentDefinition == null || intrumentDefinition.getSecurity() == null || StringUtils.isBlank( intrumentDefinition.getSecurity().getSymbol() ) ){
								syntheticItem.setSymbol( "Instrument not found in LMDS" );
							} else {
								syntheticItem.setSymbol(intrumentDefinition.getSecurity().getSymbol() );
							}
							
							strategyLegList.add(syntheticItem);
						}
					}
				} else {
					if (lmds!=null) {
						SecurityDefinition intrumentDefinition = lmds.getIntrumentDefinitionBySecurityId( ""+strategyType.getInstrument() );
						
						ReceiveSymbolSyntheticItem syntheticItem = new ReceiveSymbolSyntheticItem();
						syntheticItem.setLegSeq(0);
						syntheticItem.setSide(SideEnum.NOT_DEFINED);
						
						if ( intrumentDefinition == null || intrumentDefinition.getSecurity() == null || StringUtils.isBlank( intrumentDefinition.getSecurity().getSymbol() ) ){
							syntheticItem.setSymbol( "Instrument not found in LMDS" );
						} else {
							syntheticItem.setSymbol( intrumentDefinition.getSecurity().getSymbol() );
						}
						
						strategyLegList.add(syntheticItem);
					}					
				}
				
			} catch (DAOExceptionManhattan e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				ApplicationLogger.logError("Nao foi possivel recuperar o simbolo pelo instrumento: " + strategyType.getInstrument() );
				throw e;
			}
		}

		return strategyLegList;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getLq() {
		return lq;
	}

	public void setLq(String lq) {
		this.lq = lq;
	}

	public String getLp() {
		return lp;
	}

	public void setLp(String lp) {
		this.lp = lp;
	}

	public String getBq() {
		return bq;
	}

	public void setBq(String bq) {
		this.bq = bq;
	}

	public String getBp() {
		return bp;
	}

	public void setBp(String bp) {
		this.bp = bp;
	}

	public String getSp() {
		return sp;
	}

	public void setSp(String sp) {
		this.sp = sp;
	}

	public String getSq() {
		return sq;
	}

	public void setSq(String sq) {
		this.sq = sq;
	}

	public StrategyType getStrategyType() {
		return strategyType;
	}

	public void setStrategyType(StrategyType strategyType) {
		this.strategyType = strategyType;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public Long getTabViewId() {
		return tabViewId;
	}

	public void setTabViewId(Long tabViewId) {
		this.tabViewId = tabViewId;
	}

	public Long getStratagyTabId() {
		return stratagyTabId;
	}

	public void setStratagyTabId(Long stratagyTabId) {
		this.stratagyTabId = stratagyTabId;
	}
	
	//Using in html page for id controls and after push / subscriber update information
	private String getPKHtmlId() {
		if (this.tabViewId!=null) {
			return "mkt_" +  this.id + "_" + 
				this.tabViewId.toString() + "_";
		}else {
			return "";
		}
		
	}
	
	public String getHtmlIdLP() {
		return getPKHtmlId() + "LP";
	}
	
	public String getHtmlIdLQ() {
		return getPKHtmlId() + "LQ";
	}

	public String getHtmlIdBP() {
		return getPKHtmlId() + "BP";
	}
	
	public String getHtmlIdBQ() {
		return getPKHtmlId() + "BQ";
	}

	public String getHtmlIdSP() {
		return getPKHtmlId() + "SP";
	}

	public String getHtmlIdSQ() {
		return getPKHtmlId() + "SQ";
	}

	/**
	 * @return the subscribed
	 */
	public boolean isSubscribed() {
		return subscribed;
	}

	/**
	 * @param subscribed the subscribed to set
	 */
	public void setSubscribed(boolean subscribed) {
		this.subscribed = subscribed;
	}

	public String getErrorOnSubscribe() {
		return errorOnSubscribe;
	}

	public void setErrorOnSubscribe(String errorOnSubscribe) {
		this.errorOnSubscribe = errorOnSubscribe;
	}
}