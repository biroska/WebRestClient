package com.ubs.manhatthan.model;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Account implements Serializable {

	private Long code;

	private String name;
	
	private String description;
	
	private Long codeDisplay;
	
	private String nameDisplay;
	
	private String descriptionDisplay;

	public Account() {
		super();
	}

	public Account(Long code, String name, String description) {
		super();
		this.code = code;
		this.name = name;
		this.description = description;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getShortName() {
		String shortName = null;
		
		if (this.name != null) {
			if (this.name.length() > 20) {
				shortName = this.name.substring(0, 19) + "...";
			} else {
				shortName = this.name;
			}
		}
		
		return shortName;
	}
	
	public Long getCode() {
		return code;
	}

	public void setCode(Long code) {
		this.code = code;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Long getCodeDisplay() {
		if (codeDisplay == null) {
			return code;
		} else {
			return codeDisplay;	
		}		
	}

	public void setCodeDisplay(Long codeDisplay) {
		this.codeDisplay = codeDisplay;
	}

	public String getNameDisplay() {
		if (nameDisplay == null) {
			return name;
		} else {
			return nameDisplay;
		}
	}

	public void setNameDisplay(String nameDisplay) {
		this.nameDisplay = nameDisplay;
	}

	public String getDescriptionDisplay() {
		if (descriptionDisplay == null) {
			return description;
		} else {
			return descriptionDisplay;	
		}		
	}

	public void setDescriptionDisplay(String descriptionDisplay) {
		this.descriptionDisplay = descriptionDisplay;
	}	
}
