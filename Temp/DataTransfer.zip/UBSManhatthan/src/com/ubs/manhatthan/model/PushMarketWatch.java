package com.ubs.manhatthan.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.ubs.manhatthan.manager.lmdsadapter.SimulationItem;

@SuppressWarnings("serial")
public class PushMarketWatch implements Serializable {
	
	private Long tabViewId;
	
	private String messageId = "1";
	
	private String refreshTableIsNeeded = "N";

	private List<PushMarketWatchFields> fields = null;

	public PushMarketWatch() {

	}

	public PushMarketWatch(Long id, SimulationItem simulationItem) {
		this.addSimulationItem(id, simulationItem);
	}
	
	public String getMessageId() {
		return this.messageId;
	}	
	
	public String getRefreshTableIsNeeded() {
		return refreshTableIsNeeded;
	}

	public void setRefreshTableIsNeeded(String refreshTableIsNeeded) {
		this.refreshTableIsNeeded = refreshTableIsNeeded;
	}

	public List<PushMarketWatchFields> getFields() {
		return fields;
	}
	
	public Long getTabViewId() {
		return tabViewId;
	}

	public void setTabViewId(Long tabViewId) {
		this.tabViewId = tabViewId;
	}

	public void addSimulationItem(Long id, SimulationItem simulationItem) {
		PushMarketWatchFields field = new PushMarketWatchFields(simulationItem);
		
		field.setTabViewId(this.tabViewId);
		
		field.setId(id);
		
		if (fields == null) {
			fields = new ArrayList<PushMarketWatchFields>();
		}
				
		this.fields.add(field);
	}
	
	public void clearFields() {
		if (fields != null) {
			fields.clear();
		}
	}
}