package com.ubs.manhatthan.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import com.ubs.manhatthan.manager.utils.Util;
import com.ubs.manhatthan.common.enuns.StrategyStatusEnum;

public class StrategyReport implements Serializable {

	private static final long serialVersionUID = 7886773494602837014L;

	public StrategyReport() {
		legStrategyList = new ArrayList<LegStrategyReport>();
	}

	private long counter;
	
	private Integer legSeq;

	private Long engineId;

	private Long strategyId;
	
	private long requestId;

	private StrategyType strategyType;

	private Date strategyTimestamp;

	private String login;

	private Date startTime;

	private Date initStart = new Date();

	private Date endTime;

	private Date startTimeText;

	private Date endTimeText;
	// % - manager
	private Double executedPercentage;
	// TargetExec
	private Double executedTarget;

	private boolean startPaused;

	private boolean cancelAtive;

	private int status;

	private int totalQtd;

	private String text;

	private Double priceLimit;
	// target - manager
	private Double target;

	// target - manager
	private Double targetDif;

	private boolean targetWarning;

	private Double agressiviness;
	// Risk Level
	private Integer riskLevel;
	// Book Level
	private Integer restingLevel;

	private Double market;

	//Using when strtegy report status is 99 (Message to user);
	private boolean isPopup = false;
	
	private String message;
	
	private List<LegStrategyReport> legStrategyList;
	
	public long getCounter() {
		return counter;
	}

	public void setCounter(long counter) {
		this.counter = counter;
	}

	public StrategyType getStrategyType() {
		return strategyType;
	}

	public void setStrategyType(StrategyType strategyType) {
		this.strategyType = strategyType;
	}

	public Date getStrategyTimestamp() {
		return strategyTimestamp;
	}

	public void setStrategyTimestamp(Date strategyTimestamp) {
		this.strategyTimestamp = strategyTimestamp;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public Double getExecutedPercentage() {
		if ( executedPercentage != null )
			return (executedPercentage * 100);
		else 
			return null;
	}

	public void setExecutedPercentage(Double executedPercentage) {
		this.executedPercentage = executedPercentage;
	}

	public Double getExecutedTarget() {
		return executedTarget;
	}

	public void setExecutedTarget(Double executedTarget) {
		this.executedTarget = executedTarget;
	}

	public boolean getStartPaused() {
		return startPaused;
	}

	public void setStartPaused(boolean startPaused) {
		this.startPaused = startPaused;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public Double getPriceLimit() {
		return priceLimit;
	}

	public void setPriceLimit(Double priceLimit) {
		this.priceLimit = priceLimit;
	}

	public Double getTarget() {
		return target;
	}

	public void setTarget(Double target) {
		this.target = target;
	}

	public Double getAgressiviness() {
		return agressiviness;
	}

	public void setAgressiviness(Double agressiviness) {
		this.agressiviness = agressiviness;
	}

	public Integer getRiskLevel() {
		return riskLevel;
	}

	public void setRiskLevel(Integer riskLevel) {
		this.riskLevel = riskLevel;
	}

	public Integer getRestingLevel() {
		return restingLevel;
	}

	public void setRestingLevel(Integer restingLevel) {
		this.restingLevel = restingLevel;
	}

	public List<LegStrategyReport> getLegStrategyList() {
		return legStrategyList;
	}

	public void setLegStrategyList(List<LegStrategyReport> legStrategyList) {
		this.legStrategyList = legStrategyList;
	}

	public Date getStartTimeText() {
		return startTimeText;
	}

	public void setStartTimeText(Date startTimeText) {
		if (startTimeText != null) {
			this.startTimeText = Util.convertDateHourNowPattern(Util
				.getHourFormat(startTimeText));
		}
	}

	public Date getEndTimeText() {
		return endTimeText;
	}

	public void setEndTimeText(Date endTimeText) {
		if (endTimeText != null) {
			this.endTimeText = Util.convertDateHourNowPattern(Util
				.getHourFormat(endTimeText));
		}
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}
	
	public void setStatusDisplay() {
		
	}
	
	public String getStatusDisplay() {
		return StrategyStatusEnum.fromValue(this.status).getDescription();
	}

	public String getStatusStyleName() {
		String style = "";
				
		if (this.status == StrategyStatusEnum.SCHEDULED.getCode() || 
				this.status == StrategyStatusEnum.COMPLETED.getCode() ||
				this.status == StrategyStatusEnum.CANCELLED.getCode() ||
				this.status == StrategyStatusEnum.PAUSING.getCode() ||
				this.status == StrategyStatusEnum.INITIALIZING.getCode() ||
				this.status == StrategyStatusEnum.RESUMING.getCode() ||
				this.status == StrategyStatusEnum.CANCELLING.getCode()) {
			style = "status-no";
		} else if (this.status == StrategyStatusEnum.PAUSED.getCode()) {
			style = "status-yellow";
		} else if (this.status == StrategyStatusEnum.ERROR.getCode()) {
			style = "status-orange";
		} else if (this.status == StrategyStatusEnum.RESUMED.getCode()) {
			style = "status-green";
		} else if (this.status == StrategyStatusEnum.DISCONNECT.getCode()) {
			style = "status-black";
		}
		
		return style;
	}
	
	public String getStyleName() {
		String style = "";
		
		if (getIsUnlegging()) {
			style = getRowKey() + " column-default column-red";
		} else {
			style = getRowKey() + " column-default";
		}
		
		return style;
	}

	public Integer getLegSeq() {
		return legSeq;
	}

	public void setLegSeq(Integer legSeq) {
		this.legSeq = legSeq;
	}

	public Long getEngineId() {
		return engineId;
	}

	public int getIdEngineId() {
		int idEngineId = 0;
		
		if (engineId > 0)
			idEngineId = ((int) (engineId / 1000));
		
		return idEngineId;
	}

	public int getInstanceEngineId() {
		int idEngineId = 0;
		
		if (engineId > 0)
			idEngineId = ((int) (engineId % 1000));
		
		return idEngineId;
	}

	public void setEngineId(Long engineId) {
		this.engineId = engineId;
	}

	public Long getStrategyId() {
		return strategyId;
	}

	public void setStrategyId(Long strategyId) {
		this.strategyId = strategyId;
	}	
	
	public long getRequestId() {
		return requestId;
	}

	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}

	public boolean getCancelAtive() {
		return cancelAtive;
	}

	public void setCancelAtive(boolean cancelAtive) {
		this.cancelAtive = cancelAtive;
	}

	public int getTotalQtd() {
		int sum = 0;
		totalQtd = 0;
		if (null != legStrategyList) {
			for (LegStrategyReport strategyTypeLeg : legStrategyList) {
				sum += strategyTypeLeg.getTotalQuantity() == null ? 0 : strategyTypeLeg.getTotalQuantity();
			}
		}
		totalQtd = sum;
		return totalQtd;
	}
	
	public int getTotalRemainingQtd() {
		int sum = 0;

		if (null != legStrategyList) {
			for (LegStrategyReport legStrategyReport : legStrategyList) {
				sum += legStrategyReport.getRemainingQuantity() == null ? 0 : legStrategyReport.getRemainingQuantity();
			}
		}

		return sum;
	}

	public int getTotalExecutedQtd() {
		int sum = 0;

		if (null != legStrategyList) {
			for (LegStrategyReport legStrategyReport : legStrategyList) {
				sum += legStrategyReport.getExecutedQuantity() == null ? 0 : legStrategyReport.getExecutedQuantity();
			}
		}

		return sum;
	}

	public int getTotalOtcQtd() {
		int sum = 0;

		if (null != legStrategyList) {
			for (LegStrategyReport legStrategyReport : legStrategyList) {
				sum += legStrategyReport.getOtcQuantity() == null ? 0 : legStrategyReport.getOtcQuantity();
			}
		}

		return sum;
	}
	
	public int getTotalRestingQuantity() {
		int sum = 0;

		if (null != legStrategyList) {
			for (LegStrategyReport legStrategyReport : legStrategyList) {
				sum += legStrategyReport.getRestingQuantity() == null ? 0 : legStrategyReport.getRestingQuantity();
			}
		}

		return sum;
	}

	public Long getTotalRestingRank() {
		long sum = 0;

		if (null != legStrategyList) {
			for (LegStrategyReport legStrategyReport : legStrategyList) {
				sum += legStrategyReport.getRestingRank() == null ? 0 : legStrategyReport.getRestingRank();
			}
		}

		return sum;
	}

	public int getLeggedQtd() {
		int sum = 0;

		if (null != legStrategyList) {
			for (LegStrategyReport LegStrategyReport : legStrategyList) {
				sum += LegStrategyReport.getLeggedQuantity();
			}
		}

		return sum;
	}
	
	public boolean getIsUnlegging() {
		boolean isUnlegging = false;
		
		if (getLegStrategyList() != null) {
			for (LegStrategyReport legStrategyReport: getLegStrategyList()) {
				if (legStrategyReport.getIsUnlegging()) {
					isUnlegging = true;
					break;
				}
			}
		}
		return isUnlegging;
	}

	public void setTotalQtd(int totalQtd) {
		this.totalQtd = totalQtd;
	}

	public Date getInitStart() {
		return initStart;
	}

	public boolean isTargetWarning() {
		return targetWarning;
	}

	public void setTargetWarning(boolean targetWarning) {
		this.targetWarning = targetWarning;
	}

	public Double getTargetDif() {
		return targetDif;
	}

	public void setTargetDif(Double targetDif) {
		this.targetDif = targetDif;
	}

	public Double getMarket() {
		return market;
	}

	public void setMarket(Double market) {
		this.market = market;
	}

	public String getContractsDisplayText() {
		StringBuffer displayText = new StringBuffer("");
	
		if (this.getLegStrategyList() != null) {
			for (Iterator<LegStrategyReport> iterator = this
					.getLegStrategyList().iterator(); iterator.hasNext();) {
				LegStrategyReport lg = iterator.next();
				
				if (displayText.length() == 0) {
					displayText.append(lg.getContract());	
				} else {
					if (lg.getContract()!=null && lg.getContract().length() > 3) {
						displayText.append(lg.getContract().substring(3));
					} else {
						displayText.append(lg.getContract());
					}
				}				
				
				if (iterator.hasNext() && displayText.length() > 0) {
					displayText.append("/");
				}
			}
		}

		return displayText.toString();
	}	
	
	public boolean isPopup() {
		return isPopup;
	}

	public void setPopup(boolean isPopup) {
		this.isPopup = isPopup;
	}	
	
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	// Using in html page for id controls and after push / subscriber update
	// information
	private String getRowId() {
		return this.engineId.toString() + "_" + this.strategyId.toString();
	}	
	
	private String getHtmlRowdId() {
		return getRowId() + "_";
	}
	
	public String getRowKey() {
		return this.getRowId();
	}
	
	public String getCancelHtmlId() {
		return (getHtmlRowdId() + "cancel");
	}

	public String getCancelColumnHtmlId() {
		return (getHtmlRowdId() + "columnCancel");
	}

	public String getStatusHtmlId() {
		return (getHtmlRowdId() + "status");
	}

	public String getStatusDisplayHtmlId() {
		return (getHtmlRowdId() + "statusDisplay");
	}
	
	public String getExecutedPercentHtmlId() {
		return (getHtmlRowdId() + "executedPercentage");
	}

	public String getInstrumentHtmlId() {
		return (getHtmlRowdId() + "instrument");
	}

	public String getLeggedPriceHtmlId() {
		return (getHtmlRowdId() + "leggedPrice");
	}

	public String getQuantityRemainHtmlId() {
		return (getHtmlRowdId() + "remainingQuantity");
	}

	public String getExecutedQuantityHtmlId() {
		return (getHtmlRowdId() + "executedQuantity");
	}

	public String getAveragePriceHtmlId() {
		return (getHtmlRowdId() + "averagePrice");
	}

	public String getOtcQuantityHtmlId() {
		return (getHtmlRowdId() + "otcQuantity");
	}

	public String getOtcPriceHtmlId() {
		return (getHtmlRowdId() + "otcPrice");
	}

	public String getPoQuantityHtmlId() {
		return (getHtmlRowdId() + "poQuantity");
	}

	public String getPoPriceHtmlId() {
		return (getHtmlRowdId() + "poPrice");
	}

	public String getRankHtmlId() {
		return (getHtmlRowdId() + "rank");
	}

	public String getTargetHtmlId() {
		return (getHtmlRowdId() + "target");
	}

	public String getTargetExecutedHtmlId() {
		return (getHtmlRowdId() + "targetExecuted");
	}

	public String getTotalQuantityHtmlId() {
		return (getHtmlRowdId() + "totalQuantity");
	}

	public String getExecutedPercentageHtmlId() {
		return (getHtmlRowdId() + "executedPercentage");
	}

	public String getExecutedTargetHtmlId() {
		return (getHtmlRowdId() + "executedTarget");
	}

	public String getLeggedQuantityHtmlId() {
		return (getHtmlRowdId() + "leggedQuantity");
	}

	public String getTotalQuqntityHtmlId() {
		return (getHtmlRowdId() + "totalQuantity");
	}
	
	public String getStartTimeHtmlId() {
		return (getHtmlRowdId() + "startTime");
	}

	public String getEndTimeHtmlId() {
		return (getHtmlRowdId() + "endTime");
	}

	public String getTextHtmlId() {
		return (getHtmlRowdId() + "text");
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((engineId == null) ? 0 : engineId.hashCode());
		result = prime * result
				+ ((strategyId == null) ? 0 : strategyId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StrategyReport other = (StrategyReport) obj;
		if (engineId == null) {
			if (other.engineId != null)
				return false;
		} else if (!engineId.equals(other.engineId))
			return false;
		if (strategyId == null) {
			if (other.strategyId != null)
				return false;
		} else if (!strategyId.equals(other.strategyId))
			return false;
		return true;
	}
}