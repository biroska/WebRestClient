package com.ubs.manhatthan.model;

import java.io.Serializable;

import com.ubs.manhatthan.manager.lmdsadapter.SimulationItem;
import com.ubs.manhatthan.manager.simulator.multileg.ReturnMultilegSimulation;

@SuppressWarnings("serial")
public class PushMarketWatchFields implements Serializable {
	
	private Long id;
	
	private Long tabViewId;
	
	private Long lastQuantity;
	
	private String lastQuantityStyle;
	
	private Double lastPrice;
	
	private String lastPriceStyle;
	
	private String buyQuantity;
	
	private String buyQuantityStyle;
	
	private Double buyPrice;
	
	private String buyPriceStyle;
	
	private String sellQuantity;
	
	private String sellQuantityStyle;
	
	private Double sellPrice;
	
	private String sellPriceStyle;

	public PushMarketWatchFields (SimulationItem simulationItem) {
		if (simulationItem != null) {
			if (simulationItem.isOnlySymbol()) {
				this.lastQuantity = simulationItem.getLastQty();
				this.lastPrice = simulationItem.getLastPx();
				this.buyQuantity = simulationItem.getBuyQty();
				this.buyPrice = simulationItem.getBuyPx();
				this.sellQuantity = simulationItem.getSellQty();
				this.sellPrice = simulationItem.getSellPx();
			} else {				
				this.lastQuantity = null;
				this.lastPrice = null;
				
				ReturnMultilegSimulation buyReturnMultSimulation = simulationItem.getBuyReturnMultilegSimulation();
				ReturnMultilegSimulation sellReturnMultSimulation = simulationItem.getSellReturnMultilegSimulation();
				
				this.sellPrice = buyReturnMultSimulation.getMarketTarget();
				this.sellQuantity = buyReturnMultSimulation.getAvailableQuantity();

				this.buyPrice = sellReturnMultSimulation.getMarketTarget();
				this.buyQuantity = sellReturnMultSimulation.getAvailableQuantity();				
			}
		}
	}
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	public Long getTabViewId() {
		return tabViewId;
	}

	public void setTabViewId(Long tabViewId) {
		this.tabViewId = tabViewId;
	}

	public String getHtmlRowId() {
		if (this.id!=null && this.tabViewId!=null) {
			return ".mkt_" +  this.id.toString() + "_" + 
				this.tabViewId.toString() + "_";
		}else{
			return "";
		}
		
	}

	public Long getLastQuantity() {
		return lastQuantity;
	}

	public void setLastQuantity(Long lastQuantity) {
		this.lastQuantity = lastQuantity;
	}
	
	public String getLastQuantityHtmlId() {
		return (getHtmlRowId() + "LQ");
	}

	public Double getLastPrice() {
		return lastPrice;
	}

	public String getLastPriceHtmlId() {
		return (getHtmlRowId() + "LP");
	}

	public void setLastPrice(Double lastPrice) {
		this.lastPrice = lastPrice;
	}

	public String getBuyQuantity() {
		return buyQuantity;
	}

	public void setBuyQuantity(String buyQuantity) {
		this.buyQuantity = buyQuantity;
	}

	public String getBuyQuantityHtmlId() {
		return (getHtmlRowId() + "BQ");
	}

	public Double getBuyPrice() {
		return buyPrice;
	}

	public void setBuyPrice(Double buyPrice) {
		this.buyPrice = buyPrice;
	}

	public String getBuyPriceHtmlId() {
		return (getHtmlRowId() + "BP");
	}

	public String getSellQuantity() {
		return sellQuantity;
	}

	public void setSellQuantity(String sellQuantity) {
		this.sellQuantity = sellQuantity;
	}

	public String getSellQuantityHtmlId() {
		return (getHtmlRowId() + "SQ");
	}

	public Double getSellPrice() {
		return sellPrice;
	}

	public void setSellPrice(Double sellPrice) {
		this.sellPrice = sellPrice;
	}

	public String getSellPriceHtmlId() {
		return (getHtmlRowId() + "SP");
	}

	public String getLastQuantityStyle() {
		return lastQuantityStyle;
	}

	public void setLastQuantityStyle(String lastQuantityStyle) {
		this.lastQuantityStyle = lastQuantityStyle;
	}

	public String getLastPriceStyle() {
		return lastPriceStyle;
	}

	public void setLastPriceStyle(String lastPriceStyle) {
		this.lastPriceStyle = lastPriceStyle;
	}

	public String getBuyQuantityStyle() {
		return buyQuantityStyle;
	}

	public void setBuyQuantityStyle(String buyQuantityStyle) {
		this.buyQuantityStyle = buyQuantityStyle;
	}

	public String getBuyPriceStyle() {
		return buyPriceStyle;
	}

	public void setBuyPriceStyle(String buyPriceStyle) {
		this.buyPriceStyle = buyPriceStyle;
	}

	public String getSellQuantityStyle() {
		return sellQuantityStyle;
	}

	public void setSellQuantityStyle(String sellQuantityStyle) {
		this.sellQuantityStyle = sellQuantityStyle;
	}

	public String getSellPriceStyle() {
		return sellPriceStyle;
	}

	public void setSellPriceStyle(String sellPriceStyle) {
		this.sellPriceStyle = sellPriceStyle;
	}
}