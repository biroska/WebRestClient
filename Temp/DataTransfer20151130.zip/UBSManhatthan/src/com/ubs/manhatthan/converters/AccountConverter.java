package com.ubs.manhatthan.converters;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import com.ubs.manhatthan.mock.Mock;
import com.ubs.manhatthan.model.Account;
import com.ubs.manhatthan.service.Facade;

@FacesConverter(value="accountConverter")
public class AccountConverter implements Converter {

    Facade facade = new Mock();
    
    @Override
    public Object getAsObject(FacesContext context, UIComponent component, String value) {
    	Account c = facade.getAccountById(value);
        return c;
    }

    @Override
    public String getAsString(FacesContext context, UIComponent component, Object value) {
    	if (value != null) {
    		return String.valueOf(((Account) value).getNumber());
    	} else {
    		return null;    	
    	}
    }

}