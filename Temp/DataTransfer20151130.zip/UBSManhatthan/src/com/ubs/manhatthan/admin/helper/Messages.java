package com.ubs.manhatthan.admin.helper;

public final class Messages {

	static final String msgRequiredId = new String("Id field is required!");
	static final String msgRequiredEngine = new String("Engine field is required!");
	static final String msgRequiredHost = new String("Host field is required!");
	static final String msgRequiredIp = new String("Ip field is required!");
	static final String msgRequiredPort = new String("Port field is required!");
	static final String msgRequiredLogPath = new String("LogPath field is required!");
	static final String msgRequiredChannelId = new String("Channel Id field is required!");
	static final String msgRequiredSenderCompId = new String("SenderCompId field is required!");
	static final String msgRequiredIncrementalHost = new String("Incremental Host field is required!");
	static final String msgRequiredIncrementalPort = new String("Incremental Port field is required!");
	static final String msgRequiredRecoveryHost = new String("Recovery Host field is required!");
	static final String msgRequiredRecoveryPort = new String("Recovery Port field is required!");
	static final String msgRequiredInstDefinitionHost = new String("Inst Definition Host field is required!");
	static final String msgRequiredInstDefinitionPort = new String("Inst Definition Port field is required!");
	static final String msgRequiredAccount = new String("Account field is required!");
	
	static final String msgValidatorEngine = new String("The field Engine must be greather than 1!");
	static final String msgValidatorChannel = new String("The field Channel Id must be greather than 1!");
	
	public static String getMessageForRequiredFieldId() {
		return msgRequiredId;
	}

	public static String getMessageForRequiredFieldEngine() {
		return msgRequiredEngine;
	}

	public static String getMessageForRequiredFieldHost() {
		return msgRequiredHost;
	}

	public static String getMessageForRequiredFieldIp() {
		return msgRequiredIp;
	}

	public static String getMessageForRequiredFieldPort() {
		return msgRequiredPort;
	}

	public static String getMessageForRequiredFieldLogPath() {
		return msgRequiredLogPath;
	}

	public static String getMessageForRequiredFieldChannelId() {
		return msgRequiredChannelId;
	}

	public static String getMessageForRequiredFieldSenderCompId() {
		return msgRequiredSenderCompId;
	}

	public static String getMessageForRequiredFieldIncrementalHost() {
		return msgRequiredIncrementalHost;
	}

	public static String getMessageForRequiredFieldIncrementalPort() {
		return msgRequiredIncrementalPort;
	}

	public static String getMessageForRequiredFieldRecoveryHost() {
		return msgRequiredRecoveryHost;
	}

	public static String getMessageForRequiredFieldRecoveryPort() {
		return msgRequiredRecoveryPort;
	}

	public static String getMessageForRequiredFieldInstDefinitionHost() {
		return msgRequiredInstDefinitionHost;
	}

	public static String getMessageForRequiredFieldInstDefinitionPort() {
		return msgRequiredInstDefinitionPort;
	}

	public static String getMessageForRequiredFieldAccount() {
		return msgRequiredAccount;
	}
	
	public static String getMessageForValidatorFieldEngine() {
		return msgValidatorEngine;
	}

	public static String getMessageForValidatorFieldChannel() {
		return msgValidatorChannel;
	}
}