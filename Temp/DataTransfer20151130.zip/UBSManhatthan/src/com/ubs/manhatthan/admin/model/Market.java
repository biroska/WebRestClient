package com.ubs.manhatthan.admin.model;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Market implements Serializable {

	private Long id;
	private String strategy;
	private String contract;
	private int lq;
	private Long lp;
	private int bq;
	private long bp;
	private long sp;
	private int sq;
	
	public Market(Long long1, String string, long l){}

	public Market(String strategy, String contract, int lq, long lp, int bq, long bp, long sp, int sq ) {
		super();
		this.strategy = strategy;
		this.contract = contract;
		this.lq = lq;
		this.lp = lp;
		this.bq = bq;
		this.bp = bp;
		this.sp = sp;
		this.sq = sq;

	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	public String getStrategy() {
		return strategy;
	}

	public void setStrategy(String strategy) {
		this.strategy = strategy;
	}

	public String getContract() {
		return contract;
	}

	public void setContract(String contract) {
		this.contract = contract;
	}

	public int getLq() {
		return lq;
	}

	public void setLq(int lq) {
		this.lq = lq;
	}

	public Long getLp() {
		return lp;
	}

	public void setLp(Long lp) {
		this.lp = lp;
	}

	public int getBq() {
		return bq;
	}

	public void setBq(int bq) {
		this.bq = bq;
	}

	public long getBp() {
		return bp;
	}

	public void setBp(long bp) {
		this.bp = bp;
	}

	public long getSp() {
		return sp;
	}

	public void setSp(long sp) {
		this.sp = sp;
	}

	public int getSq() {
		return sq;
	}

	public void setSq(int sq) {
		this.sq = sq;
	}

	@Override
	public String toString() {
		return "Market [strategy=" + strategy + ", contract=" + contract + ", lq=" + lq + ", lp=" + lp + ", bq=" + bq + ", sp=" + sp + ", sq=" + sq + "]";
	}
	
}
