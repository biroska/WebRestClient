package com.ubs.manhatthan.admin.beans;

import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.event.ActionEvent;

import com.ubs.manhatthan.admin.mock.Mock;
import com.ubs.manhatthan.admin.model.Engine;
import com.ubs.manhatthan.admin.model.ExchangeType;
import com.ubs.manhatthan.admin.model.OrderEntry;
import com.ubs.manhatthan.admin.service.Facade;

@SuppressWarnings("serial")
@ViewScoped
@ManagedBean(name="orderEntryBean")
public class OrderEntryBean extends BaseBean {

	private List<OrderEntry> orderEntries;
	private OrderEntry selectedOrderEntry;
		
	private List<OrderEntry> filteredOrderEntries;

	private List<Engine> engines;
	
	private List<ExchangeType> exchangeTypes;

	private Facade facade = new Mock();
	
	public OrderEntryBean() {	
		selectedOrderEntry = new OrderEntry();
		
		orderEntries = new ArrayList<OrderEntry>(facade.getOrderEntry());

		engines = new ArrayList<Engine>(facade.getEnginers());

		exchangeTypes = new ArrayList<ExchangeType>(facade.getExchangeTypes());
	}
	
	public List<OrderEntry> getOrderEntries() {
		return orderEntries;
	}

	public void setOrderEntries(List<OrderEntry> orderEntries) {
		this.orderEntries = orderEntries;
	}

	public OrderEntry getSelectedOrderEntry() {
		return selectedOrderEntry;
	}

	public void setSelectedOrderEntry(OrderEntry selectedOrderEntry) {
		this.selectedOrderEntry = selectedOrderEntry;
	}

	public List<OrderEntry> getFilteredOrderEntries() {
		return filteredOrderEntries;
	}

	public void setFilteredOrderEntries(List<OrderEntry> filteredOrderEntries) {
		this.filteredOrderEntries = filteredOrderEntries;
	}
	
	public Engine getEngine() {
		return this.selectedOrderEntry.getEngine();
	}
	
	public void setEngine(Engine engine) {
		this.selectedOrderEntry.setEngine(engine);
	}
	
	public List<Engine> getEngines() {
		return engines;
	}
	
	public ExchangeType getExchangeType() {
		return this.selectedOrderEntry.getExchangeType();
	}
	
	public void setExchangeType(ExchangeType exchangeType) {
		this.selectedOrderEntry.setExchangeType(exchangeType);
	}
	
	public List<ExchangeType> getExchangeTypes() {
		return exchangeTypes;
	}

	public void newOrderEntry(ActionEvent actionEvent) {
		this.selectedOrderEntry = new OrderEntry(0, "" , "", 0, "", "", "", false);
	}
	
	public void addOrderEntry(ActionEvent actionEvent) {		
		boolean recordExists = false;
		
		if (this.selectedOrderEntry != null) {
			for (OrderEntry item: this.orderEntries) {
				recordExists = (selectedOrderEntry.getId() == item.getId());
				
				if (recordExists) break;
			}
			
			if (recordExists) {
				this.warnMessage("Item already registered!");
			} else {
				this.orderEntries.add(this.selectedOrderEntry);				
			}
		}
	}

	public void deleteOrderEntry(ActionEvent actionEvent) {		
		this.orderEntries.remove(this.selectedOrderEntry);
	}

	public void saveOrderEntry(ActionEvent actionEvent) {

	}

	public Facade getFacade() {
		return facade;
	}

	public void setFacade(Facade facade) {
		this.facade = facade;
	}
}