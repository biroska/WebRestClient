package com.ubs.manhatthan.admin.model;


public class User {

	private String name;
	private String login;
	private String password;
	private String profile;
	private String bmfCode;
	private int bovespaCode;
	private boolean enabled;	
	
	public User(){}
	
	public User(String name, String login, String profile, String bmfCode, int bovespaCode, boolean eneabled) {
		super();
		this.name = name;
		this.login = login;
		this.profile = profile;
		this.bmfCode = bmfCode;
		this.bovespaCode = bovespaCode;
		this.enabled = eneabled;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}


	public String getProfile() {
		return profile;
	}

	public void setProfile(String profile) {
		this.profile = profile;
	}

	public String getBmfCode() {
		return bmfCode;
	}

	public void setBmfCode(String bmfCode) {
		this.bmfCode = bmfCode;
	}

	public int getBovespaCode() {
		return bovespaCode;
	}

	public void setBovespaCode(int bovespaCode) {
		this.bovespaCode = bovespaCode;
	}

	public boolean getEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}
	
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "User [name=" + name + ", login=" + login + ", password=" + password + ", profile=" + profile
				+ ", bmfCode=" + bmfCode + ", bovespaCode=" + bovespaCode + ", enabled=" + enabled + "]";
	}

}
