package com.ubs.manhatthan.admin.beans;

import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.event.ActionEvent;

import com.ubs.manhatthan.admin.mock.Mock;
import com.ubs.manhatthan.admin.model.Account;
import com.ubs.manhatthan.admin.model.AccountSession;
import com.ubs.manhatthan.admin.service.Facade;

@SuppressWarnings("serial")
@ViewScoped
@ManagedBean(name="accountBean")
public class AccountBean extends BaseBean {

	private List<Account> accounts;
	private Account selectedAccount;
		
	private List<Account> filteredAccounts;

	private List<AccountSession> accountSessions;
		
	private Facade facade = new Mock();
	
	public AccountBean() {
		selectedAccount = new Account();
		
		accounts = new ArrayList<Account>(facade.getAccounts());
				
		accountSessions = new ArrayList<AccountSession>(facade.getAccountSessions());
	}
		
	public List<Account> getAccounts() {
		return accounts;
	}

	public void setAccounts(List<Account> accounts) {
		this.accounts = accounts;
	}

	public Account getSelectedAccount() {
		return selectedAccount;
	}

	public void setSelectedAccount(Account selectedAccount) {
		this.selectedAccount = selectedAccount;
	}

	public List<Account> getFilteredAccounts() {
		return filteredAccounts;
	}

	public void setFilteredAccounts(List<Account> filteredAccounts) {
		this.filteredAccounts = filteredAccounts;
	}

	public List<Account> completeAccount(String account) {
		return new ArrayList<Account>(facade.getAccounts());
	}
		
	public List<AccountSession> getAccountSessions() {
		return accountSessions;
	}

	public AccountSession getAccountSession() {
		return selectedAccount.getAccountSession();
	}

	public void setAccountSession(AccountSession accountSession) {
		this.selectedAccount.setAccountSession(accountSession);
	}

	public void newAccount(ActionEvent actionEvent) {		
		this.selectedAccount = new Account();
	}
	
	public void deleteAccount(ActionEvent actionEvent) {		
		this.accounts.remove(this.selectedAccount);
	}
	
	public void addAccount(ActionEvent actionEvent) {
		boolean recordExists = false;
		
		if (this.selectedAccount != null) {
			for (Account item: this.accounts) {
				recordExists = (selectedAccount.getNumber() != null) && (selectedAccount.getNumber().equals(item.getNumber()));
				
				if (recordExists) break;
			}
			
			if (recordExists) {
				this.warnMessage("Item already registered!");
			} else {
				this.accounts.add(this.selectedAccount);				
			}
		}
	}

	public void saveAccount(ActionEvent actionEvent) {

	}

	public Facade getFacade() {
		return facade;
	}

	public void setFacade(Facade facade) {
		this.facade = facade;
	}
}