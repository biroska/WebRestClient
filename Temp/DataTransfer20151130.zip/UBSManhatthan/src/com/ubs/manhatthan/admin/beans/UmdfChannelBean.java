package com.ubs.manhatthan.admin.beans;

import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.event.ActionEvent;

import com.ubs.manhatthan.admin.mock.Mock;
import com.ubs.manhatthan.admin.model.UmdfChannel;
import com.ubs.manhatthan.admin.model.ChannelType;
import com.ubs.manhatthan.admin.model.ExchangeType;
import com.ubs.manhatthan.admin.service.Facade;

@SuppressWarnings("serial")
@ViewScoped
@ManagedBean(name="umdfChannelBean")
public class UmdfChannelBean extends BaseBean {

	private List<UmdfChannel> umdfChannels;
	private UmdfChannel selectedUmdfChannel;

	private List<UmdfChannel> filteredUmdfChannels;
	
	private List<ChannelType> channelTypes;

	private List<ExchangeType> exchangeTypes;

	private Facade facade = new Mock();
	
	public UmdfChannelBean() {
		selectedUmdfChannel = new UmdfChannel();
		
		umdfChannels = new ArrayList<UmdfChannel>(facade.getUmdfChannel());
		
		channelTypes = new ArrayList<ChannelType>(facade.getChannelTypes());

		exchangeTypes = new ArrayList<ExchangeType>(facade.getExchangeTypes());
	}

	public List<UmdfChannel> getUmdfChannels() {
		return umdfChannels;
	}

	public void setUmdfChannels(List<UmdfChannel> recovery) {
		this.umdfChannels = recovery;
	}

	public UmdfChannel getSelectedUmdfChannel() {
		return  selectedUmdfChannel;
	}

	public void setSelectedUmdfChannel(UmdfChannel selectedUmdfChannel) {
		this.selectedUmdfChannel = selectedUmdfChannel;
	}

	public List<UmdfChannel> getFilteredUmdfChannels() {
		return filteredUmdfChannels;
	}

	public void setFilteredUmdfChannels(List<UmdfChannel> filteredUmdfChannels) {
		this.filteredUmdfChannels = filteredUmdfChannels;
	}
	
	public ChannelType getChannelType() {
		return this.selectedUmdfChannel.getChannelType();
	}
	
	public void setChannelType(ChannelType channelType) {
		this.selectedUmdfChannel.setChannelType(channelType);
	}
	
	public List<ChannelType> getChannelTypes() {
		return channelTypes;
	}
	
	public ExchangeType getExchangeType() {
		return this.selectedUmdfChannel.getExchangeType();
	}
	
	public void setExchangeType(ExchangeType exchangeType) {
		this.selectedUmdfChannel.setExchangeType(exchangeType);;
	}
	
	public List<ExchangeType> getExchangeTypes() {
		return exchangeTypes;
	}

	public void newUmdfChannel(ActionEvent actionEvent) {
		this.selectedUmdfChannel = new UmdfChannel(0, "", new Long(0), "", new Long(0), "", new Long(0));
	}
	
	public void addUmdfChannel(ActionEvent actionEvent) {		
		boolean recordExists = false;
		
		if (this.selectedUmdfChannel != null) {
			for (UmdfChannel item: this.umdfChannels) {
				recordExists = (selectedUmdfChannel.getId() == item.getId());
				
				if (recordExists) break;
			}
			
			if (recordExists) {
				this.warnMessage("Item already registered!");
			} else {
				this.umdfChannels.add(this.selectedUmdfChannel);				
			}
		}
	}

	public void deleteUmdfChannel(ActionEvent actionEvent) {		
		this.umdfChannels.remove(this.selectedUmdfChannel);
	}

	public void saveUmdfChannel(ActionEvent actionEvent) {

	}

	public Facade getFacade() {
		return facade;
	}

	public void setFacade(Facade facade) {
		this.facade = facade;
	}
}