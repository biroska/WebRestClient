package com.ubs.manhatthan.admin.beans;

import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.event.ActionEvent;

import com.ubs.manhatthan.admin.mock.Mock;
import com.ubs.manhatthan.admin.model.Engine;
import com.ubs.manhatthan.admin.model.ExchangeType;
import com.ubs.manhatthan.admin.model.Recovery;
import com.ubs.manhatthan.admin.service.Facade;

@SuppressWarnings("serial")
@ViewScoped
@ManagedBean(name="recoveryBean")
public class RecoveryBean extends BaseBean {

	private List<Recovery> recoveries;
	private Recovery selectedRecovery;

	private List<Recovery> filteredRecoveries;

	private List<Engine> engines;

	private List<ExchangeType> exchangeTypes;

	private Facade facade = new Mock();
	
	public RecoveryBean() {
		selectedRecovery = new Recovery();
		
		recoveries = new ArrayList<Recovery>(facade.getRecovery());

		engines = new ArrayList<Engine>(facade.getEnginers());

		exchangeTypes = new ArrayList<ExchangeType>(facade.getExchangeTypes());
	}

	public List<Recovery> getRecoveries() {
		return recoveries;
	}

	public void setRecoveries(List<Recovery> recovery) {
		this.recoveries = recovery;
	}

	public Recovery getSelectedRecovery() {
		return selectedRecovery;
	}

	public void setSelectedRecovery(Recovery selectedRecovery) {
		this.selectedRecovery = selectedRecovery;
	}
	
	public List<Recovery> getFilteredRecoveries() {
		return filteredRecoveries;
	}

	public void setFilteredRecoveries(List<Recovery> filteredRecoveries) {
		this.filteredRecoveries = filteredRecoveries;
	}

	public Engine getEngine() {
		return this.selectedRecovery.getEngine();
	}
	
	public void setEngine(Engine engine) {
		this.selectedRecovery.setEngine(engine);
	}
	
	public List<Engine> getEngines() {
		return engines;
	}
	
	public ExchangeType getExchangeType() {
		return this.selectedRecovery.getExchangeType();
	}
	
	public void setExchangeType(ExchangeType exchangeType) {
		this.selectedRecovery.setExchangeType(exchangeType);
	}
	
	public List<ExchangeType> getExchangeTypes() {
		return exchangeTypes;
	}

	public void newRecovery(ActionEvent actionEvent) {
		this.selectedRecovery = new Recovery(0, "", new Long(0),"");
	}
	
	public void addRecovery(ActionEvent actionEvent) {		
		boolean recordExists = false;
		
		if (this.selectedRecovery != null) {
			for (Recovery item: this.recoveries) {
				recordExists = (selectedRecovery.getId() == item.getId());
				
				if (recordExists) break;
			}
			
			if (recordExists) {
				this.warnMessage("Item already registered!");
			} else {
				this.recoveries.add(this.selectedRecovery);				
			}
		}
	}

	public void deleteRecovery(ActionEvent actionEvent) {		
		this.recoveries.remove(this.selectedRecovery);
	}

	public void saveRecovery(ActionEvent actionEvent) {

	}

	public Facade getFacade() {
		return facade;
	}

	public void setFacade(Facade facade) {
		this.facade = facade;
	}
}