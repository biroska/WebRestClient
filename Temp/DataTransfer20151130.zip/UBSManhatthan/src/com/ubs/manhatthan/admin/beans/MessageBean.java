package com.ubs.manhatthan.admin.beans;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ApplicationScoped;

import com.ubs.manhatthan.admin.helper.Messages;;

@ApplicationScoped
@ManagedBean(name="messageBean")
public class MessageBean {
	public MessageBean() {		

	}
	
	public String getMessageForRequiredId() {
		return Messages.getMessageForRequiredFieldId();
	}
	
	public String getMessageForRequiredEngine() {
		return Messages.getMessageForRequiredFieldEngine();
	}

	public String getMessageForRequiredHost() {
		return Messages.getMessageForRequiredFieldHost();
	}

	public String getMessageForRequiredIp() {
		return Messages.getMessageForRequiredFieldIp();
	}

	public String getMessageForRequiredPort() {
		return Messages.getMessageForRequiredFieldPort();
	}

	public String getMessageForRequiredLogPath() {
		return Messages.getMessageForRequiredFieldLogPath();
	}

	public String getMessageForRequiredChannelId() {
		return Messages.getMessageForRequiredFieldChannelId();
	}

	public String getMessageForRequiredSenderCompId() {
		return Messages.getMessageForRequiredFieldSenderCompId();
	}

	public String getMessageForRequiredIncrementalHost() {
		return Messages.getMessageForRequiredFieldIncrementalHost();
	}

	public String getMessageForRequiredIncrementalPort() {
		return Messages.getMessageForRequiredFieldIncrementalPort();
	}

	public String getMessageForRequiredRecoveryHost() {
		return Messages.getMessageForRequiredFieldRecoveryHost();
	}

	public String getMessageForRequiredRecoveryPort() {
		return Messages.getMessageForRequiredFieldRecoveryPort();
	}

	public String getMessageForRequiredInstDefinitionHost() {
		return Messages.getMessageForRequiredFieldInstDefinitionHost();
	}

	public String getMessageForRequiredInstDefinitionPort() {
		return Messages.getMessageForRequiredFieldInstDefinitionPort();
	}

	public String getMessageForRequiredAccount() {
		return Messages.getMessageForRequiredFieldAccount();
	}

	public String getMessageForValidatorEngine() {
		return Messages.getMessageForValidatorFieldEngine();
	}

	public String getMessageForValidatorChannel() {
		return Messages.getMessageForValidatorFieldChannel();
	}
}