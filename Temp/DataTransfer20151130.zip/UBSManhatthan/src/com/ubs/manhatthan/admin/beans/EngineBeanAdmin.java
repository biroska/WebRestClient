package com.ubs.manhatthan.admin.beans;

import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import com.ubs.manhatthan.admin.mock.Mock;
import com.ubs.manhatthan.admin.model.Engine;
import com.ubs.manhatthan.admin.service.Facade;

@SessionScoped
@ManagedBean(name="engineBeanAdmin")
public class EngineBeanAdmin {
	
	public EngineBeanAdmin(){
		
		engines = new ArrayList<Engine>(facade.getEnginers());
	}

	private List<Engine> engines;
	private Engine selectedEngine;
	
	private List<Engine> filteredEngines;
	
	private Facade facade = new Mock();

	public Engine getSelectedEngine() {
		return selectedEngine;
	}

	public void setSelectedEngine(Engine selectedEngine) {
		this.selectedEngine = selectedEngine;
	}

	public List<Engine> getEngines() {
		return engines;
	}

	public void setEngines(List<Engine> enginers) {
		this.engines = enginers;
	}

	public List<Engine> getFilteredEngines() {
		return filteredEngines;
	}

	public void setFilteredEngines(List<Engine> filteredEngines) {
		this.filteredEngines = filteredEngines;
	}

	public Facade getFacade() {
		return facade;
	}

	public void setFacade(Facade facade) {
		this.facade = facade;
	}
}
	
	
