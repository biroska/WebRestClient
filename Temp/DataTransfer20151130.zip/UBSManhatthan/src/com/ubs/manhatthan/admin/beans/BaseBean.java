package com.ubs.manhatthan.admin.beans;

import java.io.Serializable;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

@SuppressWarnings("serial")
public class BaseBean implements Serializable {

	public void infoMessage(String messageText) {
		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, messageText, null);
		FacesContext.getCurrentInstance().addMessage(null, message);
	}

	public void warnMessage(String messageText) {
		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_WARN, messageText, null);
		FacesContext.getCurrentInstance().addMessage(null, message);
	}

	public void errorMessage(String messageText) {
		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, messageText, null);
		FacesContext.getCurrentInstance().addMessage(null, message);
	}

	public void fatalMessage(String messageText) {
		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_FATAL, messageText, null);
		FacesContext.getCurrentInstance().addMessage(null, message);
	}
}