package com.ubs.manhatthan.admin.model;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Recovery implements Serializable {

	private int id;
	private Engine engine;
	private ExchangeType exchangeType;
	private String host;
	private long port;
	private String senderCompld;
	
	
	public Recovery() {
		this.initialize();
	}
	
	public Recovery(int id, String host, long port, String senderCompld) {
		super();

		this.initialize();
		
		this.id = id;
		this.host = host;
		this.port = port;
		this.senderCompld = senderCompld;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Engine getEngine() {
		return engine;
	}

	public void setEngine(Engine engine) {
		this.engine = engine;
	}

	public ExchangeType getExchangeType() {
		return exchangeType;
	}


	public void setExchangeType(ExchangeType exchangeType) {
		this.exchangeType = exchangeType;
	}


	public String getHost() {
		return host;
	}


	public void setHost(String host) {
		this.host = host;
	}

	public long getPort() {
		return port;
	}

	public void setPort(long port) {
		this.port = port;
	}

	public String getSenderCompld() {
		return senderCompld;
	}

	public void setSenderCompld(String senderCompld) {
		this.senderCompld = senderCompld;
	}

	@Override
	public String toString() {
		return "Recovery [engine=" + engine.getId() + ", exchangeType=" + exchangeType.getName() + ", host=" + host + ", port=" + port + 
				", senderCompld=" + senderCompld + "]";
	}

	private void initialize() {
		engine = new Engine();
		
		exchangeType = new ExchangeType();
	}
}
