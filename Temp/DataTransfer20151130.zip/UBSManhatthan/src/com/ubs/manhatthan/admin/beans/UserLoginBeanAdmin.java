package com.ubs.manhatthan.admin.beans;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.servlet.http.HttpSession;

import com.ubs.manhatthan.beans.UBSCommonBean;

@SessionScoped
@ManagedBean(name="userLoginBeanAdmin")
public class UserLoginBeanAdmin extends UBSCommonBean {     
    private String username;
     
    private String password;
 
    public String getUsername() {
        return username;
    }
 
    public void setUsername(String username) {
        this.username = username;
    }
 
    public String getPassword() {
        return password;
    }
 
    public void setPassword(String password) {
        this.password = password;
    }
   
    public String login() {
        
    	boolean loggedIn = false;
         
        if(username != null && username.equals("admin") && password != null && password.equals("admin")) {
            loggedIn = true;
        } else {
        	addMsgValidationWarn("Login Error", "Credentials invalid");
        }
         
        if (loggedIn) {
            return "mainAdmin.xhtml";
        } else {
            return "loginAdmin.xhtml";
        }                
   }
    
   public String logout()
   {
	   	HttpSession session = UBSCommonBean.getSession();
	    session.invalidate();	   
	    return "loginAdmin.xhtml?faces-redirect=true";   
   }
}