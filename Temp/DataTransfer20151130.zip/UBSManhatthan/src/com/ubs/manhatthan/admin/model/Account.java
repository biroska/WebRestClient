package com.ubs.manhatthan.admin.model;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Account implements Serializable {

	private Long number;
	private String name;
	private AccountSession accountSession;
	
	public Account() {
		this.initialize();
	}
	
	public Account(Long number, String name) {
		super();
	
		this.initialize();

		this.number = number;
		this.name = name;
	}

	public Long getNumber() {
		return number;
	}

	public void setNumber(Long number) {
		this.number = number;
	}
	

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public AccountSession getAccountSession() {
		return accountSession;
	}

	public void setAccountSession(AccountSession accountSession) {
		this.accountSession = accountSession;
	}

	@Override
	public String toString() {
		return "Account [number=" + number + ", name=" + name + "]";
	}

	private void initialize() {
		accountSession = new AccountSession();
	}
}
