package com.ubs.manhatthan.admin.beans;

import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.event.ActionEvent;

import com.ubs.manhatthan.admin.mock.Mock;
import com.ubs.manhatthan.admin.model.Engine;
import com.ubs.manhatthan.admin.service.Facade;

@SuppressWarnings("serial")
@ViewScoped
@ManagedBean(name="engineBean")
public class EngineBean extends BaseBean {

	private List<Engine> engines;
	private Engine selectedEngine;
	
	private List<Engine> filteredEngines;
	
	private Facade facade = new Mock();
	
	public EngineBean() {		
		engines = new ArrayList<Engine>(facade.getEnginers());
	}

	public List<Engine> getEngines() {
		return engines;
	}

	public void setEngines(List<Engine> enginers) {
		this.engines = enginers;
	}

	public List<Engine> getFilteredEngines() {
		return filteredEngines;
	}

	public void setFilteredEngines(List<Engine> filteredEngines) {
		this.filteredEngines = filteredEngines;
	}

	public Engine getSelectedEngine() {
		return selectedEngine;
	}

	public void setSelectedEngine(Engine selectedEngine) {
		this.selectedEngine = selectedEngine;
	}

	public void newEngine(ActionEvent actionEvent) {		
		this.selectedEngine = new Engine(0, "", 0, "");
	}
	
	public void deleteEngine(ActionEvent actionEvent) {		
		this.engines.remove(this.selectedEngine);
	}
	
	public void addEngine(ActionEvent actionEvent) {
		boolean recordExists = false;
		
		if (this.selectedEngine != null) {
			for (Engine item: this.engines) {
				recordExists = (selectedEngine.getId() == item.getId());
				
				if (recordExists) break;
			}
			
			if (recordExists) {
				this.warnMessage("Item already registered!");
			} else {
				this.engines.add(this.selectedEngine);				
			}
		}
	}

	public void saveEngine(ActionEvent actionEvent) {

	}

	public Facade getFacade() {
		return facade;
	}

	public void setFacade(Facade facade) {
		this.facade = facade;
	}
}