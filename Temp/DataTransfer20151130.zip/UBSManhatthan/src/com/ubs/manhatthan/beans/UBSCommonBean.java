package com.ubs.manhatthan.beans;

import java.util.List;

import javax.faces.application.Application;
import javax.faces.application.FacesMessage;
import javax.faces.application.ViewHandler;
import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.ubs.manhatthan.mock.Mock;
import com.ubs.manhatthan.model.Account;
import com.ubs.manhatthan.model.StrategyType;
import com.ubs.manhatthan.model.User;

public class UBSCommonBean {
	
	Mock facade = new Mock();
	
	protected List<StrategyType> strategyTypes;
	
	 // Actions
    public List<Account> completeAccount(){
        return facade.getListAllAcconts();
    }
    
	
	public void logoutSession() {
	    FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
	}

	public static HttpSession getSession() {
		return (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false);
	}
	
	public static String mainPageTrader(){
		return "main.xhtml"+forceRedirect();
	}
	
	public static String forceRedirect(){
		return "?faces-redirect=true";
	}

	public static HttpServletRequest getRequest() {
		return (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
	}

	public static String getUserName() {
		HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false);
		return session.getAttribute("username").toString();
	}
	
	public static User getUserSession() {
		UserLoginBean loginBean =  (UserLoginBean) getRequest().getSession().getAttribute("userLoginBean");
		User user = loginBean.getUserTrader();
		return user;
	}


	public static String getUserId() {
		HttpSession session = getSession();
		if (session != null)
			return (String) session.getAttribute("userid");
		else
			return null;
	}
	
	
	
	public static <T> Object getObjectSession(String sessionAtribute){        
	    HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();    
	    HttpSession session = request.getSession(true);    
	    return session.getAttribute(sessionAtribute);               
	}
	
	protected void refresh() {  
        FacesContext context = FacesContext.getCurrentInstance();  
        Application application = context.getApplication();  
        ViewHandler viewHandler = application.getViewHandler();  
        UIViewRoot viewRoot = viewHandler.createView(context, context.getViewRoot().getViewId());  
        context.setViewRoot(viewRoot);  
        context.renderResponse();  
    }
	
	public static void addMsgValidationSucess(String msgTitle, String msgCause){        
		FacesMessage message = null;
	    message = new FacesMessage(FacesMessage.SEVERITY_INFO, msgTitle, msgCause);

	    FacesContext.getCurrentInstance().addMessage(null, message);            
	}  
	
	public static void addMsgValidationError(String msgTitle, String msgCause){        
		FacesMessage message = null;
	    message = new FacesMessage(FacesMessage.SEVERITY_ERROR, msgTitle, msgCause);

	    FacesContext.getCurrentInstance().addMessage(null, message);            
	}  
	
	public static void addMsgValidationWarn(String msgTitle, String msgCause){        
		FacesMessage message = null;
	    message = new FacesMessage(FacesMessage.SEVERITY_WARN, msgTitle, msgCause);

	    FacesContext.getCurrentInstance().addMessage(null, message);            
	}

	public List<StrategyType> getStrategyTypes() {
		return strategyTypes;
	}

	public void setStrategyTypes(List<StrategyType> strategyTypes) {
		this.strategyTypes = strategyTypes;
	}
}