package com.ubs.manhatthan.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import com.ubs.manhatthan.mock.Mock;
import com.ubs.manhatthan.model.Strategy;
import com.ubs.manhatthan.service.Facade;

@SessionScoped
@ManagedBean(name="strategyBean")
public class StrategyBean extends UBSCommonBean implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3148807863083961072L;
	
	private Strategy selectedStrategy;
				
	private ArrayList<String> marketsToFilter = new ArrayList<String>();
	
	private Facade facade = new Mock();
	
	public StrategyBean(){
		
		marketsToFilter = changeToArrayString(new ArrayList<Strategy>(facade.getStrategies()));
	}

	public List<String> completeString(String query) {
		List<String> results = new ArrayList<String>();
		for (int i = 0; i < 10; i++)
			results.add(query + i);
		return results;
	}
	
		
	private ArrayList<String> changeToArrayString( List<Strategy> list ){
		ArrayList<String> stringList = new ArrayList<String>();
		
		for (Strategy item : list ) {
			stringList.add( item.getName() );
		}
		
		return stringList;
	}

	public Strategy getSelectedStrategy() {
		return selectedStrategy;
	}


	public void setSelectedStrategy(Strategy selectedStrategy) {
		this.selectedStrategy = selectedStrategy;
	}


	public ArrayList<String> getMarketsToFilter() {
		return marketsToFilter;
	}


	public void setMarketsToFilter(ArrayList<String> marketsToFilter) {
		this.marketsToFilter = marketsToFilter;
	}
}
	
	
