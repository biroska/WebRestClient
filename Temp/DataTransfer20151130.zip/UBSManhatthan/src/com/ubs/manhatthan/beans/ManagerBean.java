package com.ubs.manhatthan.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;

import com.ubs.manhatthan.common.enuns.SideEnum;
import com.ubs.manhatthan.mock.Mock;
import com.ubs.manhatthan.model.Account;
import com.ubs.manhatthan.model.Manager;
import com.ubs.manhatthan.model.StrategyType;
import com.ubs.manhatthan.model.StrategyTypeLeg;

@SessionScoped
@ManagedBean(name="managerBean")
public class ManagerBean extends UBSCommonBean implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4696450270615840861L;

	private Manager selManager;
	private StrategyTypeLeg selectStrategyTypeLeg;
	private StrategyType selectStrategyType;
	private List<Manager> managers;
	private List<Manager> selectManagers;
	private String idSelectStrategyType;
	private Account selectedAccount;
	
	private long marketingExec;

		
	Mock facade = new Mock();
	
	public ManagerBean(){
		super.strategyTypes = new ArrayList<StrategyType>(facade.getStrategyTypes());
		selectStrategyTypeLeg = new StrategyTypeLeg();
		selManager = new Manager();
		selectStrategyTypeLeg = new StrategyTypeLeg();
		managers = new ArrayList<Manager>( facade.getManagers()  );
	}
	
	public void loadFormAddStrategy() {
		for (StrategyType strategyType : super.strategyTypes) {
			if (strategyType.getDefaultStrag()==1) {
				selectStrategyType = strategyType;
				idSelectStrategyType = strategyType.getId().toString();
			}
		}
		refresh();
	}
	
	public void changeComboStrategy(ValueChangeEvent event) {
		
		String tw = (String) event.getNewValue();
		
		idSelectStrategyType = tw;

		for (StrategyType strategyType : super.strategyTypes) {
			if (Long.valueOf(tw).equals(strategyType.getId())) {
				selectStrategyType = strategyType;
				break;
			}
		}
		refresh();
	}
	
	public void changeSellBuy() {

		for (int i = 0; i < selectStrategyType.getStrategyTypeLegList().size(); i++) {
			if (null != selectStrategyType.getStrategyTypeLegList().get(i).getLegged().getTotalQty() && selectStrategyType.getStrategyTypeLegList().get(i).getLegged().getTotalQty() < 0) {
				long positivo = selectStrategyType.getStrategyTypeLegList().get(i).getLegged().getTotalQty() * -1;
				selectStrategyType.getStrategyTypeLegList().get(i).getLegged().setTotalQty(positivo);
				selectStrategyType.getStrategyTypeLegList().get(i).setDefaultSide(2);
			}else{
				selectStrategyType.getStrategyTypeLegList().get(i).setDefaultSide(1);
			}
		}
	}
	
	public void changeSellBuyEdit() {
		for (int i = 0; i < selManager.getStrategyType().getStrategyTypeLegList().size(); i++) {
			if (null != selManager.getStrategyType().getStrategyTypeLegList().get(i).getLegged().getTotalQty() && 
					selManager.getStrategyType().getStrategyTypeLegList().get(i).getLegged().getTotalQty() < 0) {
			
				long positivo = selManager.getStrategyType().getStrategyTypeLegList().get(i).getLegged().getTotalQty() * -1;
				selManager.getStrategyType().getStrategyTypeLegList().get(i).getLegged().setTotalQty(positivo);
				selManager.getStrategyType().getStrategyTypeLegList().get(i).setDefaultSide(2);
			}else{
				selManager.getStrategyType().getStrategyTypeLegList().get(i).setDefaultSide(1);
			}
		}
	}

	
	public String onChangeOTC(){
		for (int i = 0; i <managers.size(); i++) {
			if (managers.get(i).getId()==selManager.getId()) {
				for (int f = 0; f < managers.get(i).getStrategyType().getStrategyTypeLegList().size(); f++) {
					if (managers.get(i).getStrategyType().getStrategyTypeLegList().get(f).getId() == selectStrategyTypeLeg.getId()){
						managers.get(i).getStrategyType().getStrategyTypeLegList().get(f).setLegged(selectStrategyTypeLeg.getLegged());
						break;
					}
				}
				break;
			}
		}
		
		refresh();
		return "main.xhtml?faces-redirect=true";
		
	}
	
	public void changeOrderBSOTC() {
			if (SideEnum.BUY.getCode().equals(selectStrategyTypeLeg.getDefaultSide())) {
				selectStrategyTypeLeg.setDefaultSide(2);
			} else {
				selectStrategyTypeLeg.setDefaultSide(1);
			}
	}
	
	public void changeOrderBSUnLegged() {
		if (SideEnum.BUY.getCode().equals(selectStrategyTypeLeg.getDefaultSide())) {
			selectStrategyTypeLeg.setDefaultSide(2);
		} else {
			selectStrategyTypeLeg.setDefaultSide(1);
		}
	}
	
	public void editStrategy(ActionEvent actionEvent) {
		for (int i = 0; i < managers.size(); i++) {
			if (selManager.getId() == managers.get(i).getId()) {
				managers.get(i).setStrategyType(selManager.getStrategyType());
				break;
			}	
		}
		refresh();
	}
	
	public void addStrategy(ActionEvent actionEvent) {
		Manager e = new Manager();
		e.setStrategyType(selectStrategyType);
		managers.add(e);
		refresh();
	}
	
	public void submitSend() {
		addMsgValidationSucess("Ordens Send", "Send Sucess");
		refresh();
	}
	
	public void submitMarket() {
		addMsgValidationSucess("Ordens @Market", "Send @Market Sucess");
		refresh();
	}
	
	
	public void submitAllSend() {
		addMsgValidationSucess("Ordens Send", "Send Sucess");
		refresh();

	}
	
	public void submitAllMarket() {
		addMsgValidationSucess("Ordens @Market", "Send @Market Sucess");
		refresh();

	}

	public Manager getSelManager() {
		return selManager;
	}

	public void setSelManager(Manager selManager) {
		this.selManager = selManager;
	}

	public List<Manager> getManagers() {
		return managers;
	}

	public void setManagers(List<Manager> managers) {
		this.managers = managers;
	}

	public List<Manager> getSelectManagers() {
		return selectManagers;
	}

	public void setSelectManagers(List<Manager> selectManagers) {
		this.selectManagers = selectManagers;
	}

	public Mock getFacade() {
		return facade;
	}

	public void setFacade(Mock facade) {
		this.facade = facade;
	}

	public StrategyTypeLeg getSelectStrategyTypeLeg() {
		return selectStrategyTypeLeg;
	}

	public void setSelectStrategyTypeLeg(StrategyTypeLeg selectStrategyTypeLeg) {
		this.selectStrategyTypeLeg = selectStrategyTypeLeg;
	}

	public StrategyType getSelectStrategyType() {
		return selectStrategyType;
	}

	public void setSelectStrategyType(StrategyType selectStrategyType) {
		this.selectStrategyType = selectStrategyType;
	}

	public List<StrategyType> getStrategyTypes() {
		return strategyTypes;
	}

	public void setStrategyTypes(List<StrategyType> strategyTypes) {
		this.strategyTypes = strategyTypes;
	}

	public String getIdSelectStrategyType() {
		return idSelectStrategyType;
	}

	public void setIdSelectStrategyType(String idSelectStrategyType) {
		this.idSelectStrategyType = idSelectStrategyType;
	}

	public Account getSelectedAccount() {
		return selectedAccount;
	}

	public void setSelectedAccount(Account selectedAccount) {
		this.selectedAccount = selectedAccount;
	}

	public long getMarketingExec() {
		return marketingExec;
	}

	public void setMarketingExec(long marketingExec) {
		this.marketingExec = marketingExec;
	}
	
	
}