package com.ubs.manhatthan.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import com.ubs.manhatthan.mock.Mock;
import com.ubs.manhatthan.model.StrategyType;
import com.ubs.manhatthan.service.Facade;

@SuppressWarnings("serial")
@SessionScoped
@ManagedBean(name="strategyTypeBean")
public class StrategyTypeBean implements Serializable {

	private Map<String,String> strategyTypesNew;
	private StrategyType selectedStrategyType;
	private String text;
		
	private Facade facade = new Mock();
	
	public StrategyTypeBean(){		
		strategyTypesNew  = new HashMap<String, String>();
		strategyTypesNew.put("USA", "USA");
		strategyTypesNew.put("Germany", "Germany");
        strategyTypesNew.put("Brazil", "Brazil");

        new ArrayList<StrategyType>(facade.getStrategyTypes());
	}

	public List<String> completeString(String query) {
		List<String> results = new ArrayList<String>();
		for (int i = 0; i < 10; i++)
			results.add(query + i);
		return results;
	}

	public Map<String, String> getStrategyTypes() {
        return strategyTypesNew;
    }
	 
	public void setStrategyType(List<StrategyType> strategyTypes) {
	}

	public StrategyType getSelectedStrategyType() {
		return selectedStrategyType;
	}

	public void setSelectedMarket(StrategyType selectedStrategyType) {
		this.selectedStrategyType = selectedStrategyType;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public Facade getFacade() {
		return facade;
	}

	public void setFacade(Facade facade) {
		this.facade = facade;
	}
}
	
	
