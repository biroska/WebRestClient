package com.ubs.manhatthan.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import com.ubs.manhatthan.mock.Mock;
import com.ubs.manhatthan.model.ReportPriceDetail;
import com.ubs.manhatthan.service.Facade;

@SuppressWarnings("serial")
@SessionScoped
@ManagedBean(name="reportPriceBean")
public class ReportPriceBean implements Serializable {

	private List<ReportPriceDetail> reportPriceDetails;
	private ReportPriceDetail selectedReportPriceDetail;
	private String text;
		
	private Facade facade = new Mock();
	
	public ReportPriceBean(){		
		reportPriceDetails = new ArrayList<ReportPriceDetail>(facade.getReportPriceDetails());
	}
	
	public List<ReportPriceDetail> getRecords() {
		return reportPriceDetails;
	}

	public void setRecords(List<ReportPriceDetail> reportPriceDetails) {
		this.reportPriceDetails = reportPriceDetails;
	}

	public ReportPriceDetail getSelectedReportPriceDetail() {
		return selectedReportPriceDetail;
	}

	public void setSelectedReportPriceDetail(ReportPriceDetail selectedReportPriceDetail) {
		this.selectedReportPriceDetail = selectedReportPriceDetail;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public Facade getFacade() {
		return facade;
	}

	public void setFacade(Facade facade) {
		this.facade = facade;
	}
}
