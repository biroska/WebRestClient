package com.ubs.manhatthan.beans;

import java.io.Serializable;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import org.springframework.beans.factory.annotation.Autowired;

import com.ubs.manhatthan.model.User;

@SuppressWarnings("serial")
@SessionScoped
@ManagedBean(name = "userLoginBean")
public class UserLoginBean extends UBSCommonBean implements Serializable {

	@Autowired
	private User user;
	
	public UserLoginBean() {
		this.user = new User();
	}	
	

	public String login() {
		boolean loggedIn = false;

		if (null != user && null != user.getLogin() && user.getLogin().equals("admin") && user.getPassword() != null && user.getLogin().equals("admin") || user.getLogin().equals("bmfbovespa") && user.getPassword() != null && user.getLogin().equals("bmfbovespa")) {
			loggedIn = true;
		} else {
			addMsgValidationWarn("Loggin Error", "Invalid credentials");
		}

		if (loggedIn) {
			refresh();
			return "main.xhtml" + UBSCommonBean.forceRedirect();
		} else {
			return "login.xhtml" + UBSCommonBean.forceRedirect();
		}
	}

	public String logout() {
		logoutSession();
		return "login.xhtml" + UBSCommonBean.forceRedirect();
	}

	public User getUserTrader() {
		return user;
	}

	public void setUserTrader(User user) {
		this.user = user;
	}
}