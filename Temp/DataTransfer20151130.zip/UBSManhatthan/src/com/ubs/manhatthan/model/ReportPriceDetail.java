package com.ubs.manhatthan.model;

import com.ubs.manhatthan.trader.report.dto.*;

public class ReportPriceDetail implements IReportPriceDetail {

	String market;
	Double price;
	Integer quantity;
	String title;
	Double volume;
	String type;
	
	public ReportPriceDetail(String market, Double price,  Integer quantity, String title, Double volume, String type) {
		
		super();
		
		this.market = market;
		this.price = price;
		this.quantity = quantity;
		this.title = title;
		this.volume = volume;
		this.type = type;
	}

	public String getMarket() {
		return market;
	}

	public void setMarket(String market) {
		this.market = market;		
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;	
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;		
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;		
	}

	public Double getVolume() {
		return volume;
	}

	public void setVolume(Double volume) {
		this.volume = volume;
	}
}
