package com.ubs.manhatthan.model;

import java.io.Serializable;
import java.util.List;

public class StrategyType implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private boolean createStrategyInPause;

	private Long id;
	
	private Integer strategyCode;
	
	private String description;
	
	private Integer numberOfLegs;
	
	private int defaultStrag;
		
	private int totalQtd;
	
	private Account account;
	
	private String start;
	
	private String end; 
		
	private int status;
	
	private int percent;
	
	private long target;
	
	private long dif;
	
	private long efectiveTarget;
	
	private List<StrategyTypeLeg> strategyTypeLegList;
	
	public StrategyType() {
		super();
	}
	
	public  StrategyType(Long id, Integer strategyCode, String description, Integer numberOfLegs, int defaultStrag,
			List<StrategyTypeLeg> strategyTypeLegList, Account account, String start, String end, int status, int percent) {
		this.id = id;
		this.strategyCode = strategyCode;
		this.description = description;
		this.numberOfLegs = numberOfLegs;
		this.defaultStrag = defaultStrag;
		this.account = account;
		this.start = start;
		this.end = end;
		this.status = status;
		this.percent = percent;
		this.strategyTypeLegList = strategyTypeLegList;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Integer getStrategyCode() {
		return strategyCode;
	}

	public void setStrategyCode(Integer strategyCode) {
		this.strategyCode = strategyCode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getNumberOfLegs() {
		return numberOfLegs;
	}

	public void setNumberOfLegs(Integer numberOfLegs) {
		this.numberOfLegs = numberOfLegs;
	}

	public List<StrategyTypeLeg> getStrategyTypeLegList() {
		return strategyTypeLegList;
	}

	public void setStrategyTypeLegList(List<StrategyTypeLeg> strategyTypeLegList) {
		this.strategyTypeLegList = strategyTypeLegList;
	}

	public int getDefaultStrag() {
		return defaultStrag;
	}

	public void setDefaultStrag(int defaultStrag) {
		this.defaultStrag = defaultStrag;
	}
	
	public int getTotalQtd() {
		int sum = 0;
		totalQtd = 0;
		for (StrategyTypeLeg strategyTypeLeg : strategyTypeLegList) {
			sum += strategyTypeLeg.getLegged().getTotalQty();
		}
		totalQtd = sum;
		return totalQtd;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public String getStart() {
		return start;
	}

	public void setStart(String start) {
		this.start = start;
	}

	public String getEnd() {
		return end;
	}

	public void setEnd(String end) {
		this.end = end;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public int getPercent() {
		return percent;
	}

	public void setPercent(int percent) {
		this.percent = percent;
	}

	public void setTotalQtd(int totalQtd) {
		this.totalQtd = totalQtd;
	}

	public long getTarget() {
		return target;
	}

	public void setTarget(long target) {
		this.target = target;
	}

	public long getEfectiveTarget() {
		return efectiveTarget;
	}

	public void setEfectiveTarget(long efectiveTarget) {
		this.efectiveTarget = efectiveTarget;
	}

	public long getDif() {
		return dif;
	}

	public void setDif(long dif) {
		this.dif = dif;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public boolean isCreateStrategyInPause() {
		return createStrategyInPause;
	}

	public void setCreateStrategyInPause(boolean createStrategyInPause) {
		this.createStrategyInPause = createStrategyInPause;
	}
}
