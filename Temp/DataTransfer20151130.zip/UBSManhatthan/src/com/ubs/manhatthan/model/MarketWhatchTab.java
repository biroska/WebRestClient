package com.ubs.manhatthan.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class MarketWhatchTab  implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1351325431626026637L;

	private Long id;

	private String name;
	
	private String login;

	private List<Market> markets;

	public MarketWhatchTab() {
	}

	public MarketWhatchTab(Long id, String displayName, String name, List<Market> markets) {
		this.id = id;
		this.name = name;
		this.markets = markets;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Market> getMarkets() {
		if (null == markets) {
			markets = new ArrayList<Market>();
		}
		return markets;
	}

	public void setMarkets(List<Market> markets) {
		this.markets = markets;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

}
