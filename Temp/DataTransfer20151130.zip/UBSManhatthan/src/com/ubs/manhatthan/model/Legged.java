package com.ubs.manhatthan.model;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Legged implements Serializable {

	private String bs;
	private String contract;
	private long leggedPrice;
	private Long totalQty;
	private long qtyRemaining;
	private int qtyExec;
	private long averPrice;
	private int otcQtyExec; 
	private int otcPriceExec;
	private int poQty;
	private long poPrice;
	private int rank;
	private int clip;
	private int dv;
	private long target;
	private long efectiveTarget;
	private boolean po;

	public Legged() {
		super();
		this.contract = "";
		
	}

	public Legged(
			String contract, int leggedQty, long leggedPrice, Long totalQty, long qtyRemaining,
			int qtyExec, long averPrice, int otcQtyExec, int otcPriceExec, int poQty, long poPrice, int rank,
			long target, long efectiveTarget) 
	{
		super();
		this.contract = contract;
		this.leggedPrice = leggedPrice;
		this.totalQty = totalQty;
		this.qtyRemaining = qtyRemaining;
		this.qtyExec = qtyExec;
		this.averPrice = averPrice;
		this.otcQtyExec = otcQtyExec;
		this.otcPriceExec = otcPriceExec;
		this.poQty = poQty;
		this.poPrice = poPrice;
		this.rank = rank;
		this.target = target;
		this.efectiveTarget = efectiveTarget;
	}

	public String getBs() {
		return bs;
	}

	public void setBs(String bs) {
		this.bs = bs;
	}

	public String getContract() {
		return contract;
	}

	public void setContract(String contract) {
		this.contract = contract != null ? contract.toUpperCase():"";
	}

	public long getLeggedPrice() {
		return leggedPrice;
	}

	public void setLeggedPrice(long leggedPrice) {
		this.leggedPrice = leggedPrice;
	}

	public Long getTotalQty() {
		return totalQty;
	}

	public void setTotalQty(Long totalQty) {
		this.totalQty = totalQty;
	}

	public long getQtyRemaining() {
		return qtyRemaining;
	}

	public void setQtyRemaining(long qtyRemaining) {
		this.qtyRemaining = qtyRemaining;
	}

	public int getQtyExec() {
		return qtyExec;
	}

	public void setQtyExec(int qtyExec) {
		this.qtyExec = qtyExec;
	}

	public long getAverPrice() {
		return averPrice;
	}

	public void setAverPrice(long averPrice) {
		this.averPrice = averPrice;
	}

	public int getOtcQtyExec() {
		return otcQtyExec;
	}

	public void setOtcQtyExec(int otcQtyExec) {
		this.otcQtyExec = otcQtyExec;
	}

	public int getOtcPriceExec() {
		return otcPriceExec;
	}

	public void setOtcPriceExec(int otcPriceExec) {
		this.otcPriceExec = otcPriceExec;
	}

	public int getPoQty() {
		return poQty;
	}

	public void setPoQty(int poQty) {
		this.poQty = poQty;
	}

	public long getPoPrice() {
		return poPrice;
	}

	public void setPoPrice(long poPrice) {
		this.poPrice = poPrice;
	}

	public int getRank() {
		return rank;
	}

	public void setRank(int rank) {
		this.rank = rank;
	}

	public long getTarget() {
		return target;
	}

	public void setTarget(long target) {
		this.target = target;
	}

	public long getEfectiveTarget() {
		return efectiveTarget;
	}

	public void setEfectiveTarget(long efectiveTarget) {
		this.efectiveTarget = efectiveTarget;
	}

	@Override
	public String toString() {
		return "Legged [bs=" + bs + ", contract=" + contract + ", leggedPrice="
				+ leggedPrice + ", totalQty=" + totalQty + ", qtyRemaining=" + qtyRemaining + ", qtyExec=" + qtyExec
				+ ", averPrice=" + averPrice + ", otcQtyExec=" + otcQtyExec + ", otcPriceExec=" + otcPriceExec
				+ ", poQty=" + poQty + ", poPrice=" + poPrice + ", rank=" + rank + ", target=" + target
				+ ", efectiveTarget=" + efectiveTarget + "]";
	}

	public long getPreviusTotalQty() {
		return totalQty;
	}

	public int getClip() {
		return clip;
	}

	public void setClip(int clip) {
		this.clip = clip;
	}

	public int getDv() {
		return dv;
	}

	public void setDv(int dv) {
		this.dv = dv;
	}

	public boolean isPo() {
		return po;
	}

	public void setPo(boolean po) {
		this.po = po;
	}
}
