package com.ubs.manhatthan.model;

import java.io.Serializable;

public class StrategyTypeLeg implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long id;
		
	private Integer defaultSide;
	
	private Integer legSeq;
	
	private Legged legged;


	public StrategyTypeLeg(){}

	public StrategyTypeLeg(Long id,  Integer defaultSide, Integer legSeq, Legged legged) {
		super();
		this.id = id;
		this.defaultSide = defaultSide;
		this.legSeq = legSeq;
		this.legged = legged;
	}
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	

	public Integer getDefaultSide() {
		return defaultSide;
	}

	public void setDefaultSide(Integer defaultSide) {
		this.defaultSide = defaultSide;
	}

	public Integer getLegSeq() {
		return legSeq;
	}

	public void setLegSeq(Integer legSeq) {
		this.legSeq = legSeq;
	}
	
	public Legged getLegged() {
		return legged;
	}

	public void setLegged(Legged legged) {
		this.legged = legged;
	}
}