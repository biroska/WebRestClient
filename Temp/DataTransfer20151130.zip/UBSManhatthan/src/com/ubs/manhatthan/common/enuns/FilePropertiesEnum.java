package com.ubs.manhatthan.common.enuns;

public enum FilePropertiesEnum {
	
    MANHATTAN_PROPERTIES_DEV("C:\\UBS\\Dev\\projects\\UBS\\Manhattan\\Manager\\Manhattan.properties"),
    MANHATTAN_PROPERTIES_UAT("/opt/middleware/setup/investor/appdata/dat/PrecogBroker.properties"),
    MANHATTAN_PROPERTIES_PROD("/opt/middleware/setup/investor/appdata/dat/PrecogBroker.properties");

    String path;

    FilePropertiesEnum(String path) {
            this.path = path;
    }

    public String getPath() {
            return path;
    }
}