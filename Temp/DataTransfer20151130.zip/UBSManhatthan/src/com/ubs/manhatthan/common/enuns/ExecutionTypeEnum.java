package com.ubs.manhatthan.common.enuns;

public enum ExecutionTypeEnum{
	
    NEW                         ( 48 ), // 0
    CANCELED                    ( 52 ), // 4
    REPLACE                     ( 53 ), // 5
    REJECTED                    ( 56 ), // 8
    EXPIRED                     ( 67 ), // C
    RESTATED                    ( 68 ), // D
    TRADE                       ( 70 ), // F
    TRADE_CANCEL                ( 72 ); // H
    
    private final Integer code;
    
    private ExecutionTypeEnum( Integer code ) {
        this.code = code;
    }

    public Integer getCode() {
        return code;
    }
    
    public static ExecutionTypeEnum fromValue( Integer value ){
    	
		for (ExecutionTypeEnum item : ExecutionTypeEnum.values() ) {
			if ( item.getCode().equals( value ) ){
				return item;
			}
		}
		return null;
    }
}
