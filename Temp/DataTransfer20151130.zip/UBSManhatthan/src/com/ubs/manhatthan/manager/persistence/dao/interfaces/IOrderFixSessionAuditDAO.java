/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import com.ubs.manhatthan.manager.persistence.entities.audit.OrderFixSessionAudit;

/**
 * @author galdinoa
 *
 */
public interface IOrderFixSessionAuditDAO extends IGenericDAO<OrderFixSessionAudit, Long> {}
