/**
 * 
 */
package com.ubs.manhatthan.manager.dto;

import com.ubs.manhatthan.manager.enums.SideEnum;

public class ReceiveSymbolSyntheticItem {
	
	private String symbol;
	private Integer legSeq;
	private SideEnum side;
	
	public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	public Integer getLegSeq() {
		return legSeq;
	}
	public void setLegSeq(Integer legSeq) {
		this.legSeq = legSeq;
	}
	public SideEnum getSide() {
		return side;
	}
	public void setSide(SideEnum side) {
		this.side = side;
	}
}