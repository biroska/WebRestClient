/**
 * 
 */
package com.ubs.manhatthan.manager.cache;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import com.ubs.manhatthan.manager.lmdsadapter.SimulationItem;
import com.ubs.manhatthan.manager.utils.Util;

/**
 * @author galdinoa
 * 
 */
public class LmdsCache {

	// Maps for sending information from LMDS to the view
	/* symbol or synthetic */
	private static ConcurrentHashMap<String, SimulationItem> simulationItensMap;
	/* symbol *//* Lista de keys do simulationItensMap */
	private static ConcurrentHashMap<String, List<String>> listeningSimulationItens;

	private static Long requestId = 0L;
	private static Long maxRequestId = 9_223_372_036_854_775_807L;
	
	static {
//		This map associates the synthetic ( F16 / F18 ) with SimulationItem which represents
//		the values in market Watch panelSimulationItem
		simulationItensMap = new ConcurrentHashMap<String, SimulationItem>();
		
//		this map associates the symbol (DIF16) with a List< key from simulationItensMap >.
//		One entry of this map references a list with all synthetic/symbols which have this symbol( DIF16)
		listeningSimulationItens = new ConcurrentHashMap< String, List<String> >();
	}
	
	public static SimulationItem putSimulationItem( String key, SimulationItem item ){
		
		System.out.println( "\n===================== Begining ======================" );
		System.out.println( "\t key: " + key );
		System.out.println( "\t listeningSimulationItens: " + listeningSimulationItens );
		System.out.println( "\t simulationItensMap: " + simulationItensMap );
		System.out.println( "\t item: " + item );
		
		item = simulationItensMap.put( key, item );
		
		List<String> keyList = Util.extractKeyList( key );
		
		if ( keyList != null ){
		
			for (String element : keyList) {
				
				List<String> referencelist = listeningSimulationItens.get( element );
				
				if ( referencelist != null ){
					referencelist.add( key );
					
				} else {
					referencelist = new ArrayList<String>();
					referencelist.add( key );
					
					listeningSimulationItens.put( element, referencelist );
				}
			}
		}
		
		System.out.println( "===================== Endining ======================" );
		System.out.println( "\t listeningSimulationItens: " + listeningSimulationItens );
		System.out.println( "\t simulationItensMap: " + simulationItensMap );
		System.out.println( "===================================================== \n\n\n" );
		
//		listeningSimulationItens
		
		//Colocar entrada no HashMap simulationItensMap
		//Duas entradas no HashMap listeningSimulationItens
			//kye=DI1F17 e value=DI1F17|DI1F18
			//kye=DI1F18 e value=DI1F17|DI1F18
		
		return item;
	}
	
	public static List<SimulationItem> getSimulationListBySymbol( String symbol ){
		
		List<SimulationItem> simulationList = new ArrayList<SimulationItem>();
		
		List<String> syntheticKeyList = listeningSimulationItens.get( symbol );
		
		if ( syntheticKeyList == null || syntheticKeyList.isEmpty() )
			return null;
		
		for (String syntheticKey : syntheticKeyList) {
			
			SimulationItem auxSimulation = simulationItensMap.get( syntheticKey );
			
			if ( auxSimulation != null )
				simulationList.add( auxSimulation );
		}
		
		return simulationList.isEmpty() ? null : simulationList;
	}
	
	public static boolean listeningSimulationContainsKey( String symbol ){
		
		return listeningSimulationItens.containsKey( symbol );
	}
	
	public static boolean simulationItensMapContainsKey( String symbol ){
		
		return simulationItensMap.containsKey( symbol );
	}
	
	public Long generateRequestId(){
		
		if ( requestId >= maxRequestId ){
			requestId = -1L;
		}
		
		return requestId++;
	}
	
//	m�todos para mock, remover.... aim*
	
	public static String printSimulationItensMap(){
		return simulationItensMap.toString();
	}
	
	public static String printlisteningSimulationItens(){
		return listeningSimulationItens.toString();
	}

}