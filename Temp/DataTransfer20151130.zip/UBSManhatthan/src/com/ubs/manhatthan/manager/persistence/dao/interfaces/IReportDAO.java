/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import java.util.List;

import com.ubs.manhatthan.manager.persistence.entities.OrderTrade;

/**
 * @author galdinoa
 *
 */
public interface IReportDAO extends IGenericDAO<OrderTrade, Long> {

	List<OrderTrade> reportByStrategy(OrderTrade orderTrade);

	List<OrderTrade> reportByAverage(OrderTrade orderTrade);

	List<OrderTrade> reportByExecution(OrderTrade orderTrade);

	List<OrderTrade> reportByPrice(OrderTrade orderTrade);
}
