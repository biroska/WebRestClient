package com.ubs.manhatthan.manager.lmdsadapter.marketdata.basicimplementation;

import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.BookEntry;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.IncrementalBookUpdate;


/**
 * Basic incremental book update
 * 
 * @author pretof
 *
 */
public class BasicIncrementalBookUpdate implements IncrementalBookUpdate{

	private final IncrementalUpdateType updateType;
	private final int position;
	private final BookEntry entry;
	private final long incrementalID;
	
	public BasicIncrementalBookUpdate(IncrementalUpdateType updateType,
			int position, BookEntry entry, long incrementalID) {
		this.updateType = updateType;
		this.position = position;
		this.entry = entry;
		this.incrementalID = incrementalID;
	}

	@Override
	public IncrementalUpdateType getUpdateType() {
		return updateType;
	}

	@Override
	public int getPosition() {
		return position;
	}

	@Override
	public BookEntry getEntry() {
		return entry;
	}

	@Override
	public long getIncrementalID() {
		return this.incrementalID;
	}
	
}
