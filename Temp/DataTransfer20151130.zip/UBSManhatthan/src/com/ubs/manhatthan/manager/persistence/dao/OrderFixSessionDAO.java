package com.ubs.manhatthan.manager.persistence.dao;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.persistence.dao.audit.OrderFixSessionAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IExchangeDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IOrderFixSessionAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IOrderFixSessionDAO;
import com.ubs.manhatthan.manager.persistence.entities.Exchange;
import com.ubs.manhatthan.manager.persistence.entities.OrderFixSession;
import com.ubs.manhatthan.manager.persistence.entities.audit.OrderFixSessionAudit;

@Repository
@Scope("singleton")
public class OrderFixSessionDAO extends GenericDAO<OrderFixSession, Long> implements IOrderFixSessionDAO {
	
	@Autowired
	private IExchangeDAO exchangeDAO;

	@Autowired
	private IOrderFixSessionAuditDAO orderFixSessionAuditDAO;
	
	@Autowired
	private User user;
	
	@Override
	public OrderFixSession saveOrderFixSession( OrderFixSession orderFixSession ){
		
		ActionTypeEnum action = orderFixSession.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;

		orderFixSession  = update( orderFixSession );

		OrderFixSessionAudit ofsa = new OrderFixSessionAudit( orderFixSession, action, user.getLogin(), new Date() );
		
		orderFixSessionAuditDAO.save( ofsa );
		
		return orderFixSession;
	}
	
	public Long generateOrderFixSession( int qtd ){
		
		Long qtRegs = 0L;
		
		List<Exchange> allExchanges = exchangeDAO.findAll();
		
		for ( int i = 1; i<= qtd; i++ ){
			saveOrderFixSession(  new OrderFixSession( allExchanges.get( i % 2 ), "255.255.255." + i, 8070L + i, "BVMF_" + i, "UBS_" + i, "123456" ,"description" ) );
			qtRegs++;
		}
		
		return qtRegs;
	}
	
	public void setExchangeDAO(ExchangeDAO exchangeDAO) {
		this.exchangeDAO = exchangeDAO;
	}
	
	public void setOrderFixSessionAuditDAO(OrderFixSessionAuditDAO orderFixSessionAuditDAO) {
		this.orderFixSessionAuditDAO = orderFixSessionAuditDAO;
	}

	public void setUser(User user) {
		this.user = user;
	}
}
