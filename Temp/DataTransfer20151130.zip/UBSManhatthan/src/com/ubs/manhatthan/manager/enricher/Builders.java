/**
 * 
 */
package com.ubs.manhatthan.manager.enricher;

import java.util.Date;

import com.ubs.manhatthan.manager.enums.CommandTypeEnum;
import com.ubs.manhatthan.manager.enums.MessageTypeEnum;
import com.ubs.manhatthan.manager.mocks.MarketDataMock;
import com.ubs.manhatthan.manager.persistence.entities.CommandMessage;
import com.ubs.manhatthan.manager.persistence.entities.Header;
import com.ubs.manhatthan.manager.persistence.entities.LegStrategyReport;
import com.ubs.manhatthan.manager.persistence.entities.StrategyOrders;
import com.ubs.manhatthan.manager.persistence.entities.StrategyReport;
import com.ubs.manhatthan.manager.utils.Util;

/**
 * @author galdinoa
 *
 */
public class Builders {
	
	
	public Header buildHeader( MessageTypeEnum type, Long engineInstance, Long managerRequestId ){
		return new Header( type, engineInstance, Util.getManagerId(), managerRequestId );
	}
	
	public StrategyReport buildCreateModifyCancelStrategy( Header header, Long id ) throws Exception{
		
		if ( !header.isInitialized() )
			return null;
		
		StrategyReport report = new StrategyReport();
		
		report.setHeader( header );
		report.getId().setStrategyId( id );
		
		return report;
	}
	
	public StrategyOrders buildNewOrderSingle( Header header, LegStrategyReport leg ) throws Exception{
		
		if ( !header.isInitialized() || leg == null )
			return null;
		
		StrategyOrders order = new StrategyOrders();
		
		order.setHeader( header );
		
		order.getId().setOrderId( 0L );
		order.getId().setOrderDate( new Date() );
		order.getId().setEngineId( header.getEngineInstanceId() );
		
		order.setSymbol( MarketDataMock.getSymbol( leg.getInstrument() ) );
		order.setSide( leg.getSide() );
		order.setRouteId( leg.getRouteId() );
		order.setOrderType( leg.getOrderType() );
		order.setTimeInForce( leg.getTimeInForce() );
		order.setAccount( leg.getAccount() );
		
		order.setLegStrategyReport( leg );
		
		return order;
	}

	public StrategyOrders buildReportOrder( Header header, LegStrategyReport leg ) throws Exception{
		
		if ( !header.isInitialized() || leg == null )
			return null;
		
		StrategyOrders order = new StrategyOrders();
		
		order.setHeader( header );
		order.setStrategyId( leg.getId().getStrategyId() );
		order.setLegSeq( leg.getId().getLegSeq() );
		order.setSymbol( MarketDataMock.getSymbol( leg.getInstrument() ) );
		order.setExecutedQuantity( 100L );
		order.setAveragePrice( 15D );
		order.setSide( leg.getSide() );
		order.getId().setOrderId( 0L );
		order.setQuantity( 200L ); 
		
		return order; 
	}
	
	public StrategyOrders buildLeggedMessage( Header header, Long id ) throws Exception{
		
		if ( !header.isInitialized() || id == null )
			return null;
		
		StrategyOrders order = new StrategyOrders();
		
		order.setHeader( header );
		order.getId().setOrderId( id );
		
		return order;
	}
	
	public CommandMessage buildCommandMessage( Header header, CommandTypeEnum type ) throws Exception{
		
		if ( !header.isInitialized() || type == null )
			return null;
		
		CommandMessage commandMessage = new CommandMessage();
		
		commandMessage.setHeader( header );
		commandMessage.setCommandType( type );

		return commandMessage;
	}
}