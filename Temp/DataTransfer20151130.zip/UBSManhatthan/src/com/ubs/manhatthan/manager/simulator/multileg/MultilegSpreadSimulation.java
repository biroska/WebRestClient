package com.ubs.manhatthan.manager.simulator.multileg;

public class MultilegSpreadSimulation {

	public ReturnMultilegSimulation simulate(InputMultilegSimulation input) {

		ReturnMultilegSimulation returnMultilegSimulation = new ReturnMultilegSimulation();
		returnMultilegSimulation.setValid(true);
		
		return returnMultilegSimulation;
	}

}
