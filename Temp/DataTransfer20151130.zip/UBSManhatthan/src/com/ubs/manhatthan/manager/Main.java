/*
 * Main.java
 *
 *  Created on: Set 25, 2015
 *      Author: vanputtg
 */

package com.ubs.manhatthan.manager;

import java.io.FileNotFoundException;
import java.io.IOException;

import com.ubs.manhatthan.manager.converters.ConvertToProtobuffer;
import com.ubs.manhatthan.manager.enums.MessageTypeEnum;
import com.ubs.manhatthan.manager.facade.Manager;
import com.ubs.manhatthan.manager.lmdsadapter.adapter.AdapterConfigurationException;
import com.ubs.manhatthan.manager.lmdsadapter.adapter.AdapterRuntimeException;
import com.ubs.manhatthan.manager.network.client.NetworkClientManager;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_header_message;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_to_engine_message;
import com.ubs.manhatthan.manager.persistence.entities.StrategyOrders;
import com.ubs.manhatthan.manager.persistence.entities.StrategyReport;
import com.ubs.manhatthan.manager.service.ServiceException;
import com.ubs.manhatthan.manager.service.ServiceManager;

//Main Class
public class Main {
	
	//Local Objects
	static ServiceManager serviceManager = new ServiceManager();
	static volatile boolean dummy_bool = true;
	static LmdsExample lmdsExample = new LmdsExample();
	
	//Main function
	public static void main(String[] args) throws InterruptedException, ServiceException, FileNotFoundException, IOException, AdapterConfigurationException, AdapterRuntimeException{
		
		//Print start
		System.out.println("Starting engine...");
		
		//Initializing the LMDS Adapter
		lmdsExample.startLmdsAdapter("lmds-client-api.cfg");
		
		//Subscribing instruments
		lmdsExample.subscribeSymbol("WINZ15");
		lmdsExample.subscribeSymbol("DI1Z15");
		
		//ShutdownHook
		Runtime.getRuntime().addShutdownHook(new Thread() {public void run(){ exit();} });
		
		//Start & Register Network Service
		NetworkClientManager client = new NetworkClientManager("xsap6552vdap.sap.swissbank.com", 6000);
		serviceManager.registerService(client.getService());		

		//Start all services
		serviceManager.start(); //Sending logon
		
	
		
		//Start eu 
		
////		boolean goAhead = true;
//		int err = 0;
//		while(err < 7 ){
//		
//			try {
//				
//				client.send( buildToEngineMessage( client.getService().getHeader( pb_message_type_enum.PB_CREATE_STRATEGY, 1L ) ) );
//				
//				client.send( buildToEngineMessage( client.getService().getHeader( pb_message_type_enum.PB_NEW_ORDER, 1L ) ) );
//				
////				goAhead = false;
//			} catch (Exception e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
////				goAhead = false;
////				err++;
//			}
//			err++;
//		}

		//Main thread Work/Sleep
		while(dummy_bool) Thread.sleep(600000);
	}
	
	//Exit Method
    static void exit() {
    	
    	//Print stop
    	System.out.println("Stopping engine on shutdown...");
    	
    	//Stop all services
    	try {
			serviceManager.stop();
		
		} catch (ServiceException e) {
			
			System.out.println("Error while stopping engine" + e.toString());
		}
    }
    
    @SuppressWarnings("unused")
	private static pb_to_engine_message buildToEngineMessage( pb_header_message header ){
    	
    	pb_to_engine_message pbEngine = null;
    	
    	if ( header.isInitialized() ){
    	
    		// reject_create_modify_cancel_strategy_message
//    		REJECT_CREATE_STRATEGY, REJECT_MODIFY_STRATEGY e REJECT_CANCEL_STRATEGY
    		if ( ( header.getMessageType().getNumber() == MessageTypeEnum.REJECT_RESUME_STRATEGY.getCode() ) ||
    			 ( header.getMessageType().getNumber() == MessageTypeEnum.CREATE_STRATEGY.getCode() ) || 
    			 ( header.getMessageType().getNumber() == MessageTypeEnum.MODIFY_STRATEGY.getCode() ) ||
    			 ( header.getMessageType().getNumber() == MessageTypeEnum.CANCEL_STRATEGY.getCode() ) ) {

		    	Manager manager = new Manager();
		    	StrategyReport generateStrategyReport = manager.generateStrategyReport( 2L, 100);
		    	
		    	pb_to_engine_message pbStrategy = ConvertToProtobuffer.convertToStrategy( generateStrategyReport );
		    	
//		    	pbEngine = pb_to_engine_message.newBuilder()
//						   .setHeader( header )
//						   .setStrategy( pbStrategy )
//						   .build();
		    	
		    	
	    	} else
	    		if ( header.getMessageType().getNumber() == MessageTypeEnum.NEW_ORDER.getCode() ){
	    			
	    			StrategyOrders order = new StrategyOrders();
	    			
	    			pb_to_engine_message pbNewOrderSingle = ConvertToProtobuffer.convertToNewOrderSingle( order );
	    			
	    		}
	    }
    	
    	return pbEngine;
    }

}
