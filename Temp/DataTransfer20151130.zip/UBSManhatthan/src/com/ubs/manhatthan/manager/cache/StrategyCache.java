package com.ubs.manhatthan.manager.cache;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import com.ubs.manhatthan.manager.persistence.entities.LegStrategyReport;
import com.ubs.manhatthan.manager.persistence.entities.StrategyOrders;
import com.ubs.manhatthan.manager.persistence.entities.StrategyReport;
import com.ubs.manhatthan.manager.persistence.entities.id.LegStrategyReportPK;
import com.ubs.manhatthan.manager.persistence.entities.id.StrategyOrdersPK;
import com.ubs.manhatthan.manager.persistence.entities.id.StrategyReportPK;

public class StrategyCache {
	
//	Map to translate requestId from view to requestId of Engine 
	public static ConcurrentHashMap< String, Long > requestIdTranslator;
	
	public static ConcurrentHashMap< StrategyReportPK, StrategyReport > strategyReportMap;
	public static ConcurrentHashMap< LegStrategyReportPK, LegStrategyReport > legStrategyReportMap;
	public static ConcurrentHashMap< StrategyOrdersPK, StrategyOrders > strategyOrderMap;
	public static ConcurrentHashMap< StrategyOrdersPK, StrategyOrders > leggedOrderMap;
	
	public static ConcurrentHashMap< Long, StrategyReport > StrategyReportMapByRequestId;
	public static ConcurrentHashMap< Long, StrategyOrders > StrategyOrderMapByRequestId;
	
	private static ArrayList<StrategyReportPK> auxListStrategyReport;
	private static ArrayList<LegStrategyReportPK> auxListLegStrategyReport;
	
	static {
		
//		Map to translate requestId from view to requestId of Engine
		requestIdTranslator = new ConcurrentHashMap< String, Long >();
		
		// Map used to keep StrategyReport after persist
		strategyReportMap = new ConcurrentHashMap< StrategyReportPK, StrategyReport >();

		// Map used to keep LegStrategyReport after persist and avoid search the leg in all itens of strategyReportMap
		legStrategyReportMap = new ConcurrentHashMap< LegStrategyReportPK, LegStrategyReport >();
		
		// Map used to keep StrategyOrders after persist and avoid search the Order in all legs o each item of strategyReportMap
		strategyOrderMap = new ConcurrentHashMap< StrategyOrdersPK, StrategyOrders >();
		
		// Map used to keep Legged orders. This map is filled by the engine and consumed by view 
		leggedOrderMap = new ConcurrentHashMap< StrategyOrdersPK, StrategyOrders >();
		
//		Map used to keep the information before sending the message to Engine, these maps are used 
//		to retrieve the original information in case of a rejection message
		StrategyReportMapByRequestId = new ConcurrentHashMap< Long, StrategyReport >();
		StrategyOrderMapByRequestId = new ConcurrentHashMap< Long, StrategyOrders >();
		
		auxListStrategyReport = new ArrayList<StrategyReportPK>( strategyReportMap.keySet() );
		auxListLegStrategyReport = new ArrayList<LegStrategyReportPK>( legStrategyReportMap.keySet() );
	}
	
	
	public static void putLegStrategyList( List<LegStrategyReport> list ) {
		
		if ( list != null ){
			for (LegStrategyReport leg : list) {
				if ( !legStrategyReportMap.containsKey( leg.getId() ) ){
					legStrategyReportMap.put( leg.getId(), leg );
				}
			}
		}
	}
	
	public static List<LegStrategyReport> getLegStrategyReportByStrategyId( Long strategyId ){
		List<LegStrategyReport> list = new ArrayList<LegStrategyReport>();
		
		for ( LegStrategyReportPK pk : legStrategyReportMap.keySet() ) {
			if ( pk.getStrategyId().equals( strategyId ) )
				list.add( legStrategyReportMap.get( pk )  );
		}
		
		return list.isEmpty() ? null : list;
	}
	
	public static List<LegStrategyReport> getLegStrategyReportList( StrategyReport report ){
	
		if ( report == null || report.getId() == null )
			return null;
		
		List<LegStrategyReport> list = new ArrayList<LegStrategyReport>();
		
		for ( LegStrategyReportPK key : StrategyCache.legStrategyReportMap.keySet() ) {
			if ( key.getStrategyId().equals( report.getId() ) ){
				list.add( legStrategyReportMap.get( key ) );
			}
		}
		return list;
	}
	
	public static StrategyReport putStrategyReport( StrategyReport report ){
		
		if ( report != null ){
			
			strategyReportMap.put( report.getId(), report );
			
			if ( report.getLegStrategyList() != null && !report.getLegStrategyList().isEmpty() ){
				
				for (LegStrategyReport leg : report.getLegStrategyList() ) {
					legStrategyReportMap.put( leg.getId(), leg );
				}
			}
			
		}
		return report;
	}
		
//	m�todos para mock, remover.... aim*

	public static StrategyReportPK getStrategyReportByIndex( Integer index ){
		
		if ( strategyReportMap == null || strategyReportMap.isEmpty() ||
			 index == null || index < 0 )
			return null;
		
		auxListStrategyReport = new ArrayList<StrategyReportPK>( strategyReportMap.keySet() );
		
		if ( auxListStrategyReport.size() > index ){
			StrategyReportPK strategyReportPK = auxListStrategyReport.get( index );
			return strategyReportPK;
		}

		return null;
	}
	
	public static LegStrategyReport getLegStrategyReportByIndex( Integer index ){
		
		if ( index == null || index < 0 )
			return null;
		
		auxListLegStrategyReport = new ArrayList<LegStrategyReportPK>( legStrategyReportMap.keySet() );
			
		if ( auxListLegStrategyReport.size() > index ){
			return legStrategyReportMap.get( auxListLegStrategyReport.get( index ) );
		}
		
		return null;
	}
}