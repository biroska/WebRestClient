package com.ubs.manhatthan.manager.persistence.dao;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IRoleByProfileAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IRoleByProfileDAO;
import com.ubs.manhatthan.manager.persistence.entities.RoleByProfile;
import com.ubs.manhatthan.manager.persistence.entities.audit.RoleByProfileAudit;

@Repository
@Scope("singleton")
public class RoleByProfileDAO extends GenericDAO<RoleByProfile, Long> implements IRoleByProfileDAO {
	
	@Autowired
	private IRoleByProfileAuditDAO roleByProfileAuditDAO;
	
	@Autowired
	private User user;
	
	public RoleByProfile saveRoleByProfile( RoleByProfile role ){
		
		ActionTypeEnum action = role.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;

		role = update( role );

		RoleByProfileAudit pa = new RoleByProfileAudit( role, action, user.getLogin(), new Date() );
		
		roleByProfileAuditDAO.update( pa );
		
		return role;
	}

	public Long generate( int qtd ){
		
		Long qtRegs = 0L;
		
//		RoleDAO roleDAO = new RoleDAO();
//		ProfileDAO profileDAO = new ProfileDAO();
//		
//		List<Role> roleList = roleDAO.findAll();
//		List<Profile> profileList = profileDAO.findAll();
//		
//		for (int i = 0; i < roleList.size(); i++) {
//			saveRoleByProfile( new RoleByProfile( roleList.get( i % 4 ), profileList.get( i % 4) ) );
//			qtRegs++;
//		}
		
		return qtRegs;
	}
	
	public RoleByProfile getByIndex( int index ) {
		return findAll().get( index );
	}

	public void setRoleByProfileAuditDAO(IRoleByProfileAuditDAO roleByProfileAuditDAO) {
		this.roleByProfileAuditDAO = roleByProfileAuditDAO;
	}

	public void setUser(User user) {
		this.user = user;
	}
}