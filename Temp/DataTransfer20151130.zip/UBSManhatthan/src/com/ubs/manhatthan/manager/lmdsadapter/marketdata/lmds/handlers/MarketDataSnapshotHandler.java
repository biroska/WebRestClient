package com.ubs.manhatthan.manager.lmdsadapter.marketdata.lmds.handlers;

import quickfix.FieldNotFound;
import quickfix.field.SecurityExchange;
import quickfix.field.Symbol;
import quickfix.fix44.MarketDataSnapshotFullRefresh;
import quickfix.fix44.MarketDataSnapshotFullRefresh.NoMDEntries;

import com.ubs.manhatthan.manager.lmdsadapter.marketdata.manager.MDManager;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.manager.MDManagerFactory;

public class MarketDataSnapshotHandler implements Handler<MarketDataSnapshotFullRefresh>
{	
	private final MDEntryHandler entryHandler;

	public MarketDataSnapshotHandler()
	{
		this.entryHandler = new MDEntryHandler();
	}

	@Override
	public synchronized void handle(MarketDataSnapshotFullRefresh event)
	{		
		try
		{
			String symbol = event.getString(Symbol.FIELD);
			String exchange = event.getString(SecurityExchange.FIELD);
			
			MDManager manager = MDManagerFactory.getManager(exchange);
			
			this.entryHandler.setManager(manager, symbol);
				
			//
			// Reset book
			//
			NoMDEntries snapshotGroup = new NoMDEntries();
			
			for (int i = 1; i <= event.getInt(quickfix.field.NoMDEntries.FIELD); i++) {
				event.getGroup(i, snapshotGroup);
				this.entryHandler.handle(snapshotGroup);
			}
			
			
		} catch (FieldNotFound e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
