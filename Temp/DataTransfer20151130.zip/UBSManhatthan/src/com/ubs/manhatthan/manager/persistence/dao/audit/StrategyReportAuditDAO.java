package com.ubs.manhatthan.manager.persistence.dao.audit;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.criterion.Restrictions;

import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.persistence.dao.GenericDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IStrategyReportAuditDAO;
import com.ubs.manhatthan.manager.persistence.entities.LegStrategyReport;
import com.ubs.manhatthan.manager.persistence.entities.StrategyOrders;
import com.ubs.manhatthan.manager.persistence.entities.StrategyReport;
import com.ubs.manhatthan.manager.persistence.entities.audit.LegStrategyReportAudit;
import com.ubs.manhatthan.manager.persistence.entities.audit.StrategyOrdersAudit;
import com.ubs.manhatthan.manager.persistence.entities.audit.StrategyReportAudit;

//@Repository
//@Scope("singleton")
public class StrategyReportAuditDAO extends GenericDAO<StrategyReportAudit, Long> implements IStrategyReportAuditDAO {
	
	public StrategyReportAuditDAO(){}
	
	static {
		strategyOrdersAuditDAO = new StrategyOrdersAuditDAO();
		legStrategyReportAuditDAO = new LegStrategyReportAuditDAO();	
	}
	
//	@Autowired
//	private User user;
	
//	@Autowired
//	private IStrategyOrdersAuditDAO strategyOrdersAuditDAO;
	
//	@Autowired
//	private ILegStrategyReportAuditDAO legStrategyReportAuditDAO;
	
	private static StrategyOrdersAuditDAO strategyOrdersAuditDAO;
	private static LegStrategyReportAuditDAO legStrategyReportAuditDAO;
	
	@Override
	public void saveReportAudit( StrategyReport report ){
		
		Long legId = 0L;
		Long orderId = 0L;
		ActionTypeEnum legAction = null;
		ActionTypeEnum orderAction = null;
		List<StrategyOrdersAudit> lsoa = new ArrayList<StrategyOrdersAudit>();
		List<LegStrategyReportAudit> lsra = new ArrayList<LegStrategyReportAudit>();
		
//		Define StrategyReportAudit para persistencia
		Long idCount = countByCriteria( Restrictions.eq("origid", report.getId().getStrategyId() ) );
		
		ActionTypeEnum action = idCount == 0 ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;
		
//		StrategyReportAudit strategyReportAudit = new StrategyReportAudit( report, action,  user.getLogin(), new Date() );
		StrategyReportAudit strategyReportAudit = new StrategyReportAudit( report, action,  report.getLogin(), new Date() );
		
//		Define LegStrategyReportAudit para persistencia
		if ( report.getLegStrategyList() != null ){
			for (LegStrategyReport leg : report.getLegStrategyList() ) {
				
				legId = legStrategyReportAuditDAO.countByCriteria( Restrictions.eq("legSeq", leg.getId().getLegSeq() ) ,
																   Restrictions.eq("strategyReportId", leg.getId().getStrategyId() ) );
				
				legAction = legId == 0 ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;
				
//				LegStrategyReportAudit legAudit = new LegStrategyReportAudit( leg, legAction, user.getLogin(), new Date() );
				LegStrategyReportAudit legAudit = new LegStrategyReportAudit( leg, legAction, leg.getLogin(), new Date() );
				
				
				lsra.add( legAudit );
				
//				Define strategyOrdersAudit para persistencia
				if ( leg.getStrategyOrdersList() != null ){
					
					for (StrategyOrders order : leg.getStrategyOrdersList() ) {
						
						orderId = strategyOrdersAuditDAO.countByCriteria( Restrictions.eq("origid", order.getId().getOrderId() ) );
						
						orderAction = orderId == 0 ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;
						
//						lsoa.add( new StrategyOrdersAudit( order , orderAction, user.getLogin(), new Date() ) );
						lsoa.add( new StrategyOrdersAudit( order , orderAction, order.getLogin(), new Date() ) );
					}
				}
			}
		}

//		Gera registro na tabela de auditoria - Strategyreport
		update( strategyReportAudit );
		legStrategyReportAuditDAO.save( lsra );
		strategyOrdersAuditDAO.save( lsoa );
	}

//	public void setUser(User user) {
//		this.user = user;
//	}
//
//	public void setStrategyOrdersAuditDAO(StrategyOrdersAuditDAO strategyOrdersAuditDAO) {
//		this.strategyOrdersAuditDAO = strategyOrdersAuditDAO;
//	}
//
//	public void setLegStrategyReportAuditDAO(ILegStrategyReportAuditDAO legStrategyReportAuditDAO) {
//		this.legStrategyReportAuditDAO = legStrategyReportAuditDAO;
//	}
}