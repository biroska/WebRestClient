/**
 * 
 */
package com.ubs.manhatthan.manager.cache;

import java.util.HashMap;

import com.ubs.manhatthan.manager.lmdsadapter.LmdsManager;
import com.ubs.manhatthan.manager.network.client.NetworkClientManager;

/**
 * @author galdinoa
 *
 */
public class CacheHelper {
	
//	The manager can connect with several Engines  <EngineId, NetworkClient>
	public static HashMap< Long, NetworkClientManager > engineCommunicatorInstance;

//	The manager can connect with a unique LMDS Channel < ManagerId, LMDSManager >
	public static HashMap< Integer, LmdsManager > lmdsCommunicatorInstance;
	
	static {
		engineCommunicatorInstance = new HashMap< Long, NetworkClientManager>();
		lmdsCommunicatorInstance = new HashMap< Integer, LmdsManager>();
	}

}
