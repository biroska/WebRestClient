package com.ubs.manhatthan.manager.persistence.dao.audit;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.manager.persistence.dao.GenericDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IStrategyTypeAuditDAO;
import com.ubs.manhatthan.manager.persistence.entities.audit.StrategyTypeAudit;

@Repository
@Scope("singleton")
public class StrategyTypeAuditDAO extends GenericDAO<StrategyTypeAudit, Long> implements IStrategyTypeAuditDAO {}
