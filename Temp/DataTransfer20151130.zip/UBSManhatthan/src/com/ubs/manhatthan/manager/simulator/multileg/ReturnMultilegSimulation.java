package com.ubs.manhatthan.manager.simulator.multileg;

import java.util.ArrayList;
import java.util.List;

import com.ubs.manhatthan.manager.utils.Constant;

public class ReturnMultilegSimulation {
	
	public ReturnMultilegSimulation(){
		this.marketTarget = Constant.SIMULATION.INITIAL_TARGET;
		this.setOnlyTarget(false);
		this.setTargetDif(Constant.SIMULATION.INITIAL_TARGET);
		this.returnItens = new ArrayList<ReturnMultilegSimulationItem>();
		this.isValid = false;
		this.availableQuantity = Constant.SIMULATION.INITIAL_AVAILABLE_QUANTITY;
	}

	public Double getMarketTarget() {
		return marketTarget;
	}
	
	public void setMarketTarget(Double marketTarget) {
		this.marketTarget = marketTarget;
	}
	
	public boolean isOnlyTarget() {
		return onlyTarget;
	}

	public void setOnlyTarget(boolean onlyTarget) {
		this.onlyTarget = onlyTarget;
	}
	
	public Double getTargetDif() {
		return targetDif;
	}

	public void setTargetDif(Double targetDif) {
		this.targetDif = targetDif;
	}
	
	public List<ReturnMultilegSimulationItem> getReturnItens() {
		return returnItens;
	}
	
	public void setReturnItens(List<ReturnMultilegSimulationItem> itens) {
		this.returnItens = itens;
	}	

	public boolean isValid() {
		return isValid;
	}

	public void setValid(boolean isValid) {
		this.isValid = isValid;
	}
	
	public Integer getAvailableQuantity() {
		return availableQuantity;
	}

	public void setAvailableQuantity(Integer availableQuantity) {
		this.availableQuantity = availableQuantity;
	}

	private Double marketTarget;		// buyPrice / Sell Price
	private boolean onlyTarget;
	private Double targetDif;
	private Integer availableQuantity; // b/s Quantity
	private List<ReturnMultilegSimulationItem> returnItens;
	
	private boolean isValid;

	@Override
	public String toString() {
		return "ReturnMultilegSimulation [marketTarget=" + marketTarget
				+ ", onlyTarget=" + onlyTarget + ", targetDif=" + targetDif
				+ ", availableQuantity=" + availableQuantity + ", returnItens="
				+ returnItens + ", isValid=" + isValid + "]";
	}
}