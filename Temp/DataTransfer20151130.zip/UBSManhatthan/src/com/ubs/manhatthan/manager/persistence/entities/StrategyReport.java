package com.ubs.manhatthan.manager.persistence.entities;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import com.ubs.manhatthan.manager.persistence.entities.StrategyType;

import com.ubs.manhatthan.manager.persistence.entities.id.StrategyReportPK;

@Entity
@Table(name="TB_STRATEGY_REPORT")
public class StrategyReport implements Serializable, Strategy {
	
	private static final long serialVersionUID = 7886773494602837014L;

	public StrategyReport(){
		this.header = new Header();
		this.id = new StrategyReportPK();
	}
	
	@EmbeddedId
	private StrategyReportPK id;
	
//	@Column ( name = "STRATEGY_TYPE ", nullable=false)
//	private StrategyTypeEnum strategyType;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "STRATEGY_TYPE", nullable = false )
	private StrategyType strategyType;
	
	@Temporal ( TemporalType.TIMESTAMP )
	@Column ( name = "STRATEGY_TIMESTAMP", nullable=false )
	private Date strategyTimestamp;
	
	@Column ( name = "LOGIN", nullable=false, length = 64)
	private String login;
	
	@Temporal ( TemporalType.TIMESTAMP )
	@Column ( name = "START_TIME", nullable=false)
	private Date startTime;
	
	@Temporal ( TemporalType.TIMESTAMP )
	@Column ( name = "END_TIME", nullable=false)
	private Date endTime;
	
	@Column ( name = "EXECUTED_PERCENTAGE", columnDefinition= "Decimal(10,3)", nullable = false)
	private Double executedPercentage;
	
	@Column ( name = "TARGET_EXECUTED", columnDefinition= "Decimal(10,7)")
	private Double executedTarget;
	
	@Column ( name = "START_PAUSED", nullable=false)
	private Boolean startPaused;
	
	@Column ( name = "TEXT", length = 256)
	private String text;
	
	@Column ( name = "PRICE_LIMIT", columnDefinition= "Decimal(10,7)")
	private Double priceLimit;
	
	@Column ( name = "TARGET", columnDefinition= "Decimal(10,7)")
	private Double target;
	
	@Column ( name = "AGRESSIVINESS", columnDefinition= "Decimal(10,7)")
	private Double agressiviness;
	
	@Column ( name = "RISK_LEVEL")
	private Integer riskLevel;
	
	@Column ( name = "RESTING_LEVEL")
	private Integer restingLevel;
	
	@OneToMany(mappedBy = "strategyReport", fetch=FetchType.LAZY, cascade = CascadeType.ALL )
	private List<LegStrategyReport> legStrategyList;
	
	@Transient
	private Header header;
	
	public StrategyReportPK getId() {
		return id;
	}
	public void setId(StrategyReportPK id) {
		this.id = id;
	}
	
//	public StrategyTypeEnum getStrategyType() {
//		return strategyType;
//	}
//	public void setStrategyType(StrategyTypeEnum strategyType) {
//		this.strategyType = strategyType;
//	}
	
	public Date getStrategyTimestamp() {
		return strategyTimestamp;
	}

	public StrategyType getStrategyType() {
		return strategyType;
	}
	public void setStrategyType(StrategyType strategyType) {
		this.strategyType = strategyType;
	}
	public void setStrategyTimestamp(Date strategyTimestamp) {
		this.strategyTimestamp = strategyTimestamp;
	}

	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	public Date getStartTime() {
		return startTime;
	}
	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}
	public Date getEndTime() {
		return endTime;
	}
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}
	public Double getExecutedPercentage() {
		return executedPercentage;
	}
	public void setExecutedPercentage(Double executedPercentage) {
		this.executedPercentage = executedPercentage;
	}
	public Double getExecutedTarget() {
		return executedTarget;
	}
	public void setExecutedTarget(Double executedTarget) {
		this.executedTarget = executedTarget;
	}
	public Boolean getStartPaused() {
		return startPaused;
	}
	public void setStartPaused(Boolean startPaused) {
		this.startPaused = startPaused;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public Double getPriceLimit() {
		return priceLimit;
	}
	public void setPriceLimit(Double priceLimit) {
		this.priceLimit = priceLimit;
	}
	public Double getTarget() {
		return target;
	}
	public void setTarget(Double target) {
		this.target = target;
	}
	public Double getAgressiviness() {
		return agressiviness;
	}
	public void setAgressiviness(Double agressiviness) {
		this.agressiviness = agressiviness;
	}
	public Integer getRiskLevel() {
		return riskLevel;
	}
	public void setRiskLevel(Integer riskLevel) {
		this.riskLevel = riskLevel;
	}
	
	public Integer getRestingLevel() {
		return restingLevel;
	}
	public void setRestingLevel(Integer restingLevel) {
		this.restingLevel = restingLevel;
	}
	public List<LegStrategyReport> getLegStrategyList() {
		return legStrategyList;
	}

	public void setLegStrategyList(List<LegStrategyReport> legStrategyList) {
		this.legStrategyList = legStrategyList;
	}
	
	public Header getHeader() {
		return header;
	}
	public void setHeader(Header header) {
		this.header = header;
	}
	//	Seta o relacionamento entre as entidades
	public LegStrategyReport addLegStrategyReport( LegStrategyReport legStrategy ){
		if ( getLegStrategyList() == null )
			setLegStrategyList( new ArrayList<LegStrategyReport>() );
		
		getLegStrategyList().add( legStrategy );
		legStrategy.setStrategyReport( this );
//		legStrategy.getId().setStrategyId( this.getId().getStrategyId() );
		
		return legStrategy;
	}
	
	public LegStrategyReport removeLegStrategyReport( LegStrategyReport legStrategy ){
		getLegStrategyList().remove( legStrategy );
		legStrategy.setStrategyReport( null );
		legStrategy.getId().setLegSeq( null );
		
		return legStrategy;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StrategyReport other = (StrategyReport) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "StrategyReport [strategyId=" + id +", strategyType = " + strategyType
				+ ", strategyTimestamp=" + strategyTimestamp
				+ ", login=" + login + ", startTime=" + startTime
				+ ", endTime=" + endTime + ", executedPercentage="
				+ executedPercentage + ", executedTarget=" + executedTarget
				+ ", startPaused=" + startPaused + ", text=" + text
				+ ", priceLimit=" + priceLimit + ", target=" + target
				+ ", agressiviness=" + agressiviness + ", riskLevel="
				+ riskLevel + ", restingLevel=" + restingLevel + ", header= " + header + " ]";
	}
}