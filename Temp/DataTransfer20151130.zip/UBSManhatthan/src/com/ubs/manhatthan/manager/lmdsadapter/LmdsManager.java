package com.ubs.manhatthan.manager.lmdsadapter;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import org.apache.commons.lang.StringUtils;

import com.ubs.manhatthan.manager.cache.CacheHelper;
import com.ubs.manhatthan.manager.cache.LmdsCache;
import com.ubs.manhatthan.manager.dto.ReceiveSymbolSyntheticItem;
import com.ubs.manhatthan.manager.dto.ReceiveSynthetic;
import com.ubs.manhatthan.manager.enums.SideEnum;
import com.ubs.manhatthan.manager.facade.Facade;
import com.ubs.manhatthan.manager.facade.FacadeImpl;
import com.ubs.manhatthan.manager.facade.FacadeService;
import com.ubs.manhatthan.manager.facade.FacadeServiceImpl;
import com.ubs.manhatthan.manager.lmdsadapter.adapter.AdapterConfigurationException;
import com.ubs.manhatthan.manager.lmdsadapter.adapter.AdapterRuntimeException;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.BookSnapshot;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.SecurityDefinition;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.Trade;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.lmds.LMDSAdapter;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.manager.MDManager;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.manager.MDManagerFactory;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.manager.MDSubscribeResponse;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.manager.MDSubscriberHandler;
import com.ubs.manhatthan.manager.mocks.MarketDataMock;
import com.ubs.manhatthan.manager.persistence.dao.StrategyTypeDAO;
import com.ubs.manhatthan.manager.simulator.multileg.InputMultilegSimulation;
import com.ubs.manhatthan.manager.simulator.multileg.InputMultilegSimulationItem;
import com.ubs.manhatthan.manager.simulator.multileg.ReturnMultilegSimulation;
import com.ubs.manhatthan.manager.utils.Constant;
import com.ubs.manhatthan.manager.utils.Util;


public class LmdsManager implements MDSubscriberHandler {
	
	private final MDManager manager = MDManagerFactory.getManager("BVMF");
	private LMDSAdapter adapter = new LMDSAdapter();
	private SimulationItem simulationItem = new SimulationItem();
	private FacadeService fService = new FacadeServiceImpl();
	private Facade facade = new FacadeImpl();
	
	private StrategyTypeDAO dao = new StrategyTypeDAO();
	
//	Aux values to assign values in map using reference 
	private int minBid;
	private List<Double> bidPrices;
	private int minAsk;
	private List<Long> bidQuantities;
	private List<Double> askPrices;
	private List<Long> askQuantities;
	
	/**
	 * sintetic = symbol1|symbol2|...
	 * concurent map
	 */
//  	
	public boolean subscribeManager( ReceiveSynthetic synthetic ) {
		
		String syntheticKey = "";
		
		if ( synthetic == null || synthetic.getSyntheticList() == null || synthetic.getSyntheticList().isEmpty() )
			return false;
		
		if( synthetic.getStrategyType().isSynthetic() ) { //E sintetico
			
			//verifica se numero de simbolos bata com estrategia cadastrada no banco TB_DOMAIN_STRATEGY_TYPE
			Integer numberOfLegs = this.dao.getNumberOfLegsFromStrategyType( synthetic.getStrategyType() );
			
			if ( numberOfLegs != synthetic.getSyntheticList().size() )
				return false;

			//criar key do sintetico  ex: DI1F17|DI1F18 e cria objeto SimulationItem
			syntheticKey = buildSyntheticKey( synthetic.getSyntheticList() );
			
			// apenas symbol
		} else {
			//mesmo processo anterior sem chamar o simulate, pois os resultados n�o precisam ser calculados
			
			if ( synthetic.getSyntheticList().size() != 1 )
				return false;
			
			syntheticKey = synthetic.getSyntheticList().get( 0 ).getSymbol();
		}
		

//		Se o sint�tico / simbolo j� estiver em cache (logo, j� foi subscrito) retona true
		if ( LmdsCache.simulationItensMapContainsKey( syntheticKey ) )
			return true;
		
//		cria objeto SimulationItem
		simulationItem = initializeSimulationItem( synthetic );
		
//		Colocar entrada no HashMap simulationItensMap
//		Se for sint�tico gerar duas entradas no HashMap listeningSimulationItens
//			kye=DI1F17 e value=DI1F17|DI1F18
//			kye=DI1F18 e value=DI1F17|DI1F18
//
//		Se for Symbol gerar uma entrada no HashMap listeningSimulationItens
//		Em ambos casos gerar uma entrada no HashMap simulationItensMap
		LmdsCache.putSimulationItem( syntheticKey, simulationItem );
		
		List<String> symbolList = Util.extractKeyList( syntheticKey );

		if ( symbolList == null || symbolList.isEmpty() )
			return false;
		

//		Subscreve symbols recebendo o retorno MDSubscribeResponse
//		termina de popular as estruturas
//		updateBookValuesAndQuantitiesInCache
		for (String symbol : symbolList) {
			
//			Subscribing instruments and updateBookValuesAndQuantitiesInCache 
//			chama pela primeira vez o simulate (buy e sell)
//			com retorno do simulate ja popula o resto dos resultados da estrutura SimulationItem
			this.subscribeSymbol( symbol );
		}
		
		return true;
	}
	
	private static String buildSyntheticKey( List<ReceiveSymbolSyntheticItem> syntheticList ){
		
		String key = "";
		
		if ( syntheticList != null && !syntheticList.isEmpty() ){
			for (ReceiveSymbolSyntheticItem item : syntheticList) {
				key += item.getSymbol() + Constant.SIMULATION.SEPARATOR_SYNTHETIC_KEYMAP; 
			}
			key = key.substring( 0, key.length() -1 );
		}
		
		return key;
	}
	
	private SimulationItem initializeSimulationItem( ReceiveSynthetic synthetic ){
		
		if ( synthetic == null || synthetic.getSyntheticList() == null ||  synthetic.getSyntheticList().isEmpty() )
			return null;
		
		SimulationItem item = new SimulationItem();
		
		item.setOnlySymbol( synthetic.getSyntheticList().size() == 1 ? true : false );
		
		for ( ReceiveSymbolSyntheticItem symbol : synthetic.getSyntheticList() ) {
			
			InputMultilegSimulationItem inputMultilegSimulationItem = new InputMultilegSimulationItem();
			
			inputMultilegSimulationItem.setLegSeq( symbol.getLegSeq() );
			inputMultilegSimulationItem.setSide( symbol.getSide() );
			inputMultilegSimulationItem.setInstrument( MarketDataMock.getInstrument( symbol.getSymbol() ) );
			
			if ( SideEnum.BUY.equals( symbol.getSide() ) ){
				item.getBuyInputMultilegSimulationList().getInputItens().add( inputMultilegSimulationItem );
				item.getBuyInputMultilegSimulationList().setSimulationMode( synthetic.getStrategyType() );
				
			} else 
				if ( SideEnum.SELL.equals( symbol.getSide() ) ){
					item.getSellInputMultilegSimulationList().getInputItens().add( inputMultilegSimulationItem );
					item.getSellInputMultilegSimulationList().setSimulationMode( synthetic.getStrategyType() );
			}
		}
		
		return item;
	}
	
	//metodo para pegar resultados do marketwatch
	
	//metodo para calculate da estrategia
		//montar imput
		//chamar simulate
		//retornar resultado do simulate
	
	
	public void startLmdsAdapter(String configFile) throws FileNotFoundException,
									      				   IOException,
									    				   AdapterConfigurationException,
									    				   AdapterRuntimeException {
		
		Properties properties = new Properties();
		properties.load(new FileInputStream(configFile));
		
		this.adapter.configure(properties);
		this.adapter.start();
		
//		After start puts the instance in cache to be accessible in any part of the code 
		CacheHelper.lmdsCommunicatorInstance.put( Util.getManagerId(), this );
		
	}
	
	public void startLmdsAdapter(InputStream configFile)
			throws FileNotFoundException, IOException,
			AdapterConfigurationException, AdapterRuntimeException {

		Properties properties = new Properties();
		properties.load(configFile);

		this.adapter.configure(properties);
		this.adapter.start();

		// After start puts the instance in cache to be accessible in any part
		// of the code
		CacheHelper.lmdsCommunicatorInstance.put(Util.getManagerId(), this);

	}
	
	public void stopLmdsAdapter() throws AdapterRuntimeException {
		
		this.adapter.stop();
	}
	
	protected MDSubscribeResponse subscribeSymbol(String symbol ) {
		
		MDSubscribeResponse subscribe = this.manager.subscribe(symbol, this);
		
		if ( subscribe == null || !subscribe.isSuccess() )
			return null;
		
		updateBookValuesAndQuantitiesInCache( symbol, subscribe.getSnapshot() );
		
		return subscribe;
	}
	
	public void unsubscribeSymbol(String symbol) {
		
		this.manager.unsubscribe(symbol, this);
	}
	
	public SecurityDefinition getIntrumentDefinitionBySymbol(String symbol) {
		
		return this.manager.getInstrumentDefinitionBySymbol(symbol);
	}
	
	public SecurityDefinition getIntrumentDefinitionBySecurityId(String securityId) {
		
		return this.manager.getInstrumentDefinitionBySecurityID(securityId);
	}

	@Override
	public void onBookUpdate(String symbol, BookSnapshot book) {

		//acessa o mapa listeningSimulationItens e atualiza resultados dos objetos chamando o simulate para buy e sell
		
		System.out.println("Received on BOOK listener: " + symbol);
		
		if( !LmdsCache.listeningSimulationContainsKey( symbol ) ) { return; }
		
		updateBookValuesAndQuantitiesInCache( symbol, book );
		
		System.out.println("\n\n\n ===================== Book Update ====================== ");
		System.out.println("\t Symbol: " + symbol );
		System.out.println("\t book: " + book );
		System.out.println("\t ListeningSimulationItens: " + LmdsCache.printlisteningSimulationItens() );
		System.out.println("\t SimulationItensMap: " + LmdsCache.printSimulationItensMap() );
		System.out.println("======================================================== \n\n\n ");
		
	}

	@Override
	public synchronized void onTrade(String symbol, Trade trade) {
		
		//acessa o mapa listeningSimulationItens e atualiza ultimo preco e quantidade para todos os objetos da lista

		String tradeLog = "Received TRADE." +  
				   " Symbol: " + symbol +
				   ", Price: " + trade.getPrice() +
				   ", Qty: " + trade.getQuantity() +
				   ", Date: " + trade.getTradeDate() ;
		
		System.out.println( tradeLog );
		
		if ( StringUtils.isBlank( symbol ) || trade == null )
			return;
		
		System.out.println("\n ===================== Trade Update ====================== ");
		System.out.println("\n ========================= Input ========================= ");
		System.out.println("\t Symbol: " + symbol );
		System.out.println("\t Trade: " + tradeLog );
		System.out.println("\t ListeningSimulationItens: " + LmdsCache.printlisteningSimulationItens() );
		System.out.println("\t SimulationItensMap: " + LmdsCache.printSimulationItensMap() );
		System.out.println("======================================================== \n\n\n ");
		
		if( !LmdsCache.listeningSimulationContainsKey( symbol ) ) {
			System.out.println("if( !CacheHelper.listeningSimulationContainsKey( symbol ) ) {");
			return;
		}
		
//		Busca nos caches os SimuationItens associados com o symbol informado
		List<SimulationItem> simulationList = LmdsCache.getSimulationListBySymbol( symbol );
		
		for (SimulationItem item : simulationList) {
			item.setLastPx( trade.getPrice() != null ? trade.getPrice().doubleValue() : Constant.SIMULATION.DEFAULT_BOOK_PRICE );
			item.setLastQty( trade.getQuantity() );
		}
		
		System.out.println("\n ===================== Trade Update ====================== ");
		System.out.println("\n ======================== output ========================= ");
		System.out.println("\t Symbol: " + symbol );
		System.out.println("\t Trade: " + tradeLog );
		System.out.println("\t ListeningSimulationItens: " + LmdsCache.printlisteningSimulationItens() );
		System.out.println("\t SimulationItensMap: " + LmdsCache.printSimulationItensMap() );
		System.out.println("======================================================== \n\n\n ");
		
	}
	
	private void updateBookValuesAndQuantitiesInCache( String symbol, BookSnapshot book ){
		
		InputMultilegSimulation input = null;
		Integer businessDays = null;
		
		if ( StringUtils.isBlank( symbol ) || book == null || book.isEmpty() )
			return;
		
		minBid 			= Math.min( book.getBidSize(), Constant.SIMULATION.DEFAULT_BOOK_LEVEL );
		minAsk 			= Math.min( book.getAskSize(), Constant.SIMULATION.DEFAULT_BOOK_LEVEL );
		bidPrices 		= new ArrayList<Double>(       Constant.SIMULATION.DEFAULT_BOOK_LEVEL );
		bidQuantities 	= new ArrayList<Long>  (       Constant.SIMULATION.DEFAULT_BOOK_LEVEL );
		askPrices 		= new ArrayList<Double>(       Constant.SIMULATION.DEFAULT_BOOK_LEVEL );
		askQuantities 	= new ArrayList<Long>  (       Constant.SIMULATION.DEFAULT_BOOK_LEVEL );
			
//		Busca nos caches os SimuationItens associados com o symbol informado
		List<SimulationItem> simulationList = LmdsCache.getSimulationListBySymbol( symbol );
		
		for (SimulationItem item : simulationList) {
			
//			Se for apenas symbol, pega o topo do book e seta direto nas vari�veis
			if ( item.isOnlySymbol() ){
				
				item.setBuyQty( Constant.SIMULATION.DEFAULT_BOOK_QUANTITY );
				item.setBuyPx( Constant.SIMULATION.DEFAULT_BOOK_PRICE );
				
				if ( book.getBidSize() > 0 ){
					item.setBuyQty( book.getBidAt( 0 ).getQuantity() );
					item.setBuyPx( book.getBidAt( 0 ).getPrice() != null ? book.getBidAt( 0 ).getPrice().doubleValue() : Constant.SIMULATION.DEFAULT_BOOK_PRICE );
				}
				
				item.setSellQty( Constant.SIMULATION.DEFAULT_BOOK_QUANTITY );
				item.setSellPx( Constant.SIMULATION.DEFAULT_BOOK_PRICE );
				
				if ( book.getAskSize() > 0 ){
					item.setSellQty( book.getAskAt( 0 ).getQuantity() );
					item.setSellPx( book.getAskAt( 0 ).getPrice() != null ? book.getAskAt( 0 ).getPrice().doubleValue() : Constant.SIMULATION.DEFAULT_BOOK_PRICE );
				}
				
//			Se for synthetic, copia o booke at� o n�vel 5 (se existir) para os arrays auxiliares
			} else {
				
				for(int i = 0; i < minBid; i++)
				{
					bidPrices.set( i , book.getBidAt( i ).getPrice().doubleValue() );
					bidQuantities.set( i , book.getBidAt( i ).getQuantity() );
				}
				
				for(int i = 0; i < minAsk; i++)
				{
					askPrices.set( i , book.getAskAt( i ).getPrice().doubleValue() );
					askQuantities.set( i , book.getAskAt( i ).getQuantity() );
				}
			
				/*
				 * BUY
				 * 
				 * */
//				Set os arrays auxiliares no BuyInputMultilegSimulationList/SellInputMultilegSimulationList
				for (InputMultilegSimulationItem simulationBuyItem : item.getBuyInputMultilegSimulationList().getInputItens() ) {
					
					businessDays = facade.businessDayTotal2( new Date(), getIntrumentDefinitionBySymbol(symbol).getMaturityDate() );
					simulationBuyItem.setBusinessDays( businessDays );
					
					simulationBuyItem.setMinAsk( minAsk );
					simulationBuyItem.setMinBid( minBid );
					
					
					simulationBuyItem.setAskPrices( askPrices );
					simulationBuyItem.setAskQuantities( askQuantities );
					
					simulationBuyItem.setBidPrices( bidPrices );
					simulationBuyItem.setBidQuantities( bidQuantities );
					
				}
				
//				Faz a chamada para o calculo
				input = new InputMultilegSimulation();
				input.setSimulationMode( item.getBuyInputMultilegSimulationList().getSimulationMode() );
				input.setInputItens( item.getBuyInputMultilegSimulationList().getInputItens() );
				
				ReturnMultilegSimulation calculateBuy = fService.calculate( input );

//				Com o retorno seta o pre�o de compra e de venda no simulationItem
				if ( calculateBuy != null && calculateBuy.isValid() ){
					item.setBuyPx( calculateBuy.getMarketTarget() );
					item.setBuyQty( (long) calculateBuy.getAvailableQuantity() );
				}
				
				/*
				 * SELL
				 * 
				 * */
				for (InputMultilegSimulationItem simulationSellItem : item.getSellInputMultilegSimulationList().getInputItens() ) {
					
					businessDays = facade.businessDayTotal2( new Date(), getIntrumentDefinitionBySymbol(symbol).getMaturityDate() );
					simulationSellItem.setBusinessDays( businessDays );
					
					simulationSellItem.setMinAsk( minAsk );
					simulationSellItem.setMinBid( minBid );
					
					simulationSellItem.setAskPrices( askPrices );
					simulationSellItem.setAskQuantities( askQuantities );
					
					simulationSellItem.setBidPrices( bidPrices );
					simulationSellItem.setBidQuantities( bidQuantities );
				}
				
				input = new InputMultilegSimulation();
				input.setSimulationMode( item.getSellInputMultilegSimulationList().getSimulationMode() );
				input.setInputItens( item.getSellInputMultilegSimulationList().getInputItens() );
				
				ReturnMultilegSimulation calculateSell = fService.calculate( input );
				
				if ( calculateSell != null && calculateSell.isValid() ){
					item.setSellPx( calculateSell.getMarketTarget() );
					item.setSellQty( (long) calculateSell.getAvailableQuantity() );
				}
			}
		}
	}
}