/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import com.ubs.manhatthan.manager.persistence.entities.OrderFixSession;
import com.ubs.manhatthan.manager.persistence.entities.Role;

/**
 * @author galdinoa
 *
 */
public interface IOrderFixSessionDAO extends IGenericDAO<OrderFixSession, Long> {

	OrderFixSession saveOrderFixSession(OrderFixSession orderFixSession);
}
