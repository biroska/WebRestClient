/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import com.ubs.manhatthan.manager.persistence.entities.StrategyByTab;

/**
 * @author galdinoa
 *
 */
public interface IStrategyByTabDAO extends IGenericDAO<StrategyByTab, Long> {

	StrategyByTab saveStrategyByTab(StrategyByTab strategyByTab);}
