package com.ubs.manhatthan.manager.dispatcher.manager;

import com.ubs.manhatthan.manager.cache.StrategyCache;
import com.ubs.manhatthan.manager.converters.ConvertToProtobuffer;
import com.ubs.manhatthan.manager.enricher.PrepareToEngine;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_to_engine_message;
import com.ubs.manhatthan.manager.persistence.entities.CommandMessage;
import com.ubs.manhatthan.manager.persistence.entities.Message;
import com.ubs.manhatthan.manager.persistence.entities.StrategyOrders;
import com.ubs.manhatthan.manager.persistence.entities.StrategyReport;

public class Manager {
	
	private PrepareToEngine enricher = new PrepareToEngine();
	
	public pb_to_engine_message managerMessage( Message obj ) throws Exception{
		
		pb_to_engine_message engineMessage = null;
		
		if ( obj instanceof StrategyReport ){
			
			StrategyReport report = ( StrategyReport ) obj;
			
			switch ( report.getHeader().getMessageType() ) {
			
				case CREATE_STRATEGY:
					if ( report != null ){
						StrategyCache.StrategyReportMapByRequestId.put( report.getHeader().getManagerRequestId() , report );
					}
					
					engineMessage = manageCreateStrategy( report );
					
					break;
					
				case MODIFY_STRATEGY:
				case CANCEL_STRATEGY:
					if ( report != null ){
//						CacheHelper.strategyReportMap.put( report.getId(), report );
						StrategyCache.putStrategyReport( report );
						StrategyCache.StrategyReportMapByRequestId.put( report.getHeader().getManagerRequestId() , report );
					}
					
					engineMessage = manageModifyCancelStrategy( report );
					break;

			default:
				System.out.println("Tipo de mensagen desconhecido!!!!!");
				break;
			}
			
		} else
			
			if ( obj instanceof StrategyOrders ){
				
				StrategyOrders order = ( StrategyOrders ) obj;
				
				switch ( order.getHeader().getMessageType() ) {
				
					case LEGGED_ORDER:
						if ( order != null ){
//							CacheHelper.strategyOrderMap.put( order.getId(), order );
//							CacheHelper.StrategyOrderMapByEngineId.put( order.getHeader().getManagerRequestId(), order );
							
							StrategyCache.leggedOrderMap.remove( order.getId() );
						}
						
						engineMessage = manageLeggedMessage( order );
						break;
						
					case REPORT_EXECUTION_ORDER:
						if ( order != null ){
							StrategyCache.strategyOrderMap.put( order.getId(), order );
							StrategyCache.StrategyOrderMapByRequestId.put( order.getHeader().getManagerRequestId(), order );
						}
						
						engineMessage = manageExecutionReportOrder( order );
						break;
						
					case NEW_ORDER:
						if ( order != null ){
							StrategyCache.strategyOrderMap.put( order.getId(), order );
							StrategyCache.StrategyOrderMapByRequestId.put( order.getHeader().getManagerRequestId(), order );
						}
						
						engineMessage = manageNewOrderSingle( order );
						break;

				default:
					System.out.println("Tipo de mensagen desconhecido!!!!!");
					break;
				}
				
			} else
				if ( obj instanceof CommandMessage ){
					CommandMessage commandMessage = (CommandMessage) obj;
					engineMessage = manageCommandMessage( commandMessage );
				}
		
		return engineMessage;
	}
	
	
	private pb_to_engine_message manageCreateStrategy( StrategyReport report ) throws Exception{
		
//		Enricher
		System.out.println("Enriching...");
		report = enricher.enrichCreateStrategy( report );
		
//		Converter to protobuffer
		System.out.println("Converting...");
		pb_to_engine_message engineMessage = ConvertToProtobuffer.convertToStrategy( report );
		
		return engineMessage;
	}
	
	private pb_to_engine_message manageModifyCancelStrategy( StrategyReport report ) throws Exception{
		
//		Enricher
		System.out.println("Enriching...");
		report = enricher.enrichModifyCancelStrategy( report );
		
//		Converter to protobuffer
		System.out.println("Converting...");
		pb_to_engine_message engineMessage = ConvertToProtobuffer.convertToStrategy( report );
		
		return engineMessage;
	}
	
	private pb_to_engine_message manageLeggedMessage( StrategyOrders order ) throws Exception{
		
//		Enricher
		System.out.println("Enriching...");
		order = enricher.enrichLeggedStrategyOrder( order );
		
//		Converter to protobuffer
		System.out.println("Converting...");
		pb_to_engine_message engineMessage = ConvertToProtobuffer.convertToLeggedOrder ( order );
		
		return engineMessage;
	}

	private pb_to_engine_message manageExecutionReportOrder( StrategyOrders order ) throws Exception{
		
//		Enricher
		System.out.println("Enriching...");
		order = enricher.enrichStrategyOrder( order );
		
//		Converter to protobuffer
		System.out.println("Converting...");
		pb_to_engine_message engineMessage = ConvertToProtobuffer.convertToReportOrder( order );
		
		return engineMessage;
	}

	private pb_to_engine_message manageNewOrderSingle( StrategyOrders order ) throws Exception{
//		� uma new order n�o h� necessidade de enriquecer, apenas retransmitir a mensagem

//		Converter to protobuffer
		System.out.println("Converting...");
		pb_to_engine_message engineMessage = ConvertToProtobuffer.convertToNewOrderSingle( order );
		
		return engineMessage;
	}
	
	private pb_to_engine_message manageCommandMessage( CommandMessage commandMessage ) throws Exception{
		
//		Enricher
		System.out.println("Enriching...");
		
//		Converter to protobuffer
		System.out.println("Converting...");
		pb_to_engine_message engineMessage = ConvertToProtobuffer.convertToCommandMessage ( commandMessage );
		
		return engineMessage;
	}
}