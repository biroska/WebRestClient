/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import com.ubs.manhatthan.manager.persistence.entities.PasswordParameter;

/**
 * @author galdinoa
 *
 */
public interface IPasswordParameterDAO extends IGenericDAO<PasswordParameter, Long> {

	public PasswordParameter savePasswordParameter(PasswordParameter passwordParameter);
	
}
