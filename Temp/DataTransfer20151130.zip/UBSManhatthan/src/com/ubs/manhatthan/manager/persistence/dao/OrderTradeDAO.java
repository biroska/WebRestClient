package com.ubs.manhatthan.manager.persistence.dao;

import java.util.Date;

import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.persistence.dao.audit.OrderTradeAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IOrderTradeDAO;
import com.ubs.manhatthan.manager.persistence.entities.OrderTrade;
import com.ubs.manhatthan.manager.persistence.entities.audit.OrderTradeAudit;

//@Repository
//@Scope("singleton")
public class OrderTradeDAO extends GenericDAO<OrderTrade, Long> implements IOrderTradeDAO {

	static {
		orderTradeAuditDAO = new OrderTradeAuditDAO();
	}
	
	private static OrderTradeAuditDAO orderTradeAuditDAO;
	
//	@Autowired
//	private IStrategyOrdersDAO strategyOrdersDAO;
//	
//	@Autowired
//	private IClientAccountDAO clientAccountDAO;
//
//	@Autowired
//	private IOrderTradeAuditDAO orderTradeAuditDAO;
//	
//	@Autowired
//	private User user;
	
	@Override
	public OrderTrade saveOrderTrade( OrderTrade orderTrade ){
		
		ActionTypeEnum action = orderTrade.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;
		
		orderTrade.setOrderTimestamp( new Date() );

		orderTrade  = update( orderTrade );

//		OrderTradeAudit teca = new OrderTradeAudit( orderTrade, action, user.getLogin(), new Date() );
		OrderTradeAudit teca = new OrderTradeAudit( orderTrade, action, orderTrade.getLogin(), new Date() );
		
		orderTradeAuditDAO.update( teca );
		
		return orderTrade;
	}
	
	public Long generate( int qtd ){
		
		Long qtRegs = 0L;
		
//		StrategyOrders strategyOrder = strategyOrdersDAO.getByIndex( 0 );
//		List<ClientAccount> clientAccountList = clientAccountDAO.findAll();
//		
//		for ( int i = 1; i<= qtd; i++ ){
//			saveOrderTrade( new OrderTrade( strategyOrder, OrderStatusEnum.REPLACED , "SYMBOL",
//					                        SideEnum.fromValue( (i % 2) +1 ) ,
//					                        clientAccountList.get( i % 5), "TRADE_"+i,  i * 25L, (Math.random() * i * 100) ) );
//			qtRegs++;
//		}
		
		return qtRegs;
	}
	
//	public void setStrategyOrdersDAO(IStrategyOrdersDAO strategyOrdersDAO) {
//		this.strategyOrdersDAO = strategyOrdersDAO;
//	}
//
//	public void setClientAccountDAO(IClientAccountDAO clientAccountDAO) {
//		this.clientAccountDAO = clientAccountDAO;
//	}
//
//	public void setOrderTradeAuditDAO(IOrderTradeAuditDAO orderTradeAuditDAO) {
//		this.orderTradeAuditDAO = orderTradeAuditDAO;
//	}
//
//	public void setUser(User user) {
//		this.user = user;
//	}
}