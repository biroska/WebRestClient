/**
 * 
 */
package com.ubs.manhatthan.manager.enricher;

import com.ubs.manhatthan.manager.persistence.entities.StrategyOrders;
import com.ubs.manhatthan.manager.persistence.entities.StrategyReport;

/**
 * @author galdinoa
 *
 */
public interface IPrepareToPersist {

	public StrategyOrders saveOrder(StrategyOrders order);

	public StrategyReport saveReport(StrategyReport report);

}
