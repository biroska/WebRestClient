package com.ubs.manhatthan.manager.utils;


import com.ubs.manhatthan.manager.enums.FilePropertiesEnum_remover;

public class EnvironmentVariables {
	
    public static Properties getManhattanProperties() {
    	
        return new Properties( FilePropertiesEnum_remover.MANHATTAN_PROPERTIES.getPath() );
    }
}
