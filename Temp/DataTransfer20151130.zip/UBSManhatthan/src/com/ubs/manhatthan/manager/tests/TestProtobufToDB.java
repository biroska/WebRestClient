package com.ubs.manhatthan.manager.tests;

import java.util.Date;

import javax.persistence.EntityTransaction;

import com.ubs.manhatthan.manager.converters.ConverterToEntity;
import com.ubs.manhatthan.manager.enricher.PrepareToPersist;
import com.ubs.manhatthan.manager.enums.ExecutionTypeEnum;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_execution_type_enum;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_header_message;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_message_type_enum;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_order_status_enum;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_order_type_enum;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_report_order_message;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_report_strategy_message;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_side_enum;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_strategy_body_report_message;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_strategy_leg_report_message;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_strategy_state_enum;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_strategy_type_enum;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_time_in_force_enum;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_to_manager_message;
import com.ubs.manhatthan.manager.persistence.entities.Strategy;
import com.ubs.manhatthan.manager.persistence.entities.StrategyOrders;
import com.ubs.manhatthan.manager.persistence.entities.StrategyReport;
import com.ubs.manhatthan.manager.persistence.factory.FactoryManager;
import com.ubs.manhatthan.manager.utils.Constant;
import com.ubs.manhatthan.manager.utils.Util;

public class TestProtobufToDB {

	public static void main(String[] args) {
		
		StrategyReport strategyReport = null;
		EntityTransaction transaction = FactoryManager.getEntityManager().getTransaction();
		try {
			transaction.begin();
	
			pb_to_manager_message generateProtobufMessage = generateProtobufStrategyReportMessage();
			
			pb_to_manager_message generateProtobufOrderMessage = generateProtobufOrderReportMessage();
			
			Strategy strategy = ConverterToEntity.convertToStrategy( Util.getEngineId(), generateProtobufMessage );
			
//			Strategy strategy = ConverterHelper.convertToStrategy( generateProtobufOrderMessage );
			
			PrepareToPersist persist = new PrepareToPersist();
			
			if ( strategy instanceof StrategyReport ){
				System.out.println("\n\n\n Strategy Report \n\n\n");
				System.out.println( generateProtobufMessage );
				
				strategyReport = (StrategyReport) strategy;
				
				System.out.println( strategyReport );
				
				persist.saveReport( strategyReport );
				
			} else
				if ( strategy instanceof StrategyOrders ){
					
					System.out.println("\n\n\n Strategy Order \n\n\n");
					
					System.out.println( generateProtobufOrderMessage );
					
					StrategyOrders  strategyOrders  = (StrategyOrders ) strategy;
					
					strategyOrders.setExecutionType( ExecutionTypeEnum.TRADE );
					
					System.out.println( strategyOrders );
					
					persist.saveOrder( strategyOrders );
				}
				
				transaction.commit();
		} catch (Exception e) {
			System.out.println("Rollback " + new Date() );
			e.printStackTrace();
//			if ( transaction.isActive() ) {
//				transaction.rollback();
//			}
		} finally {
		
			System.out.println("finally " + new Date() );
//			FactoryManager.closeEntityManagerFactory();
		}
	}
	
	private static pb_header_message generateProtobufHeaderMessage(){
	
//		Build the header o message
		pb_header_message header = pb_header_message.newBuilder()
				.setEngineInstanceId( 2L )
				.setManagerInstanceId( 1L )
				.setManagerRequestId( 3L )
				.setMessageType( pb_message_type_enum.PB_CREATE_STRATEGY )
				.build();
		
		return header;
	}
	
	
	private static pb_to_manager_message generateProtobufStrategyReportMessage(){
		
		pb_header_message header = generateProtobufHeaderMessage();
		
		pb_strategy_body_report_message strategyBody = pb_strategy_body_report_message.newBuilder()
														.setStrategyState( pb_strategy_state_enum.PB_STRATEGY_STATUS_RESUMING )
														.setLogin( "AIM*" )
														.setStartTime( (new Date()).getTime() )
														.setEndTime( (new Date()).getTime() )
														.setExecutedPercentage( Math.random() )
														.setTargetExecuted( Math.random() )
														.setStrategyType( pb_strategy_type_enum.PB_STRATEGY_TYPE_MULTILEG_FRA )
														.setStartPaused( Boolean.TRUE )
														.setText( "StrategyBody - Teste para" )
														.setTarget( Math.random() )
														.build();
		
		pb_strategy_leg_report_message legs = pb_strategy_leg_report_message.newBuilder()
												.setLegSeq( 1 )
												.setInstrument( 2 )
												.setTotalQuantity( 169 )
												.setExecutedPercentage( Math.random() )
												.setRemainingQuantity( 20 )
												.setExecutedQuantity( 15 )
												.setAveragePrice( Math.random() )
												.setText( "Teste Insert" )
												.setSide( pb_side_enum.PB_SIDE_BUY )
												.setRouteId( 200 )
												.setOrderType( pb_order_type_enum.PB_ORDER_TYPE_MARKET )
												.setTimeInForce( pb_time_in_force_enum.PB_TIME_IN_FORCE_DAY )
												.setAccount( 220 )
												.setPassiveLeg( Boolean.FALSE )
												.build();
		
		pb_report_strategy_message strategy = pb_report_strategy_message.newBuilder()
												.setStrategyId( 1234567256L )
												.setBody( strategyBody)
												.addLegs(legs)
												.build();
				
		pb_to_manager_message toManager = pb_to_manager_message.newBuilder()
										.setHeader( header )
										.setReportStrategy( strategy )
										.build();
		
		return toManager;
	}
	
	private static pb_to_manager_message generateProtobufOrderReportMessage(){
		
//		Build the header o message
		pb_header_message header = generateProtobufHeaderMessage();
		
		pb_report_order_message strategyOrder = pb_report_order_message.newBuilder()
												.setStrategyId( Constant.MOCK.STRATEGY_ID )
												.setLegSeq( 1 )
												.setInstrument( 333333 )
												.setExecutedQuantity( 10 )
												.setAveragePrice( Math.random() )
												.setSide( pb_side_enum.PB_SIDE_SELL )
												.setOrderId( 212345678 )
												.setQuantity( 100 )
												.setExecutionType( pb_execution_type_enum.PB_EXECUTION_TYPE_TRADE )
												.setOrderStatus( pb_order_status_enum.PB_ORDER_STATUS_NEW )
												.setClientOrderId( ""+6769 )
												.setUniqueTradeId( "ALTER2")
												.build();
		
		pb_to_manager_message toManager = pb_to_manager_message.newBuilder()
				.setHeader( header )
				.setReportOrder( strategyOrder )
				.build();
		
		return toManager;
	}
}