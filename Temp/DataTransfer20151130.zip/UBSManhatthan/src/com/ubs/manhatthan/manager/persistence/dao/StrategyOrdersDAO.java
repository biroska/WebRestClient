package com.ubs.manhatthan.manager.persistence.dao;

import java.util.Date;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.persistence.dao.audit.StrategyOrdersAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IStrategyOrdersAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IStrategyOrdersDAO;
import com.ubs.manhatthan.manager.persistence.entities.StrategyOrders;
import com.ubs.manhatthan.manager.persistence.entities.audit.StrategyOrdersAudit;
import com.ubs.manhatthan.manager.persistence.entities.id.StrategyOrdersPK;

//@Repository
//@Scope("singleton")
public class StrategyOrdersDAO extends GenericDAO<StrategyOrders, StrategyOrdersPK> implements IStrategyOrdersDAO {
	
	static {
		strategyOrdersAuditDAO = new StrategyOrdersAuditDAO();
	}
	
	private static StrategyOrdersAuditDAO strategyOrdersAuditDAO;
	
//	@Autowired
//	private IStrategyOrdersAuditDAO strategyOrdersAuditDAO;
//	
//	@Autowired
//	private User user;
	
	@Override
	public StrategyOrders saveStrategyOrder( StrategyOrders order ){
		
		ActionTypeEnum action = order.getId().getOrderId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;
		
		findById( order.getId() );

		order = update( order );

//		StrategyOrdersAudit soa = new StrategyOrdersAudit( order, action, user.getLogin(), new Date() );
		StrategyOrdersAudit soa = new StrategyOrdersAudit( order, action, order.getLogin(), new Date() );
		
		strategyOrdersAuditDAO.update( soa );
		
		return order;
	}

//	public void setStrategyOrdersAuditDAO(IStrategyOrdersAuditDAO strategyOrdersAuditDAO) {
//		this.strategyOrdersAuditDAO = strategyOrdersAuditDAO;
//	}
//
//	public void setUser(User user) {
//		this.user = user;
//	}
}