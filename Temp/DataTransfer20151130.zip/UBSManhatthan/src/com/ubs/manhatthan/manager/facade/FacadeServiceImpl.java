/**
 * 
 */
package com.ubs.manhatthan.manager.facade;

import org.springframework.stereotype.Service;

import com.ubs.manhatthan.manager.cache.CacheHelper;
import com.ubs.manhatthan.manager.cache.StrategyCache;
import com.ubs.manhatthan.manager.dispatcher.manager.Manager;
import com.ubs.manhatthan.manager.dto.ReceiveSynthetic;
import com.ubs.manhatthan.manager.lmdsadapter.LmdsManager;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_to_engine_message;
import com.ubs.manhatthan.manager.persistence.entities.Message;
import com.ubs.manhatthan.manager.simulator.multileg.InputMultilegSimulation;
import com.ubs.manhatthan.manager.simulator.multileg.MultilegSimulation;
import com.ubs.manhatthan.manager.simulator.multileg.ReturnMultilegSimulation;
import com.ubs.manhatthan.manager.utils.Util;

@Service
public class FacadeServiceImpl implements FacadeService {

	private Manager manager = new Manager();

	private MultilegSimulation simulation = new MultilegSimulation();
	
	
	
	/**
	 * <p>
	 * The calculate is responsible for the calculus of the values of the market and strategy
	 * </p>
	 * 
	 * @author <a href="mailto:aimbere.galdino@ubs.com">Aimbere Galdino</a>
	 * @param <M>
	 *            contains the {@link InputMultilegSimulation}.
	 * @param <E>
	 *            contains the {@link ReturnMultilegSimulation}.
	 * @since 1.7
	 */
	@Override
	public ReturnMultilegSimulation calculate( InputMultilegSimulation input ) {

		return simulation.simulate( input );
	}
	
	/**
	 * <p>
	 * The subscribe is responsible to subscribe a symbol to lmds and put
	 * the symbol subscribed in the cache map
	 * </p>
	 * 
	 * @author <a href="mailto:aimbere.galdino@ubs.com">Aimbere Galdino</a>
	 * @param <M>
	 *            contains the {@link ReceiveSynthetic}.
	 * @param <E>
	 *            contains the {@link boolean}.
	 * @since 1.7
	 */
	@Override
	public boolean subscribe( ReceiveSynthetic synthetic ){
		
		if ( synthetic == null || synthetic.getStrategyType() == null ||
			 synthetic.getSyntheticList() == null || synthetic.getSyntheticList().isEmpty() )
				return false;
		
		LmdsManager lmdsManager = CacheHelper.lmdsCommunicatorInstance.get( Util.getManagerId() );
		
		boolean subscribeManager = lmdsManager.subscribeManager( synthetic );
		
		return subscribeManager;
	}

	/**
	 * <p>
	 * The sendToEngine is responsible to send CommandMessages, orders, Strategies, etc...
	 * to the Engine
	 * </p>
	 * 
	 * @author <a href="mailto:aimbere.galdino@ubs.com">Aimbere Galdino</a>
	 * @param <M>
	 *            contains the {@link Message}.
	 * @param <E>
	 *            contains the {@link boolean}.
	 * @since 1.7
	 */
	@Override
	public boolean sendToEngine(Message message) {

		try {
			pb_to_engine_message engineMessage = manager.managerMessage( message );
			
			CacheHelper.engineCommunicatorInstance.get( Util.getEngineId() ).send( engineMessage );
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
		return false;
	}
}