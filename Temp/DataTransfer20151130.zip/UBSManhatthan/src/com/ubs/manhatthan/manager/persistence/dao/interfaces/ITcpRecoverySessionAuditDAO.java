/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import com.ubs.manhatthan.manager.persistence.entities.audit.TcpRecoverySessionAudit;

/**
 * @author galdinoa
 *
 */
public interface ITcpRecoverySessionAuditDAO extends IGenericDAO<TcpRecoverySessionAudit, Long> {}
