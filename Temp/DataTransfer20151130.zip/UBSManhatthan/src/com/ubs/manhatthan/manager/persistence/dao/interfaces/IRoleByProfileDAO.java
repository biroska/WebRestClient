/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import com.ubs.manhatthan.manager.persistence.entities.RoleByProfile;

/**
 * @author galdinoa
 *
 */
public interface IRoleByProfileDAO extends IGenericDAO<RoleByProfile, Long> {

	RoleByProfile saveRoleByProfile( RoleByProfile role );
}
