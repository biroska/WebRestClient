package com.ubs.manhatthan.manager.tests;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityTransaction;

import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.facade.FacadeImpl;
import com.ubs.manhatthan.manager.facade.Manager;
import com.ubs.manhatthan.manager.mocks.StrategyWithLegsMock;
import com.ubs.manhatthan.manager.persistence.dao.AccountTypeDAO;
import com.ubs.manhatthan.manager.persistence.dao.EngineInstanceDAO;
import com.ubs.manhatthan.manager.persistence.dao.EngineUmdfChannelDAO;
import com.ubs.manhatthan.manager.persistence.dao.ExchangeDAO;
import com.ubs.manhatthan.manager.persistence.dao.LegStrategyReportDAO;
import com.ubs.manhatthan.manager.persistence.dao.OrderFixSessionDAO;
import com.ubs.manhatthan.manager.persistence.dao.OrderTradeDAO;
import com.ubs.manhatthan.manager.persistence.dao.PasswordParameterDAO;
import com.ubs.manhatthan.manager.persistence.dao.ProfileDAO;
import com.ubs.manhatthan.manager.persistence.dao.RoleByProfileDAO;
import com.ubs.manhatthan.manager.persistence.dao.RoleDAO;
import com.ubs.manhatthan.manager.persistence.dao.SessionByAccountDAO;
import com.ubs.manhatthan.manager.persistence.dao.SessionByEngineDAO;
import com.ubs.manhatthan.manager.persistence.dao.StrategyByTabDAO;
import com.ubs.manhatthan.manager.persistence.dao.StrategyByTabLegDAO;
import com.ubs.manhatthan.manager.persistence.dao.StrategyReportDAO;
import com.ubs.manhatthan.manager.persistence.dao.StrategyTypeDAO;
import com.ubs.manhatthan.manager.persistence.dao.StrategyTypeLegDAO;
import com.ubs.manhatthan.manager.persistence.dao.TcpRecoverySessionDAO;
import com.ubs.manhatthan.manager.persistence.dao.TraderDAO;
import com.ubs.manhatthan.manager.persistence.dao.TraderExchangeCodeDAO;
import com.ubs.manhatthan.manager.persistence.dao.TraderWatchTabDAO;
import com.ubs.manhatthan.manager.persistence.dao.UmdfChannelByEngineDAO;
import com.ubs.manhatthan.manager.persistence.dao.UmdfRecoverySessionByEngineDAO;
import com.ubs.manhatthan.manager.persistence.dao.audit.EngineInstanceAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.audit.EngineUmdfChannelAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.audit.LegStrategyReportAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.audit.OrderFixSessionAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.audit.SessionByAccountAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.audit.SessionByEngineAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.audit.StrategyOrdersAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.audit.StrategyReportAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.audit.TcpRecoverySessionAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.audit.TraderAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.audit.TraderExchangeCodeAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.audit.UmdfChannelByEngineAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.audit.UmdfRecoverySessionByEngineAuditDAO;
import com.ubs.manhatthan.manager.persistence.entities.EngineInstance;
import com.ubs.manhatthan.manager.persistence.entities.EngineUmdfChannel;
import com.ubs.manhatthan.manager.persistence.entities.LegStrategyReport;
import com.ubs.manhatthan.manager.persistence.entities.OrderFixSession;
import com.ubs.manhatthan.manager.persistence.entities.SessionByAccount;
import com.ubs.manhatthan.manager.persistence.entities.SessionByEngine;
import com.ubs.manhatthan.manager.persistence.entities.StrategyOrders;
import com.ubs.manhatthan.manager.persistence.entities.StrategyReport;
import com.ubs.manhatthan.manager.persistence.entities.TcpRecoverySession;
import com.ubs.manhatthan.manager.persistence.entities.Trader;
import com.ubs.manhatthan.manager.persistence.entities.TraderExchangeCode;
import com.ubs.manhatthan.manager.persistence.entities.UmdfChannelByEngine;
import com.ubs.manhatthan.manager.persistence.entities.UmdfRecoverySessionByEngine;
import com.ubs.manhatthan.manager.persistence.entities.audit.EngineInstanceAudit;
import com.ubs.manhatthan.manager.persistence.entities.audit.EngineUmdfChannelAudit;
import com.ubs.manhatthan.manager.persistence.entities.audit.LegStrategyReportAudit;
import com.ubs.manhatthan.manager.persistence.entities.audit.OrderFixSessionAudit;
import com.ubs.manhatthan.manager.persistence.entities.audit.SessionByAccountAudit;
import com.ubs.manhatthan.manager.persistence.entities.audit.SessionByEngineAudit;
import com.ubs.manhatthan.manager.persistence.entities.audit.StrategyOrdersAudit;
import com.ubs.manhatthan.manager.persistence.entities.audit.StrategyReportAudit;
import com.ubs.manhatthan.manager.persistence.entities.audit.TcpRecoverySessionAudit;
import com.ubs.manhatthan.manager.persistence.entities.audit.TraderAudit;
import com.ubs.manhatthan.manager.persistence.entities.audit.TraderExchangeCodeAudit;
import com.ubs.manhatthan.manager.persistence.entities.audit.UmdfChannelByEngineAudit;
import com.ubs.manhatthan.manager.persistence.entities.audit.UmdfRecoverySessionByEngineAudit;
import com.ubs.manhatthan.manager.persistence.factory.FactoryManager;

public class CriacaoTabelas {
	
	private RoleDAO roleDAO = new RoleDAO();
	private ProfileDAO profileDAO = new ProfileDAO();
	private TraderDAO traderDAO = new TraderDAO();
	private ExchangeDAO exchangeDAO = new ExchangeDAO();
	private OrderTradeDAO orderTradeDAO = new OrderTradeDAO();
	private AccountTypeDAO accountTypeDAO = new AccountTypeDAO();
	private StrategyTypeDAO strategyTypeDAO = new StrategyTypeDAO();
	private RoleByProfileDAO roleByProfileDAO = new RoleByProfileDAO();
	private StrategyByTabDAO strategyByTabDAO = new StrategyByTabDAO();
	private EngineInstanceDAO engineInstanceDAO = new EngineInstanceDAO();
	private StrategyReportDAO strategyReportDAO = new StrategyReportDAO();
	private TraderWatchTabDAO traderWatchTabDAO = new TraderWatchTabDAO();
	private OrderFixSessionDAO orderFixSessionDAO = new OrderFixSessionDAO();
	private SessionByEngineDAO sessionByEngineDAO = new SessionByEngineDAO();
	private StrategyTypeLegDAO strategyTypeLegDAO = new StrategyTypeLegDAO();
	private SessionByAccountDAO sessionByAccountDAO = new SessionByAccountDAO();
	private StrategyByTabLegDAO strategyByTabLegDAO = new StrategyByTabLegDAO();
	private EngineUmdfChannelDAO engineUmdfChannelDAO = new EngineUmdfChannelDAO();
	private LegStrategyReportDAO legStrategyReportDAO = new LegStrategyReportDAO();
	private PasswordParameterDAO passwordParameterDAO = new PasswordParameterDAO();
	private TraderExchangeCodeDAO traderExchangeCodeDAO = new TraderExchangeCodeDAO();
	private TcpRecoverySessionDAO tcpRecoverySessionDAO = new TcpRecoverySessionDAO();
	private UmdfChannelByEngineDAO umdfChannelByEngineDAO = new UmdfChannelByEngineDAO();
	private UmdfRecoverySessionByEngineDAO umdfRecoverySessionByEngineDAO = new UmdfRecoverySessionByEngineDAO();
	
	private TraderAuditDAO traderAuditDAO = new TraderAuditDAO();
	private EngineInstanceAuditDAO engineInstanceAuditDAO = new EngineInstanceAuditDAO();
	private StrategyOrdersAuditDAO strategyOrdersAuditDAO = new StrategyOrdersAuditDAO();
	private StrategyReportAuditDAO strategyReportAuditDAO = new StrategyReportAuditDAO();
	private OrderFixSessionAuditDAO orderFixSessionAuditDAO = new OrderFixSessionAuditDAO();
	private SessionByEngineAuditDAO sessionByEngineAuditDAO = new SessionByEngineAuditDAO();
	private SessionByAccountAuditDAO sessionByAccountAuditDAO = new SessionByAccountAuditDAO();
	private EngineUmdfChannelAuditDAO engineUmdfChannelAuditDAO = new EngineUmdfChannelAuditDAO();
	private LegStrategyReportAuditDAO legStrategyReportAuditDAO = new LegStrategyReportAuditDAO();
	private TcpRecoverySessionAuditDAO tcpRecoverySessionAuditDAO = new TcpRecoverySessionAuditDAO();
	private TraderExchangeCodeAuditDAO traderExchangeCodeAuditDAO = new TraderExchangeCodeAuditDAO();
	private UmdfChannelByEngineAuditDAO umdfChannelByEngineAuditDAO = new UmdfChannelByEngineAuditDAO();
	private UmdfRecoverySessionByEngineAuditDAO umdfRecoverySessionByEngineAuditDAO = new UmdfRecoverySessionByEngineAuditDAO();
	
	private Manager manager = new Manager();
	
	private Long generatedRegs = 0L;
	
		/**
		 * @param args
		 */
		public static void main(String[] args) {
			
			Date startTime = null;
			EntityTransaction transaction = FactoryManager.getEntityManager().getTransaction();
			
			startTime = new Date();
			CriacaoTabelas main = new CriacaoTabelas();
			
			try {
				
//				ApplicationContext context = new ClassPathXmlApplicationContext( "applicationContext.xml");
				
//				MockToInject mockToInject = (MockToInject) context.getBean("mockToInject");
//				System.out.println( mockToInject );
				
				System.out.println("Transactio Begin " + startTime );
				transaction.begin();
				
				System.out.println("\n \n \n");
				
//				main.loadTest( true );
				
//				main.generateDomainTables(); 			// Gera tabelas de dom�nio
//				main.generateRelationBetweenTables();   // Gera relacionamentos
				StrategyReport strategyReport = main.buildStrategyReport( 2L, 100 );
				FacadeImpl facade = new FacadeImpl();
				facade.saveReport( strategyReport );
				
//				main.generateOrderTrade();
				
//				facade.generateStrategyReport( 4L, 100 );
//				main.loadStrategy( 1_446_045_867_460L );
				
//				main.cascadeClientAccountToClient();
//				main.cascadeClientsByTrader();
//				main.cascadeClientsByEngine();
				
//				main.saveAuditTables();
				
//				main.saveClientAccountAudit();
				
//				Teste loading from view
//				System.out.println("Acesso a view " + main.clienteDAO.findById( 8376L ) );
				
				transaction.commit();
				
			} catch (Exception e) {
				System.out.println("Rollback " + new Date() );
				e.printStackTrace();
				if ( transaction.isActive() ) {
					transaction.rollback();
				}
			} finally {
			
				System.out.println("finally " + new Date() );
				FactoryManager.closeEntityManagerFactory();
			}
			
			System.out.println("Elapsed time: " + ( new Date().getTime() - startTime.getTime() ) / 1000 + "s"  );
		}
		
		@SuppressWarnings("unused")
		private void loadStrategy( Long id ){
			
			StrategyReport strategy = new StrategyReport();
			StrategyWithLegsMock mock = new StrategyWithLegsMock();
			
			strategy = mock.loadStrategyReportMock( id );
			
			System.out.println("Teste.run(): " + strategy.getId() );
			System.out.println("Teste.run(): " + strategy.getLegStrategyList().get( 0 ).getId() );
			System.out.println("Teste.run(): " + strategy.getLegStrategyList().get( 1 ).getId() );
			
		}
		
		@SuppressWarnings("unused")
		private void loadTest( boolean isActive ){
			
			List<Trader> traders = traderDAO.findAllActive( isActive );
			
			for (Trader trader : traders) {
				System.out.println("Trader: " + trader.getUsername() + " " + ( trader.isEnable() == true ? "Ativo" : "Inativo" ) );
			}
			
		}

		@SuppressWarnings("unused")
		private void insert() {
			
			StrategyReport strategy = new StrategyReport();
			StrategyWithLegsMock mock = new StrategyWithLegsMock();
			
//	============================= Insert test com Strategy, Legs e Ordens ============================= 
			strategy = mock.insert( 4 );
			strategy = mock.generateOrders( strategy );
			FactoryManager.getEntityManager().persist( strategy );
//	============================= Insert test com Strategy, Legs e Ordens ============================= 
		}

		@SuppressWarnings("unused")
		private void remove( Long id ) {

			StrategyReport strategy = new StrategyReport();
			StrategyWithLegsMock mock = new StrategyWithLegsMock();
			
//			============================= remove test =============================
			strategy = mock.loadStrategyReportMock( id );
			
			System.out.println("Teste.run(): " + strategy.getId() );
			System.out.println("Teste.run(): " + strategy.getLegStrategyList().get( 0 ).getId() );
			System.out.println("Teste.run(): " + strategy.getLegStrategyList().get( 1 ).getId() );
			
			strategy.getLegStrategyList().get( 1 ).getStrategyOrdersList( ).clear();
			
			strategy.getLegStrategyList().remove( 1 );
			
			FactoryManager.getEntityManager().remove( strategy.getLegStrategyList().get( 1 ) );
//			============================= remove test ============================= 
		}
		
		@SuppressWarnings("unused")
		private void generateDomainTables(){
			
//			============================= Generate Account Type ============================= 
				generatedRegs = accountTypeDAO.generateAccountType( 10 );
				System.out.println("Tipos de contas gerados: " + generatedRegs );
//			============================= Generate Account Type ============================= 
				
//			============================= Generate Exchange ============================= 
				generatedRegs = exchangeDAO.generateExchange();
				System.out.println("Tipos de contas gerados: " + generatedRegs );
//			============================= Generate Exchange ============================= 
				
//			============================= Generate Profiles ============================= 
				generatedRegs = profileDAO.generate( 10 );
				System.out.println("Profile gerados: " + generatedRegs );
//			============================= Generate Profiles =============================
				
//				S�o lidos da view do sinacor, n�o � mais necess�rio gerar
//			============================= Generate Clients ============================= 
//				generatedRegs = clienteDAO.generate( 10 );
//				System.out.println("Clientes gerados: " + generatedRegs );
//			============================= Generate Clients ============================= 
				
//			============================= Generate Engines ============================= 
				generatedRegs = engineInstanceDAO.generateEngine( 10 );
				System.out.println("Engine gerados: " + generatedRegs );
//			============================= Generate Clients ============================= 
				
//			============================= Generate Password Parameters ============================= 
				generatedRegs = passwordParameterDAO.generate( 10 );
				System.out.println("Engine gerados: " + generatedRegs );
//			============================= Generate Password Parameters ============================= 

//			============================= Generate Traders ============================= 
				generatedRegs = traderDAO.generateTraders( 10 );
				System.out.println("Traders gerados: " + generatedRegs );
//			============================= Generate Exchange ============================= 

//			============================= Generate Roles ============================= 
				generatedRegs = roleDAO.generate( 10 );
				System.out.println("Traders gerados: " + generatedRegs );
//			============================= Generate Roles ============================= 
				
//			============================= Generate Strategy Type ============================= 
				generatedRegs = strategyTypeDAO.generate( 10 );
				System.out.println("Traders gerados: " + generatedRegs );
//			============================= Generate Strategy Type ============================= 
				
//			============================= Generate Strategy Type Leg ============================= 
				generatedRegs = strategyTypeLegDAO.generate( 10 );
				System.out.println("Traders gerados: " + generatedRegs );
//			============================= Generate Strategy Type Leg ============================= 
				
//			============================= Generate Watch Tabs ============================= 
				generatedRegs = traderWatchTabDAO.generate( 10 );
				System.out.println("Traders gerados: " + generatedRegs );
//			============================= Generate Watch Tabs ============================= 
		}
		
		@SuppressWarnings("unused")
		private void generateRelationBetweenTables(){

////			============================= Generate Client_Accounts =========================
//			generatedRegs = clientAccountDAO.generateClientsAccounts( 10 );
//			System.out.println("Cliente Account: " + generatedRegs );
////			============================= Generate Client_Accounts =========================

//			============================= Generate FixSessions ============================= 
			generatedRegs = orderFixSessionDAO.generateOrderFixSession( 10 );
			System.out.println("FixSessions: " + generatedRegs );
//			============================= Generate FixSessions ============================= 
//			
////			============================= Generate Client By Engine ========================
//			generatedRegs = clientByEngineDAO.generateClientByEngine( 10 );
//			System.out.println("Cliente Engine: " + generatedRegs );
////			============================= Generate Client By Engine ========================

////			============================= Generate Client By Trader ========================
//			generatedRegs = clientByTraderDAO.generate( 10 );
//			System.out.println("Cliente by Trader: " + generatedRegs );
////			============================= Generate Client By Trader ========================
//
//			=========================== Generate Trader Exchange Code ======================
			generatedRegs = traderExchangeCodeDAO.generate( 10 );
			System.out.println("Trader Exchange Code: " + generatedRegs );
//			=========================== Generate Trader Exchange Code ======================

//			============================ Generate Session by Account =======================
			generatedRegs = sessionByAccountDAO.generate( 10 );
			System.out.println("Session by Account: " + generatedRegs );
//			============================ Generate Session by Account =======================
//			
//			============================ Generate Session by Engine =======================
			generatedRegs = sessionByEngineDAO.generate( 10 );
			System.out.println("Session by Engine: " + generatedRegs );
//			============================ Generate Session by Engine =======================
			
//			=========================== Generate Engine UMDF Channel ======================
			generatedRegs = engineUmdfChannelDAO.generate( 10 );
			System.out.println("Engine UMDF Channel: " + generatedRegs );
//			=========================== Generate Engine UMDF Channel ======================
			
//			=========================== Generate TCP Recovery Session =====================
			generatedRegs = tcpRecoverySessionDAO.generate( 10 );
			System.out.println("TCP Recovery Session: " + generatedRegs );
//			=========================== Generate TCP Recovery Session =====================
			
//			=========================== Generate UMDF Channel Engine ======================
			generatedRegs = umdfChannelByEngineDAO.generate( 10 );
			System.out.println("UMDF Channel Engine: " + generatedRegs );
//			=========================== Generate UMDF Channel Engine ======================
			
//			===================== Generate UMDF Recovery Session By Engine ================
			generatedRegs = umdfRecoverySessionByEngineDAO.generate( 10 );
			System.out.println("UMDF Channel Engine: " + generatedRegs );
//			===================== Generate UMDF Recovery Session By Engine ================
			
//			===================== Generate Roles by Profiles ================
			generatedRegs = roleByProfileDAO.generate( 10 );
			System.out.println("UMDF Channel Engine: " + generatedRegs );
//			===================== Generate Roles by Profiles ================
			
//			===================== Generate Strategy by Tab ================
			generatedRegs = strategyByTabDAO.generate( 10 );
			System.out.println("UMDF Channel Engine: " + generatedRegs );
//			===================== Generate Strategy by Tab ================
			
//			===================== Generate Strategy by Tab ================
			generatedRegs = strategyByTabLegDAO.generate( 10 );
			System.out.println("UMDF Channel Engine: " + generatedRegs );
//			===================== Generate Strategy by Tab ================

		}
		
		@SuppressWarnings("unused")
		private void generateOrderTrade(){
		
//			===================== Generate Order Trade ================
			generatedRegs = orderTradeDAO.generate( 10 );
			System.out.println("UMDF Channel Engine: " + generatedRegs );
//			===================== Generate Order Trade ================
		}
		
//		private void cascadeClientAccountToClient(){
//			
//			ClientAccount ca = new ClientAccount();
//			
//			AccountType accountType = accountTypeDAO.getAccountTypeByIndex( 1 );
//			
////			Cliente novo
////			Client client = new Client("Teste para cascade 2");
//			
////			Cliente j� existente
////			Client client = clienteDAO.getByIndex( 3 );
//			
//			ca.setAccount( 987654321L );
//			ca.setAccountType( accountType );
////			ca.setClientId( client );
////			client.addClientAccount( ca );
//			
////			clientAccountDAO.save( ca );
//			clientAccountDAO.saveClientAccount( ca );
//			
//		}
		
//		private void cascadeClientsByTrader(){
//			
//			ClientByTrader ct = new ClientByTrader();
//			
//			Trader trader = new Trader();
//			
////			Cliente novo
////			Client client = new Client("Teste cascade ClientByTrader");
//			
////			Cliente j� existente
////			Client client = clienteDAO.getByIndex( 3 );
//			
////			Trader novo
////			trader = new Trader("Teste cascade ClientByTrader");
//			
////			trader j� existente
//			trader = traderDAO.getByIndex( 3 );
//			
////			ct.setClientId( client );
////			ct.setTraderId( trader );
//			
//			clientByTraderDAO.save( ct );
//		}
		
//		private void cascadeClientsByEngine(){
//			
//			ClientByEngine ce = new ClientByEngine();
//			
//			EngineInstance engine = new EngineInstance();
////			Client client = new Client();
//			
////			Cliente novo
////			client = new Client("Teste cascade ClientsByEngine");
//			
////			Cliente j� existente
////			client = clienteDAO.getByIndex( 3 );
//			
////			Engine novo
////			engine = new EngineInstance( 123L, "1.1.1.1.0", 9090L);
//			
////			Engine j� existente
//			engine = engineInstanceDAO.getByIndex( 3 );
//			
////			ce.setClientId( client );
//			ce.setEngineId( engine );
//			
//			clientByEngineDAO.save( ce );
//		}

		@SuppressWarnings("unused")
		private void saveAuditTables(){
			saveEngineInstance();
			saveEngineUmdfChannelAudit();
			saveOrderFixSessionAudit();
			saveTcpRecoverySessionAudit();
			saveTraderAudit();
//			saveClientAccountAudit();
//			saveClientByEngineAudit();
//			saveClientsByTraderAudit();
			saveSessionByAccountAudit();
			saveSessionByEngineAudit();
			saveTraderExchangeCodeAudit();
			saveUmdfChannelByEngineAudit();
			saveUmdfRecoverySessionByEngineAudit();
			saveStrategyReportAudit();
		}
		
		private void saveEngineInstance(){
			EngineInstance ei = engineInstanceDAO.getByIndex( 2 );
			
			EngineInstanceAudit engineInstanceAudit = new EngineInstanceAudit( ei, ActionTypeEnum.UPDATE, "USER - aim*", new Date() );
			
			engineInstanceAuditDAO.save( engineInstanceAudit );
		}
		
		private void saveEngineUmdfChannelAudit(){
			EngineUmdfChannel euc = engineUmdfChannelDAO.getByIndex( 2 );
			
			EngineUmdfChannelAudit euca = new EngineUmdfChannelAudit( euc, ActionTypeEnum.UPDATE, "USER - aim*", new Date() );
			
			engineUmdfChannelAuditDAO.save( euca );
		}
		
		private void saveOrderFixSessionAudit(){
			OrderFixSession euc = orderFixSessionDAO.getByIndex( 2 );
			
			OrderFixSessionAudit euca = new OrderFixSessionAudit( euc, ActionTypeEnum.UPDATE, "USER - aim*", new Date() );
			
			orderFixSessionAuditDAO.save( euca );
		}
		
		private void saveTcpRecoverySessionAudit(){
			TcpRecoverySession euc = tcpRecoverySessionDAO.getByIndex( 2 );
			
			TcpRecoverySessionAudit euca = new TcpRecoverySessionAudit( euc, ActionTypeEnum.UPDATE, "USER - aim*", new Date() );
			
			tcpRecoverySessionAuditDAO.save( euca );
		}
		
		private void saveTraderAudit(){
			Trader trader = traderDAO.getByIndex( 2 );
			
			TraderAudit euca = new TraderAudit( trader, ActionTypeEnum.UPDATE, "USER - aim*", new Date() );
			
			traderAuditDAO.save( euca );
		}
		
		
//		private void saveClientAccountAudit(){
//			ClientAccount clientAccount = clientAccountDAO.getByIndex( 2 );
//			
////			ClientAudit clientAudit = clientAuditDAO.findById( 2L );
//			
//			ClientAccountAudit caa = new ClientAccountAudit( clientAccount, ActionTypeEnum.UPDATE, "USER - aim*", new Date() );
////			Novo registro
////			caa.setClientId( new ClientAudit( clientAccount.getClientId(), ActionTypeEnum.UPDATE, "USER - aim*", new Date() ) );
//			
////			Utilizando cliente j� existente
////			caa.setClientId( clientAudit );
////			caa.getClientId().addClientAccount( caa );
//			
//			clientAccountAuditDAO.save( caa );
//		}
		
//		private void saveClientByEngineAudit(){
//			ClientByEngine clientByEngine = clientByEngineDAO.getByIndex( 2 );
//			
//			ClientByEngineAudit cea = new ClientByEngineAudit(clientByEngine, ActionTypeEnum.UPDATE, "USER - aim*", new Date() );
//			
////			Novo registro
////			cea.setClientId( new ClientAudit( clientByEngine.getClientId(), ActionTypeEnum.UPDATE, "USER - aim*", new Date() ) );
////			cea.setEngineId( new EngineInstanceAudit( clientByEngine.getEngineId() , ActionTypeEnum.UPDATE, "USER - aim*", new Date() )   );
//			
////			caa.setClientId( clientAudit );
////			caa.getClientId().addClientAccount( caa );
//			
//			clientByEnginAuditDAO.save( cea );
//		}
		
//		private void saveClientsByTraderAudit(){
//			ClientByTrader clientByTrader = clientByTraderDAO.getByIndex( 2 );
//			
////			ClientAudit clientAudit = clientAuditDAO.findById( 2L );
//
//			ClientByTraderAudit cbta = new ClientByTraderAudit( clientByTrader , ActionTypeEnum.UPDATE, "USER - aim*", new Date() );
//			
////			Novo registro cascade
////			cbta.setClientId( new ClientAudit( clientByTrader.getClientId(), ActionTypeEnum.UPDATE, "USER - aim*", new Date() ) );
////			cbta.setTraderId( new TraderAudit( clientByTrader.getTraderId() , ActionTypeEnum.UPDATE, "USER - aim*", new Date() )   );
//			
//			clientByTraderAuditDAO.save( cbta );
//		}
		
		private void saveSessionByAccountAudit(){
			SessionByAccount sessionByAccount = sessionByAccountDAO.getByIndex( 2 );
			
			SessionByAccountAudit sbaa = new SessionByAccountAudit(sessionByAccount, ActionTypeEnum.UPDATE, "USER - aim*", new Date() );
			
//			Novo registro cascade
//			sbaa.setOrderFixSessionId( new OrderFixSessionAudit( sessionByAccount.getOrderFixSessionId(), ActionTypeEnum.UPDATE, "USER - aim*", new Date() ) );
//			sbaa.setClientAccountId( new ClientAccountAudit( sessionByAccount.getClientAccountId(), ActionTypeEnum.UPDATE, "USER - aim*", new Date() ) );
			
//			sbaa.getClientAccountId().setClientId( new ClientAudit( sessionByAccount.getClientAccountId().getClientId(), ActionTypeEnum.UPDATE, "USER - aim*", new Date() ) );
			
			sessionByAccountAuditDAO.save( sbaa );
		}
		
		private void saveSessionByEngineAudit(){
			
			SessionByEngine sessionByEngine = sessionByEngineDAO.getByIndex( 2 );
			
			SessionByEngineAudit sbea = new SessionByEngineAudit(sessionByEngine, ActionTypeEnum.UPDATE, "USER - aim*", new Date() );
			
//			Novo registro cascade
//			sbea.setOrderFixSessionId( new OrderFixSessionAudit( sessionByEngine.getOrderFixSessionId(), ActionTypeEnum.UPDATE, "USER - aim*", new Date() ) );
//			sbea.setEngineInstanceId( new EngineInstanceAudit( sessionByEngine.getEngineInstanceId(), ActionTypeEnum.UPDATE, "USER - aim*", new Date() ) );
			
			sessionByEngineAuditDAO.save( sbea );
		}
		
		private void saveTraderExchangeCodeAudit(){
			
			TraderExchangeCode traderExchange = traderExchangeCodeDAO.getByIndex( 2 );
			
			TraderExchangeCodeAudit teca = new TraderExchangeCodeAudit( traderExchange, ActionTypeEnum.UPDATE, "USER - aim*", new Date() );
			
//			Novo registro cascade
//			teca.setTraderId( new TraderAudit( traderExchange.getTraderId(), ActionTypeEnum.UPDATE, "USER - aim*", new Date() ) );
			
			traderExchangeCodeAuditDAO.save( teca );
		}
		
		private void saveUmdfChannelByEngineAudit(){
			
			UmdfChannelByEngine umdfChannelByEngine = umdfChannelByEngineDAO.getByIndex( 2 );
			
			UmdfChannelByEngineAudit ucbea = new UmdfChannelByEngineAudit( umdfChannelByEngine, ActionTypeEnum.UPDATE, "USER - aim*", new Date() );
			
//			Novo registro cascade
//			ucbea.setEngine( new EngineInstanceAudit( umdfChannelByEngine.getEngine(), ActionTypeEnum.UPDATE, "USER - aim*", new Date() ) );
//			ucbea.setEngineUmdfChannel( new EngineUmdfChannelAudit( umdfChannelByEngine.getEngineUmdfChannel(), ActionTypeEnum.UPDATE, "USER - aim*", new Date() ) );
			
			umdfChannelByEngineAuditDAO.save( ucbea );
		}
		
		private void saveUmdfRecoverySessionByEngineAudit(){
			
			UmdfRecoverySessionByEngine umdfRecoverySessionByEngine = umdfRecoverySessionByEngineDAO.getByIndex( 2 );
			
			UmdfRecoverySessionByEngineAudit ursbea = new UmdfRecoverySessionByEngineAudit( 
													  umdfRecoverySessionByEngine, ActionTypeEnum.UPDATE, "USER - aim*", new Date() );
			
//			Novo registro cascade
//			ursbea.setEngine( new EngineInstanceAudit( umdfRecoverySessionByEngine.getEngine(), ActionTypeEnum.UPDATE, "USER - aim*", new Date() ) );
//			ursbea.setTcpRecoverySession( new TcpRecoverySessionAudit( umdfRecoverySessionByEngine.getTcpRecoverySession(), ActionTypeEnum.UPDATE, "USER - aim*", new Date() ) );
			
			umdfRecoverySessionByEngineAuditDAO.save( ursbea );
		}
		
		private void saveStrategyReportAudit(){
			
			StrategyReport strategyReport = strategyReportDAO.getByIndex( 0 );
			
			StrategyReportAudit sra = new StrategyReportAudit( strategyReport, ActionTypeEnum.UPDATE, "USER - aim*", new Date() );
			
			List<LegStrategyReport> legs = legStrategyReportDAO.findByStrategyId( strategyReport.getId().getStrategyId() );
			
			List<StrategyOrdersAudit> orderListAudit = new ArrayList<StrategyOrdersAudit>();
			
			List<LegStrategyReportAudit> lsra = new ArrayList<LegStrategyReportAudit>();
			
			for (LegStrategyReport leg : legs) {
				
				LegStrategyReportAudit legAudit = new LegStrategyReportAudit( leg, ActionTypeEnum.UPDATE, "USER - aim*", new Date() );
				
				lsra.add( legAudit );
				
				for (StrategyOrders order : leg.getStrategyOrdersList() ) {
					orderListAudit.add( new StrategyOrdersAudit( order , ActionTypeEnum.UPDATE, "USER - aim*", new Date()) );
				}
				
			}
			
			strategyReportAuditDAO.save( sra );
			legStrategyReportAuditDAO.save( lsra );
			strategyOrdersAuditDAO.save( orderListAudit );
		}

		
		private StrategyReport buildStrategyReport( Long qtdLegs, Integer qtdOrders ){
			
			StrategyReport strategy = manager.generateStrategyReport(qtdLegs, qtdOrders);
			
			return strategy;
		}
		
		public void POC( int qtdStrategies ) {
			
			StrategyReport strategy = new StrategyReport();
			StrategyWithLegsMock mock = new StrategyWithLegsMock();
			
			for (int i = 0; i < qtdStrategies; i++) {
				strategy = mock.insert( 4 );
				strategy = mock.generateOrders( strategy );
				
				FactoryManager.getEntityManager().persist( strategy );
			}
		}
}