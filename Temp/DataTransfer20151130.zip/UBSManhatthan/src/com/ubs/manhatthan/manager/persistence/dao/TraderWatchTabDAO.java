package com.ubs.manhatthan.manager.persistence.dao;

import java.util.Date;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.ITraderWatchTabAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.ITraderWatchTabDAO;
import com.ubs.manhatthan.manager.persistence.entities.TraderWatchTab;
import com.ubs.manhatthan.manager.persistence.entities.audit.TraderWatchTabAudit;
import com.ubs.manhatthan.manager.persistence.factory.FactoryManager;

@Repository
@Scope("singleton")
public class TraderWatchTabDAO extends GenericDAO<TraderWatchTab, Long> implements ITraderWatchTabDAO {
	
	@Autowired
	private ITraderWatchTabAuditDAO traderWatchTabAuditDAO;
	
	@Autowired
	private User user;
	
	@Override
	public TraderWatchTab saveTraderWatchTab( TraderWatchTab traderWatchTab ){
		
		ActionTypeEnum action = traderWatchTab.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;

		traderWatchTab = update( traderWatchTab );

		TraderWatchTabAudit sta = new TraderWatchTabAudit( traderWatchTab, action, traderWatchTab.getLogin(), new Date() );
		
		traderWatchTabAuditDAO.update( sta );
		
		return traderWatchTab;
	}
	
	@Override
	public List<TraderWatchTab> getListTraderWatchsTabsByLogin(String login) {
		CriteriaBuilder criteriaBuilder = FactoryManager.getEntityManager().getCriteriaBuilder();

		CriteriaQuery<TraderWatchTab> criteriaQuery = criteriaBuilder.createQuery(TraderWatchTab.class);
		Root<TraderWatchTab> traderWatchTabRoot = criteriaQuery.from(TraderWatchTab.class);
		criteriaQuery.where( criteriaBuilder.equal( traderWatchTabRoot.get( "login" ), login.trim() ) );		
		
		criteriaQuery.select( traderWatchTabRoot );

		List<TraderWatchTab> list = FactoryManager.getEntityManager().createQuery(criteriaQuery).getResultList();
		
		return list;
	}

	public Long generate( int qtd ){

		Long qtRegs = 0L;
		
		for (int i = 1; i <= 10; i++) {
			saveTraderWatchTab( new TraderWatchTab( "AIM*", "Descrip_" + i ) );
			qtRegs++;
		}
		
		return qtRegs;
	}

	public void setTraderWatchTabAuditDAO(ITraderWatchTabAuditDAO traderWatchTabAuditDAO) {
		this.traderWatchTabAuditDAO = traderWatchTabAuditDAO;
	}

	public void setUser(User user) {
		this.user = user;
	}
}