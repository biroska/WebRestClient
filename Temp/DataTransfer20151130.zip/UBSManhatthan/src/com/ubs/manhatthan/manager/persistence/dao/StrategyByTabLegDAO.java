package com.ubs.manhatthan.manager.persistence.dao;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IStrategyByTabLegAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IStrategyByTabLegDAO;
import com.ubs.manhatthan.manager.persistence.entities.StrategyByTab;
import com.ubs.manhatthan.manager.persistence.entities.StrategyByTabLeg;
import com.ubs.manhatthan.manager.persistence.entities.StrategyTypeLeg;
import com.ubs.manhatthan.manager.persistence.entities.audit.StrategyByTabLegAudit;

@Repository
@Scope("singleton")
public class StrategyByTabLegDAO extends GenericDAO<StrategyByTabLeg, Long> implements IStrategyByTabLegDAO {
	
	@Autowired
	private IStrategyByTabLegAuditDAO strategyByTabLegAuditDAO;
	
	@Autowired
	private User user;
	
	@Override
	public StrategyByTabLeg saveStrategyByTabLeg( StrategyByTabLeg strategyByTabLeg ){
		
		ActionTypeEnum action = strategyByTabLeg.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;

		strategyByTabLeg = update( strategyByTabLeg );

		StrategyByTabLegAudit sta = new StrategyByTabLegAudit( strategyByTabLeg, action, user.getLogin(), new Date() );
		
		strategyByTabLegAuditDAO.update( sta );
		
		return strategyByTabLeg;
	}

	public Long generate( int qtd ){
		
		StrategyByTabDAO strategyByTabDAO = new StrategyByTabDAO();
		List<StrategyByTab> strategyByTabList = strategyByTabDAO.findAll();
		
		StrategyTypeLegDAO strategyTypeLegDAO = new StrategyTypeLegDAO();
		List<StrategyTypeLeg> strategyTypeLegList = strategyTypeLegDAO.findAll();
		
		Long qtRegs = 0L;
		
		for (int i = 1; i <= 10; i++) {
			saveStrategyByTabLeg( new StrategyByTabLeg( strategyByTabList.get( i % 5), strategyTypeLegList.get( i % 5 ) , ( i % 4 ) +1 ) );
			qtRegs++;
		}
		
		return qtRegs;
	}

	public void setStrategyByTabLegAuditDAO(IStrategyByTabLegAuditDAO strategyByTabLegAuditDAO) {
		this.strategyByTabLegAuditDAO = strategyByTabLegAuditDAO;
	}

	public void setUser(User user) {
		this.user = user;
	}
}