package com.ubs.manhatthan.manager.mocks;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Set;

public class MarketDataMock {
	
	private static LinkedHashMap< Integer, String > symbolInstrumentMap = new LinkedHashMap< Integer, String>();
	private static ArrayList<Integer> auxList;
	
	static {
		symbolInstrumentMap.put( 700020, "DI1F17" );
		symbolInstrumentMap.put( 701259, "DI1F18" );
		symbolInstrumentMap.put( 701325, "DI1F19" );
		symbolInstrumentMap.put( 701663, "DI1F21" );
		symbolInstrumentMap.put( 701838, "DI1F23" );
		/*symbolInstrumentMap.put( 244276L, "DI1X15" );
		symbolInstrumentMap.put( 244284L, "DI1Z15" );
		symbolInstrumentMap.put( 700012L, "DI1F16" );
		symbolInstrumentMap.put( 244292L, "DI1G16" );
		symbolInstrumentMap.put( 244300L, "DI1H16" );
		symbolInstrumentMap.put( 701895L, "DI1J16" );
		symbolInstrumentMap.put( 278241L, "DI1K16" );
		symbolInstrumentMap.put( 247170L, "DI1M16" );
		symbolInstrumentMap.put( 701747L, "DI1N16" );
		symbolInstrumentMap.put( 321504L, "DI1Q16" );
		symbolInstrumentMap.put( 335348L, "DI1U16" );
		symbolInstrumentMap.put( 701903L, "DI1V16" );
		symbolInstrumentMap.put( 324607L, "DI1Z16" );
		symbolInstrumentMap.put( 345883L, "DI1G17" );
		symbolInstrumentMap.put( 345891L, "DI1H17" );
		symbolInstrumentMap.put( 701804L, "DI1J17" );
		symbolInstrumentMap.put( 701952L, "DI1N17" );
		symbolInstrumentMap.put( 701960L, "DI1V17" );
		symbolInstrumentMap.put( 702018L, "DI1J18" );
		symbolInstrumentMap.put( 701994L, "DI1N18" );
		symbolInstrumentMap.put( 702042L, "DI1V18" );
		symbolInstrumentMap.put( 702158L, "DI1V19" );
		symbolInstrumentMap.put( 701655L, "DI1F20" );
		symbolInstrumentMap.put( 702166L, "DI1J20" );
		symbolInstrumentMap.put( 702000L, "DI1N20" );
		symbolInstrumentMap.put( 701846L, "DI1V20" );
		symbolInstrumentMap.put( 702174L, "DI1J21" );
		symbolInstrumentMap.put( 702109L, "DI1N21" );
		symbolInstrumentMap.put( 702182L, "DI1V21" );
		symbolInstrumentMap.put( 701200L, "DI1F22" );
		symbolInstrumentMap.put( 702117L, "DI1N22" );
		symbolInstrumentMap.put( 702190L, "DI1N23" );
		symbolInstrumentMap.put( 701820L, "DI1F24" );
		symbolInstrumentMap.put( 702208L, "DI1N24" );
		symbolInstrumentMap.put( 701770L, "DI1F25" );
		symbolInstrumentMap.put( 702299L, "DI1F26" );
		symbolInstrumentMap.put( 146687L, "DI1F29" );
		symbolInstrumentMap.put( 320100L, "DI1F30" );*/
		
		auxList = new ArrayList<Integer>( MarketDataMock.getKeySet() );
	}
	
	public static String getSymbol( Long instrument ){
		return symbolInstrumentMap.get( instrument );
	}
	
	public static String getSymbolByIndex( Integer index ){
		
		if ( index == null || index < 0 )
			return null;
		
		return symbolInstrumentMap.get( auxList.get( index ) );
	}
	
	public static Integer getInstrumentByIndex( Integer index ){
		
		if ( index == null || index < 0 )
			return null;
		
		return auxList.get( index );
	}
	
	public static Integer getInstrument( String symbol ){
		
		if ( symbol == null )
			return null;

		for (Integer key : auxList ) {
			if ( symbolInstrumentMap.get( key ).equals( symbol ) )
				return key;
		}
		
		return null;
	}
	
	
	private static Set<Integer> getKeySet(){
		return symbolInstrumentMap.keySet();
	}
}