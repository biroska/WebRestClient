package com.ubs.manhatthan.manager.persistence.dao;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IEngineInstanceAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IEngineInstanceDAO;
import com.ubs.manhatthan.manager.persistence.entities.EngineInstance;
import com.ubs.manhatthan.manager.persistence.entities.audit.EngineInstanceAudit;

@Repository
@Scope("singleton")
public class EngineInstanceDAO extends GenericDAO<EngineInstance, Integer> implements IEngineInstanceDAO {
	
	@Autowired
	private IEngineInstanceAuditDAO engineInstanceAudit;
	
	@Autowired
	private User user;
	
	@Override
	public EngineInstance saveEngineInstance( EngineInstance engine ){
		
		ActionTypeEnum action = engine.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;

		engine = update( engine );

		EngineInstanceAudit pa = new EngineInstanceAudit( engine, action, user.getLogin(), new Date() );
		
		engineInstanceAudit.update( pa );
		
		return engine;
	}
	
	public Long generateEngine( int qtd ){
		
		Long qtRegs = 0L;
		
		for ( int i = 1; i<= qtd; i++ ){
			saveEngineInstance(  new EngineInstance( (long) i, " 255.255.255." + i, (long) 8079 + i, "EngDesc") );
			qtRegs++;
		}
		return qtRegs;
	}
	
	public EngineInstance getByIndex( int index ) {
		return findAll().get( index );
	}

	public void setUser(User user) {
		this.user = user;
	}

	public void setEngineInstanceAudit(IEngineInstanceAuditDAO engineInstanceAudit) {
		this.engineInstanceAudit = engineInstanceAudit;
	}
}