package com.ubs.manhatthan.manager.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;

public class Util {
	
	private static SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
	
	public static String getDateFormated(){
		return sdf.format( new Date() );
	}
	
	public static String convertDatePattern( Date dt, String pattern ){
		
		if ( pattern == null )
			return null;
		
		SimpleDateFormat formatter = new SimpleDateFormat( pattern );
		
		return formatter.format( dt );
	}
	
	public static Date convertDatePattern( String dt, String pattern ){
		
		if ( pattern == null || StringUtils.isBlank( dt ) )
			return null;
		
		SimpleDateFormat formatter = new SimpleDateFormat( pattern );
		
		try {
			return formatter.parse( dt );
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	public static long dateToMicroSegundos( Date date ){
		long time = date.getTime() * 1000;
		return time;
	}
	
	public static Date microSegundosToDate ( long micro ){
		Date date = new Date( micro / 1000 );
		return date;
	}
	
	public static Integer getManagerId(){
		/* L� do arquivo properties a o managerId */
		Integer retorno = getPropertyFromFile("manhattan.manager.id") == "" ? null : Integer.valueOf( getPropertyFromFile("manhattan.manager.id") );
		return retorno;
	}
	
	public static Long getEngineId(){
		/* L� do arquivo properties a o managerId */
		Long retorno = getPropertyFromFile("manhattan.engine.id") == "" ? null : Long.valueOf( getPropertyFromFile("manhattan.engine.id") );
		return retorno;
	}
	
	public static String getPropertyFromFile( String key ){
		/* L� do arquivo properties a localiza��o do arquivo de log */
		return EnvironmentVariables.getManhattanProperties().getValue( key );
	}
	
	public static List<String> extractKeyList( String key ){
		
		if ( StringUtils.isBlank( key ) )
			return null;
		
		String[] split = StringUtils.split( key, Constant.SIMULATION.SEPARATOR_SYNTHETIC_KEYMAP );
		
		if ( split == null || split.length == 0 )
			return null;
		
		return new ArrayList<String>( Arrays.asList( split ) );
	}
}
