package com.ubs.manhatthan.manager.lmdsadapter.marketdata.lmds.handlers;

public interface Handler<T>
{
	
	void handle(T event);
	
}
