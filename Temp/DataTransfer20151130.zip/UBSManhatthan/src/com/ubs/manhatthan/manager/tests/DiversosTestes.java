/**
 * 
 */
package com.ubs.manhatthan.manager.tests;

import java.util.Calendar;
import java.util.Date;

import com.ubs.manhatthan.manager.utils.Util;



/**
 * @author galdinoa
 *
 */
public class DiversosTestes {
	
	public static void main (String[] args){
		
		System.out.println( Util.convertDatePattern( new Date(), "yyyyMMdd" ) );
		System.out.println( Util.convertDatePattern( "20151126", "yyyyMMdd" ) );
		
		Long maxValue = (long) ( Math.pow( 2, 63 ) -1);
		
		Long maxValueFixed = 9_223_372_036_854_775_807L;
		
		System.out.printf("Max value: %f\n", ( Math.pow( 2, 63 ) -1 ) );
		System.out.println("Max value: " + maxValue);
		System.out.println("Max value: " + maxValueFixed);
		System.out.println("Max value: " + "9223372036854775807 ");
		
		Calendar cal = Calendar.getInstance();
		cal.add( Calendar.DATE , -10 );
		
	}
	
}