/**
 * 
 */
package com.ubs.manhatthan.manager.persistence;

import com.ubs.manhatthan.manager.cache.PersistenceCache;
import com.ubs.manhatthan.manager.enricher.PrepareToPersist;
import com.ubs.manhatthan.manager.persistence.entities.Strategy;
import com.ubs.manhatthan.manager.persistence.entities.StrategyOrders;
import com.ubs.manhatthan.manager.persistence.entities.StrategyReport;

/**
 * @author galdinoa
 *
 */
public class PersistenceThread implements Runnable {

	@Override
	public void run() {
		System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
		System.out.println("Thread: " + Thread.currentThread().getName() + " iniciada");
		System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
		
		Strategy message = null;
		
		PrepareToPersist persist = new PrepareToPersist();
		
		StrategyOrders order = null;
		StrategyReport report = null;
		
		while ( true ){
			
			try {
				
				if ( PersistenceCache.isEmpty() )
					continue;
				
				message = PersistenceCache.extractFirst();
				
				if ( message == null )
					continue;
				
				if ( message instanceof StrategyReport ){
					report = (StrategyReport) message;
					persist.saveReport( report );
					
				} else
					if ( message instanceof StrategyOrders ){
						order = (StrategyOrders) message;
						persist.saveOrder( order );
						
					} else {
						System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
						System.out.println("Objeto n�o tratado: \t" + message );
						System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
					}
				
				Thread.sleep( 500 );
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
