/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.entities;


/**
 * <p>
 * This is a super obj to agregate Strategy and CommandOrders
 *  Strategy is a group of messages of type: StrategyReport, 
 *  LegStrategyReport and StrategyOrders
 * </p>
 * 
 * @author <a href="mailto:aimbere.galdino@ubs.com">Aimbere Galdino</a>
 * @since 1.7
 */
public interface Message {

}
