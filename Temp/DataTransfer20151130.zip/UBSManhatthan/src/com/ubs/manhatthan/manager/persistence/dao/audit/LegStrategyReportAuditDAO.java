package com.ubs.manhatthan.manager.persistence.dao.audit;

import java.util.List;

import com.ubs.manhatthan.manager.persistence.dao.GenericDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.ILegStrategyReportAuditDAO;
import com.ubs.manhatthan.manager.persistence.entities.audit.LegStrategyReportAudit;

//@Repository
//@Scope("singleton")
public class LegStrategyReportAuditDAO extends GenericDAO<LegStrategyReportAudit, Long> implements ILegStrategyReportAuditDAO {
	
	@Override
	public List<LegStrategyReportAudit> save(List<LegStrategyReportAudit> list) {

		for (LegStrategyReportAudit item : list) {
			item = update(item);
		}
		return list;
	}
}
