/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.manager.persistence.entities.audit.RoleByProfileAudit;

/**
 * @author galdinoa
 *
 */
@Repository
@Scope("singleton")
public interface IRoleByProfileAuditDAO extends IGenericDAO<RoleByProfileAudit, Long> {
}
