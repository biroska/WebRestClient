package com.ubs.manhatthan.manager.persistence.dao.audit;

import java.util.List;

import com.ubs.manhatthan.manager.persistence.dao.GenericDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IStrategyOrdersAuditDAO;
import com.ubs.manhatthan.manager.persistence.entities.audit.StrategyOrdersAudit;

//@Repository
//@Scope("singleton")
public class StrategyOrdersAuditDAO extends GenericDAO<StrategyOrdersAudit, Long> implements IStrategyOrdersAuditDAO {
	
	@Override
	public List<StrategyOrdersAudit> save(List<StrategyOrdersAudit> list) {

		for (StrategyOrdersAudit item : list) {
			item = update(item);
		}
		return list;
	}
	
}
