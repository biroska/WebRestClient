package com.ubs.manhatthan.manager.persistence.entities;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.ubs.manhatthan.manager.enums.OrderTypeEnum;
import com.ubs.manhatthan.manager.enums.SideEnum;
import com.ubs.manhatthan.manager.enums.TimeInForceEnum;
import com.ubs.manhatthan.manager.persistence.entities.id.LegStrategyReportPK;

@Entity
@Table(name="TB_LEG_STRATEGY_REPORT")
public class LegStrategyReport implements Serializable, Strategy{
	
	private static final long serialVersionUID = -9133982911106466279L;

	public LegStrategyReport(){
//		Injeta ums instancia da PK
		this.setId( new LegStrategyReportPK() );
	}
	
	@EmbeddedId
	private LegStrategyReportPK id;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumns({
		  @JoinColumn( name = "ENGINE_ID", referencedColumnName = "ENGINE_ID" , nullable = false, insertable = false, updatable= false ),
		  @JoinColumn( name = "STRATEGY_ID", referencedColumnName = "STRATEGY_ID" , nullable = false, insertable = false, updatable= false ),
		  @JoinColumn( name = "STRATEGY_DATE", referencedColumnName = "STRATEGY_DATE" , nullable = false, insertable = false, updatable= false )
		})
	private StrategyReport strategyReport;
	
	@Column ( name = "INSTRUMENT", nullable=false)
	private Long instrument;
	
	@Column ( name = "TOTAL_QUANTITY", nullable=false)
	private Long totalQuantity;
	
	@Column ( name = "EXECUTED_PERCENTAGE", columnDefinition= "Decimal(10,3)", nullable = false)
	private Double executedPercentage;
	
	@Column ( name = "REMAINING_QUANTITY", nullable = false)
	private Long remainingQuantity;
	
	@Column ( name = "EXECUTED_QUANTITY", nullable = false)
	private Long executedQuantity;
	
	@Column ( name = "AVERAGE_PRICE", columnDefinition= "Decimal(10,7)", nullable = false)
	private Double averagePrice;
	
	@Column ( name = "TEXT", length = 256 )
	private String text;
	
	@Column ( name = "SIDE", nullable = false)
	private SideEnum side;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "ROUTE_ID", nullable = false )
	private OrderFixSession routeId;
	
	@Column ( name = "ORDER_TYPE")
	private OrderTypeEnum orderType;
	
	@Column ( name = "TIME_IN_FORCE")
	private TimeInForceEnum timeInForce;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "ACCOUNT", nullable = false )
	private ClientAccount account;
	
	@Column ( name = "PASSIVE_LEG")
	private Boolean passiveLeg;
	
	@Column ( name = "MAX_QUANTITY_DISPLAY")
	private Long maxQuantityDisplay;
	
	@Column ( name = "MIN_QUANTITY_DISPLAY")
	private Long minQuantityDisplay;
	
	@Column ( name = "RESTING_QUANTITY")
	private Long restingQuantity;
	
	@Column ( name = "RESTING_PRICE", columnDefinition= "Decimal(10,7)")
	private Double restingPrice;
	
	@Column ( name = "RESTING_RANK")
	private Long restingRank;
	
	@Column ( name = "TIME_OUT")
	private Long timeOut;
	
	@Column ( name = "INVESTOR_ID", length = 16)
	private String investorId;
	
	@Column ( name = "ENTERING_TRADER", length = 8)
	private String enteringTrader;
	
	@Column ( name = "DURATION", nullable = false )
	private Integer duration;
	
	@Column ( name = "LOGIN", length = 64)
	private String login;

	@OneToMany(mappedBy = "legStrategyReport", fetch=FetchType.LAZY, cascade = CascadeType.ALL )
	private List<StrategyOrders> strategyOrdersList;
	
	public LegStrategyReportPK getId() {
		return id;
	}
	
	public void setId(LegStrategyReportPK id) {
		this.id = id;
	}

	public StrategyReport getStrategyReport() {
		return strategyReport;
	}

	public void setStrategyReport(StrategyReport strategyReport) {
		this.strategyReport = strategyReport;
	}

	public Long getInstrument() {
		return instrument;
	}

	public void setInstrument(Long instrument) {
		this.instrument = instrument;
	}

	public Long getTotalQuantity() {
		return totalQuantity;
	}

	public void setTotalQuantity(Long totalQuantity) {
		this.totalQuantity = totalQuantity;
	}

	public Double getExecutedPercentage() {
		return executedPercentage;
	}

	public void setExecutedPercentage(Double executedPercentage) {
		this.executedPercentage = executedPercentage;
	}

	public Long getRemainingQuantity() {
		return remainingQuantity;
	}

	public void setRemainingQuantity(Long remainingQuantity) {
		this.remainingQuantity = remainingQuantity;
	}

	public Long getExecutedQuantity() {
		return executedQuantity;
	}

	public void setExecutedQuantity(Long executedQuantity) {
		this.executedQuantity = executedQuantity;
	}

	public Double getAveragePrice() {
		return averagePrice;
	}

	public void setAveragePrice(Double averagePrice) {
		this.averagePrice = averagePrice;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public SideEnum getSide() {
		return side;
	}

	public void setSide(SideEnum side) {
		this.side = side;
	}

	public OrderFixSession getRouteId() {
		return routeId;
	}

	public void setRouteId(OrderFixSession routeId) {
		this.routeId = routeId;
	}

	public OrderTypeEnum getOrderType() {
		return orderType;
	}

	public void setOrderType(OrderTypeEnum orderType) {
		this.orderType = orderType;
	}

	public TimeInForceEnum getTimeInForce() {
		return timeInForce;
	}

	public void setTimeInForce(TimeInForceEnum timeInForce) {
		this.timeInForce = timeInForce;
	}
	
	public ClientAccount getAccount() {
		return account;
	}

	public void setAccount(ClientAccount account) {
		this.account = account;
	}

	public Boolean getPassiveLeg() {
		return passiveLeg;
	}

	public void setPassiveLeg(Boolean passiveLeg) {
		this.passiveLeg = passiveLeg;
	}

	public Long getMaxQuantityDisplay() {
		return maxQuantityDisplay;
	}

	public void setMaxQuantityDisplay(Long maxQuantityDisplay) {
		this.maxQuantityDisplay = maxQuantityDisplay;
	}

	public Long getMinQuantityDisplay() {
		return minQuantityDisplay;
	}

	public void setMinQuantityDisplay(Long minQuantityDisplay) {
		this.minQuantityDisplay = minQuantityDisplay;
	}

	public Long getRestingQuantity() {
		return restingQuantity;
	}

	public void setRestingQuantity(Long restingQuantity) {
		this.restingQuantity = restingQuantity;
	}

	public Double getRestingPrice() {
		return restingPrice;
	}

	public void setRestingPrice(Double restingPrice) {
		this.restingPrice = restingPrice;
	}

	public Long getRestingRank() {
		return restingRank;
	}

	public void setRestingRank(Long restingRank) {
		this.restingRank = restingRank;
	}

	public Long getTimeOut() {
		return timeOut;
	}

	public void setTimeOut(Long timeOut) {
		this.timeOut = timeOut;
	}

	public String getInvestorId() {
		return investorId;
	}

	public void setInvestorId(String investorId) {
		this.investorId = investorId;
	}

	public String getEnteringTrader() {
		return enteringTrader;
	}

	public void setEnteringTrader(String enteringTrader) {
		this.enteringTrader = enteringTrader;
	}
	
	public Integer getDuration() {
		return duration;
	}

	public void setDuration(Integer duration) {
		this.duration = duration;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public List<StrategyOrders> getStrategyOrdersList() {
		return strategyOrdersList;
	}

	public void setStrategyOrdersList(List<StrategyOrders> strategyOrdersList) {
		this.strategyOrdersList = strategyOrdersList;
	}

	//	Seta o relacionamento entre as entidades
	public StrategyOrders addStrategyOrder( StrategyOrders strategyOrder ){
		if ( getStrategyOrdersList() == null )
			setStrategyOrdersList( new ArrayList<StrategyOrders>() );
		
		getStrategyOrdersList().add( strategyOrder );
		strategyOrder.setLegStrategyReport( this );
		
		return strategyOrder;
	}
	
	public StrategyOrders removeStrategyOrder( StrategyOrders strategyOrder ){
		getStrategyOrdersList().remove( strategyOrder );
		strategyOrder.setLegStrategyReport( null );
		
		return strategyOrder;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LegStrategyReport other = (LegStrategyReport) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "LegStrategyReport [id=" + id + ", instrument=" + instrument
				+ ", totalQuantity=" + totalQuantity + ", executedPercentage="
				+ executedPercentage + ", remainingQuantity="
				+ remainingQuantity + ", executedQuantity=" + executedQuantity
				+ ", averagePrice=" + averagePrice + ", text=" + text
				+ ", side=" + side + ", routeId=" + routeId + ", orderType="
				+ orderType + ", timeInForce=" + timeInForce + ", account="
				+ account + ", passiveLeg=" + passiveLeg
				+ ", maxQuantityDisplay=" + maxQuantityDisplay
				+ ", minQuantityDisplay=" + minQuantityDisplay
				+ ", restingQuantity=" + restingQuantity + ", restingPrice="
				+ restingPrice + ", restingRank=" + restingRank + ", timeOut="
				+ timeOut + ", investorId=" + investorId + ", enteringTrader="
				+ enteringTrader + ", login= " + login + ", duration= " + duration + "]";
	}
}