/**
 * 
 */
package com.ubs.manhatthan.manager.cache;

import java.util.LinkedList;

import com.ubs.manhatthan.manager.persistence.entities.Strategy;

/**
 * @author galdinoa
 *
 */
public class PersistenceCache {
	
	private static LinkedList<Strategy> persistenceMap;
	
	static {
		persistenceMap = new LinkedList<Strategy>();
	}
	
	/*
	 * Methods to encapsulate the persistenceMap
	 * 
	 * */
	public static boolean addLast( Strategy message){
		
		try {
			if ( persistenceMap != null ){
				persistenceMap.addLast( message );
				return true;
			}
		} catch ( Exception e){
			e.printStackTrace();
			return false;
		}
		return false;
	}
	
	public static Strategy extractFirst(){
		
		try {
			if ( !isEmpty() ){
				return persistenceMap.removeFirst();
			}
		} catch ( Exception e){
			e.printStackTrace();
			return null;
		}
		return null;
	}
	
	public static boolean isEmpty(){
		
		if ( persistenceMap != null && !persistenceMap.isEmpty() )
			return false;

		return true;
	}
}
