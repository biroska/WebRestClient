package com.ubs.manhatthan.manager.enums;

public enum MessageTypeEnum {
	
	UNKNOWN               			( 0 ),
	CREATE_STRATEGY       			( 1 ),
	MODIFY_STRATEGY       			( 2 ),
	RESUME_STRATEGY       			( 3 ),
	PAUSE_STRATEGY        			( 4 ),
	CANCEL_STRATEGY       			( 5 ),
	REPORT_STRATEGY       			( 6 ),
	REJECT_RESUME_STRATEGY			( 7 ),
	REPORT_ORDER          			( 8 ),
	MODIFY_ORDER          			( 9 ),
	CANCEL_ORDER          			( 10 ),
	NEW_ORDER             			( 11 ),
	HEARTBEAT             			( 12 ),
	LOGON                 			( 13 ),
	REJECT_CREATE_STRATEGY			( 14 ),
	REJECT_MODIFY_STRATEGY			( 15 ),
	REJECT_CANCEL_STRATEGY			( 16 ),
	STATISTICS_MESSAGE    			( 17 ),
	WARNING_MESSAGE       			( 18 ),
	COMMAND_MESSAGE      			( 19 ),
	LEGGED_ORDER          			( 20 ),
	LOGOFF                			( 21 ),
	REJECT_PAUSE_STRATEGY 			( 22 ),
	REJECT_REPORT_EXECUTION_ORDER   ( 23 ),
	REPORT_EXECUTION_ORDER			( 24 );

    private int code;

    MessageTypeEnum(int code ) {
            this.code = code;
    }

    public int getCode( ) {
    	return code;
    }
}