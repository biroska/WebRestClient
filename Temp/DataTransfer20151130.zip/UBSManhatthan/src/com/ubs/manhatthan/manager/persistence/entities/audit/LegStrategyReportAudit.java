package com.ubs.manhatthan.manager.persistence.entities.audit;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.enums.OrderTypeEnum;
import com.ubs.manhatthan.manager.enums.SideEnum;
import com.ubs.manhatthan.manager.enums.TimeInForceEnum;
import com.ubs.manhatthan.manager.persistence.entities.LegStrategyReport;

@Entity
@Table(name="TB_AUDIT_LEG_STRATEGY_REPORT")
public class LegStrategyReportAudit {
	
	public LegStrategyReportAudit() {
		super();
	}
	
	public LegStrategyReportAudit( LegStrategyReport legStrategyReport, ActionTypeEnum action, String user,
			Date registryDate ) {
		super();
		this.action = action;
		this.user = user;
		this.registryDate = registryDate;
		this.legSeq = legStrategyReport.getId().getLegSeq();
		this.strategyReportId =  legStrategyReport.getId().getStrategyId();
		
		this.instrument = legStrategyReport.getInstrument();
		this.totalQuantity = legStrategyReport.getTotalQuantity();
		this.executedPercentage = legStrategyReport.getExecutedPercentage();
		this.remainingQuantity = legStrategyReport.getRemainingQuantity();
		this.executedQuantity = legStrategyReport.getExecutedQuantity();
		this.averagePrice = legStrategyReport.getAveragePrice();
		this.text = legStrategyReport.getText();
		this.side = legStrategyReport.getSide();
		this.orderType = legStrategyReport.getOrderType();
		this.timeInForce = legStrategyReport.getTimeInForce();
		this.passiveLeg = legStrategyReport.getPassiveLeg();
		this.maxQuantityDisplay = legStrategyReport.getMaxQuantityDisplay();
		this.minQuantityDisplay = legStrategyReport.getMinQuantityDisplay();
		this.restingQuantity = legStrategyReport.getRestingQuantity();
		this.restingPrice = legStrategyReport.getRestingPrice();
		this.restingRank = legStrategyReport.getRestingRank();
		this.timeOut = legStrategyReport.getTimeOut();
		this.investorId = legStrategyReport.getInvestorId();
		this.enteringTrader = legStrategyReport.getEnteringTrader();
		this.routeId = legStrategyReport.getRouteId() != null ? legStrategyReport.getRouteId().getId() : null;
		this.account = legStrategyReport.getAccount() != null ? legStrategyReport.getAccount().getCode() : null;
		this.login = legStrategyReport.getLogin();
	}

	@Id
	@Column ( name = "ID")
	@SequenceGenerator(name = "TB_AUDIT_LEG_STRATEGY_REPORT_ID_GENERATOR", sequenceName = "SEQ_AUDIT_LEG_STRATEGY_REPORT", allocationSize = 1)
	@GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "TB_AUDIT_LEG_STRATEGY_REPORT_ID_GENERATOR" )
	private Long id;
	
	@Enumerated(EnumType.STRING)
	@Column( name = "ACTION", nullable=false )
	private ActionTypeEnum action;
	
	@Column( name = "REGISTRY_USER", nullable=false )
	private String user;
	
	@Column( name = "REGISTRY_DATE", nullable=false )
	private Date registryDate;
	
	@Column ( name = "ORIG_ID_LEG_SEQ", nullable=false)
	private Integer legSeq;
	
	@Column(name = "ORIG_ID_STRATEGY_ID", nullable = false )
	private Long strategyReportId;
	
	@Column ( name = "INSTRUMENT", nullable=false)
	private Long instrument;
	
	@Column ( name = "TOTAL_QUANTITY", nullable=false)
	private Long totalQuantity;
	
	@Column ( name = "EXECUTED_PERCENTAGE", columnDefinition= "Decimal(10,3)", nullable = false)
	private Double executedPercentage;
	
	@Column ( name = "REMAINING_QUANTITY", nullable = false)
	private Long remainingQuantity;
	
	@Column ( name = "EXECUTED_QUANTITY", nullable = false)
	private Long executedQuantity;
	
	@Column ( name = "AVERAGE_PRICE", columnDefinition= "Decimal(10,7)", nullable = false)
	private Double averagePrice;
	
	@Column ( name = "TEXT", length = 256 )
	private String text;
	
	@Column ( name = "SIDE", nullable = false)
	private SideEnum side;
	
	@Column(name = "ROUTE_ID", nullable = false )
	private Integer routeId;
	
	@Column ( name = "ORDER_TYPE")
	private OrderTypeEnum orderType;
	
	@Column ( name = "TIME_IN_FORCE")
	private TimeInForceEnum timeInForce;
	
	@Column(name = "ACCOUNT", nullable = false )
	private Long account;
	
	@Column ( name = "PASSIVE_LEG")
	private Boolean passiveLeg;
	
	@Column ( name = "MAX_QUANTITY_DISPLAY")
	private Long maxQuantityDisplay;
	
	@Column ( name = "MIN_QUANTITY_DISPLAY")
	private Long minQuantityDisplay;
	
	@Column ( name = "RESTING_QUANTITY")
	private Long restingQuantity;
	
	@Column ( name = "RESTING_PRICE", columnDefinition= "Decimal(10,7)")
	private Double restingPrice;
	
	@Column ( name = "RESTING_RANK")
	private Long restingRank;
	
	@Column ( name = "TIME_OUT")
	private Long timeOut;
	
	@Column ( name = "INVESTOR_ID", length = 16)
	private String investorId;
	
	@Column ( name = "ENTERING_TRADER", length = 8)
	private String enteringTrader;
	
	@Column ( name = "LOGIN", length = 64)
	private String login;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public ActionTypeEnum getAction() {
		return action;
	}

	public void setAction(ActionTypeEnum action) {
		this.action = action;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public Date getRegistryDate() {
		return registryDate;
	}

	public void setRegistryDate(Date registryDate) {
		this.registryDate = registryDate;
	}

	public Integer getLegSeq() {
		return legSeq;
	}

	public void setLegSeq(Integer legSeq) {
		this.legSeq = legSeq;
	}

	public Long getStrategyReportId() {
		return strategyReportId;
	}

	public void setStrategyReportId(Long strategyReportId) {
		this.strategyReportId = strategyReportId;
	}
	
	public Long getInstrument() {
		return instrument;
	}

	public void setInstrument(Long instrument) {
		this.instrument = instrument;
	}

	public Long getTotalQuantity() {
		return totalQuantity;
	}

	public void setTotalQuantity(Long totalQuantity) {
		this.totalQuantity = totalQuantity;
	}

	public Double getExecutedPercentage() {
		return executedPercentage;
	}

	public void setExecutedPercentage(Double executedPercentage) {
		this.executedPercentage = executedPercentage;
	}

	public Long getRemainingQuantity() {
		return remainingQuantity;
	}

	public void setRemainingQuantity(Long remainingQuantity) {
		this.remainingQuantity = remainingQuantity;
	}

	public Long getExecutedQuantity() {
		return executedQuantity;
	}

	public void setExecutedQuantity(Long executedQuantity) {
		this.executedQuantity = executedQuantity;
	}

	public Double getAveragePrice() {
		return averagePrice;
	}

	public void setAveragePrice(Double averagePrice) {
		this.averagePrice = averagePrice;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public SideEnum getSide() {
		return side;
	}

	public void setSide(SideEnum side) {
		this.side = side;
	}

	public OrderTypeEnum getOrderType() {
		return orderType;
	}

	public void setOrderType(OrderTypeEnum orderType) {
		this.orderType = orderType;
	}

	public TimeInForceEnum getTimeInForce() {
		return timeInForce;
	}

	public void setTimeInForce(TimeInForceEnum timeInForce) {
		this.timeInForce = timeInForce;
	}

	public Boolean getPassiveLeg() {
		return passiveLeg;
	}

	public void setPassiveLeg(Boolean passiveLeg) {
		this.passiveLeg = passiveLeg;
	}

	public Long getMaxQuantityDisplay() {
		return maxQuantityDisplay;
	}

	public void setMaxQuantityDisplay(Long maxQuantityDisplay) {
		this.maxQuantityDisplay = maxQuantityDisplay;
	}

	public Long getMinQuantityDisplay() {
		return minQuantityDisplay;
	}

	public void setMinQuantityDisplay(Long minQuantityDisplay) {
		this.minQuantityDisplay = minQuantityDisplay;
	}

	public Long getRestingQuantity() {
		return restingQuantity;
	}

	public void setRestingQuantity(Long restingQuantity) {
		this.restingQuantity = restingQuantity;
	}

	public Double getRestingPrice() {
		return restingPrice;
	}

	public void setRestingPrice(Double restingPrice) {
		this.restingPrice = restingPrice;
	}

	public Long getRestingRank() {
		return restingRank;
	}

	public void setRestingRank(Long restingRank) {
		this.restingRank = restingRank;
	}

	public Long getTimeOut() {
		return timeOut;
	}

	public void setTimeOut(Long timeOut) {
		this.timeOut = timeOut;
	}

	public String getInvestorId() {
		return investorId;
	}

	public void setInvestorId(String investorId) {
		this.investorId = investorId;
	}

	public String getEnteringTrader() {
		return enteringTrader;
	}

	public void setEnteringTrader(String enteringTrader) {
		this.enteringTrader = enteringTrader;
	}

	public Integer getRouteId() {
		return routeId;
	}

	public void setRouteId(Integer routeId) {
		this.routeId = routeId;
	}

	public Long getAccount() {
		return account;
	}

	public void setAccount(Long account) {
		this.account = account;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((action == null) ? 0 : action.hashCode());
		result = prime * result + ((legSeq == null) ? 0 : legSeq.hashCode());
		result = prime * result
				+ ((registryDate == null) ? 0 : registryDate.hashCode());
		result = prime
				* result
				+ ((strategyReportId == null) ? 0 : strategyReportId.hashCode());
		result = prime * result + ((user == null) ? 0 : user.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LegStrategyReportAudit other = (LegStrategyReportAudit) obj;
		if (action != other.action)
			return false;
		if (legSeq == null) {
			if (other.legSeq != null)
				return false;
		} else if (!legSeq.equals(other.legSeq))
			return false;
		if (registryDate == null) {
			if (other.registryDate != null)
				return false;
		} else if (!registryDate.equals(other.registryDate))
			return false;
		if (strategyReportId == null) {
			if (other.strategyReportId != null)
				return false;
		} else if (!strategyReportId.equals(other.strategyReportId))
			return false;
		if (user == null) {
			if (other.user != null)
				return false;
		} else if (!user.equals(other.user))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "LegStrategyReportAudit [id=" + id + ", action=" + action
				+ ", user=" + user + ", registryDate=" + registryDate
				+ ", legSeq=" + legSeq + ", strategyReportId="
				+ strategyReportId + ", instrument=" + instrument
				+ ", totalQuantity=" + totalQuantity + ", executedPercentage="
				+ executedPercentage + ", remainingQuantity="
				+ remainingQuantity + ", executedQuantity=" + executedQuantity
				+ ", averagePrice=" + averagePrice + ", text=" + text
				+ ", side=" + side + ", routeId=" + routeId + ", orderType="
				+ orderType + ", timeInForce=" + timeInForce + ", account="
				+ account + ", passiveLeg=" + passiveLeg
				+ ", maxQuantityDisplay=" + maxQuantityDisplay
				+ ", minQuantityDisplay=" + minQuantityDisplay
				+ ", restingQuantity=" + restingQuantity + ", restingPrice="
				+ restingPrice + ", restingRank=" + restingRank + ", timeOut="
				+ timeOut + ", investorId=" + investorId + ", enteringTrader="
				+ enteringTrader + ", login=" + login + "]";
	}
}