/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import com.ubs.manhatthan.manager.persistence.entities.audit.SessionByEngineAudit;

/**
 * @author galdinoa
 *
 */
public interface ISessionByEngineAuditDAO extends IGenericDAO<SessionByEngineAudit, Long> {}
