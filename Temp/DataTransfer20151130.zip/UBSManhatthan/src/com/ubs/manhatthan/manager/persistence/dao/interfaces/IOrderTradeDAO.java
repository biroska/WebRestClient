/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import com.ubs.manhatthan.manager.persistence.entities.OrderTrade;

/**
 * @author galdinoa
 *
 */
public interface IOrderTradeDAO extends IGenericDAO<OrderTrade, Long> {

	OrderTrade saveOrderTrade(OrderTrade orderTrade);
}
