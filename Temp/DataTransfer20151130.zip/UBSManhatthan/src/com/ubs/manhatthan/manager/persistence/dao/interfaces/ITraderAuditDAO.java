/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import com.ubs.manhatthan.manager.persistence.entities.audit.TraderAudit;


/**
 * @author galdinoa
 *
 */
public interface ITraderAuditDAO extends IGenericDAO<TraderAudit, Long> {}
