package com.ubs.manhatthan.manager.lmdsadapter.adapter;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class AdapterManager
{
	private final static AdapterManager instance = new AdapterManager();
	
	private boolean started;

	private AdapterManager()
	{
		this.started = true;
	}
	
	public synchronized void configureAdapter(String configFile) throws AdapterConfigurationException, AdapterRuntimeException {
		
		
		Properties config = new Properties();
		
		//
		// Load config
		//
		try {
		InputStream configInStream = new FileInputStream(configFile);
		config.load(configInStream);
		}
		catch (IOException e) {
			throw new AdapterConfigurationException("Cannot open configuration file", e);
		}
		
		//
		// Get class name
		//
		String adapterClassName = config.getProperty("marketdata.adapter");
		if (adapterClassName == null) {
			throw new AdapterConfigurationException("Invalid adapter configuration. Missing: marketdata.adapter ");
		}
		
		//
		// Load adapter
		//
		Adapter adapter = null;
		try
		{
			adapter = AdapterManager.getAdapterByName(adapterClassName);
		} catch (ClassNotFoundException e)
		{
			throw new AdapterConfigurationException("Invalid adapter class:" + adapterClassName, e);
		}
		adapter.configure(config);
		
		if (this.started) {
			adapter.start();
		}
		
	}

	public static AdapterManager getInstance()
	{
		return instance;
	}	
	
	private static Adapter getAdapterByName(String className) throws ClassNotFoundException {
		
		Class<?> c = Class.forName(className);
		
		if (!Adapter.class.isAssignableFrom(c)) {
			throw new ClassNotFoundException("Class " + className + " does not implement interface Adapter");
		}	
		
		Adapter adapter;
		try
		{
			adapter = (Adapter)c.newInstance();
		} catch (InstantiationException | IllegalAccessException e)
		{
			throw new ClassNotFoundException("Class " + className + " does not implement default constructor", e);
		}
	
		return adapter;
	}

}
