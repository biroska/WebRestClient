package com.ubs.manhatthan.manager.persistence.dao;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.ISessionByAccountAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.ISessionByAccountDAO;
import com.ubs.manhatthan.manager.persistence.entities.ClientAccount;
import com.ubs.manhatthan.manager.persistence.entities.OrderFixSession;
import com.ubs.manhatthan.manager.persistence.entities.SessionByAccount;
import com.ubs.manhatthan.manager.persistence.entities.audit.SessionByAccountAudit;

@Repository
@Scope("singleton")
public class SessionByAccountDAO extends GenericDAO<SessionByAccount, Long> implements ISessionByAccountDAO {
	
	private ClientAccountDAO clientAccountDAO = new ClientAccountDAO();
	private OrderFixSessionDAO orderFixSessionDAO = new OrderFixSessionDAO();
	
	@Autowired
	private ISessionByAccountAuditDAO sessionByAccountAuditDAO;
	
	@Autowired
	private User user;
	
	@Override
	public SessionByAccount saveOrderFixSession( SessionByAccount sessionByAccount ){
		
		ActionTypeEnum action = sessionByAccount.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;

		sessionByAccount  = update( sessionByAccount );

		SessionByAccountAudit sbaa = new SessionByAccountAudit( sessionByAccount, action, user.getLogin(), new Date() );
		
		sessionByAccountAuditDAO.update( sbaa );
		
		return sessionByAccount;
	}

	public Long generate( int qtd ){
		
		List<ClientAccount> clientAccountList = clientAccountDAO.findAll();
		List<OrderFixSession> orderFixSessionList = orderFixSessionDAO.findAll();
		
		Long qtRegs = 0L;
		
		for ( int i = 1; i<= qtd; i++ ){
			saveOrderFixSession( new SessionByAccount( clientAccountList.get( i -1), orderFixSessionList.get( qtd -i) ) );
			qtRegs++;
		}
		
		return qtRegs;
	}
	
	public void setSessionByAccountAuditDAO(ISessionByAccountAuditDAO sessionByAccountAuditDAO) {
		this.sessionByAccountAuditDAO = sessionByAccountAuditDAO;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
}