package com.ubs.manhatthan.manager.persistence.dao.audit;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.manager.persistence.dao.GenericDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IRoleAuditDAO;
import com.ubs.manhatthan.manager.persistence.entities.audit.RoleAudit;

@Repository
@Scope("singleton")
public class RoleAuditDAO extends GenericDAO<RoleAudit, Long> implements IRoleAuditDAO {}
