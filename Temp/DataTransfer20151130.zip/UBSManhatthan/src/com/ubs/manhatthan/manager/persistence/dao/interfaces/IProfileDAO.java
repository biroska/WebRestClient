/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import java.util.List;

import com.ubs.manhatthan.manager.persistence.entities.Profile;

/**
 * @author galdinoa
 *
 */
public interface IProfileDAO extends IGenericDAO<Profile, Long> {

	Profile saveProfile(Profile profile);

	List<Profile> findProfile(Profile profile);
}
