package com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities;

public interface BookSnapshot {
	
	/**
	 * Get the ID of the last incremental update that was
	 * applied.
	 * 
	 * @return the unique id of the last incremental
	 */
	long getLastIncrementalID();
	
	/**
	 * Instrument related to this book
	 * 
	 * @return The instrument of this book
	 */
	Security getSecurity();

	/**
	 * Check if the book is empty (no entries on bid and offer)
	 * 
	 * @return True if the book is empty
	 */
	boolean isEmpty();
	
	/**
	 * Number of entries on bid size
	 * 
	 * @return number of entries
	 */
	int getBidSize();
	
	/**
	 * Number of entries on ask size
	 * 	
	 * @return number of entries
	 */
	int getAskSize();
	
	/**
	 * Get bid entry at the given position
	 * 
	 * @param position 0 is the first position
	 * @return entry at the given position or null if position is invalid
	 */
	BookEntry getBidAt(int position);
	
	/**
	 * Get ask entry at the given position
	 * 
	 * @param position 0 is the first position
	 * @return entry at the given position or null if position is invalid
	 */	
	BookEntry getAskAt(int position);
	
}
