package com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities;

import java.math.BigDecimal;

public interface BookEntry {
	
	Side getSide();
	
	long getQuantity();
	
	BigDecimal getPrice();
	
	boolean isAggregatedEntry();
	
	int numberOfAggregatedOrders();

}
