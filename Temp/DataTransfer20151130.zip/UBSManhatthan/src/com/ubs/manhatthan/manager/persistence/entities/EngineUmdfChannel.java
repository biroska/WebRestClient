package com.ubs.manhatthan.manager.persistence.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name="TB_ENGINE_UMDF_CHANNELS",
	   uniqueConstraints={
				   @UniqueConstraint(columnNames={"CHANNEL_ID"}, name = "CK_ENGINE_UMDF_CHANNELS_CHANNELID")
				})
public class EngineUmdfChannel {
	
	public EngineUmdfChannel(){}
	
	public EngineUmdfChannel(Long channelId, Exchange exchange) {
		super();
		this.channelId = channelId;
		this.exchange = exchange;
	}

	public EngineUmdfChannel(Long channelId, Exchange exchange,
			String incrementalIp, Long incrementalPort,
			String marketRecoveryIp, Long marketRecoveryPort,
			String instrumentDefinitionIp, Long instrumentDefinitionPort) {
		super();
		this.channelId = channelId;
		this.exchange = exchange;
		this.incrementalIp = incrementalIp;
		this.incrementalPort = incrementalPort;
		this.marketRecoveryIp = marketRecoveryIp;
		this.marketRecoveryPort = marketRecoveryPort;
		this.instrumentDefinitionIp = instrumentDefinitionIp;
		this.instrumentDefinitionPort = instrumentDefinitionPort;
	}



	@Id
	@Column ( name = "ID")
	@SequenceGenerator(name = "TB_ENGINE_UMDF_CHANNELS_ID_GENERATOR", sequenceName = "SEQ_ENGINE_UMDF_CHANNELS", allocationSize = 1)
	@GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "TB_ENGINE_UMDF_CHANNELS_ID_GENERATOR" )
	private Long id;
	
	@Column(name = "CHANNEL_ID", nullable = false )
	private Long channelId;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "EXCHANGE", nullable = false )
	private Exchange exchange;
	
	@Column(name = "INCREMENTAL_IP", nullable = false, length = 16  )
	private String incrementalIp;
	
	@Column(name = "INCREMENTAL_PORT", nullable = false  )
	private Long incrementalPort;
	
	@Column(name = "MARKET_RECOVERY_IP", nullable = false, length = 16  )
	private String marketRecoveryIp;
	
	@Column(name = "MARKET_RECOVERY_PORT", nullable = false  )
	private Long marketRecoveryPort;
	
	@Column(name = "INSTRUMENT_DEFINITION_IP", nullable = false, length = 16  )
	private String instrumentDefinitionIp;
	
	@Column(name = "INSTRUMENT_DEFINITION_PORT", nullable = false  )
	private Long instrumentDefinitionPort;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getChannelId() {
		return channelId;
	}

	public void setChannelId(Long channelId) {
		this.channelId = channelId;
	}

	public Exchange getExchange() {
		return exchange;
	}

	public void setExchange(Exchange exchange) {
		this.exchange = exchange;
	}

	public String getIncrementalIp() {
		return incrementalIp;
	}

	public void setIncrementalIp(String incrementalIp) {
		this.incrementalIp = incrementalIp;
	}

	public Long getIncrementalPort() {
		return incrementalPort;
	}

	public void setIncrementalPort(Long incrementalPort) {
		this.incrementalPort = incrementalPort;
	}

	public String getMarketRecoveryIp() {
		return marketRecoveryIp;
	}

	public void setMarketRecoveryIp(String marketRecoveryIp) {
		this.marketRecoveryIp = marketRecoveryIp;
	}

	public Long getMarketRecoveryPort() {
		return marketRecoveryPort;
	}

	public void setMarketRecoveryPort(Long marketRecoveryPort) {
		this.marketRecoveryPort = marketRecoveryPort;
	}

	public String getInstrumentDefinitionIp() {
		return instrumentDefinitionIp;
	}

	public void setInstrumentDefinitionIp(String instrumentDefinitionIp) {
		this.instrumentDefinitionIp = instrumentDefinitionIp;
	}

	public Long getInstrumentDefinitionPort() {
		return instrumentDefinitionPort;
	}

	public void setInstrumentDefinitionPort(Long instrumentDefinitionPort) {
		this.instrumentDefinitionPort = instrumentDefinitionPort;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((channelId == null) ? 0 : channelId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EngineUmdfChannel other = (EngineUmdfChannel) obj;
		if (channelId == null) {
			if (other.channelId != null)
				return false;
		} else if (!channelId.equals(other.channelId))
			return false;
		return true;
	}
}