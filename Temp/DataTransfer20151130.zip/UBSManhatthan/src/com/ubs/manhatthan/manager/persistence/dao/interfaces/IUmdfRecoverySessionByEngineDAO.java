/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import com.ubs.manhatthan.manager.persistence.entities.UmdfRecoverySessionByEngine;

/**
 * @author galdinoa
 *
 */
public interface IUmdfRecoverySessionByEngineDAO extends IGenericDAO<UmdfRecoverySessionByEngine, Long> {

	UmdfRecoverySessionByEngine saveUmdfRecoverySessionByEngine(
			UmdfRecoverySessionByEngine umdfRecoverySessionByEngine);
}
