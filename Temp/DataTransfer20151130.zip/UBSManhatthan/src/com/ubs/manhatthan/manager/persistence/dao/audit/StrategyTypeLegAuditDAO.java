package com.ubs.manhatthan.manager.persistence.dao.audit;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.manager.persistence.dao.GenericDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IStrategyTypeLegAuditDAO;
import com.ubs.manhatthan.manager.persistence.entities.audit.StrategyTypeLegAudit;

@Repository
@Scope("singleton")
public class StrategyTypeLegAuditDAO extends GenericDAO<StrategyTypeLegAudit, Long> implements IStrategyTypeLegAuditDAO {}
