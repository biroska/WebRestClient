/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import com.ubs.manhatthan.manager.persistence.entities.SessionByAccount;

/**
 * @author galdinoa
 *
 */
public interface ISessionByAccountDAO extends IGenericDAO<SessionByAccount, Long> {

	SessionByAccount saveOrderFixSession(SessionByAccount sessionByAccount);

}
