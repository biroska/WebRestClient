/**
 * 
 */
package com.ubs.manhatthan.manager.facade;

import com.ubs.manhatthan.manager.persistence.entities.StrategyReport;

/**
 * @author galdinoa
 *
 */
public interface IManager {

	public StrategyReport generateStrategyReport(Long qtdLegs, Integer qtdOrders);

}
