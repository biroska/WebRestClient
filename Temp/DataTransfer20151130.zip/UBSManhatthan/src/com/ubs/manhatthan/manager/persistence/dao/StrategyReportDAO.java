package com.ubs.manhatthan.manager.persistence.dao;

import java.util.Date;

import com.ubs.manhatthan.manager.persistence.dao.audit.StrategyReportAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IStrategyReportDAO;
import com.ubs.manhatthan.manager.persistence.entities.StrategyReport;
import com.ubs.manhatthan.manager.persistence.entities.id.StrategyReportPK;

//@Repository
//@Scope("singleton")
public class StrategyReportDAO extends GenericDAO<StrategyReport, StrategyReportPK> implements IStrategyReportDAO {
	
	public StrategyReportDAO() {}
	
	static {
		strategyReportAuditDAO = new StrategyReportAuditDAO();
	}
	
//	@Autowired
//	private IStrategyReportAuditDAO strategyReportAuditDAO;
	private static StrategyReportAuditDAO strategyReportAuditDAO;
	
	
	@Override
	public StrategyReport saveReport( StrategyReport report ){
		
		report.setStrategyTimestamp( new Date() );
		
//		Salva o strategy report, legs e orders
		report = update( report );
		
//		Gera registro na tabela de auditoria - Strategyreport
		strategyReportAuditDAO.saveReportAudit( report );
		
		return report;
	}
}