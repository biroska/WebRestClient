package com.ubs.manhatthan.manager.enums;


public enum SideEnum{
	
	NOT_DEFINED                 ( 0 ),
    BUY                         ( 1 ), // 49
    SELL                        ( 2 ), // 50
    CROSS						( 8 ); // 56

    private final Integer code;
    
    private SideEnum( Integer code ) {
        this.code = code;
    }

    public Integer getCode() {
        return code;
    }
    
    public static SideEnum fromValue( Integer value ){
    	
		for (SideEnum item : SideEnum.values() ) {
			if ( item.getCode().equals( value ) ){
				return item;
			}
		}
		return null;
    }
    
    public static char integerToCharValue( Integer value ){
    	return (char) String.valueOf( value ).charAt( 0 );
    }
    
    public static Integer ascToIntegerValue( int value ){
    	return Integer.valueOf( String.valueOf( (char) value ) );
    }
    
}