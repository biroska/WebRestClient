package com.ubs.manhatthan.manager.persistence.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name="TB_ENGINE_INSTANCES", 
	   uniqueConstraints={
				   @UniqueConstraint(columnNames={"ENGINE_ID"}, name = "CK_ENGINE_INSTANCES_ENGINE_ID")
	  })
public class EngineInstance {
	
	public EngineInstance(){}
	
	public EngineInstance(Long engineId, String host, Long port, String description) {
		super();
		this.engineId = engineId;
		this.host = host;
		this.port = port;
		this.description = description;
	}

	@Id
	@Column ( name = "ID")
	@SequenceGenerator(name = "TB_ENGINE_INSTANCES_ID_GENERATOR", sequenceName = "SEQ_ENGINE_INSTANCES", allocationSize = 1)
	@GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "TB_ENGINE_INSTANCES_ID_GENERATOR" )
	private Integer id;
	
	@Column ( name = "ENGINE_ID", nullable=false )
	private Long engineId;
	
	@Column ( name = "HOST", nullable=false, length = 256 )
	private String host;
	
	@Column ( name = "PORT", nullable=false )
	private Long port;
	
	@Column ( name = "DESCRIPTION", nullable=false, length = 15 )
	private String description;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Long getEngineId() {
		return engineId;
	}

	public void setEngineId(Long engineId) {
		this.engineId = engineId;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public Long getPort() {
		return port;
	}

	public void setPort(Long port) {
		this.port = port;
	}
	
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((engineId == null) ? 0 : engineId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EngineInstance other = (EngineInstance) obj;
		if (engineId == null) {
			if (other.engineId != null)
				return false;
		} else if (!engineId.equals(other.engineId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "EngineInstance [id=" + id + ", engineId=" + engineId
				+ ", host=" + host + ", port=" + port + ", description="
				+ description + "]";
	}
}