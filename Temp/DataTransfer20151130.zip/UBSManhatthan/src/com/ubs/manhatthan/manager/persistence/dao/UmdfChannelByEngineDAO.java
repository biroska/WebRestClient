package com.ubs.manhatthan.manager.persistence.dao;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IEngineInstanceDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IEngineUmdfChannelDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IUmdfChannelByEngineAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IUmdfChannelByEngineDAO;
import com.ubs.manhatthan.manager.persistence.entities.EngineInstance;
import com.ubs.manhatthan.manager.persistence.entities.EngineUmdfChannel;
import com.ubs.manhatthan.manager.persistence.entities.UmdfChannelByEngine;
import com.ubs.manhatthan.manager.persistence.entities.audit.UmdfChannelByEngineAudit;

@Repository
@Scope("singleton")
public class UmdfChannelByEngineDAO extends GenericDAO<UmdfChannelByEngine, Long> implements IUmdfChannelByEngineDAO {
	
	@Autowired
	private IEngineInstanceDAO engineInstanceDAO;
	
	@Autowired
	private IEngineUmdfChannelDAO engineUmdfChannelDAO;
	
	@Autowired
	private IUmdfChannelByEngineAuditDAO umdfChannelByEngineAuditDAO;
	
	@Autowired
	private User user;
	
	@Override
	public UmdfChannelByEngine saveUmdfChannelByEngine( UmdfChannelByEngine umdfChannelByEngine ){
		
		ActionTypeEnum action = umdfChannelByEngine.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;

		umdfChannelByEngine  = update( umdfChannelByEngine );

		UmdfChannelByEngineAudit ofsa = new UmdfChannelByEngineAudit( umdfChannelByEngine, action, user.getLogin(), new Date() );
		
		umdfChannelByEngineAuditDAO.update( ofsa );
		
		return umdfChannelByEngine;
	}

	public Long generate( int qtd ){
		
		List<EngineInstance> engineInstanceList = engineInstanceDAO.findAll();
		List<EngineUmdfChannel> engineUmdfChannelList = engineUmdfChannelDAO.findAll();
		
		Long qtRegs = 0L;
		
		for ( int i = 1; i<= qtd; i++ ){
			saveUmdfChannelByEngine( new UmdfChannelByEngine( engineInstanceList.get( i -1 ), engineUmdfChannelList.get( qtd -i ) ) );
			qtRegs++;
		}
		
		return qtRegs;
	}

	public void setEngineInstanceDAO(IEngineInstanceDAO engineInstanceDAO) {
		this.engineInstanceDAO = engineInstanceDAO;
	}

	public void setEngineUmdfChannelDAO(IEngineUmdfChannelDAO engineUmdfChannelDAO) {
		this.engineUmdfChannelDAO = engineUmdfChannelDAO;
	}

	public void setUmdfChannelByEngineAuditDAO(IUmdfChannelByEngineAuditDAO umdfChannelByEngineAuditDAO) {
		this.umdfChannelByEngineAuditDAO = umdfChannelByEngineAuditDAO;
	}

	public void setUser(User user) {
		this.user = user;
	}
}