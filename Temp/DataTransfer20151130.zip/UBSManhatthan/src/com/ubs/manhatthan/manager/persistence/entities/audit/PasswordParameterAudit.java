package com.ubs.manhatthan.manager.persistence.entities.audit;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.persistence.entities.PasswordParameter;

@Entity
@Table(name="TB_AUDIT_PASSWORD_PARAMETERS")
public class PasswordParameterAudit {
	
	public PasswordParameterAudit(){}

	public PasswordParameterAudit( PasswordParameter passwordParameters, ActionTypeEnum action, String user,
								   Date registryDate ) {
		super();
		this.action = action;
		this.user = user;
		this.registryDate = registryDate;
		
		this.origId = passwordParameters.getId();
		this.qtUpperChars = passwordParameters.getQtUpperChars();
		this.qtLowerChars = passwordParameters.getQtLowerChars();
		this.qtNumbers = passwordParameters.getQtNumbers();
		this.qtMinLength = passwordParameters.getQtMinLength();
		this.qtValidDays = passwordParameters.getQtValidDays();
	}

	@Id
	@Column ( name = "PROFILE")
	@SequenceGenerator(name = "TB_AUDIT_PASSWORD_PARAMETER_ID_GENERATOR", sequenceName = "SEQ_AUDIT_PASSWORD_PARAMETER", allocationSize = 1)
	@GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "TB_AUDIT_PASSWORD_PARAMETER_ID_GENERATOR" )
	private Long id;
	
	@Enumerated(EnumType.STRING)
	@Column( name = "ACTION", nullable=false )
	private ActionTypeEnum action;
	
	@Column( name = "REGISTRY_USER", nullable=false )
	private String user;
	
	@Column( name = "REGISTRY_DATE", nullable=false )
	private Date registryDate;

	@Column ( name = "ORIG_ID", nullable=false )
	private Long origId;
	
	@Column ( name = "QT_UPPER_CHARS")
	private Integer qtUpperChars;
	
	@Column ( name = "QT_LOWER_CHARS")
	private Integer qtLowerChars;
	
	@Column ( name = "QT_NUMBERS")
	private Integer qtNumbers;
	
	@Column ( name = "QT_MIN_LENGTH")
	private Integer qtMinLength;
	
	@Column ( name = "QT_VALID_DAYS", nullable = false)
	private Integer qtValidDays = 90;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public ActionTypeEnum getAction() {
		return action;
	}

	public void setAction(ActionTypeEnum action) {
		this.action = action;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public Date getRegistryDate() {
		return registryDate;
	}

	public void setRegistryDate(Date registryDate) {
		this.registryDate = registryDate;
	}

	public Long getOrigId() {
		return origId;
	}

	public void setOrigId(Long origId) {
		this.origId = origId;
	}

	public Integer getQtUpperChars() {
		return qtUpperChars;
	}

	public void setQtUpperChars(Integer qtUpperChars) {
		this.qtUpperChars = qtUpperChars;
	}

	public Integer getQtLowerChars() {
		return qtLowerChars;
	}

	public void setQtLowerChars(Integer qtLowerChars) {
		this.qtLowerChars = qtLowerChars;
	}

	public Integer getQtNumbers() {
		return qtNumbers;
	}

	public void setQtNumbers(Integer qtNumbers) {
		this.qtNumbers = qtNumbers;
	}

	public Integer getQtMinLength() {
		return qtMinLength;
	}

	public void setQtMinLength(Integer qtMinLength) {
		this.qtMinLength = qtMinLength;
	}

	@Override
	public String toString() {
		return "PasswordParameterAudit[id=" + id + ", qtUpperChars=" + qtUpperChars +
									", qtLowerChars=" + qtLowerChars + ", qtNumbers=" + qtNumbers +
									", qtMinLength=" + qtMinLength + ", qtValidDays= " + qtValidDays +"]";
	}
}