/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.entities;

import com.ubs.manhatthan.manager.enums.MessageTypeEnum;

/**
 * @author galdinoa
 *
 */
public class Header {
	
	public Header(){}
	
	/**
	 * @param messageType
	 * @param engineInstanceId
	 * @param managerInstanceId
	 * @param managerRequestId
	 */
	public Header(MessageTypeEnum messageType, Long engineInstanceId,
			Integer managerInstanceId, Long managerRequestId) {
		super();
		this.messageType = messageType;
		this.engineInstanceId = engineInstanceId;
		this.managerInstanceId = managerInstanceId;
		this.managerRequestId = managerRequestId;
	}

	private MessageTypeEnum messageType;
	
	private Long engineInstanceId;
	
	private Integer managerInstanceId;
	
	private Long managerRequestId;

	public MessageTypeEnum getMessageType() {
		return messageType;
	}

	public void setMessageType(MessageTypeEnum messageType) {
		this.messageType = messageType;
	}

	public Long getEngineInstanceId() {
		return engineInstanceId;
	}

	public void setEngineInstanceId(Long engineInstanceId) {
		this.engineInstanceId = engineInstanceId;
	}

	public Integer getManagerInstanceId() {
		return managerInstanceId;
	}

	public void setManagerInstanceId(Integer managerInstanceId) {
		this.managerInstanceId = managerInstanceId;
	}

	public Long getManagerRequestId() {
		return managerRequestId;
	}

	public void setManagerRequestId(Long managerRequestId) {
		this.managerRequestId = managerRequestId;
	}
	
	public boolean isInitialized(){
		
		if ( messageType != null && engineInstanceId != null && 
			 managerInstanceId != null && managerRequestId != null )
			return true;
		
		return false;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((engineInstanceId == null) ? 0 : engineInstanceId.hashCode());
		result = prime
				* result
				+ ((managerInstanceId == null) ? 0 : managerInstanceId
						.hashCode());
		result = prime
				* result
				+ ((managerRequestId == null) ? 0 : managerRequestId.hashCode());
		result = prime * result
				+ ((messageType == null) ? 0 : messageType.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Header other = (Header) obj;
		if (engineInstanceId == null) {
			if (other.engineInstanceId != null)
				return false;
		} else if (!engineInstanceId.equals(other.engineInstanceId))
			return false;
		if (managerInstanceId == null) {
			if (other.managerInstanceId != null)
				return false;
		} else if (!managerInstanceId.equals(other.managerInstanceId))
			return false;
		if (managerRequestId == null) {
			if (other.managerRequestId != null)
				return false;
		} else if (!managerRequestId.equals(other.managerRequestId))
			return false;
		if (messageType != other.messageType)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Header [messageType=" + messageType + ", engineInstanceId="
				+ engineInstanceId + ", managerInstanceId=" + managerInstanceId
				+ ", managerRequestId=" + managerRequestId + "]";
	}
}
