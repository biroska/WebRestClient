/**
 * 
 */
package com.ubs.manhatthan.manager.tests;

import javax.persistence.EntityTransaction;

import com.ubs.manhatthan.manager.network.client.NetworkClientManager;
import com.ubs.manhatthan.manager.persistence.factory.FactoryManager;
import com.ubs.manhatthan.manager.service.ServiceException;
import com.ubs.manhatthan.manager.service.ServiceManager;
import com.ubs.manhatthan.manager.utils.Constant;

/**
 * @author galdinoa
 *
 */
public class CommunicationTeste {
	
	public static void main(String[] args){
		
		System.out.println( ""+FactoryManager.getEntityManager() );
		
		ServiceManager serviceManager = new ServiceManager();
		
		//Start & Register Network Service
		NetworkClientManager client = new NetworkClientManager( Constant.COMUNICATION.ADDRESS, 
															    Constant.COMUNICATION.PORT );
		
		try {
			serviceManager.registerService( client.getService() );
			//Start all services
			serviceManager.start();
			
			Thread.sleep(600000);
			
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
