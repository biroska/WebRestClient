/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import com.ubs.manhatthan.manager.persistence.entities.audit.StrategyTypeLegAudit;

/**
 * @author galdinoa
 *
 */
public interface IStrategyTypeLegAuditDAO extends IGenericDAO<StrategyTypeLegAudit, Long> {
}
