/**
 * 
 */
package com.ubs.manhatthan.manager.utils;

import java.io.FileNotFoundException;
import java.io.IOException;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import com.ubs.manhatthan.manager.cache.CacheHelper;
import com.ubs.manhatthan.manager.enums.EnviromentEnum;
import com.ubs.manhatthan.manager.lmdsadapter.LmdsManager;
import com.ubs.manhatthan.manager.lmdsadapter.adapter.AdapterConfigurationException;
import com.ubs.manhatthan.manager.lmdsadapter.adapter.AdapterRuntimeException;
import com.ubs.manhatthan.manager.network.client.NetworkClientManager;
import com.ubs.manhatthan.manager.persistence.PersistenceThread;
import com.ubs.manhatthan.manager.service.ServiceException;
import com.ubs.manhatthan.manager.service.ServiceManager;


/**
 * @author galdinoa
 *
 */

/* Objeto que � criado no deploy da aplica��o e possui um m�todo init que 
 * inicializa as conex�es com o engine e com o LMDS
 */
public class DeployInitialize {

	public void init(){
		
		boolean engineStarted = false;
		
//		Se a aplica��o estiver rodando em ambiente local, n�o estartar as conex�es
		if ( EnviromentEnum.LOCAL.name().equals( com.ubs.manhatthan.manager.utils.Util.getPropertyFromFile( "manhattan.enviroment" ) ) ){
			System.out.println("======================================================================================");
			System.out.println("Enviroment is local! \t Engine and LMDS are not started");
			System.out.println("======================================================================================");
			return;
		} else {
			try {
				if( CacheHelper.engineCommunicatorInstance.get( com.ubs.manhatthan.manager.utils.Util.getEngineId() ) == null ){
					
					System.out.println("======================================================================================");
					System.out.println("Starting Engine Service");
					System.out.println("======================================================================================");
					
					ServiceManager serviceManager = new ServiceManager();
					
					//Start & Register Network Service
					NetworkClientManager client = new NetworkClientManager( Constant.COMUNICATION.ADDRESS, 
																		    Constant.COMUNICATION.PORT );
					
					serviceManager.registerService( client.getService() );
					
					//Start all services
					serviceManager.start(); //Sending logon
					
//				Put the instance of engine in the cache
					CacheHelper.engineCommunicatorInstance.put( com.ubs.manhatthan.manager.utils.Util.getEngineId(), client );
					
					engineStarted = true;
				}
				
			} catch (ServiceException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			System.out.println("======================================================================================");
			System.out.println("Starting LMDS Service");
			System.out.println("======================================================================================");

			try {
				LmdsManager lmds = new LmdsManager();
				
				//Print start
				System.out.println("Starting LMDS...");
				
				//Initializing the LMDS Adapter

				ExternalContext ec = FacesContext.getCurrentInstance().getExternalContext();
				
				lmds.startLmdsAdapter( ec.getResourceAsStream("/WEB-INF/lmds-client-api.cfg") );
				
//				getClass().getResource("lmds-client-api.cfg");
//				getClass().getResource("./lmds-client-api.cfg");
//				getClass().getResource("././lmds-client-api.cfg");
//				getClass().getResource("../lmds-client-api.cfg");
				
				//ShutdownHook
//				Runtime.getRuntime().addShutdownHook(new Thread() {public void run(){ } });
//				
//				while(true) Thread.sleep(600000);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (AdapterConfigurationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (AdapterRuntimeException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			if ( engineStarted ){
				
				Thread persistenceThread = new Thread(new PersistenceThread(), "Persistence Thread");
				persistenceThread.start();				
			}
		}
	}
	
	public void destroy() throws Exception {
		System.out.println("======================================================================================");
		System.out.println("Spring Container is destroy! Customer clean up");
		System.out.println("======================================================================================");
	}

}
