package com.ubs.manhatthan.manager.persistence.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.TypedQuery;

import org.apache.commons.lang.StringUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.manager.persistence.dao.interfaces.IReportDAO;
import com.ubs.manhatthan.manager.persistence.entities.OrderTrade;

@Repository
@Scope("singleton")
public class ReportDAO extends GenericDAO<OrderTrade, Long> implements IReportDAO {

	private final String queryByStrategy = " SELECT  new OrderTrade( o.strategyOrder.legStrategyReport.strategyReport.id.strategyId , " +
									       "                         o.strategyOrder.legStrategyReport.strategyReport.strategyType.description , " +
									       "                         CASE WHEN ( o.side = 1 ) THEN 'C' WHEN ( o.side = 2 ) THEN 'V' ELSE '-' END , " + // Side C/V
									       "                         o.symbol, " +																	   // Symbol
								           "                         SUM(o.quantity), " +                                                              // Quantidade 
								           " 						 CASE WHEN ( SUM( o.quantity ) > 0 ) THEN ( SUM( o.quantity * o.price ) / SUM( o.quantity ) ) ELSE 0 END " +                         // Pre�o - m�dia ponderada  Sum( Qtd * R$ ) / sum(Qtd) 
		                   //              "                       , CASE WHEN ( SUM( o.quantity ) > 0 ) THEN ( SUM( o.quantity ) * ( SUM( o.quantity * o.price ) / SUM( o.quantity ) ) ) ELSE 0 END " + // Produto entre os valores das colunas Quantidade e Pre�o
						            	   "                        ) " +
						            	   "   FROM OrderTrade o ";

	private final String queryByAverage = " SELECT  new OrderTrade( CASE WHEN ( o.side = 1 ) THEN 'C' WHEN ( o.side = 2 ) THEN 'V' ELSE '-' END , " + // Side C/V
										  "                         o.symbol, " +																	   // Symbol
										  "                         SUM(o.quantity), " +                                                              // Quantidade 
										  " 						 CASE WHEN ( SUM( o.quantity ) > 0 ) THEN ( SUM( o.quantity * o.price ) / SUM( o.quantity ) ) ELSE 0 END " +                         // Pre�o - m�dia ponderada  Sum( Qtd * R$ ) / sum(Qtd) 
						  //              "                       , CASE WHEN ( SUM( o.quantity ) > 0 ) THEN ( SUM( o.quantity ) * ( SUM( o.quantity * o.price ) / SUM( o.quantity ) ) ) ELSE 0 END " + // Produto entre os valores das colunas Quantidade e Pre�o
							  			  "                        ) " +
										  "   FROM OrderTrade o ";
	
	private final String queryByExecution = " SELECT  new OrderTrade( CASE WHEN ( o.side = 1 ) THEN 'C' WHEN ( o.side = 2 ) THEN 'V' ELSE '-' END , " + // Side C/V
											"                         o.symbol, " +																	   // Symbol
											"						  o.orderTimestamp,	" +															   // hora da Execu��o
											"                         o.quantity , " +                                                             // Quantidade 
											" 						  o.price " +                         // Pre�o - m�dia ponderada  Sum( Qtd * R$ ) / sum(Qtd) 
											//              "                       , CASE WHEN ( SUM( o.quantity ) > 0 ) THEN ( SUM( o.quantity ) * ( SUM( o.quantity * o.price ) / SUM( o.quantity ) ) ) ELSE 0 END " + // Produto entre os valores das colunas Quantidade e Pre�o
											"                        ) " +
											"   FROM OrderTrade o ";
	
	private final String queryByPrice = " SELECT  new OrderTrade( o.strategyOrder.legStrategyReport.strategyReport.id.strategyId , " +
								        "                         o.strategyOrder.legStrategyReport.strategyReport.strategyType.description , " +
									    " 						  CASE WHEN ( o.side = 1 ) THEN 'C' WHEN ( o.side = 2 ) THEN 'V' ELSE '-' END , " + // Side C/V
									    "                         o.symbol, " +																	   // Symbol
									    "                         SUM( o.quantity ) , " +                                                             // Quantidade 
									    " 						  o.price " +                         // Pre�o - m�dia ponderada  Sum( Qtd * R$ ) / sum(Qtd) 
									//              "                       , CASE WHEN ( SUM( o.quantity ) > 0 ) THEN ( SUM( o.quantity ) * ( SUM( o.quantity * o.price ) / SUM( o.quantity ) ) ) ELSE 0 END " + // Produto entre os valores das colunas Quantidade e Pre�o
									    "                        ) " +
									    "   FROM OrderTrade o ";
	
	private Map<String, Object> parametersMap;
	
	@Override
	public List<OrderTrade> reportByStrategy( OrderTrade orderTrade ){
		
		String queryTemp = queryByStrategy;
		
		queryTemp = buildRestrictions( orderTrade, queryTemp );
		
		queryTemp += " GROUP BY o.strategyOrder.legStrategyReport.strategyReport.id.strategyId, " +
				   	 "          o.strategyOrder.legStrategyReport.strategyReport.strategyType.description, " +
				     "          o.symbol, " +
				     "          o.side " + 
		             " ORDER BY o.strategyOrder.legStrategyReport.strategyReport.id.strategyId, o.symbol ";
		
		TypedQuery<OrderTrade> typedQuery = getEm().createQuery( queryTemp, OrderTrade.class );

//		Setting the parameters
		for ( String param : parametersMap.keySet() ) {
			typedQuery.setParameter( param, parametersMap.get( param ) );
        }
		
		List<OrderTrade> resultList = typedQuery.getResultList();
		
		return resultList;
	}
	
	@Override
	public List<OrderTrade> reportByAverage( OrderTrade orderTrade ){
		
		String queryTemp = queryByAverage;
		
		queryTemp = buildRestrictions( orderTrade, queryTemp );
		
		queryTemp += " GROUP BY o.symbol, " +
				     "          o.side " + 
		             " ORDER BY o.symbol ";
		
		TypedQuery<OrderTrade> typedQuery = getEm().createQuery( queryTemp, OrderTrade.class );

//		Setting the parameters
		for ( String param : parametersMap.keySet() ) {
			typedQuery.setParameter( param, parametersMap.get( param ) );
        }
		
		List<OrderTrade> resultList = typedQuery.getResultList();
		
		return resultList;
	}
	
	@Override
	public List<OrderTrade> reportByExecution( OrderTrade orderTrade ){
		
		String queryTemp = queryByExecution;
		
		queryTemp = buildRestrictions( orderTrade, queryTemp );
		
		queryTemp += " ORDER BY o.symbol ";
		
		TypedQuery<OrderTrade> typedQuery = getEm().createQuery( queryTemp, OrderTrade.class );
		
//		Setting the parameters
		for ( String param : parametersMap.keySet() ) {
			typedQuery.setParameter( param, parametersMap.get( param ) );
		}
		
		List<OrderTrade> resultList = typedQuery.getResultList();
		
		return resultList;
	}
	
	@Override
	public List<OrderTrade> reportByPrice( OrderTrade orderTrade ){
		
		String queryTemp = queryByPrice;
		
		queryTemp = buildRestrictions( orderTrade, queryTemp );
		
		queryTemp += " GROUP BY o.strategyOrder.legStrategyReport.strategyReport.id.strategyId, " +
				   	 "          o.strategyOrder.legStrategyReport.strategyReport.strategyType.description, " +
				     "          o.symbol, " +
				     "          o.side, " + 
				     "          o.price " + 
		             " ORDER BY o.strategyOrder.legStrategyReport.strategyReport.id.strategyId, o.symbol ";
		
		TypedQuery<OrderTrade> typedQuery = getEm().createQuery( queryTemp, OrderTrade.class );
		
//		Setting the parameters
		for ( String param : parametersMap.keySet() ) {
			typedQuery.setParameter( param, parametersMap.get( param ) );
		}
		
		List<OrderTrade> resultList = typedQuery.getResultList();
		
		return resultList;
	}
	
	private String buildRestrictions( OrderTrade orderTrade, String query ){
		
		boolean whereWasSet = false;
        
		parametersMap = new HashMap<String, Object>();
		
		if ( StringUtils.isNotBlank( orderTrade.getLogin() ) ){
			query += buildWhere( whereWasSet );
			query += " o.login = :login ";
			whereWasSet = true;
			parametersMap.put("login", orderTrade.getLogin() );
	    }
		
		if ( orderTrade.getAccount() != null ){
			
			if ( orderTrade.getAccount().getCode() != null ){
				query += buildWhere( whereWasSet );
				query += " o.account.code = :code ";
				parametersMap.put("code", orderTrade.getAccount().getCode() );
			} else
				if ( orderTrade.getAccount().getName() != null ){
					query += buildWhere( whereWasSet );
					query += " o.account.name = :name ";
					parametersMap.put("name", orderTrade.getAccount().getName() );
				}
			
			whereWasSet = true;
		}
		
		if ( orderTrade.getStartDt() != null ){
			query += buildWhere( whereWasSet );
			query += " o.orderTimestamp >= :startDt ";
			parametersMap.put("startDt", orderTrade.getStartDt() );
		}
		
		if ( orderTrade.getEndDt() != null ){
			query += buildWhere( whereWasSet );
			query += " o.orderTimestamp <= :endDt ";
			parametersMap.put("endDt", orderTrade.getEndDt() );
		}
		
		return query;
	}
	
	private String buildWhere( boolean flag ){
		return flag ? " AND " : " WHERE  ";
	}
}