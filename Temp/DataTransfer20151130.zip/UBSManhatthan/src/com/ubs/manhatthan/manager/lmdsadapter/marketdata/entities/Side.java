package com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities;

/**
 * Side of an order
 * 
 * @author pretof
 *
 */
public enum Side {
	BUY,
	SELL,
	UNKNOWN
}
