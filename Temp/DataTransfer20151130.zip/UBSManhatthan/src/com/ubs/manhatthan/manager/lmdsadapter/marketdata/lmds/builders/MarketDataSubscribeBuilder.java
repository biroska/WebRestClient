package com.ubs.manhatthan.manager.lmdsadapter.marketdata.lmds.builders;

import quickfix.Message;
import quickfix.field.MDEntryType;
import quickfix.field.MDReqID;
import quickfix.field.MDUpdateType;
import quickfix.field.MarketDepth;
import quickfix.field.SecurityID;
import quickfix.field.SecurityIDSource;
import quickfix.field.SubscriptionRequestType;
import quickfix.field.Symbol;
import quickfix.fix44.MarketDataRequest;
import quickfix.fix44.MarketDataRequest.NoMDEntryTypes;
import quickfix.fix44.MarketDataRequest.NoRelatedSym;

public class MarketDataSubscribeBuilder
{	
	public static final char AGGREGATE_BID = 'e';
	public static final char AGGREGATE_OFFER = 'f';
	public static final char TRADING_PHASE = 'b';
	public static final char TRADING_STATUS = 'c';
	
	
	private final static char[] entryTypes = {
			//MDEntryType.BID, MDEntryType.OFFER,
			AGGREGATE_BID, AGGREGATE_OFFER,
			MDEntryType.TRADE,
			MDEntryType.OPENING_PRICE, MDEntryType.CLOSING_PRICE,
			MDEntryType.TRADING_SESSION_HIGH_PRICE,
			MDEntryType.TRADING_SESSION_LOW_PRICE,
			MDEntryType.TRADING_SESSION_VWAP_PRICE,
			MDEntryType.TRADE_VOLUME };

	/**
	 * Do not construct 
	 */
	private MarketDataSubscribeBuilder()
	{
		
	}

	public static Message buildSubscribe(String exchange, String symbol, String securityId, String reqId) {
		
		MarketDataRequest request = new MarketDataRequest();
		
		request.setString(MDReqID.FIELD, reqId);
		request.setChar(SubscriptionRequestType.FIELD, SubscriptionRequestType.SNAPSHOT_PLUS_UPDATES);
		request.setInt(MarketDepth.FIELD, 0);
		request.setInt(MDUpdateType.FIELD, MDUpdateType.INCREMENTAL_REFRESH);
		
		for (char entryType : entryTypes) {
			NoMDEntryTypes group = new NoMDEntryTypes();
			group.setChar(MDEntryType.FIELD, entryType);
			request.addGroup(group);
		}
		
		{
			NoRelatedSym group = new NoRelatedSym();
			group.setString(Symbol.FIELD, symbol);
			group.setString(SecurityID.FIELD, securityId);
			group.setString(SecurityIDSource.FIELD, SecurityIDSource.EXCHANGE_SYMBOL);
			request.addGroup(group);
		}		
		
		return request;
		
	}

	public static Message buildUnsubscribe(String exchange, String symbol, String securityId, String reqId) {
		
		MarketDataRequest request = new MarketDataRequest();
		
		request.setString(MDReqID.FIELD, reqId);
		request.setChar(SubscriptionRequestType.FIELD, SubscriptionRequestType.DISABLE_PREVIOUS_SNAPSHOT_PLUS_UPDATE_REQUEST);
		request.setInt(MarketDepth.FIELD, 0);
		request.setInt(MDUpdateType.FIELD, MDUpdateType.INCREMENTAL_REFRESH);
		
		for (char entryType : entryTypes) {
			NoMDEntryTypes group = new NoMDEntryTypes();
			group.setChar(MDEntryType.FIELD, entryType);
			request.addGroup(group);
		}
		
		{
			NoRelatedSym group = new NoRelatedSym();
			group.setString(Symbol.FIELD, symbol);
			group.setString(SecurityID.FIELD, securityId);
			group.setString(SecurityIDSource.FIELD, SecurityIDSource.EXCHANGE_SYMBOL);
			request.addGroup(group);
		}		
		
		return request;
		
	}
	
}
