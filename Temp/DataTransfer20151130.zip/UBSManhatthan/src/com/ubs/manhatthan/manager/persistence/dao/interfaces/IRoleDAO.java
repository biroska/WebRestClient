/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import java.util.List;

import com.ubs.manhatthan.manager.persistence.entities.Role;

/**
 * @author galdinoa
 *
 */
public interface IRoleDAO extends IGenericDAO<Role, Long> {

	Role saveRole(Role role);

	List<Role> findRole(Role role);
}
