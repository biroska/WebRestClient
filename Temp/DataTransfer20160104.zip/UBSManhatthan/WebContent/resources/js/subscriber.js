var countReceivedPackage = 0;
var countReceivedManagerPackage = 0;
var countReceivedMarketWatchPackage = 0;

var replaceDataEnabled = true;
var logEnabled = true;

function handleMessage(objJson) {
	countReceivedPackage++;
	
	log("handleMessage - total package [" + countReceivedPackage + "]");

	if (objJson.messageId == "1") { //Market Whatch data
		handleMessageMarketWhatch(objJson);
	} else { //Manager data
		handleMessageManager(objJson);
	}
}

function handleMessageMarketWhatch(objJson) {
	countReceivedMarketWatchPackage++;
	
	log("handleMessageMarketWhatch - total package [" + countReceivedMarketWatchPackage + "]");
	
	if (objJson.refreshTableIsNeeded == "S") {
		log("Refresh Screen Status for Market Whatch" + objJson.refreshTableIsNeeded);
		
		updateMarketWhatchTab();
	} else {
		handleMarketWatchObject(objJson);
	}
}

function handleMessageManager(objJson) {
	countReceivedManagerPackage++;
	
	log("handleMessageManager - total package [" + countReceivedManagerPackage + "]");
	
	if (objJson.refreshTableIsNeeded == "S") {
		log("Refresh Screen Status for Manager" + objJson.refreshTableIsNeeded);
		
		updateManagerTable();
	} else {
		handleManagerObject(objJson);
	}
}

function handleMarketWatchObject(objJson) {
	
	log("handleMarketWatch()");

	if (replaceDataEnabled == false) {
		log("replace data is disabled");
		
		return;
	}
	
	log("Process " + objJson.fields.length + " records for market whatch");
	
	for (var i = 0; i < objJson.fields.length; i++) {	
		//Update values 
		processMarketWatchObject(objJson.fields[i]);
	}
}

function handleManagerObject(objJson) {

	log("handleManager()");
	
	if (replaceDataEnabled == false) {
		log("replace data is disabled");
		
		return;
	}

	if (objJson.fields == null)
		return;
	
	log("Process " + objJson.fields.length + " records for manager");
		
	for (var i = 0; i < objJson.fields.length; i++) {
		processManagerObject(objJson.fields[i]);
	}	
}

function processMarketWatchObject(objJson) {
	
	log("processMarketWatchObject()");
	
	setNewFieldValue(objJson.lastQuantityHtmlId, objJson.lastQuantity);	
	setNewFieldValue(objJson.lastPriceHtmlId, objJson.lastPrice);	
	setNewFieldValue(objJson.buyQuantityHtmlId, objJson.buyQuantity);	
	setNewFieldValue(objJson.buyPriceHtmlId, objJson.buyPrice);	
	setNewFieldValue(objJson.sellQuantityHtmlId, objJson.sellQuantity);	
	setNewFieldValue(objJson.sellPriceHtmlId, objJson.sellPrice);	

	setNewStyleForLastPrice(objJson.lastPriceHtmlId, objJson.lastPrice);
}

function processManagerObject(objJson) {
	
	log("processManagerObject()");
	
	if (!objJson.isALeg) { //Is strategy report, not is a leg
		setNewFieldValue(objJson.statusHtmlId, objJson.statusDisplayText);

		setNewStyleForCancel(objJson.cancelHtmlId, objJson.status);			

		setNewStyleForStatus(objJson.cancelColumnHtmlId, objJson.status);
		
		setStyleForNotificationBar(objJson.status);
	} else {
		if (objJson.mustBeUnlegging) {
			setRowStyleForUnlegging(objJson.parentStatusHtmlId);
		} else {
			resetRowStyle(objJson.parentStatusHtmlId);
		}

		if (typeof $(objJson.leggedQuantityHtmlId).html() == "undefined") {
			log("Received a leg information but the same is colsed in webbrowser");
			
			return;
		}
	}
	
	setNewFieldValue(objJson.executedPercentHtmlId, objJson.executedPercent);	
	setNewFieldValue(objJson.leggedQuantityHtmlId, objJson.leggedQuantity);
	setNewFieldValue(objJson.leggedPriceHtmlId, objJson.leggedPrice);
	setNewFieldValue(objJson.totalQuantityHtmlId, objJson.totalQuantity);
	setNewFieldValue(objJson.quantityRemainHtmlId, objJson.quantityRemain);
	setNewFieldValue(objJson.quantityExecutedHtmlId, objJson.quantityExecuted);
	setNewFieldValue(objJson.averagePriceHtmlId, objJson.averagePrice);
	setNewFieldValue(objJson.otcQuantityHtmlId, objJson.otcQuantity);
	setNewFieldValue(objJson.otcPriceHtmlId, objJson.otcPrice);
	setNewFieldValue(objJson.poQuantityHtmlId, objJson.poQuantity);
	setNewFieldValue(objJson.poPriceHtmlId, objJson.poPrice);
	setNewFieldValue(objJson.executedTargetHtmlId, objJson.executedTarget);
	setNewFieldValue(objJson.textHtmlId, objJson.text);
}

function setNewStyleForLastPrice(fieldHtmlId, fieldNewValue) {
	if ($(fieldHtmlId).html() > fieldNewValue) {
		$(fieldHtmlId).attr("style", "color: red;");
	} else if ($(fieldHtmlId).html() < fieldNewValue) {
		$(fieldHtmlId).attr("style", "color: green;");
	} else {
		$(fieldHtmlId).attr("style", "color: black;");
	}
}

function setNewFieldValue(fieldHtmlId, fieldNewValue) {
	if (fieldNewValue == null) 
		$(fieldHtmlId).html(" - ");
	else
		$(fieldHtmlId).html(fieldNewValue);

	logNewFieldValue(fieldHtmlId, fieldNewValue);
}

function setNewStyleForCancel(fieldHtmlId, fieldNewValue) {
	if (fieldNewValue != 4 && fieldNewValue != 9 && fieldNewValue != 10) {
		$(fieldHtmlId).attr("style", "display: block; border: 0");
	} else {
		$(fieldHtmlId).attr("style", "display: none;");
	}
}

function setNewStyleForStatus(fieldHtmlId, fieldNewValue) {
	if (fieldNewValue == 1 || fieldNewValue == 2 || fieldNewValue == 3 || fieldNewValue == 4 ||
			fieldNewValue == 5 || fieldNewValue == 8 || fieldNewValue == 9) {
		$(fieldHtmlId).attr("style", "background-color: transparent !important; text-align: center; text-transform: lowercase;");
	} else if (fieldNewValue == 6) {
		$(fieldHtmlId).attr("style", "background-color: yellow !important; color: balck !important; text-align: center; text-transform: lowercase;");
	} else if (fieldNewValue == 10) {
		$(fieldHtmlId).attr("style", "background-color: orange !important; color: balck !important; text-align: center; text-transform: lowercase;");
	} else if (fieldNewValue == 7) {
		$(fieldHtmlId).attr("style", "background-color: green !important; color: balck !important; text-align: center; text-transform: lowercase;");
	} else if (fieldNewValue == 11) {
		$(fieldHtmlId).attr("style", "background-color: black !important; color: white !important; text-align: center; text-transform: lowercase;");
	} else {
		$(fieldHtmlId).attr("style", "background-color: #555555 !important; color: balck !important; text-align: center; text-transform: lowercase;");
	}
}

function setRowStyleForUnlegging(cancelColumnId) {
	$(cancelColumnId).parent('tr').attr("style", "background-color: red;");
}

function resetRowStyle(cancelColumnId) {
	$(cancelColumnId).parent('tr').attr("style", "background-color: transparent;");
}

function setStyleForNotificationBar(fieldNewValue) {
	if (fieldNewValue == 11) { //Disconnected engine
		PF('w_notification_bar_text').jq.val("The system is off-line");
	}
}

function logNewFieldValue(fieldHtmlId, fieldNewValue) {
	log("Field [" + fieldHtmlId + "] [" + $(fieldHtmlId).html() + "], [" + fieldNewValue + "]" );
}

function log(logText) {
	if (logEnabled == true) console.log(logText);
}