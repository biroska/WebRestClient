package com.ubs.manhatthan.admin.helper;

public final class Messages {

	public static final String msgRequiredId = new String("Id field is required!");
	public static final String msgRequiredEngine = new String("Engine field is required!");
	public static final String msgRequiredDescription = new String("Description field is required!");
	public static final String msgRequiredHost = new String("Host field is required!");
	public static final String msgRequiredIp = new String("Ip field is required!");
	public static final String msgRequiredPort = new String("Port field is required!");
	public static final String msgRequiredLogPath = new String("LogPath field is required!");
	public static final String msgRequiredChannelId = new String("Channel Id field is required!");
	public static final String msgRequiredSenderCompId = new String("SenderCompId field is required!");
	public static final String msgRequiredIncrementalIp = new String("Incremental Ip field is required!");
	public static final String msgRequiredIncrementalHost = new String("Incremental Host field is required!");
	public static final String msgRequiredIncrementalPort = new String("Incremental Port field is required!");
	public static final String msgRequiredRecoveryHost = new String("Recovery Host field is required!");
	public static final String msgRequiredRecoveryPort = new String("Recovery Port field is required!");
	public static final String msgRequiredInstDefinitionHost = new String("Inst Definition Host field is required!");
	public static final String msgRequiredInstDefinitionPort = new String("Inst Definition Port field is required!");
	public static final String msgRequiredAccount = new String("Account field is required!");
	
	public static final String msgValidatorEngine = new String("The field Engine must be greather than 1!");
	public static final String msgValidatorChannel = new String("The field Channel Id must be greather than 1!");
}