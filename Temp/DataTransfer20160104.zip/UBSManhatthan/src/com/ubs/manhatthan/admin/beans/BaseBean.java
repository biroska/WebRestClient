package com.ubs.manhatthan.admin.beans;

import java.io.Serializable;

import javax.faces.application.Application;
import javax.faces.application.FacesMessage;
import javax.faces.application.ViewHandler;
import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;

import org.apache.log4j.Level;
import org.springframework.beans.factory.annotation.Autowired;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.manager.facade.Facade;
import com.ubs.manhatthan.manager.logger.ManhattanLogger;
import com.ubs.manhatthan.manager.utils.Util;

@SuppressWarnings("serial")
public class BaseBean implements Serializable {

	@Autowired
	protected Facade facade;
	
	@Autowired
	protected User user;

	public void infoMessage(String messageText) {
		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, messageText, null);
		FacesContext.getCurrentInstance().addMessage(null, message);
	}

	public void warnMessage(String messageText) {
		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_WARN, messageText, null);
		FacesContext.getCurrentInstance().addMessage(null, message);
	}

	public void errorMessage(String messageText) {
		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, messageText, null);
		FacesContext.getCurrentInstance().addMessage(null, message);
	}

	public void fatalMessage(String messageText) {
		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_FATAL, messageText, null);
		FacesContext.getCurrentInstance().addMessage(null, message);
	}
	
	public void logWarn(String message) {
		ManhattanLogger.log(Util.getManagerId().toString(), message, Level.WARN);
	}

	public void logError(String message) {
		ManhattanLogger.log(Util.getManagerId().toString(), message, Level.ERROR);
	}
	
	public Facade getFacade() {
		return facade;
	}

	public void setFacade(Facade facade) {
		this.facade = facade;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
	protected void refreshView() {
		FacesContext context = FacesContext.getCurrentInstance();
		Application application = context.getApplication();
		ViewHandler viewHandler = application.getViewHandler();
		UIViewRoot viewRoot = viewHandler.createView(context, context.getViewRoot().getViewId());
		context.setViewRoot(viewRoot);
		context.renderResponse();
	}
}