package com.ubs.manhatthan.admin.beans;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ubs.manhatthan.admin.model.ChannelType;
import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.cache.CacheHelper;
import com.ubs.manhatthan.manager.enums.ChannelTypeEnum;
import com.ubs.manhatthan.manager.persistence.entities.EngineUmdfChannel;
import com.ubs.manhatthan.manager.persistence.entities.Exchange;
import com.ubs.manhatthan.manager.persistence.entities.UmdfChannelByEngine;

@SuppressWarnings("serial")
@Component("umdfChannelBean")
@Scope("session")
@ViewScoped
@ManagedBean(name="umdfChannelBean")
public class UmdfChannelBean extends BaseBean {

	private List<EngineUmdfChannel> umdfChannels;
	private EngineUmdfChannel selectedUmdfChannel;

	private List<EngineUmdfChannel> filteredUmdfChannels;
	
	
	private List<ChannelType> channelTypes;	
	private String idSelectType;
	
	@PostConstruct
	public void init() {
		try {
			selectedUmdfChannel = new EngineUmdfChannel();
			
			if (umdfChannels == null)
				umdfChannels = facade.getUmdfChannels();
		
			if (channelTypes == null)
				channelTypes = ChannelTypeEnum.convertToList();
			
			idSelectType = channelTypes.get(0).getName();
		} catch (DAOExceptionManhattan ex) {
			ex.printStackTrace();
			
			logError(ex.getMessage());
		}
	}

	public List<EngineUmdfChannel> getUmdfChannels() {
		return umdfChannels;
	}

	public void setUmdfChannels(List<EngineUmdfChannel> umdfChannels) {
		this.umdfChannels = umdfChannels;
	}

	public EngineUmdfChannel getSelectedUmdfChannel() {
		return  selectedUmdfChannel;
	}

	public void setSelectedUmdfChannel(EngineUmdfChannel selectedUmdfChannel) {
		this.selectedUmdfChannel = selectedUmdfChannel;
	}

	public List<EngineUmdfChannel> getFilteredUmdfChannels() {
		return filteredUmdfChannels;
	}

	public void setFilteredUmdfChannels(List<EngineUmdfChannel> filteredUmdfChannels) {
		this.filteredUmdfChannels = filteredUmdfChannels;
	}
	
	public List<ChannelType> getChannelTypes() {
		return channelTypes;
	}
	
	public Exchange getExchange() {
		return this.selectedUmdfChannel.getExchange();
	}
	
	public void setExchange(Exchange exchange) {
		this.selectedUmdfChannel.setExchange(exchange);;
	}
	
	public List<Exchange> getExchanges() {
		return CacheHelper.exchangeListCache;
	}

	public void newUmdfChannel(ActionEvent actionEvent) {
		this.selectedUmdfChannel = new EngineUmdfChannel();
	}
	
	public void addUmdfChannel(ActionEvent actionEvent) {		
		boolean recordExists = false;
		
		try {
			if (this.selectedUmdfChannel != null) {
				for (EngineUmdfChannel item: this.umdfChannels) {
					recordExists = (selectedUmdfChannel.getId() == item.getId());
					
					if (recordExists) break;
				}
				
				if (recordExists) {
					this.warnMessage("Item already registered!");
				} else {
					

					this.selectedUmdfChannel.setChannelType(ChannelTypeEnum.fromValue(idSelectType));
					
					this.selectedUmdfChannel = facade.saveEngineUmdfChannel(this.selectedUmdfChannel);
					
					UmdfChannelByEngine umdfChannelByEngine = new UmdfChannelByEngine();
					
					umdfChannelByEngine.setEngineUmdfChannel(this.selectedUmdfChannel);
					//umdfChannelByEngine.setEngine(engine);
					
					this.umdfChannels.add(this.selectedUmdfChannel);
					refreshView();
				}
			}
		} catch (Exception ex) {
			logError(ex.getMessage());
			
			this.errorMessage("Error on add UmdfChannel!");
		}
	}

	public void deleteUmdfChannel(ActionEvent actionEvent) {		
		try {
			//this.facade.
			
			this.umdfChannels.remove(this.selectedUmdfChannel);
			refreshView();
		} catch (Exception ex) {
			logError(ex.getMessage());
			
			this.errorMessage("Error on add UmdfChannel!");
		}
	}

	public void saveUmdfChannel(ActionEvent actionEvent) {
		boolean recordExists = false;
		
		try {
			if (this.selectedUmdfChannel != null) {
				for (EngineUmdfChannel item: this.umdfChannels) {
					recordExists = (selectedUmdfChannel.getId().equals(item.getId()));
					
					if (recordExists) break;
				}
				
				if (recordExists) {
					this.selectedUmdfChannel.setChannelType(ChannelTypeEnum.fromValue(idSelectType));
					
					facade.saveEngineUmdfChannel(this.selectedUmdfChannel);
					refreshView();
				} else {
					this.errorMessage("Error on save Umdf Channel!");
				}
			}
		} catch (Exception ex) {
			logError(ex.getMessage());
			
			this.errorMessage("Error on add UmdfChannel!");
		}
	}
	
	public void changeComboType(ValueChangeEvent event) {
		String tw = (String) event.getNewValue();
		idSelectType = tw;
		refreshView();
	}

	/**
	 * @return the idSelectType
	 */
	public String getIdSelectType() {
		return idSelectType;
	}

	/**
	 * @param idSelectType the idSelectType to set
	 */
	public void setIdSelectType(String idSelectType) {
		this.idSelectType = idSelectType;
	}
}