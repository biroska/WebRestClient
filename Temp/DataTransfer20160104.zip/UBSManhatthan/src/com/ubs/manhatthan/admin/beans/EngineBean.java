package com.ubs.manhatthan.admin.beans;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.event.ActionEvent;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ubs.manhatthan.exception.BussinessExceptionManhattan;
import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.persistence.entities.EngineInstance;


@SuppressWarnings("serial")
@Component("engineBean")
@Scope("session")
@ViewScoped
@ManagedBean(name="engineBean")
public class EngineBean extends BaseBean {

	private List<EngineInstance> engines;
	private EngineInstance selectedEngine;
	
	private List<EngineInstance> filteredEngines;
		
	@PostConstruct
	public void init() {
		//try {
		if (engines == null)
			try {
				engines = facade.getEngines();
			} catch (DAOExceptionManhattan e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		//} catch (Exception ex) {
		//	logError("teste");
		//}
	}

	public List<EngineInstance> getEngines() {
		return engines;
	}

	public void setEngines(List<EngineInstance> engines) {
		this.engines = engines;
	}

	public List<EngineInstance> getFilteredEngines() {
		return filteredEngines;
	}

	public void setFilteredEngines(List<EngineInstance> filteredEngines) {
		this.filteredEngines = filteredEngines;
	}

	public EngineInstance getSelectedEngine() {
		return selectedEngine;
	}

	public void setSelectedEngine(EngineInstance selectedEngine) {
		this.selectedEngine = selectedEngine;
	}

	public void newEngine(ActionEvent actionEvent) {		
		this.selectedEngine = new EngineInstance();
	}
	
	public void deleteEngine(ActionEvent actionEvent) {	
		try {
			facade.deleteEngineInstance(this.selectedEngine);
			
			this.engines.remove(this.selectedEngine);
			refreshView();
		} catch (BussinessExceptionManhattan ex) {
			logError(ex.getMessage());
			
			this.errorMessage(ex.getMessage());
		} catch (Exception ex) {
			logError(ex.getMessage());
			
			this.errorMessage("Error on delete Engine!");
		}
	}
	
	public void addEngine(ActionEvent actionEvent) {
		boolean recordExists = false;
		
		try {
			if (this.selectedEngine != null) {
				for (EngineInstance item: this.engines) {
					recordExists = (selectedEngine.getId() == item.getId());
					
					if (recordExists) break;
				}
				
				if (recordExists) {
					this.warnMessage("Item already registered!");
				} else {
					this.selectedEngine = facade.saveEngineInstance(this.selectedEngine);
					
					this.engines.add(this.selectedEngine);		
					refreshView();
				}
			}
						
		} catch (Exception ex) {
			logError(ex.getMessage());
			
			this.errorMessage("Error on add Engine!");
		}
	}

	public void saveEngine(ActionEvent actionEvent) {
		boolean recordExists = false;

		try {
			if (this.selectedEngine != null) {
				for (EngineInstance item: this.engines) {
					recordExists = (selectedEngine.getEngineId().equals(item.getEngineId()));
					
					if (recordExists) break;
				}
				
				if (recordExists) {
					facade.saveEngineInstance(this.selectedEngine);
					refreshView();
				} else {
					this.errorMessage("Error on save Engine!");
				}
			}
						
		} catch (Exception ex) {
			logError(ex.getMessage());

			this.errorMessage("Error on save Engine!");
		}
	}
}