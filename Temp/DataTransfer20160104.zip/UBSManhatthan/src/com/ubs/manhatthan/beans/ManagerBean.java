package com.ubs.manhatthan.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ubs.manhatthan.common.enuns.StrategyStatusEnum;
import com.ubs.manhatthan.exception.BussinessExceptionManhattan;
import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.enums.MessageTypeEnum;
import com.ubs.manhatthan.manager.enums.SideEnum;
import com.ubs.manhatthan.manager.facade.FacadeService;
import com.ubs.manhatthan.manager.utils.Constant;
import com.ubs.manhatthan.manager.utils.Util;
import com.ubs.manhatthan.model.Account;
import com.ubs.manhatthan.model.LegStrategyReport;
import com.ubs.manhatthan.model.StrategyReport;
import com.ubs.manhatthan.model.StrategyType;
import com.ubs.manhatthan.model.StrategyTypeLeg;
import com.ubs.manhatthan.model.Unlegging;
import com.ubs.manhatthan.service.ManagerFacade;
import com.ubs.manhatthan.service.MarketWatchFacade;

@Component("managerBean")
@Scope("session")
@SessionScoped
@ManagedBean(name = "managerBean")
public class ManagerBean extends UBSCommonBean implements Serializable {

	private static final long serialVersionUID = -4696450270615840861L;
	
	@Autowired
	MarketWatchFacade marketWatchFacade;

	@Autowired
	ManagerFacade managerFacade;

	@Autowired
	FacadeService facadeService;

	private StrategyTypeLeg selectStrategyTypeLeg;
	private StrategyType selectStrategyType;
	private StrategyReport strategyReport;
	private StrategyReport selectStrategyReport;
	private LegStrategyReport selectLegStrategyReport;
	private Unlegging selectUnlegging;
	
	private Account selectAccount;

	private List<StrategyReport> strategyReports;
	private List<StrategyReport> selectStrategyReports;
	private List<StrategyReport> filteredStrategyReports;

	private String idSelectStrategyType;

	private long marketingExec;

	private boolean isStrategyPauseAll;
	private boolean isStrategyResumeAll;
	private boolean isOnlyMarket;
	
	private boolean checkAllPO;
	
	private String instrument;
	
	private boolean protectQty;
	private boolean protectDiv1;
	
	private Integer otherTabOrderIndex = 100;
	
	public ManagerBean() {
		isStrategyPauseAll = true;
		isStrategyResumeAll = false;
		selectStrategyTypeLeg = new StrategyTypeLeg();
	}

	@PostConstruct
	private void loadView() {
		loadInfo();
	}
	
	public void loadInfo() {
		try {
			strategyReports = new ArrayList<StrategyReport>();
			strategyTypes = marketWatchFacade.getStrategyTypesDomain();
			if (null != strategyTypes) {
				idSelectStrategyType = String.valueOf(strategyTypes.get(0).getId());
				selectStrategyType = strategyTypes.get(0);
				strategyReport = initInfoStrategyReport(idSelectStrategyType);
				selectStrategyReport = initInfoStrategyReport(idSelectStrategyType);
				selectLegStrategyReport = new LegStrategyReport();
				selectUnlegging = new Unlegging();
			}

		} catch (DAOExceptionManhattan e) {
			logError(e.getMessage());
		}
	}

	public void loadFormAddStrategy() {
		selectStrategyType = strategyTypes.get(0);
		idSelectStrategyType = selectStrategyType.getId().toString();
		strategyReport = initInfoStrategyReport(idSelectStrategyType);
		refresh();
	}

	public void changeComboStrategy(ValueChangeEvent event) {
		String tw = (String) event.getNewValue();
		idSelectStrategyType = tw;
		strategyReport = initInfoStrategyReport(idSelectStrategyType);
		refresh();
	}
	
	public void clearDialogFields( StrategyReport report) {
		clearStrategyParametersFields( false, false, report );
	}
	
	public void clearStrategyParameters( boolean isStrategyParameterEdition, StrategyReport report ) {
		clearStrategyParametersFields( false, isStrategyParameterEdition, report );
	}
	
	public void changeSideFromDoubleClick( StrategyReport report ) {
//		No fim, n�o precisou do parametro vindo do remoteCommand,
//		mas fica como modelo quando precisar
//		FacesContext context = FacesContext.getCurrentInstance();
//	    Map map = context.getExternalContext().getRequestParameterMap();
//	    Object object = map.get("index" );
		
		for (LegStrategyReport leg : report.getLegStrategyList() ) {
			
			if ( SideEnum.BUY.getCode().equals( leg.getSide() ) ){
				leg.setSide( SideEnum.SELL.getCode() );
			} else {
				leg.setSide( SideEnum.BUY.getCode() );
			}
		}
		
//		managerEmptyFields();
	}

	private StrategyReport initInfoStrategyReport(String value) {
		StrategyReport report = new StrategyReport();
		report.setRestingLevel( Constant.DEFAULT.RESTING_LEVEL );
		report.setRiskLevel( Constant.DEFAULT.RISK_LEVEL );
		report.setEndTimeText(Util.convertDateHourNowPattern( Constant.DEFAULT.END_TIME ));
		for (StrategyType strategyType : strategyTypes) {
			if (Long.valueOf(value).equals(strategyType.getId())) {
				selectStrategyType = strategyType;
				report.setStrategyType(selectStrategyType);
				if (null != selectStrategyType.getStrategyTypeLegList()) {
					report.setLegStrategyList(new ArrayList<LegStrategyReport>());
					for (StrategyTypeLeg typeLeg : selectStrategyType.getStrategyTypeLegList()) {
						LegStrategyReport legStrategyReport = new LegStrategyReport();
						BeanUtils.copyProperties(typeLeg, legStrategyReport);
						legStrategyReport.setSide(typeLeg.getDefaultSide());
						report.getLegStrategyList().add(legStrategyReport);
					}
				}
				break;
			}
		}
		return report;
	}

	public void changeSellBuy() {

		for (int i = 0; i < selectStrategyType.getStrategyTypeLegList().size(); i++) {
			if (null != selectStrategyType.getStrategyTypeLegList().get(i).getLegged().getTotalQty()
					&& selectStrategyType.getStrategyTypeLegList().get(i).getLegged().getTotalQty() < 0) {
				long positivo = selectStrategyType.getStrategyTypeLegList().get(i).getLegged().getTotalQty() * -1;
				selectStrategyType.getStrategyTypeLegList().get(i).getLegged().setTotalQty(positivo);
				selectStrategyType.getStrategyTypeLegList().get(i).setDefaultSide(2);
			} else {
				selectStrategyType.getStrategyTypeLegList().get(i).setDefaultSide(1);
			}
		}
	}
	
	public void changeSellBuyByQuantity( String indexParam, StrategyReport report ) {
			
		if ( StringUtils.isNotBlank( indexParam ) ){
		
			int lastIndexOfLegList = report.getLegStrategyList().size() -1;
			
			Integer intIndexParam = Integer.valueOf( indexParam );
			
			if ( lastIndexOfLegList == intIndexParam ){
			
//				Define o �ltimo objeto da lista, se for negativo, considera o m�dulo
//				e ajusta o side para Sell, caso contr�rio define o side como buy
				if ( null != report.getLegStrategyList().get( lastIndexOfLegList ).getTotalQuantity() &&
						report.getLegStrategyList().get( lastIndexOfLegList ).getTotalQuantity() < 0) {
					
					Long positivo = Math.abs( report.getLegStrategyList().get( lastIndexOfLegList ).getTotalQuantity() );
					report.getLegStrategyList().get( lastIndexOfLegList ).setTotalQuantity(positivo);
					
					report.getLegStrategyList().get( lastIndexOfLegList ).setSide(SideEnum.SELL.getCode());
				} else { 
					if ( null != report.getLegStrategyList().get( lastIndexOfLegList ).getTotalQuantity() ){
							report.getLegStrategyList().get( lastIndexOfLegList ).setSide(SideEnum.BUY.getCode());
					}
				}
				
//				ajusta os buy/sell de todas as legs baseado na �ltima
				changeSideByLastLeg( report.getLegStrategyList().get( lastIndexOfLegList ).getSide(),
			             			 lastIndexOfLegList, report );
			} else {
				if ( report.getLegStrategyList().get( intIndexParam ).getTotalQuantity() != null ){
					report.getLegStrategyList().get( intIndexParam ).setTotalQuantity( 
								   Math.abs( report.getLegStrategyList().get( intIndexParam ).getTotalQuantity() ) );
				}
			}
			
			
			
			for (LegStrategyReport legItem : report.getLegStrategyList() ) {
				
				if ( legItem.getTotalQuantity() != null ){
					protectQty = false;
					protectDiv1 = true;
				} else {
					protectQty = false;
					protectDiv1 = false;
				}
			}
		}
		
//		managerEmptyFields();
	}
	
	public void changeSellBuyByDiv( String indexParam, StrategyReport report ) {
		
		if ( StringUtils.isNotBlank( indexParam ) ){
			
			int lastIndexOfLegList = report.getLegStrategyList().size() -1;
			
			Integer intIndexParam = Integer.valueOf( indexParam );
			
			if ( lastIndexOfLegList == intIndexParam ){
				
//				Define o �ltimo objeto da lista, se for negativo, considera o m�dulo
//				e ajusta o side para Sell, caso contr�rio define o side como buy
				if ( null != report.getLegStrategyList().get( lastIndexOfLegList ).getDiv1() &&
						report.getLegStrategyList().get( lastIndexOfLegList ).getDiv1() < 0) {
					
					double positivo = Math.abs( report.getLegStrategyList().get( lastIndexOfLegList ).getDiv1() );
					report.getLegStrategyList().get( lastIndexOfLegList ).setDiv1(positivo);
					
					report.getLegStrategyList().get( lastIndexOfLegList ).setSide(SideEnum.SELL.getCode());

				} else { 
					if ( null != report.getLegStrategyList().get( lastIndexOfLegList ).getDiv1() ){
						report.getLegStrategyList().get( lastIndexOfLegList ).setSide(SideEnum.BUY.getCode());
					}
				}
//				ajusta os buy/sell de todas as legs baseado na �ltima
					changeSideByLastLeg( report.getLegStrategyList().get( lastIndexOfLegList ).getSide(),
										 lastIndexOfLegList, report );				
			} else {
				if ( report.getLegStrategyList().get( intIndexParam ).getDiv1() != null ){
					report.getLegStrategyList().get( intIndexParam ).setDiv1( 
								   Math.abs( report.getLegStrategyList().get( intIndexParam ).getDiv1() ) );
				}
			}
			
			
			for (LegStrategyReport legItem : report.getLegStrategyList() ) {
				
				if ( legItem.getDiv1() != null ){
					protectQty = true;
					protectDiv1 = false;
					break;
				} else {
					protectQty = false;
					protectDiv1 = false;
				}
			}
		}
		
//		managerEmptyFields();
	}
	
	private void changeSideByLastLeg( Integer lastSide, Integer lastIndexOfLegList, StrategyReport report ){
		
		for (int i = lastIndexOfLegList -1; i >= 0; i--) {
			
			if ( SideEnum.BUY.equals( SideEnum.fromValue( lastSide ) ) ){
				report.getLegStrategyList().get( i ).setSide(SideEnum.SELL.getCode());	
			} else {
				report.getLegStrategyList().get( i ).setSide(SideEnum.BUY.getCode());	
			}
			lastSide = report.getLegStrategyList().get( i ).getSide();
		}
	}
	
	public void checkAll( StrategyReport report ) {
		for (LegStrategyReport leg : report.getLegStrategyList()) {
			leg.setPassiveLeg( checkAllPO );
		}
	}
	
	public void startPaused( StrategyReport report ) {
		System.out.println("ManagerBean.startPaused(): " + report.getStartPaused() );
		if ( report.getStartPaused() ){
			report.setStartTimeText( null );
			report.setEndTimeText( null );
		} else {
			report.setEndTimeText(Util.convertDateHourNowPattern( Constant.DEFAULT.END_TIME ));
		}
		
	}
	
	

	public void callSendOTC(ActionEvent actionEvent) {
		try {
			managerFacade.sendOTC(selectStrategyReport, selectLegStrategyReport);
		} catch (BussinessExceptionManhattan e) {
			addMsgValidationError(e.getLocalizedMessage());
			
			logError(e.getMessage());
		} catch (DAOExceptionManhattan e) {
			logError(e.getMessage());
		}
		
	}

	public void changeOrderBSUnLegged() {
		if (SideEnum.BUY.getCode().equals(selectStrategyTypeLeg.getDefaultSide())) {
			selectStrategyTypeLeg.setDefaultSide(2);
		} else {
			selectStrategyTypeLeg.setDefaultSide(1);
		}
	}

	public void calculateIsOnlyTarget(boolean isStrategyParameterEdition, StrategyReport report) {
		
		try {
			if ( validation( true, isStrategyParameterEdition, report ) ){
				report = managerFacade.calculateValuesStrategyReport(report, true);
			}
		} catch (DAOExceptionManhattan e) {
			e.printStackTrace();
			logError(e.getMessage());
			
			addMsgValidationError(e.getLocalizedMessage());
		} catch (BussinessExceptionManhattan e) {
			e.printStackTrace();
			
			logError(e.getMessage());
			
			addMsgValidationError(e.getLocalizedMessage());
		}
//		managerEmptyFields();
	}

	public void calculateStrategyValues(boolean isStrategyParameterEdition, StrategyReport report) {
		
		try {
			
			if ( validation( false, isStrategyParameterEdition, report ) ){
				report = managerFacade.calculateValuesStrategyReport(report, false);
			}			
		} catch (DAOExceptionManhattan e) {		
			e.printStackTrace();
			
			logError(e.getMessage());
			
			addMsgValidationError(e.getLocalizedMessage());
		} catch (BussinessExceptionManhattan e) {
			e.printStackTrace();
			
			logError(e.getMessage());
			
			addMsgValidationError(e.getLocalizedMessage());
		}

		//		managerEmptyFields();
	}
	
	public boolean validateStrategyCreation( boolean isStrategyParameterEdition, StrategyReport report ){
		boolean validationOK = true;
		
		validationOK = validation( false, isStrategyParameterEdition, report );
		
		String idPrefix = getIdPrefix( isStrategyParameterEdition );
		
		for (int i = 0; i < report.getLegStrategyList().size(); i++) {
			LegStrategyReport leg = report.getLegStrategyList().get( i );
			
			if ( leg.getClip() == null ){
				addValidationMessage( idPrefix + ":clip"+i,
						  			  "Strategy Creation Error",
									  "Clip " + (i+1) + " is mandatory" );
				validationOK = false;
			} else 
				if ( leg.getClip() < 1 ){
					addValidationMessage( idPrefix + ":clip"+i,
							  			  "Strategy Creation Error",
										  "Clip " + (i+1) + " must be positive" );
					validationOK = false;
				} else {
					if ( leg.getClip() > leg.getTotalQuantity() ){
						addValidationMessage( idPrefix + ":clip"+i,
					  			  "Strategy Creation Error",
								  "Clip " + (i+1) + " be less than the quantity" );
						validationOK = false;	
					}
				}
		}
		
		
		if ( isStrategyParameterEdition ){
			if ( selectStrategyReport == null || selectStrategyReport.getLegStrategyList() == null ||
				 selectStrategyReport.getLegStrategyList().isEmpty() ||
				 selectStrategyReport.getLegStrategyList().get( 0 ).getAccount() == null ){
				addValidationMessage( idPrefix + ":accName",
												 "Strategy Creation Error",
												 "Account is mandatory" );
				validationOK = false;
			}
		} else {
		
			if ( selectAccount == null ){
				addValidationMessage( idPrefix + ":accName",
												 "Strategy Creation Error",
												 "Account is mandatory" );
				validationOK = false;
			}
		}
		
		if ( report.getRestingLevel() == null ){
			addValidationMessage( idPrefix + ":bookLevel_input",
					  			  "Strategy Creation Error",
								  "Book Level is mandatory" );
			validationOK = false;
		}
		
		if ( report.getRiskLevel() == null ){
			addValidationMessage( idPrefix + ":riskLevel",
								  "Strategy Creation Error",
								  "Risk Level is mandatory" );
			
			validationOK = false;
		}
		
		if ( report.getStartPaused() == false && 
			 ( report.getEndTimeText() == null || report.getStartTimeText() == null ) ){
			
			addValidationMessage( idPrefix + ":txtStart",
							      "Strategy Creation Error",
								  "Create Strategy Paused or set a time to start and end" );
			
			addValidationBorder( idPrefix + ":txtEnd" );
			addValidationBorder( idPrefix + ":createStrategyPaused" );
			
			validationOK = false;
		}
		
		
		if ( report.getEndTimeText() != null && report.getStartTimeText() != null ) {
			if ( report.getStartTimeText().compareTo( report.getEndTimeText() ) > 0 ){
				addValidationMessage( idPrefix + ":txtStart",
								      "Strategy Creation Error",
									  "Set a start time before the end time" );
	
				addValidationBorder( idPrefix + ":txtEnd" );
			}
		}
		
		return validationOK;
	}
	
	public boolean validateUnlegging( Unlegging unlegging, Integer countIndex ){
		boolean validationOK = true;
							
		if ( unlegging == null || unlegging.getPrice() == null ||  unlegging.getPrice().equals(0D)){
			addValidationBorder( "componentStrategyParameters:formUnlegging:leggedPx"+countIndex );
			
			addValidationMessage( "componentStrategyParameters:formUnlegging:leggedPx"+countIndex,
								  "Send Error",
								  "Price is mandatory" );
			
			validationOK = false;
		}
		
		return validationOK;
	}
	
	public boolean validation( boolean isOnlyTarget, boolean isStrategyParameterEdition, StrategyReport report ){
		
		boolean validationOK = true;
		
		if ( report == null || report.getLegStrategyList() == null ||
			 report.getLegStrategyList().isEmpty() || report.getLegStrategyList().size() < 2  ){
			
			addMsgValidationError( "Generic Error", "The report structure is incorrect");

			return false;
		}
		
		String idPrefix = getIdPrefix( isStrategyParameterEdition );
						
		for (int i = 0; i < report.getLegStrategyList().size(); i++) {
			
			LegStrategyReport leg = report.getLegStrategyList().get( i );
			
			if ( leg.getLegSeq() == null || leg.getSide() == null ){
				addMsgValidationError( "Generic Error", "The report structure is incorrect");
				return false;
			}
			
			if ( StringUtils.isBlank( leg.getContract() ) ){
				addValidationMessage( idPrefix + ":contracts"+i,
						  			  "Calculation Error",
									  "Contract " + (i+1) + " is mandatory" );
				validationOK = false;
			} else {
				try {
					instrument = facadeService.getInstrument( leg.getContract() );
					
					if ( StringUtils.isBlank( instrument ) ){
						addValidationMessage( idPrefix + ":contracts"+i,
					  			  			  "Calculation Error",
					  			  			  "Invalid contract: " + leg.getContract() );
						validationOK = false;
					}
					
				} catch (DAOExceptionManhattan e) {
					e.printStackTrace();
				}
			}
			
		}
		
		if ( report.getTarget() == null ){
			addValidationMessage( idPrefix + ":target",
								  "Calculation Error",
								  "Target is mandatory" );
			validationOK = false;
			
		}
			
		if( !isOnlyTarget ){
			
			Integer lastIndex = report.getLegStrategyList().size() -1;
			
			LegStrategyReport lastLeg = report.getLegStrategyList().get( lastIndex );
			
			if ( lastLeg.getTotalQuantity() == null && lastLeg.getDiv1() == null ){
				addValidationBorder( idPrefix + ":dv"+lastIndex );
				
				addValidationMessage( idPrefix + ":qty"+lastIndex,
									  "Calculation Error",
									  "Quantity or Div1 is mandatory" );
				
				validationOK = false;
			}
		}
		
		return validationOK;
	}

	public List<Account> completeAccount(String name) {
		List<Account> accounts = new ArrayList<Account>();
		try {
			accounts = managerFacade.findListAccountByName(name);
		} catch (DAOExceptionManhattan e) {
			logError(e.getMessage());
		}
		return accounts;
	}

	public void createStrategy( StrategyReport report) {
		try {
			
			if ( validateStrategyCreation(false, report) ){
				
				for (int i = 0; i < report.getLegStrategyList().size(); i++) {
					report.getLegStrategyList().get(i).setAccount(selectAccount);
				}
	
				managerFacade.createStrategyReport(report);

				clearStrategyParametersFields( false, false, report );
			}
		} catch (BussinessExceptionManhattan e) {
			addMsgValidationError(e.getMessage());
			
			logError(e.getMessage());
		} catch (DAOExceptionManhattan e) {
			addMsgValidationError(e.getMessage());
			
			logError(e.getMessage());
		}
	}
	
//	private void managerEmptyFields(){
//		
//		for ( LegStrategyReport leg : strategyReport.getLegStrategyList() ) {
//			leg.setDuration( leg.getDuration() == null || leg.getDuration() == 0 ? null : leg.getDuration() );
//			leg.setTotalQuantity( leg.getTotalQuantity() == null || leg.getTotalQuantity() == 0L ? null : leg.getTotalQuantity() );
//			leg.setClip( leg.getClip() == null || leg.getClip() == 0L ? null : leg.getClip()  );
//			leg.setRestingRank( leg.getRestingRank() == null || leg.getRestingRank() == 0L ? null : leg.getRestingRank() );
//			leg.setDiv1( leg.getDiv1() == null || leg.getDiv1() == 0.0 ? null : leg.getDiv1() );
//		}
//		strategyReport.setRestingLevel( Constant.DEFAULT.RESTING_LEVEL );
//		strategyReport.setRiskLevel( Constant.DEFAULT.RISK_LEVEL );
//		strategyReport.setTarget( strategyReport.getTarget() == null || strategyReport.getTarget() == 0.0 ? null : strategyReport.getTarget() );
//		strategyReport.setTargetDif( strategyReport.getTargetDif() == null || strategyReport.getTargetDif() == 0.0 ? null : strategyReport.getTargetDif() );
//		strategyReport.setMarket( strategyReport.getMarket() == null || strategyReport.getMarket() == 0.0 ? null : strategyReport.getMarket() );
//	}
	
	private void clearStrategyParametersFields( boolean onlyStrategyParameters, boolean isStrategyParameterEdition, StrategyReport report ){
		
		this.setCheckAllPO( false );
		this.otherTabOrderIndex = 100;
		
		for ( LegStrategyReport leg : report.getLegStrategyList() ) {
			
			if ( !isStrategyParameterEdition ){
				leg.setContract( "" );
			}
			
			leg.setDuration( null );
			leg.setTotalQuantity( null );
			leg.setClip( null );
			leg.setRestingRank( null );
			leg.setDiv1( null );
			leg.setPassiveLeg( false );
			
			protectQty = false;
			protectDiv1 = false;
		}
		
		
		if ( !isStrategyParameterEdition ){
			this.selectAccount = null;
		}
		
		if ( !onlyStrategyParameters ){
			report.setRestingLevel( Constant.DEFAULT.RESTING_LEVEL );
			report.setRiskLevel( Constant.DEFAULT.RISK_LEVEL );
			report.setTarget( null );
			report.setTargetDif( null );
			report.setMarket( null );
			report.setStartTime( null );
			report.setEndTimeText(Util.convertDateHourNowPattern( Constant.DEFAULT.END_TIME));
			report.setStartPaused( false );
		}
	}

	public void updateStrategy( StrategyReport report ) {
		try {
			
			if ( validateStrategyCreation( true, report ) ){
			
				managerFacade.updateStrategyReport(report, MessageTypeEnum.MODIFY_STRATEGY);
			}
		} catch (BussinessExceptionManhattan e) {
			addMsgValidationError(e.getMessage());
			
			logError(e.getMessage());
		} catch (DAOExceptionManhattan e) {
			addMsgValidationError(e.getMessage());
			
			logError(e.getMessage());
		}
		refresh();
	}

	public void resumeStrategy(ActionEvent actionEvent) {
		try {
			for (int i = 0; i < selectStrategyReports.size(); i++) {
				managerFacade.updateActionsStrategyReport(selectStrategyReports.get(i), MessageTypeEnum.RESUME_STRATEGY);
			}
		} catch (BussinessExceptionManhattan e) {
			addMsgValidationError(e.getMessage());
			logError(e.getMessage());
		} catch (DAOExceptionManhattan e) {
			logError(e.getMessage());
		}
		refresh();
	}

	public void cancelStrategy(ActionEvent actionEvent) {
		try {
			if (this.selectStrategyReport != null) {
			managerFacade.updateActionsStrategyReport(selectStrategyReport, MessageTypeEnum.CANCEL_STRATEGY);
			}
		} catch (BussinessExceptionManhattan e) {
			logError(e.getMessage());

			addMsgValidationError(e.getMessage());
		} catch (DAOExceptionManhattan e) {
			logError(e.getMessage());

			addMsgValidationError(e.getMessage());
		}
		
		refresh();
	}

	public void cancelAllStrategies(ActionEvent actionEvent) {
		try {
			for (int i = 0; i < selectStrategyReports.size(); i++) {
				managerFacade.updateActionsStrategyReport(selectStrategyReports.get(i), MessageTypeEnum.CANCEL_STRATEGY);
			}
		} catch (BussinessExceptionManhattan e) {
			logError(e.getMessage());
		} catch (DAOExceptionManhattan e) {
			logError(e.getMessage());
		}
		refresh();
	}

	public void pauseStrategy(ActionEvent actionEvent) {
		try {
			for (int i = 0; i < selectStrategyReports.size(); i++) {
				managerFacade.updateActionsStrategyReport(selectStrategyReports.get(i), MessageTypeEnum.PAUSE_STRATEGY);
			}
		} catch (BussinessExceptionManhattan e) {
			addMsgValidationError(e.getMessage());
			logError(e.getMessage());
		} catch (DAOExceptionManhattan e) {
			logError(e.getMessage());
		}
		refresh();
	}

	public void statusStrategyClicked(ActionEvent actionEvent) {
		try {
			if (selectStrategyReport != null) {
				if (StrategyStatusEnum.RESUMED.getCode().equals(selectStrategyReport.getStatus())) {
					managerFacade.updateActionsStrategyReport(selectStrategyReport, MessageTypeEnum.PAUSE_STRATEGY);
				} if (StrategyStatusEnum.PAUSED.getCode().equals(selectStrategyReport.getStatus())) {
					managerFacade.updateActionsStrategyReport(selectStrategyReport, MessageTypeEnum.RESUME_STRATEGY);
				}				
			}
		} catch (BussinessExceptionManhattan e) {
			addMsgValidationError(e.getMessage());
			
			logError(e.getMessage());
		} catch (DAOExceptionManhattan e) {
			logError(e.getMessage());
		}
	}

	public void submitSend(Integer countIndex) {
		try {
			
			if ( validateUnlegging(selectUnlegging, countIndex) ){
				selectUnlegging.setMarket(false);
				managerFacade.sendUnlegged(selectUnlegging);
			}
			
		} catch (BussinessExceptionManhattan e) {
			addMsgValidationError(e.getLocalizedMessage());
			
				logError(e.getMessage());
		} catch (DAOExceptionManhattan e) {
			
			logError(e.getMessage());
		}
	}

	public void submitMarket(Integer countIndex) {
		try {
			if ( validateUnlegging(selectUnlegging, countIndex) ){
				selectUnlegging.setMarket(true);
				managerFacade.sendUnlegged(selectUnlegging);
			}
		} catch (BussinessExceptionManhattan e) {
			addMsgValidationError(e.getLocalizedMessage());
			
			logError(e.getMessage());
		} catch (DAOExceptionManhattan e) {
			
			logError(e.getMessage());
		}
	}

	public void submitAllSend() {
		try {
			
			if ( selectLegStrategyReport!=null 
					&& !selectLegStrategyReport.getUnleggingList().isEmpty() ) {
				
				int countIndex = 0;
					
				for (Unlegging unlegging : selectLegStrategyReport.getUnleggingList()) {					
					
					if (validateUnlegging(unlegging, countIndex)) {						
						unlegging.setMarket(false);
						managerFacade.sendUnlegged(unlegging);
					}	
					
					countIndex++;
				}			
			}			
			
		} catch (BussinessExceptionManhattan e) {
			addMsgValidationError(e.getLocalizedMessage());
			
			logError(e.getMessage());
		} catch (DAOExceptionManhattan e) {
			
			logError(e.getMessage());
		}
	}

	public void submitAllMarket() {
		try {
			
			if ( selectLegStrategyReport!=null 
					&& !selectLegStrategyReport.getUnleggingList().isEmpty() ) {
				
				int countIndex = 0;
					
				for (Unlegging unlegging : selectLegStrategyReport.getUnleggingList()) {					
					
					if (validateUnlegging(unlegging, countIndex)) {						
						unlegging.setMarket(true);
						managerFacade.sendUnlegged(unlegging);
					}	
					
					countIndex++;
				}			
			}		
		} catch (BussinessExceptionManhattan e) {
			addMsgValidationError(e.getLocalizedMessage());
			
			logError(e.getMessage());
		} catch (DAOExceptionManhattan e) {
			
			logError(e.getMessage());
		}
	}

	private String getIdPrefix( boolean isStrategyParameterEdition){
		if ( isStrategyParameterEdition ){
			return "componentStrategyParametersEdit:formManagerEditStrategy";
		} else {
			return "componentStrategyParameters:formManagerAddStrategy";
		}
	}

	public boolean getDisabledButtons() {
		return ((this.strategyReports != null) && (this.strategyReports.size() == 0));
	}
	
	public StrategyTypeLeg getSelectStrategyTypeLeg() {
		return selectStrategyTypeLeg;
	}

	public void setSelectStrategyTypeLeg(StrategyTypeLeg selectStrategyTypeLeg) {
		this.selectStrategyTypeLeg = selectStrategyTypeLeg;
	}

	public StrategyType getSelectStrategyType() {
		return selectStrategyType;
	}

	public void setSelectStrategyType(StrategyType selectStrategyType) {
		this.selectStrategyType = selectStrategyType;
	}

	public String getIdSelectStrategyType() {
		return idSelectStrategyType;
	}

	public void setIdSelectStrategyType(String idSelectStrategyType) {
		this.idSelectStrategyType = idSelectStrategyType;
	}

	public long getMarketingExec() {
		return marketingExec;
	}

	public void setMarketingExec(long marketingExec) {
		this.marketingExec = marketingExec;
	}

	public void setMarketWatchFacade(MarketWatchFacade marketWatchFacade) {
		this.marketWatchFacade = marketWatchFacade;
	}

	public StrategyReport getStrategyReport() {
		return strategyReport;
	}

	public void setStrategyReport(StrategyReport strategyReport) {
		this.strategyReport = strategyReport;
	}

	public List<StrategyReport> getStrategyReports() {
		return strategyReports;
	}

	public void setStrategyReports(List<StrategyReport> strategyReports) {
		this.strategyReports = strategyReports;
	}	

	public List<StrategyReport> getFilteredStrategyReports() {
		return filteredStrategyReports;
	}

	public void setFilteredStrategyReports(
			List<StrategyReport> filteredStrategyReports) {
		this.filteredStrategyReports = filteredStrategyReports;
	}

	public List<StrategyReport> getSelectStrategyReports() {
		return selectStrategyReports;
	}

	public void setSelectStrategyReports(List<StrategyReport> selectStrategyReports) {
		this.selectStrategyReports = selectStrategyReports;
	}

	public Account getSelectAccount() {
		return selectAccount;
	}

	public void setSelectAccount(Account selectAccount) {
		this.selectAccount = selectAccount;
	}

	public StrategyReport getSelectStrategyReport() {
		return selectStrategyReport;
	}

	public void setSelectStrategyReport(StrategyReport selectStrategyReport) {
		
		if (selectStrategyReport != null) {
			BeanUtils.copyProperties(selectStrategyReport, this.selectStrategyReport);

			this.selectStrategyReport.setStrategyType(new StrategyType());		
			BeanUtils.copyProperties(selectStrategyReport.getStrategyType(), this.selectStrategyReport.getStrategyType());
	
			if (selectStrategyReport.getLegStrategyList() != null) {		
				this.selectStrategyReport.setLegStrategyList(new ArrayList<LegStrategyReport>());
				
				for (int i=0; i<selectStrategyReport.getLegStrategyList().size(); i++) {
					LegStrategyReport legStrategyReport = new LegStrategyReport();
					
					BeanUtils.copyProperties(selectStrategyReport.getLegStrategyList().get(i), legStrategyReport);
					
					legStrategyReport.setAccount(new Account());
					BeanUtils.copyProperties(selectStrategyReport.getLegStrategyList().get(i).getAccount(), legStrategyReport.getAccount());

					legStrategyReport.setOrderType(selectStrategyReport.getLegStrategyList().get(i).getOrderType());
					
					if (selectStrategyReport.getLegStrategyList().get(i).getUnleggingList() != null) {
						
						legStrategyReport.setUnleggingList(new ArrayList<Unlegging>());
						
						for (int ii=0; ii<selectStrategyReport.getLegStrategyList().get(i).getUnleggingList().size();ii++) {
							Unlegging unlegging = new Unlegging(); 
							
							BeanUtils.copyProperties(selectStrategyReport.getLegStrategyList().get(i).getUnleggingList().get(ii), unlegging);
							
							legStrategyReport.getUnleggingList().add(unlegging);
						}
					}
					
					this.selectStrategyReport.getLegStrategyList().add(legStrategyReport);	
				}
			}
		}
	}

	public LegStrategyReport getSelectLegStrategyReport() {
		return selectLegStrategyReport;
	}

	public void setSelectLegStrategyReport(LegStrategyReport selectLegStrategyReport) {
		if (selectLegStrategyReport != null) {
			BeanUtils.copyProperties(selectLegStrategyReport, this.selectLegStrategyReport);
			
			this.selectLegStrategyReport.setAccount(new Account());
			BeanUtils.copyProperties(selectLegStrategyReport.getAccount(), this.selectLegStrategyReport.getAccount());

			this.selectLegStrategyReport.setOrderType(selectLegStrategyReport.getOrderType());
			
			if (selectLegStrategyReport.getUnleggingList() != null) {
				
				this.selectLegStrategyReport.setUnleggingList(new ArrayList<Unlegging>());
				
				for (int i=0; i<selectLegStrategyReport.getUnleggingList().size();i++) {
					Unlegging unlegging = new Unlegging(); 
					
					BeanUtils.copyProperties(selectLegStrategyReport.getUnleggingList().get(i), unlegging);
					
					this.selectLegStrategyReport.getUnleggingList().add(unlegging);
				}
			}
		}
	}
	
	private Integer columnGeneratrix( StrategyReport report, Integer columnIndex ){
		return columnIndex * report.getLegStrategyList().size();
	}
	
	public Integer getFirstColumnGeneratrix( StrategyReport report ) {
		return columnGeneratrix( report, 0 ) +2;
	}
	
	public Integer getSecondColumnGeneratrix( StrategyReport report ) {
		return columnGeneratrix( report, 1 ) +2;
	}
	
	public Integer getThirdColumnGeneratrix( StrategyReport report ) {
		return columnGeneratrix( report, 2 ) +2;
	}
	
	public Integer getFourthColumnGeneratrix( StrategyReport report ) {
		return columnGeneratrix( report, 3 ) +2;
	}
	
	public Integer getOrdenedTabOrder( StrategyReport report, Integer index ) {
		return getFourthColumnGeneratrix( report ) + report.getLegStrategyList().size() + index;
	}
	
	public Integer getOtherTabOrder() {
		return otherTabOrderIndex++;
	}
	
	public Unlegging getSelectUnlegging() {
		return selectUnlegging;
	}

	public void setSelectUnlegging(Unlegging selectUnlegging) {
		BeanUtils.copyProperties(selectUnlegging, this.selectUnlegging);
	}

	public void setManagerFacade(ManagerFacade managerFacade) {
		this.managerFacade = managerFacade;
	}

	public void setFacade(FacadeService facade) {
		this.facadeService = facade;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public MarketWatchFacade getMarketWatchFacade() {
		return marketWatchFacade;
	}

	public boolean isStrategyPauseAll() {
		return isStrategyPauseAll;
	}

	public void setStrategyPauseAll(boolean isStrategyPauseAll) {
		this.isStrategyPauseAll = isStrategyPauseAll;
	}

	public boolean isStrategyResumeAll() {
		return isStrategyResumeAll;
	}

	public void setStrategyResumeAll(boolean isStrategyResumeAll) {
		this.isStrategyResumeAll = isStrategyResumeAll;
	}

	public boolean isOnlyMarket() {
		return isOnlyMarket;
	}

	public void setOnlyMarket(boolean isOnlyMarket) {
		this.isOnlyMarket = isOnlyMarket;
	}

	public boolean isCheckAllPO() {
		return checkAllPO;
	}

	public void setCheckAllPO(boolean checkAllPO) {
		this.checkAllPO = checkAllPO;
	}

	public boolean isProtectQty() {
		return protectQty;
	}

	public void setProtectQty(boolean protectQty) {
		this.protectQty = protectQty;
	}

	public boolean isProtectDiv1() {
		return protectDiv1;
	}

	public void setProtectDiv1(boolean protectDiv1) {
		this.protectDiv1 = protectDiv1;
	}
}