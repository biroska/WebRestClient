package com.ubs.manhatthan.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

import org.primefaces.event.CellEditEvent;

import com.ubs.manhatthan.model.Unlegging;

@SuppressWarnings("serial")
@SessionScoped
@ManagedBean(name="unleggingBean")
public class UnleggingBean implements Serializable {

	private List<Unlegging> unlegging;
		
	public UnleggingBean(){
		
		unlegging = new ArrayList<Unlegging>();
	}

	public List<String> completeString(String query) {
		List<String> results = new ArrayList<String>();
		for (int i = 0; i < 10; i++)
			results.add(query + i);
		return results;
	}
		
	public void onCellEdit( CellEditEvent event ) {
		
        Object oldValue = event.getOldValue();
        Object newValue = event.getNewValue();
        
        int rowIndex = event.getRowIndex();
        
        Unlegging unleggings=  unlegging.get( rowIndex );
        
        unlegging.get( rowIndex ).setContract( unlegging.get( rowIndex ).getContract() + " Editado" );
         
        if( newValue != null && !newValue.equals(oldValue) ) {
            FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "unlegging: " + unleggings.getContract() +  " Cell Changed", "Old: " + oldValue + ", New:" + newValue);
            FacesContext.getCurrentInstance().addMessage(null, msg);
        }
    }

	public List<Unlegging> getUnlegging() {
		return unlegging;
	}

	public void setUnlegging(List<Unlegging> unlegging) {
		this.unlegging = unlegging;
	}
}