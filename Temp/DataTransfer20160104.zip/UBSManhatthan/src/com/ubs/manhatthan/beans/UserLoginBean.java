package com.ubs.manhatthan.beans;

import java.io.Serializable;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ubs.manhatthan.admin.model.User;

@Component("userLoginBean")
@Scope("session")
public class UserLoginBean extends UBSCommonBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5217352473575716096L;
	
	Thread threadMarketWhatchForPersistence;
	
	Thread threadManagerForPersistence;
	
	@Autowired
	SubscriberMarketWhacthBean subscriberMarketWhatchBean;

	@Autowired
	SubscriberManagerBean subscriberManagerBean;
	
	private boolean loginUser() {
		return (null != user && null != user.getLogin() && user.getPassword() != null);
	}
	
	public String loginAdmin() {
		boolean userLogged = loginUser();
		
		if (!userLogged) {
			addMsgValidationWarn("Loggin Error", "Invalid credentials for administrator.");
			
			return "loginAdmin.xhtml" + UBSCommonBean.forceRedirect();
		} else {
			refresh();

			return "mainAdmin.xhtml" + UBSCommonBean.forceRedirect();
		}
	}
	
	public String login() {
		boolean userLogged = loginUser();

		if (!userLogged) {
			addMsgValidationWarn("Loggin Error", "Invalid credentials");
		
			return "login.xhtml" + UBSCommonBean.forceRedirect();
		} else {
			user.setProfile(user.getLogin());
			user.setLogged(true);
			User userLog = new User();
			BeanUtils.copyProperties(user, userLog);
			
			if (com.ubs.manhatthan.manager.utils.Util.getPropertyFromFile("manhattan.subscriber.marketwatch").equals("1")) {
				subscriberMarketWhatchBean.setUserLogged(userLog);
				threadMarketWhatchForPersistence = new Thread(subscriberMarketWhatchBean);
				threadMarketWhatchForPersistence.start();
			}

			if (com.ubs.manhatthan.manager.utils.Util.getPropertyFromFile("manhattan.subscriber.manager").equals("1")) {
				subscriberManagerBean.setUserLogged(userLog);
				threadManagerForPersistence = new Thread(subscriberManagerBean);
				threadManagerForPersistence.start();
			}
			
			refresh();

			return "main.xhtml" + UBSCommonBean.forceRedirect();
		}
	}

	private void logoutUser() {
		user.setLogged(false);
		
		if (com.ubs.manhatthan.manager.utils.Util.getPropertyFromFile("manhattan.subscriber.marketwatch").equals("1")) {
			subscriberMarketWhatchBean.shutdown();
		}
		
		if (com.ubs.manhatthan.manager.utils.Util.getPropertyFromFile("manhattan.subscriber.manager").equals("1")) {
			subscriberManagerBean.shutdown();
		}
		
		logoutSession();
	}
			
	public String logoutAdmin() {
		logoutUser();
		
		return "loginAdmin.xhtml" + UBSCommonBean.forceRedirect();
	}

	public String logout() {
		logoutUser();
		
		return "login.xhtml" + UBSCommonBean.forceRedirect();
	}

	public void setSubscriberMarketWhatchBean(SubscriberMarketWhacthBean subscriberMarketWhatchBean) {
		this.subscriberMarketWhatchBean = subscriberMarketWhatchBean;
	}

	public void setSubscriberManagerBean(SubscriberManagerBean subscriberManagerBean) {
		this.subscriberManagerBean = subscriberManagerBean;
	}
}