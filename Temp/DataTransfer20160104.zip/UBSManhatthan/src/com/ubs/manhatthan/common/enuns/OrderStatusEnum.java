package com.ubs.manhatthan.common.enuns;

public enum OrderStatusEnum{
	
    NEW                           ( 48 ), // 0
    PARTIALLY_FILLED              ( 49 ), // 1
    FILLED                        ( 50 ), // 2
    CANCELED                      ( 52 ), // 4
    REPLACED                      ( 53 ), // 5
    REJECTED                      ( 56 ), // 8
    EXPIRED                       ( 67 ), // C
    PREVIOUS_FINAL_STATE          ( 90 ); // Z
    
    private final Integer code;
    
    private OrderStatusEnum( Integer code ) {
        this.code = code;
    }

    public Integer getCode() {
        return code;
    }
    
    public static OrderStatusEnum fromValue( Integer value ){
    	
		for (OrderStatusEnum item : OrderStatusEnum.values() ) {
			if ( item.getCode().equals( value ) ){
				return item;
			}
		}
		return null;
    }
}
