package com.ubs.manhatthan.common.enuns;

public enum StrategyTypeEnum{
	
	UNKNOWN			             ( 0 ),
	MULTILEG_DI1_SPREAD          ( 1 ),
	MULTILEG_DI1_FRA             ( 2 );
    
    private final Integer code;
    
    private StrategyTypeEnum( Integer code ) {
        this.code = code;
    }

    public Integer getCode() {
        return code;
    }
    
    public static StrategyTypeEnum fromValue( Integer value ){
    	
		for (StrategyTypeEnum item : StrategyTypeEnum.values() ) {
			if ( item.getCode().equals( value ) ){
				return item;
			}
		}
		return null;
    }
}