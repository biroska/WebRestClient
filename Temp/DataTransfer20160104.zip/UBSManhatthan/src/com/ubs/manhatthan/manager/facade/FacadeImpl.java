package com.ubs.manhatthan.manager.facade;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ubs.manhatthan.exception.BussinessExceptionManhattan;
import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.cache.CacheHelper;
import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.enums.StrategyTypeEnum;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IAccountTypeDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IClientAccountDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IEngineInstanceDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IEngineUmdfChannelDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IExchangeDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.ILegStrategyReportDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IOrderFixSessionDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IOrderTradeDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IPasswordParameterDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IProfileDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IRecoverySessionByEngineDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IReportDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IRoleByProfileDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IRoleDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.ISessionByAccountDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.ISessionByEngineDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IStrategyByTabDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IStrategyByTabLegDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IStrategyOrdersDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IStrategyReportDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IStrategyTypeDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IStrategyTypeLegDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.ITcpRecoverySessionDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.ITraderDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.ITraderExchangeCodeDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.ITraderWatchTabDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IUmdfChannelByEngineDAO;
import com.ubs.manhatthan.manager.persistence.entities.AccountType;
import com.ubs.manhatthan.manager.persistence.entities.ClientAccount;
import com.ubs.manhatthan.manager.persistence.entities.EngineInstance;
import com.ubs.manhatthan.manager.persistence.entities.EngineUmdfChannel;
import com.ubs.manhatthan.manager.persistence.entities.Exchange;
import com.ubs.manhatthan.manager.persistence.entities.LegStrategyReport;
import com.ubs.manhatthan.manager.persistence.entities.OrderFixSession;
import com.ubs.manhatthan.manager.persistence.entities.OrderTrade;
import com.ubs.manhatthan.manager.persistence.entities.PasswordParameter;
import com.ubs.manhatthan.manager.persistence.entities.Profile;
import com.ubs.manhatthan.manager.persistence.entities.RecoverySessionByEngine;
import com.ubs.manhatthan.manager.persistence.entities.Role;
import com.ubs.manhatthan.manager.persistence.entities.RoleByProfile;
import com.ubs.manhatthan.manager.persistence.entities.SessionByAccount;
import com.ubs.manhatthan.manager.persistence.entities.SessionByEngine;
import com.ubs.manhatthan.manager.persistence.entities.StrategyByTab;
import com.ubs.manhatthan.manager.persistence.entities.StrategyByTabLeg;
import com.ubs.manhatthan.manager.persistence.entities.StrategyOrders;
import com.ubs.manhatthan.manager.persistence.entities.StrategyReport;
import com.ubs.manhatthan.manager.persistence.entities.StrategyType;
import com.ubs.manhatthan.manager.persistence.entities.StrategyTypeLeg;
import com.ubs.manhatthan.manager.persistence.entities.TcpRecoverySession;
import com.ubs.manhatthan.manager.persistence.entities.Trader;
import com.ubs.manhatthan.manager.persistence.entities.TraderExchangeCode;
import com.ubs.manhatthan.manager.persistence.entities.TraderWatchTab;
import com.ubs.manhatthan.manager.persistence.entities.UmdfChannelByEngine;
import com.ubs.manhatthan.manager.persistence.entities.id.LegStrategyReportPK;
import com.ubs.manhatthan.manager.persistence.functions.IDataBaseFunctions;

@Service
@Scope("singleton")
@Transactional
public class FacadeImpl implements Facade, Serializable {
	
	private static final long serialVersionUID = 1L;

	@Autowired
	private IManager manager;
	
	@Autowired
	private IRoleDAO roleDAO;
	
	@Autowired
	private IAccountTypeDAO accountTypeDAO;
	
	@Autowired
	private IEngineInstanceDAO engineInstanceDAO;
	
	@Autowired
	private IEngineUmdfChannelDAO engineUmdfChannelDAO;
	
	@Autowired
	private IExchangeDAO exchangeDAO;
	
	@Autowired
	private IOrderFixSessionDAO orderFixSessionDAO;
	
	@Autowired
	private IPasswordParameterDAO passwordParameterDAO;
	
	@Autowired
	private IProfileDAO profileDAO;
	
	@Autowired
	private IRoleByProfileDAO roleByProfileDAO;
	
	@Autowired
	private ISessionByAccountDAO sessionByAccountDAO;
	
	@Autowired
	private IClientAccountDAO clientAccountDAO;
	
	@Autowired
	private ISessionByEngineDAO sessionByEngineDAO;
	
	@Autowired
	private IStrategyByTabDAO strategyByTabDAO;
	
	@Autowired
	private ITraderWatchTabDAO traderWatchTabDAO;
	
	@Autowired
	private IStrategyTypeDAO strategyTypeDAO;
	
	@Autowired
	private IStrategyByTabLegDAO strategyByTabLegDAO;
	
	@Autowired
	private IStrategyTypeLegDAO strategyTypeLegDAO;
	
	@Autowired
	private ITcpRecoverySessionDAO tcpRecoverySessionDAO;
	
	@Autowired
	private ITraderDAO traderDAO;
	
	@Autowired
	private IUmdfChannelByEngineDAO umdfChannelByEngineDAO;
	
	@Autowired
	private ITraderExchangeCodeDAO traderExchangeCodeDAO;
	
	@Autowired
	private IRecoverySessionByEngineDAO recoverySessionByEngineDAO;
	
	@Autowired
	private IReportDAO reportDAO;
	
	@Autowired
	private IStrategyReportDAO strategyReportDAO;
	
	@Autowired
	private ILegStrategyReportDAO legStrategyReportDAO;
	
	@Autowired
	private IStrategyOrdersDAO strategyOrderDAO;
	
	@Autowired
	private IOrderTradeDAO orderTradeDAO;

	@Autowired
	private IDataBaseFunctions dataBaseFunctions;
	
	@Override
	public List<OrderTrade> reportByStrategy( OrderTrade orderTrade )  throws DAOExceptionManhattan {
		
		if ( orderTrade == null )
			return null;
			
		try {
			return reportDAO.reportByStrategy(orderTrade);
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
	}
	
	@Override
	public List<OrderTrade> reportByAverage( OrderTrade orderTrade )  throws DAOExceptionManhattan {
		if ( orderTrade == null )
			return null;
		
		try {
			return reportDAO.reportByAverage(orderTrade);
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
	}
	
	@Override
	public List<OrderTrade> reportByExecution( OrderTrade orderTrade )  throws DAOExceptionManhattan {
		if ( orderTrade == null )
			return null;
		
		try {
			return reportDAO.reportByExecution(orderTrade);
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
	}
	
	@Override
	public List<OrderTrade> reportByPrice( OrderTrade orderTrade )  throws DAOExceptionManhattan {
		if ( orderTrade == null )
			return null;

		try {
			return reportDAO.reportByPrice(orderTrade);
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
	}

	@Override
	public StrategyReport saveReport(StrategyReport report) throws Exception {
		try {
			report = strategyReportDAO.saveReport( report );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return report;
	}

	@Override
	public StrategyOrders saveOrder(StrategyOrders order ) throws Exception {
		try {
			order = strategyOrderDAO.saveStrategyOrder( order );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return order;
	}

	@Override
	public OrderTrade saveOrderTrade(OrderTrade orderTrade) throws Exception {
		try {
			orderTrade = orderTradeDAO.saveOrderTrade( orderTrade );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}

		return orderTrade;
	}

	@Override
	public LegStrategyReport getLegStrategyByID(Integer legSeq, Long strategyReportId) 
			throws Exception {
		
		LegStrategyReport leg = null;
		try {
			if ( legSeq != null && legSeq >= 0 &&
				 strategyReportId != null && strategyReportId > 0 ) {
	
				LegStrategyReportPK legStrategyReportPK = new LegStrategyReportPK( getEngineIdByAccount( 2056L ), strategyReportId, legSeq, new Date() );
				
				leg = legStrategyReportDAO.findById( legStrategyReportPK );
			}
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return leg;
	}

	/* (non-Javadoc)
	 * @see com.ubs.manhattan.facade.Facade#getLegStrategyByReport(java.lang.Long)
	 */
	@Override
	public List<LegStrategyReport> getLegStrategyByReportId(Long strategyReportId) throws Exception {
		try {
			return legStrategyReportDAO.findByStrategyId( strategyReportId );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
	}
	
	public StrategyReport findStrategyReportById( StrategyReport report )  throws DAOExceptionManhattan {
		try {
			if ( report != null && report.getId() != null ) {
				report = strategyReportDAO.findById( report.getId() );
			}
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return report;
	}
	
	public StrategyOrders findStrategyOrderById( StrategyOrders order )  throws DAOExceptionManhattan  {
		try {
			if ( order != null && order.getId() != null && order.getId().getOrderId() != null )
				order = strategyOrderDAO.findById( order.getId() );
		} catch ( DAOExceptionManhattan e ) {
			throw e;
		}
		
		return order;
	}

	@Override
	public Integer businessDayTotal(Date beginningDt, Date endingDt) throws DAOExceptionManhattan {

		if ( beginningDt == null || endingDt == null )
			return null;
		try {
			return dataBaseFunctions.businessDayTotal(beginningDt, endingDt);
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
	}

	@Override
	public Integer businessDayTotal2(Date beginningDt, Date endingDt) throws DAOExceptionManhattan {
		
		if ( beginningDt == null || endingDt == null )
			return null;
		try {
			return dataBaseFunctions.businessDayTotal2(beginningDt, endingDt);
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
	}
	
	@Override
	public Role saveRole( Role role ) throws DAOExceptionManhattan {
		try {
			Role saveRole = roleDAO.saveRole( role );
			return saveRole;
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
	}
	
	@Override
	public AccountType saveAccountType( AccountType accountType ) throws DAOExceptionManhattan {
		try {
			AccountType saveAccountType = accountTypeDAO.saveAccountType( accountType );
			return saveAccountType;
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
	}
	
	@Override
	public EngineInstance saveEngineInstance(EngineInstance engine)  throws DAOExceptionManhattan  {
		try {
			if ( engine != null )
				engine = engineInstanceDAO.saveEngineInstance( engine );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		return engine;
	}
	
	@Override
	public EngineUmdfChannel saveEngineUmdfChannel( EngineUmdfChannel engineUmdfChannel ) throws DAOExceptionManhattan {
		try {
			if ( engineUmdfChannel != null )
				engineUmdfChannel = engineUmdfChannelDAO.saveEngineUmdfChannel( engineUmdfChannel );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return engineUmdfChannel;
	}
	
	@Override
	public Exchange saveExchange( Exchange exchange ) throws DAOExceptionManhattan {
		try {
			if ( exchange != null )
				exchange = exchangeDAO.saveExchange( exchange );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return exchange;
	}
	
	@Override
	public List<Exchange> findExchange( Exchange exchange ) throws DAOExceptionManhattan {
		try {
			List<Exchange> findExchange = null;
			if ( exchange != null ) {
				findExchange = exchangeDAO.findExchange(exchange);
			}
			return findExchange;
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
	}
	
	@Override
	public OrderFixSession saveOrderFixSession( OrderFixSession orderFixSession, ActionTypeEnum action ) throws DAOExceptionManhattan, BussinessExceptionManhattan {
		try {
			if ( orderFixSession != null )
				orderFixSession = orderFixSessionDAO.saveOrderFixSession( orderFixSession, action );
		} catch ( BussinessExceptionManhattan e ) {
			throw e;
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return orderFixSession;
	}
	
	@Override
	public PasswordParameter savePasswordParameter( PasswordParameter passwordParameter ) throws DAOExceptionManhattan {
		try {
			if ( passwordParameter != null )
				passwordParameter = passwordParameterDAO.savePasswordParameter( passwordParameter );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return passwordParameter;
	}
	
	@Override
	public Profile saveProfile( Profile profile ) throws DAOExceptionManhattan {
		try {
			if ( profile != null )
				profile = profileDAO.saveProfile( profile );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return profile;
	}
	
	@Override
	public RoleByProfile saveRoleByProfile( RoleByProfile role ) throws DAOExceptionManhattan {
		try {
			if ( role != null )
				role = roleByProfileDAO.saveRoleByProfile( role );
		
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return role;
	}
	
	@Override
	public Role findRole( int index )  throws DAOExceptionManhattan {
		return roleDAO.getByIndex( index );
	}
	
	@Override
	public Profile findProfile( int index ) throws DAOExceptionManhattan {
		return profileDAO.getByIndex( index );
	}
	
	@Override
	public SessionByAccount saveOrderFixSession( SessionByAccount sessionByAccount ) throws DAOExceptionManhattan {
		try {
			if ( sessionByAccount != null )
				sessionByAccount = sessionByAccountDAO.saveOrderFixSession( sessionByAccount );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return sessionByAccount;
	}
	
	@Override
	public List<SessionByAccount> getAccountSessions() throws DAOExceptionManhattan {
		try {
			return sessionByAccountDAO.findAll();
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
	}
	
	@Override
	public SessionByAccount saveSessionByAccount( SessionByAccount sessionByAccount ) throws DAOExceptionManhattan {
		try {
			if ( sessionByAccount != null )
				sessionByAccount = sessionByAccountDAO.saveOrderFixSession(sessionByAccount);
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return sessionByAccount;
	}

	@Override
	public SessionByEngine saveSessionByEngine( SessionByEngine sessionByEngine ) throws DAOExceptionManhattan {
		try {
			if ( sessionByEngine != null )
				sessionByEngine = sessionByEngineDAO.saveSessionByEngine( sessionByEngine );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return sessionByEngine;
	}
	
	@Override
	public TraderWatchTab saveTraderWatchTab( TraderWatchTab traderWatchTab )  throws DAOExceptionManhattan {
		try {
			if ( traderWatchTab != null )
				traderWatchTab = traderWatchTabDAO.saveTraderWatchTab( traderWatchTab );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return traderWatchTab;
	}
	
	@Override
	public StrategyType saveStrategyType( StrategyType strategyType ) throws DAOExceptionManhattan {
		try {
			if ( strategyType != null )
				strategyType = strategyTypeDAO.saveStrategyType( strategyType );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return strategyType;
	}
	
	@Override
	public StrategyByTab saveStrategyByTab( StrategyByTab strategyByTab ) throws DAOExceptionManhattan {
		try{
			if ( strategyByTab != null )
				strategyByTab = strategyByTabDAO.saveStrategyByTab( strategyByTab );
		}catch(Exception e){
			throw new DAOExceptionManhattan(e);	
		}
		return strategyByTab;
	}
	
	@Override
	public StrategyByTabLeg saveStrategyByTabLeg( StrategyByTabLeg strategyByTabLeg ) throws DAOExceptionManhattan {
		try {
			if ( strategyByTabLeg != null )
				strategyByTabLeg = strategyByTabLegDAO.saveStrategyByTabLeg( strategyByTabLeg );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return strategyByTabLeg;
	}
	
	@Override
	public StrategyTypeLeg saveStrategyTypeLeg( StrategyTypeLeg strategyTypeLeg )  throws DAOExceptionManhattan {
		try {
			if ( strategyTypeLeg != null )
				strategyTypeLeg = strategyTypeLegDAO.saveStrategyTypeLeg( strategyTypeLeg );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return strategyTypeLeg;
	}
	
	@Override
	public TcpRecoverySession saveTcpRecoverySession( TcpRecoverySession tcpRecoverySession )  throws DAOExceptionManhattan {
		try {
			if ( tcpRecoverySession != null )
				tcpRecoverySession = tcpRecoverySessionDAO.saveTcpRecoverySession( tcpRecoverySession );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return tcpRecoverySession;
	}
	
	@Override
	public void deleteRecoverySessionByEngine ( RecoverySessionByEngine recoverySessionByEngine ) throws DAOExceptionManhattan {
		try {
			if (recoverySessionByEngine != null) {
				recoverySessionByEngineDAO.deleteRecoverySessionByEngine(recoverySessionByEngine);
			}
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
	}
	
	@Override
	public void deleteSessionByEngine(SessionByEngine sessionByEngine) throws DAOExceptionManhattan {
		try {
			if (sessionByEngine != null) {
				sessionByEngineDAO.deleteSessionByEngine(sessionByEngine);
			}
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
	}
	
	@Override
	public Trader saveTrader( Trader trader )  throws DAOExceptionManhattan {
		try {
			if ( trader != null )
				trader = traderDAO.saveTrader( trader );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return trader;
	}
	
	@Override
	public TraderExchangeCode saveTraderExchangeCode( TraderExchangeCode traderExchangeCode )  throws DAOExceptionManhattan {
		try {
			if ( traderExchangeCode != null )
				traderExchangeCode = traderExchangeCodeDAO.saveTraderExchangeCode( traderExchangeCode );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return traderExchangeCode;
	}
	
	@Override
	public UmdfChannelByEngine saveUmdfChannelByEngine( UmdfChannelByEngine umdfChannelByEngine )  throws DAOExceptionManhattan {
		try {
			if ( umdfChannelByEngine != null )
				umdfChannelByEngine = umdfChannelByEngineDAO.saveUmdfChannelByEngine( umdfChannelByEngine );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return umdfChannelByEngine;
	}
	
	@Override
	public RecoverySessionByEngine saveUmdfRecoverySessionByEngine( RecoverySessionByEngine recoverySessionByEngine )  throws DAOExceptionManhattan {
		try {
			if ( recoverySessionByEngine != null )
				recoverySessionByEngine = recoverySessionByEngineDAO.saveRecoverySessionByEngine( recoverySessionByEngine );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return recoverySessionByEngine;
	}
	
	@Override
	public StrategyReport saveStrategyReport( StrategyReport strategy ) throws DAOExceptionManhattan {
		try {
			if ( strategy != null )
				strategy = strategyReportDAO.save( strategy );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return strategy;
	}
	
	@Override
	public List<StrategyType> findAllStrategyType() throws DAOExceptionManhattan {
		try {
			return strategyTypeDAO.findAll();
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
	}
	
	@Override
	public List<Exchange> findAllExchange() throws DAOExceptionManhattan {
		try {
			return exchangeDAO.findAll();
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
	}
	
	@Override
	public ClientAccount getClientAccountByIndex( int index ) throws DAOExceptionManhattan  {
		return clientAccountDAO.getByIndex( index );
	}

	@Override
	public ClientAccount findClientAccountByCode( Long code ) throws DAOExceptionManhattan  {
		try {
			
			ClientAccount clientAccount = CacheHelper.getClientAccount( code );
			
			if ( clientAccount != null ){
				return clientAccount; 
			} else {
				
				clientAccount = clientAccountDAO.findById(code);
				CacheHelper.putClientAccount( clientAccount );
				
				return clientAccount;
			}
			
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
	}

	@Override
	public List<ClientAccount> FindClientAccount(ClientAccount clientAccount) throws DAOExceptionManhattan {
		try {
			return clientAccountDAO.findClientAccount(clientAccount);
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
	}

	@Override
	public List<ClientAccount> findAllClientAccount() throws DAOExceptionManhattan {
		try {
			return clientAccountDAO.findAll();
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
	}
	
	@Override
	public Exchange getExchangeByIndex( int index )  throws DAOExceptionManhattan {
		return exchangeDAO.getByIndex( index );
	}
	
	@Override
	public EngineInstance getEngineInstanceByIndex( int index ) throws DAOExceptionManhattan {
		return engineInstanceDAO.getByIndex( index );
	}

	@Override
	public EngineInstance findEngineInstanceByIndex( int index ) throws DAOExceptionManhattan {
		return engineInstanceDAO.findById(index);
	}

	@Override
	public EngineInstance findEngineInstanceById( int id ) throws DAOExceptionManhattan {
		try {
			return engineInstanceDAO.findById(id);
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
	}

	@Override
	public OrderFixSession getOrderFixSessionByIndex(int index)  throws DAOExceptionManhattan {
		return orderFixSessionDAO.getByIndex( index );
	}
	@Override
	public OrderFixSession findOrderFixSessionById(int id) throws DAOExceptionManhattan {
		try {
			return orderFixSessionDAO.findById(id);
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
	}
	
	@Override
	public TraderWatchTab getTraderWatchTabByIndex(int index) throws DAOExceptionManhattan  {
		return traderWatchTabDAO.getByIndex( index );
	}
	
	@Override
	public StrategyType getStrategyTypeByIndex(int index) throws DAOExceptionManhattan  {
		return strategyTypeDAO.getByIndex( index );
	}
	
	@Override
	public StrategyByTab getStrategyByTabByIndex(int index) throws DAOExceptionManhattan  {
		return strategyByTabDAO.getByIndex( index );
	}
	
	@Override
	public StrategyTypeLeg getStrategyTypeLegByIndex(int index) throws DAOExceptionManhattan  {
		return strategyTypeLegDAO.getByIndex( index );
	}
	
	@Override
	public Profile getProfileByIndex(int index) throws DAOExceptionManhattan  {
		return profileDAO.getByIndex( index );
	}
	
	@Override
	public EngineUmdfChannel getEngineUmdfChannelByIndex(int index) throws DAOExceptionManhattan  {
		return engineUmdfChannelDAO.getByIndex( index );
	}
	
	@Override
	public TcpRecoverySession getTcpRecoverySessionByIndex(int index) throws DAOExceptionManhattan {
		return tcpRecoverySessionDAO.getByIndex( index );
	}
	
	public void setRoleDAO(IRoleDAO roleDAO) {
		this.roleDAO = roleDAO;
	}

	public void setAccountTypeDAO(IAccountTypeDAO accountTypeDAO) {
		this.accountTypeDAO = accountTypeDAO;
	}

	public void setEngineInstanceDAO(IEngineInstanceDAO engineInstanceDAO) {
		this.engineInstanceDAO = engineInstanceDAO;
	}

	public void setExchangeDAO(IExchangeDAO exchangeDAO) {
		this.exchangeDAO = exchangeDAO;
	}

	public void setOrderFixSessionDAO(IOrderFixSessionDAO orderFixSessionDAO) {
		this.orderFixSessionDAO = orderFixSessionDAO;
	}

	public void setPasswordParameterDAO(IPasswordParameterDAO passwordParameterDAO) {
		this.passwordParameterDAO = passwordParameterDAO;
	}

	public IProfileDAO getProfileDAO() {
		return profileDAO;
	}

	public void setProfileDAO(IProfileDAO profileDAO) {
		this.profileDAO = profileDAO;
	}

	public void setRoleByProfile(IRoleByProfileDAO roleByProfileDAO) {
		this.roleByProfileDAO = roleByProfileDAO;
	}

	public void setSessionByAccountDAO(ISessionByAccountDAO sessionByAccountDAO) {
		this.sessionByAccountDAO = sessionByAccountDAO;
	}

	public IClientAccountDAO getClientAccountDAO() {
		return clientAccountDAO;
	}

	public void setClientAccountDAO(IClientAccountDAO clientAccountDAO) {
		this.clientAccountDAO = clientAccountDAO;
	}

	public void setSessionByEngineDAO(ISessionByEngineDAO sessionByEngineDAO) {
		this.sessionByEngineDAO = sessionByEngineDAO;
	}

	public void setStrategyByTabDAO(IStrategyByTabDAO strategyByTabDAO) {
		this.strategyByTabDAO = strategyByTabDAO;
	}

	public void setTraderWatchTabDAO(ITraderWatchTabDAO traderWatchTabDAO) {
		this.traderWatchTabDAO = traderWatchTabDAO;
	}

	public void setStrategyTypeDAO(IStrategyTypeDAO strategyTypeDAO) {
		this.strategyTypeDAO = strategyTypeDAO;
	}

	public void setStrategyByTabLegDAO(IStrategyByTabLegDAO strategyByTabLegDAO) {
		this.strategyByTabLegDAO = strategyByTabLegDAO;
	}

	public void setStrategyTypeLegDAO(IStrategyTypeLegDAO strategyTypeLegDAO) {
		this.strategyTypeLegDAO = strategyTypeLegDAO;
	}

	public void setTcpRecoverySessionDAO(ITcpRecoverySessionDAO tcpRecoverySessionDAO) {
		this.tcpRecoverySessionDAO = tcpRecoverySessionDAO;
	}

	public void setTraderDAO(ITraderDAO traderDAO) {
		this.traderDAO = traderDAO;
	}

	public void setTraderExchangeCodeDAO(ITraderExchangeCodeDAO traderExchangeCodeDAO) {
		this.traderExchangeCodeDAO = traderExchangeCodeDAO;
	}

	public void setUmdfChannelByEngineDAO(IUmdfChannelByEngineDAO umdfChannelByEngineDAO) {
		this.umdfChannelByEngineDAO = umdfChannelByEngineDAO;
	}

	public void setUmdfRecoverySessionByEngineDAO(IRecoverySessionByEngineDAO umdfRecoverySessionByEngineDAO) {
		this.recoverySessionByEngineDAO = umdfRecoverySessionByEngineDAO;
	}
	
	public void setReportDAO(IReportDAO reportDAO) {
		this.reportDAO = reportDAO;
	}

	public void setStrategyReportDAO(IStrategyReportDAO strategyReportDAO) {
		this.strategyReportDAO = strategyReportDAO;
	}


	public void setManager(IManager manager) {
		this.manager = manager;
	}

	@Override
	public List<TraderWatchTab> getListTraderWatchsTabsByLogin(String login) throws DAOExceptionManhattan {
		try {
			return traderWatchTabDAO.getListTraderWatchsTabsByLogin( login );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}

	}
	
	@Override
	public List<StrategyByTab> getListStrategyOrInstrumentByTab(TraderWatchTab traderWatchTab) throws DAOExceptionManhattan {
		try {
			return traderWatchTabDAO.getListStrategyOrInstrumentByTab( traderWatchTab );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
	}
	
	@Override 
	public List<EngineInstance> getEngines() throws DAOExceptionManhattan  {
		try {
			return engineInstanceDAO.findAll();
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
	}	

	@Override
	public void deleteEngineInstance(EngineInstance engine) throws DAOExceptionManhattan, BussinessExceptionManhattan 
	{
		try {
			engineInstanceDAO.deleteEngineInstance(engine);
		} catch ( BussinessExceptionManhattan e ) {
			throw e;
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
	}

	@Override 
	public List<Exchange> getExchanges() throws DAOExceptionManhattan  {
		try {
			return exchangeDAO.findAll();
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
	}	

	@Override 
	public List<EngineUmdfChannel> getUmdfChannels() throws DAOExceptionManhattan  {
		try {
			return engineUmdfChannelDAO.findAll();
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
	}	

	@Override
	public void deleteUmdfChannel(EngineUmdfChannel umdfChannel) throws DAOExceptionManhattan {
		try {
			engineUmdfChannelDAO.delete(umdfChannel);
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
	}
	
	@Override 
	public List<TcpRecoverySession> getTcpRecoveries() throws DAOExceptionManhattan  {
		try {
			return tcpRecoverySessionDAO.getTcpRecoveries();
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
	}	

	@Override
	public void deleteTcpRecovery(TcpRecoverySession tcpRecovery) throws DAOExceptionManhattan {
		try {
			tcpRecoverySessionDAO.delete(tcpRecovery);
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
	}

	@Override
	public void deleteSessionByAccount(SessionByAccount sessionByAccount) throws DAOExceptionManhattan {
		try {
			sessionByAccountDAO.deleteSessionByAccount(sessionByAccount);
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
	}

	@Override 
	public List<OrderFixSession> getOrderFixSessions() throws DAOExceptionManhattan {
		try {
			return orderFixSessionDAO.getOrderFixSessions();
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
	}
	
	@Override
	public void deleteOrderFixSession(OrderFixSession orderFixSession) throws DAOExceptionManhattan {
		try {
			orderFixSessionDAO.delete(orderFixSession);
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
	}

	@Override
	public StrategyType getStrategyTypeById(Long id) throws DAOExceptionManhattan  {
		try {
			return strategyTypeDAO.findById(id);
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
	}
	
	@Override
	public void deleteTraderWatchTabById(Long id) throws DAOExceptionManhattan  {
		traderWatchTabDAO.deleteById(id);
	}
	
	@Override
	public void deleteStrategyTabById(Long id) throws DAOExceptionManhattan  {
		try {
			strategyByTabDAO.deleteById(id);
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
	}
	
	@Override
	public StrategyTypeLeg findStrategyTypeLegById(StrategyTypeLeg strategyTypeLeg)  throws DAOExceptionManhattan  {
		try {
			if (null != strategyTypeLeg && null != strategyTypeLeg.getId())
				strategyTypeLeg = strategyTypeLegDAO.findById( strategyTypeLeg.getId() );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		return strategyTypeLeg;
	}

	@Override
	public StrategyByTab getStrategyByTab(StrategyByTab strategyByTab) throws DAOExceptionManhattan {
		try {
			return strategyByTabDAO.getStrategyByTab(strategyByTab);
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
	}
	
	@Override
	public Integer getNumberOfLegsFromStrategyType( StrategyTypeEnum strategyType ) throws DAOExceptionManhattan {
		try {
			return strategyTypeDAO.getNumberOfLegsFromStrategyType( strategyType );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
	}
	
	@Override
	public List<EngineInstance> getEngineByAccount( Long accountId ) throws DAOExceptionManhattan {
		if ( accountId == null || accountId < 1 )
			return null;
		try {
			return engineInstanceDAO.getEngineByAccount( accountId );
		} catch (Exception e){
			e.printStackTrace();
			throw new DAOExceptionManhattan( e );
		}
	}
	
	@Override
	public Long getEngineIdByAccount( Long accountId ) throws DAOExceptionManhattan {
	
		if ( accountId == null || accountId < 1 )
			return null;
		try {
			List<EngineInstance> engineByAccount = getEngineByAccount( accountId );
			
			if ( engineByAccount == null || engineByAccount.isEmpty() )
				return null;
			
			return engineByAccount.get( 0 ).getEngineId();
		} catch (Exception e ){
			e.printStackTrace();
			throw new DAOExceptionManhattan( e );
		}
	}

	@Override
	public OrderFixSession getOrderFixByAccount( Long accountId ) throws DAOExceptionManhattan {
		
		if ( accountId == null || accountId < 1 )
			return null;
		
		try {
			List<OrderFixSession> orderFixByAccount = orderFixSessionDAO.getOrderFixByAccount( accountId );
			
			if ( orderFixByAccount == null || orderFixByAccount.isEmpty() )
				return null;
			
			return orderFixByAccount.get( 0 );
			
		} catch (Exception e){
			e.printStackTrace();
			throw new DAOExceptionManhattan( e );
		}
	}
	
	@Override
	public String getEnteringTraderByLogin( String login ) throws DAOExceptionManhattan {
		
		if ( StringUtils.isBlank( login ) )
			return null;
		
		try {
		
			Trader traderByLogin = traderDAO.getTraderByLogin( login );
			
			if ( traderByLogin == null )
				return null;
			
			return traderByLogin.getEnteringTrader();
			
		} catch ( Exception e ){
			throw new DAOExceptionManhattan( e );
		}
	}
	
	@Override
	public List<Trader> getAllActiveTraders() throws DAOExceptionManhattan {
		try {
			return traderDAO.findAllActive( true );
		} catch ( Exception e ){
			throw new DAOExceptionManhattan( e );
		}
	}
}