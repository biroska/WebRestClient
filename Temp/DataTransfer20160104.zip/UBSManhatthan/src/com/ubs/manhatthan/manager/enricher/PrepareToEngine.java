/**
 * 
 */
package com.ubs.manhatthan.manager.enricher;

import java.io.Serializable;
import java.util.List;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.cache.StrategyCache;
import com.ubs.manhatthan.manager.enums.CommandTypeEnum;
import com.ubs.manhatthan.manager.facade.Facade;
import com.ubs.manhatthan.manager.facade.FacadeImpl;
import com.ubs.manhatthan.manager.persistence.entities.LegStrategyReport;
import com.ubs.manhatthan.manager.persistence.entities.StrategyOrders;
import com.ubs.manhatthan.manager.persistence.entities.StrategyReport;


/**
 * @author galdinoa
 *
 */
public class PrepareToEngine implements Serializable {
	
	private static final long serialVersionUID = 7248804236564942094L;
	
	Facade facade = new FacadeImpl();
	
	public StrategyReport enrichCreateStrategy( StrategyReport report ) throws Exception {
		return report;
	}
	
	public StrategyReport enrichModifyCancelStrategy( StrategyReport report ) throws Exception {
		
		if ( report != null ){
			
			report = enrichStrategyReport( report );
			
//			report.setLegStrategyList( getLegListByReport( report ) );
			
//			if ( report.getLegStrategyList() != null && !report.getLegStrategyList().isEmpty() ){
//				report.setLegStrategyList( enrichLegList( report.getLegStrategyList() ) );
//			}
		}
		
		return report;
	}
	
	public StrategyOrders enrichNewOrderReportOrder ( StrategyOrders order ) throws Exception{
		
		if ( order != null ){
			
			order = enrichStrategyOrder( order );
			
//		busca a leg da ordem, os dados da leg ser�o utilizados no converterToProtobuf
			if ( order.getLegStrategyReport() != null ){
				LegStrategyReport leg = enrichLegStrategyReport( order.getLegStrategyReport() );
				
				order.setLegStrategyReport( leg );
			}
		}
		
		return order;
	}
	
	public StrategyOrders enrichReportOrder ( StrategyOrders order ) throws Exception{
		order = enrichStrategyOrder( order );
		
//		busca a leg da ordem, os dados da leg ser�o utilizados no converterToProtobuf
		if ( order.getLegStrategyReport() != null ){
			LegStrategyReport leg = enrichLegStrategyReport( order.getLegStrategyReport() );
			
			order.setLegStrategyReport( leg );
		}
			
		return order;
	}

	public CommandTypeEnum enrichCommandMessage( CommandTypeEnum type ){
		return type;
	}
	
	public StrategyOrders enrichLeggedStrategyOrder ( StrategyOrders order ) throws Exception{
		order = enrichStrategyOrder( order );
		return order;
	}
	
	private StrategyReport enrichStrategyReport ( StrategyReport report ) throws Exception{
		
		StrategyReport fullReport = StrategyCache.strategyReportMap.get( report.getId() );
		
		if ( fullReport == null )
			fullReport = facade.findStrategyReportById( report );
		
		if ( fullReport != null ){
			report.setStrategyType( report.getStrategyType() == null ? fullReport.getStrategyType() : report.getStrategyType() );
			report.setStrategyTimestamp( report.getStrategyTimestamp() == null ? fullReport.getStrategyTimestamp() : report.getStrategyTimestamp() );
			report.setLogin( report.getLogin() == null ? fullReport.getLogin() : report.getLogin() );
			report.setStartTime( report.getStartTime() == null ? fullReport.getStartTime() : report.getStartTime() );
			report.setEndTime( report.getEndTime() == null ? fullReport.getEndTime() : report.getEndTime() );
			report.setExecutedPercentage( report.getExecutedPercentage() == null ? fullReport.getExecutedPercentage() : report.getExecutedPercentage() );
			report.setExecutedTarget( report.getExecutedTarget() == null ? fullReport.getExecutedTarget() : report.getExecutedTarget() );
			report.setStartPaused( report.getStartPaused() == null ? fullReport.getStartPaused() : report.getStartPaused() );
			report.setText( report.getText() == null ? fullReport.getText() : report.getText() );
			report.setPriceLimit( report.getPriceLimit() == null ? fullReport.getPriceLimit() : report.getPriceLimit() );
			report.setTarget( report.getTarget() == null ? fullReport.getTarget() : report.getTarget() );
			report.setAgressiviness( report.getAgressiviness() == null ? fullReport.getAgressiviness() : report.getAgressiviness() );
			report.setRiskLevel( report.getRiskLevel() == null ? fullReport.getRiskLevel() : report.getRiskLevel() );
			report.setLegStrategyList( report.getLegStrategyList() == null ? fullReport.getLegStrategyList() : report.getLegStrategyList() );
		}
		
		return report;
	}
	
	public StrategyOrders enrichStrategyOrder ( StrategyOrders order ) throws Exception {
		
		StrategyOrders fullOrder = StrategyCache.strategyOrderMap.get( order.getId().getOrderId() );

		if ( fullOrder == null)
			try {
				fullOrder = facade.findStrategyOrderById( order );
			} catch (DAOExceptionManhattan e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw e;
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw e;
			}
		
		if ( fullOrder != null ){
			order.setLegStrategyReport( order.getLegStrategyReport() == null ? fullOrder.getLegStrategyReport() : order.getLegStrategyReport() );
			order.setExecutedQuantity( order.getExecutedQuantity() == null ? fullOrder.getExecutedQuantity() : order.getExecutedQuantity() );
			order.setAveragePrice( order.getAveragePrice() == null ? fullOrder.getAveragePrice() : order.getAveragePrice() );
			order.setSymbol( order.getSymbol() == null ? fullOrder.getSymbol() : order.getSymbol() );
			order.setSide( order.getSide() == null ? fullOrder.getSide() : order.getSide() );
			order.setQuantity( order.getQuantity() == null ? fullOrder.getQuantity() : order.getQuantity() );
			order.setRemainingQuantity( order.getRemainingQuantity() == null ? fullOrder.getRemainingQuantity() : order.getRemainingQuantity() );
			order.setRouteId( order.getRouteId() == null ? fullOrder.getRouteId() : order.getRouteId() );
			order.setOrderType( order.getOrderType() == null ? fullOrder.getOrderType() : order.getOrderType() );
			order.setTimeInForce( order.getTimeInForce() == null ? fullOrder.getTimeInForce() : order.getTimeInForce() );
			order.setAccount( order.getAccount() == null ? fullOrder.getAccount() : order.getAccount() );
			order.setClientOrderId( order.getClientOrderId() == null ? fullOrder.getClientOrderId() : order.getClientOrderId() );
			order.setOrderStatus( order.getOrderStatus() == null ? fullOrder.getOrderStatus() : order.getOrderStatus() );
			order.setExecutionType( order.getExecutionType() == null ? fullOrder.getExecutionType() : order.getExecutionType() );
			order.setPrice( order.getPrice() == null ? fullOrder.getPrice() : order.getPrice() );
		}
		
		return order;
	}
	
	private LegStrategyReport enrichLegStrategyReport ( LegStrategyReport leg ) throws Exception{
		
		if ( leg.getId() != null ){
		
			LegStrategyReport legFromCache = StrategyCache.legStrategyReportMap.get( leg.getId() );
			
			if ( legFromCache == null)
				legFromCache = facade.getLegStrategyByID( leg.getId().getLegSeq(), 
														  leg.getId().getStrategyId() );
			
			if ( legFromCache != null ){
				leg.setStrategyReport( leg.getStrategyReport() == null ? legFromCache.getStrategyReport() : leg.getStrategyReport() );
				leg.setInstrument( leg.getInstrument() == null ? legFromCache.getInstrument() : leg.getInstrument() );
				leg.setTotalQuantity( leg.getTotalQuantity() == null ? legFromCache.getTotalQuantity() : leg.getTotalQuantity() );
				leg.setExecutedPercentage( leg.getExecutedPercentage() == null ? legFromCache.getExecutedPercentage() : leg.getExecutedPercentage() );
				leg.setRemainingQuantity( leg.getRemainingQuantity() == null ? legFromCache.getRemainingQuantity() : leg.getRemainingQuantity() );
				leg.setExecutedQuantity( leg.getExecutedQuantity() == null ? legFromCache.getExecutedQuantity() : leg.getExecutedQuantity() );
				leg.setAveragePrice( leg.getAveragePrice() == null ? legFromCache.getAveragePrice() : leg.getAveragePrice() );
				leg.setText( leg.getText() == null ? legFromCache.getText() : leg.getText() );
				leg.setSide( leg.getSide() == null ? legFromCache.getSide() : leg.getSide() );
				leg.setRouteId( leg.getRouteId() == null ? legFromCache.getRouteId() : leg.getRouteId() );
				leg.setOrderType( leg.getOrderType() == null ? legFromCache.getOrderType() : leg.getOrderType() );
				leg.setTimeInForce( leg.getTimeInForce() == null ? legFromCache.getTimeInForce() : leg.getTimeInForce() );
				leg.setAccount( leg.getAccount() == null ? legFromCache.getAccount() : leg.getAccount() );
				leg.setPassiveLeg( leg.getPassiveLeg() == null ? legFromCache.getPassiveLeg() : leg.getPassiveLeg() );
				leg.setMaxQuantityDisplay( leg.getMaxQuantityDisplay() == null ? legFromCache.getMaxQuantityDisplay() : leg.getMaxQuantityDisplay() );
				leg.setMinQuantityDisplay( leg.getMinQuantityDisplay() == null ? legFromCache.getMinQuantityDisplay() : leg.getMinQuantityDisplay() );
				leg.setRestingQuantity( leg.getRestingQuantity() == null ? legFromCache.getRestingQuantity() : leg.getRestingQuantity() );
				leg.setRestingPrice( leg.getRestingPrice() == null ? legFromCache.getRestingPrice() : leg.getRestingPrice() );
				leg.setRestingRank( leg.getRestingRank() == null ? legFromCache.getRestingRank() : leg.getRestingRank() );
				leg.setTimeOut( leg.getTimeOut() == null ? legFromCache.getTimeOut() : leg.getTimeOut() );
				leg.setInvestorId( leg.getInvestorId() == null ? legFromCache.getInvestorId() : leg.getInvestorId() );
				leg.setEnteringTrader( leg.getEnteringTrader() == null ? legFromCache.getEnteringTrader() : leg.getEnteringTrader() );
				leg.setDuration( leg.getDuration() == null ? legFromCache.getDuration() : leg.getDuration() );
			}
			
//			if ( !CacheHelper.legStrategyReportMap.containsKey( leg.getId() ) )
//				CacheHelper.legStrategyReportMap.put( leg.getId(), leg );
			
		}
		
		return leg;
	}
	
	@SuppressWarnings("unused")
	private List<LegStrategyReport> enrichLegList ( List<LegStrategyReport> legList ) throws Exception{
		
		for (LegStrategyReport leg : legList ) {
			leg = enrichLegStrategyReport ( leg );
		}
		
		return legList;
	}
	
	private List<LegStrategyReport> getLegListByReport( StrategyReport report ) throws Exception{
		
		List<LegStrategyReport> legList = null;
		
		if ( report != null ){
			
			legList = StrategyCache.getLegStrategyReportList( report );
			
			if ( legList == null || legList.isEmpty() ){
				legList = facade.getLegStrategyByReportId( report.getId().getStrategyId() );
			}
			
		}
		
		return legList;
	}
}