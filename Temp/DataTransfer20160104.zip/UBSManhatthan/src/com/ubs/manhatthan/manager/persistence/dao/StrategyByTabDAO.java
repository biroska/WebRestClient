package com.ubs.manhatthan.manager.persistence.dao;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IStrategyByTabAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IStrategyByTabDAO;
import com.ubs.manhatthan.manager.persistence.entities.StrategyByTab;
import com.ubs.manhatthan.manager.persistence.entities.StrategyType;
import com.ubs.manhatthan.manager.persistence.entities.TraderWatchTab;
import com.ubs.manhatthan.manager.persistence.entities.audit.StrategyByTabAudit;

@Repository
@Scope("singleton")
public class StrategyByTabDAO extends GenericDAO<StrategyByTab, Long> implements IStrategyByTabDAO, Serializable {
	
	@Autowired
	private IStrategyByTabAuditDAO strategyByTabAuditDAO;
	
	@Autowired
	private User user;
	
	@Override
	public StrategyByTab saveStrategyByTab( StrategyByTab strategyByTab ) throws DAOExceptionManhattan {
		try{
		
		ActionTypeEnum action = strategyByTab.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;

		strategyByTab = update( strategyByTab );

		StrategyByTabAudit sta = new StrategyByTabAudit( strategyByTab, action, user.getLogin(), new Date() );
		
		strategyByTabAuditDAO.update( sta );
		}
		catch(Exception e){
			throw new DAOExceptionManhattan(e);	
		}
		
		return strategyByTab;
	}

	public Long generate( int qtd ) throws DAOExceptionManhattan {
		
		StrategyTypeDAO strategyTypeDAO = new StrategyTypeDAO();
		TraderWatchTabDAO traderWatchTabDAO = new TraderWatchTabDAO();
		
		List<StrategyType> strategyTypeList = strategyTypeDAO.findAll();
		List<TraderWatchTab> traderWatchTabList = traderWatchTabDAO.findAll();
		
		Long qtRegs = 0L;
		
		for (int i = 1; i <= 10; i++) {
			saveStrategyByTab( new StrategyByTab( traderWatchTabList.get( i % 5 ), strategyTypeList.get( i % 5), i ) );
			qtRegs++;
		}
		
		return qtRegs;
	}
	
	@Override
	public StrategyByTab getStrategyByTab(StrategyByTab strategyByTab) throws DAOExceptionManhattan{
		StrategyByTab obj = null;
		try {
			CriteriaBuilder criteriaBuilder = getEm().getCriteriaBuilder();
	
			CriteriaQuery<StrategyByTab> criteriaQuery = criteriaBuilder.createQuery(StrategyByTab.class);
			Root<StrategyByTab> root = criteriaQuery.from(StrategyByTab.class);
			criteriaQuery.where( criteriaBuilder.equal( root.get( "instrument" ), strategyByTab.getInstrument() ) );
			criteriaQuery.where( criteriaBuilder.equal( root.get( "tab" ), strategyByTab.getTab() ) );		
			criteriaQuery.where( criteriaBuilder.equal( root.get( "strategyType" ), strategyByTab.getStrategyType() == null ? null :  strategyByTab.getStrategyType() ) );		
	
	
			
			criteriaQuery.select( root );
	
			obj = getEm().createQuery(criteriaQuery).getSingleResult();
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return obj;
	}

	public void setStrategyByTabAuditDAO(IStrategyByTabAuditDAO strategyByTabAuditDAO) {
		this.strategyByTabAuditDAO = strategyByTabAuditDAO;
	}

	public void setUser(User user) {
		this.user = user;
	}
}