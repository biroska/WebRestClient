package com.ubs.manhatthan.manager.lmdsadapter.marketdata.basicimplementation;

import java.math.BigDecimal;
import java.util.Date;

import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.Trade;

public class BasicTrade implements Trade {
	
	private final BigDecimal price;
	private final long quantity;
	private final Date tradeDate;	
	
	public BasicTrade(BigDecimal price, long quantity, Date tradeDate) {
		super();
		this.price = price;
		this.quantity = quantity;
		this.tradeDate = tradeDate;
	}

	@Override
	public BigDecimal getPrice() {
		return this.price;
	}

	@Override
	public long getQuantity() {
		return this.quantity;
	}

	@Override
	public Date getTradeDate() {
		return this.tradeDate;
	}

}
