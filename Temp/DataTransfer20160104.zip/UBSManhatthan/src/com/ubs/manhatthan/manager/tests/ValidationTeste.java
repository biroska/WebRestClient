/**
 * 
 */
package com.ubs.manhatthan.manager.tests;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.ubs.manhatthan.manager.persistence.entities.StrategyOrders;

/**
 * @author galdinoa
 * 
 */
public class ValidationTeste {
	
	private static final String REF_TEXT = "nullable=";
	private static List<Field> obrigatorios = new ArrayList<Field>();

	public static void main(String[] args) {
		

		Class<StrategyOrders> obj = StrategyOrders.class;
		
		System.out.println( "\n\n\n\n" );
		
		// Retrieve all annotations from the class
		Field[] fields = obj.getDeclaredFields();
		
		for (Field field : fields) {
			
//			System.out.println( field );
			
			Annotation[] annotations2 = field.getAnnotations();
			
			for (Annotation an : annotations2) {
				if ( isNullable( false, an.toString() ) ){
					obrigatorios.add( field );
				}
					
			}
		}
		
		for ( Field field : obrigatorios ) {
			System.out.println( field.getName() + "\n" );
		}
		
		
		StrategyOrders order = new StrategyOrders();
		order.setAveragePrice( 12. );
		order.setClientOrderId( "23424234" );
//		order.setEngineInstanceId( Util.getEngineId() );
		order.getId().setOrderId( 123456L );
		order.setOrderTimestamp( new Date() );
		
		validate( order );
		
	}
	
	private static boolean isNullable( boolean is, String exp ){
		exp = exp.replace(" ", "");
		if ( exp.contains( REF_TEXT + is ) )
			return true;
		
		return false;
	}
	
	private static boolean validate( StrategyOrders order ){
		
		if ( order == null )
			return false;
		
//		Get the reference to the struct Class
		Class<? extends StrategyOrders> obj = order.getClass();
		
//		get all the fields of the class
		Field[] declaredFields = obj.getDeclaredFields();
		
//		iterate all fields (atributes) of the class
		for (Field field : declaredFields) {
			
//			iterate the list of mandatory fields od the class
			for ( Field obrig : obrigatorios ) {
				
//				When match the names of allFieldsList and MandatoryList
				if ( field.getName().equals( obrig.getName() ) ){
					field.setAccessible( true );
					try {
						String fieldName = field.getName();
						System.out.println("ValidationTeste.validate(): " + fieldName + " field.getType(): " + field.getType() );
						
//						Get the value of the field
						Object object = field.get( order );

//						if the value is null the log the error
						if ( object == null ){
							System.out.println("============================================== NULO - validar");
						}
						
//						if ( field.getType().toString().contains( "java.lang.Long" ) ){
//							Long value = (Long) field.get( order );
//							System.out.println("=============== Long Value: " + value );
//						}
						
						System.out.println("\n");
						
					} catch (IllegalArgumentException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IllegalAccessException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		}
		
		return true;
	}
}