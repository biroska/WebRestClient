/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import com.ubs.manhatthan.manager.persistence.entities.audit.PasswordParameterAudit;

/**
 * @author galdinoa
 *
 */
public interface IPasswordParameterAuditDAO extends IGenericDAO<PasswordParameterAudit, Long> {}
