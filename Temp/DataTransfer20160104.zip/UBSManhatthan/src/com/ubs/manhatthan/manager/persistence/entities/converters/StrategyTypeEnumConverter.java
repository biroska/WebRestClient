package com.ubs.manhatthan.manager.persistence.entities.converters;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import com.ubs.manhatthan.manager.enums.StrategyTypeEnum;

@Converter(autoApply = true)
public class StrategyTypeEnumConverter implements AttributeConverter<StrategyTypeEnum, Integer> {

	@Override
	public Integer convertToDatabaseColumn(StrategyTypeEnum strategyTypeEnum ) {
		return strategyTypeEnum.getCode();
	}

	@Override
	public StrategyTypeEnum convertToEntityAttribute(Integer dbData) {
		for ( StrategyTypeEnum tif : StrategyTypeEnum.values() ) {
			if ( tif.getCode().equals(dbData) ) {
				return tif;
			}
		}

		throw new IllegalArgumentException("Unknown database value:" + dbData );
	}
}