/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import java.util.List;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.persistence.entities.Trader;

/**
 * @author galdinoa
 *
 */
public interface ITraderDAO extends IGenericDAO<Trader, Long> {

	Trader saveTrader(Trader trader) throws DAOExceptionManhattan;

	Trader getTraderByLogin(String login) throws DAOExceptionManhattan;

	List<Trader> findAllActive(boolean isActive) throws DAOExceptionManhattan;}
