/**
 * 
 */
package com.ubs.manhatthan.manager.enricher;

import java.util.Date;

import org.apache.commons.lang.StringUtils;

import com.ubs.manhatthan.manager.cache.CacheHelper;
import com.ubs.manhatthan.manager.enums.CommandTypeEnum;
import com.ubs.manhatthan.manager.enums.MessageTypeEnum;
import com.ubs.manhatthan.manager.lmdsadapter.LmdsManager;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.SecurityDefinition;
import com.ubs.manhatthan.manager.logger.ApplicationLogger;
import com.ubs.manhatthan.manager.persistence.entities.CommandMessage;
import com.ubs.manhatthan.manager.persistence.entities.Header;
import com.ubs.manhatthan.manager.persistence.entities.LegStrategyReport;
import com.ubs.manhatthan.manager.persistence.entities.StrategyOrders;
import com.ubs.manhatthan.manager.persistence.entities.StrategyReport;
import com.ubs.manhatthan.manager.utils.Util;

/**
 * @author galdinoa
 *
 */
public class Builders {
	
	private LmdsManager lmds;
	
	public Builders(){
		lmds = CacheHelper.lmdsCommunicatorInstance.get( Util.getManagerId() );
	}
	
	public Header buildHeader( MessageTypeEnum type, Long engineInstance, Long managerRequestId ){
		return new Header( type, engineInstance, Util.getManagerId(), managerRequestId );
	}
	
	public StrategyReport buildCreateModifyCancelStrategy( Header header, Long id ) throws Exception{
		
		if ( !header.isInitialized() )
			return null;
		
		StrategyReport report = new StrategyReport();
		
		report.setHeader( header );
		report.getId().setStrategyId( id );
		
		return report;
	}
	
	public StrategyOrders buildNewOrderSingle( Header header, LegStrategyReport leg ) throws Exception{
		
		if ( !header.isInitialized() || leg == null )
			return null;
		
		SecurityDefinition intrumentDefinition = lmds.getIntrumentDefinitionBySecurityId( ""+leg.getInstrument() );
		String symbol = "";
		
		if ( intrumentDefinition == null || intrumentDefinition.getSecurity() == null || StringUtils.isBlank( intrumentDefinition.getSecurity().getSymbol() ) ){
			ApplicationLogger.logError("N�o foi possivel recuperar o simbolo pelo instrumento: " + leg.getInstrument() );
		} else {
			symbol = intrumentDefinition.getSecurity().getSymbol();
		}
		
		StrategyOrders order = new StrategyOrders();
		
		order.setHeader( header );
		
		order.getId().setOrderId( 0L );
		order.getId().setOrderDate( new Date() );
		order.getId().setEngineId( header.getEngineInstanceId() );
		
		order.setSymbol( symbol );
		order.setSide( leg.getSide() );
		order.setRouteId( leg.getRouteId() );
		order.setOrderType( leg.getOrderType() );
		order.setTimeInForce( leg.getTimeInForce() );
		order.setAccount( leg.getAccount() );
		
		order.setLegStrategyReport( leg );
		
		return order;
	}

//	public StrategyOrders buildReportOrder( Header header, LegStrategyReport leg ) throws Exception{
//		
//		if ( !header.isInitialized() || leg == null )
//			return null;
//		
//		SecurityDefinition intrumentDefinition = lmds.getIntrumentDefinitionBySecurityId( ""+leg.getInstrument() );
//		String symbol = "";
//		
//		if ( intrumentDefinition == null || intrumentDefinition.getSecurity() == null || StringUtils.isBlank( intrumentDefinition.getSecurity().getSymbol() ) ){
//			ApplicationLogger.logError("N�o foi possivel recuperar o simbolo pelo instrumento: " + leg.getInstrument() );
//			return null;
//		} else {
//			symbol = intrumentDefinition.getSecurity().getSymbol();
//		}
//		
//		StrategyOrders order = new StrategyOrders();
//		
//		order.setHeader( header );
//		order.setStrategyId( leg.getId().getStrategyId() );
//		order.setLegSeq( leg.getId().getLegSeq() );
//		order.setSymbol( symbol );
//		order.setExecutedQuantity( leg.getExecutedQuantity() );
//		order.setAveragePrice( leg.getAveragePrice() );
//		order.setSide( leg.getSide() );
////		order.getId().setOrderId( 0L );
////		order.setQuantity( leg.get ); 
//		
//		return order; 
//	}
	
	public StrategyOrders buildLeggedMessage( Header header, Long id ) throws Exception{
		
		if ( !header.isInitialized() || id == null )
			return null;
		
		StrategyOrders order = new StrategyOrders();
		
		order.setHeader( header );
		order.getId().setOrderId( id );
		
		return order;
	}
	
	public CommandMessage buildCommandMessage( Header header, CommandTypeEnum type ) throws Exception{
		
		if ( !header.isInitialized() || type == null )
			return null;
		
		CommandMessage commandMessage = new CommandMessage();
		
		commandMessage.setHeader( header );
		commandMessage.setCommandType( type );

		return commandMessage;
	}
}