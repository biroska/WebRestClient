package com.ubs.manhatthan.manager.persistence.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name="TB_REL_STRATEGY_PER_TAB_LEGS",
uniqueConstraints={
		   @UniqueConstraint(columnNames={"STRATEGY_PER_TAB", "STRATEGY_TAB_LEGS", "INSTRUMENT"}, name = "CK_STRATEGY_PER_TAB_LEGS")
		})
public class StrategyByTabLeg implements Serializable {
	
	public StrategyByTabLeg(){}
	
	public StrategyByTabLeg(StrategyByTab strategyByTab,
			StrategyTypeLeg strategyTypeLeg, Integer instrument) {
		super();
		this.strategyByTab = strategyByTab;
		this.strategyTypeLeg = strategyTypeLeg;
		this.instrument = instrument;
	}

	@Id
	@Column ( name = "ID")
	@SequenceGenerator(name = "TB_REL_STRATEGY_PER_TAB_LEGS_ID_GENERATOR", sequenceName = "SEQ_STRATEGY_PER_TAB_LEGS", allocationSize = 1)
	@GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "TB_REL_STRATEGY_PER_TAB_LEGS_ID_GENERATOR" )
	private Long id;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "STRATEGY_PER_TAB", nullable = false )
	private StrategyByTab strategyByTab;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "STRATEGY_TAB_LEGS")
	private StrategyTypeLeg strategyTypeLeg;
	
	@Column ( name = "INSTRUMENT")
	private Integer instrument;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public StrategyByTab getStrategyByTab() {
		return strategyByTab;
	}

	public void setStrategyByTab(StrategyByTab strategyByTab) {
		this.strategyByTab = strategyByTab;
	}

	public StrategyTypeLeg getStrategyTypeLeg() {
		return strategyTypeLeg;
	}

	public void setStrategyTypeLeg(StrategyTypeLeg strategyTypeLeg) {
		this.strategyTypeLeg = strategyTypeLeg;
	}

	public Integer getInstrument() {
		return instrument;
	}

	public void setInstrument(Integer instrument) {
		this.instrument = instrument;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((instrument == null) ? 0 : instrument.hashCode());
		result = prime * result
				+ ((strategyByTab == null) ? 0 : strategyByTab.hashCode());
		result = prime * result
				+ ((strategyTypeLeg == null) ? 0 : strategyTypeLeg.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StrategyByTabLeg other = (StrategyByTabLeg) obj;
		if (instrument == null) {
			if (other.instrument != null)
				return false;
		} else if (!instrument.equals(other.instrument))
			return false;
		if (strategyByTab == null) {
			if (other.strategyByTab != null)
				return false;
		} else if (!strategyByTab.equals(other.strategyByTab))
			return false;
		if (strategyTypeLeg == null) {
			if (other.strategyTypeLeg != null)
				return false;
		} else if (!strategyTypeLeg.equals(other.strategyTypeLeg))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "StrategyByTabLeg [id=" + id + ", strategyByTab="
				+ strategyByTab + ", strategyTypeLeg=" + strategyTypeLeg
				+ ", instrument=" + instrument + "]";
	}
}