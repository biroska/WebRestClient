package com.ubs.manhatthan.manager.persistence.dao;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IProfileAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IProfileDAO;
import com.ubs.manhatthan.manager.persistence.entities.Profile;
import com.ubs.manhatthan.manager.persistence.entities.audit.ProfileAudit;

@Repository
@Scope("singleton")
public class ProfileDAO extends GenericDAO<Profile, Long> implements IProfileDAO, Serializable {
	
	private static final long serialVersionUID = 1488111676183040195L;

	@Autowired
	private IProfileAuditDAO profileAuditDAO;
	
	@Autowired
	private User user;
	
	public Profile saveProfile( Profile profile ) throws DAOExceptionManhattan {
		try {
			ActionTypeEnum action = profile.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;
	
			profile = update( profile );
	
			ProfileAudit pa = new ProfileAudit( profile, action, user.getLogin(), new Date() );
			
			profileAuditDAO.update( pa );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return profile;
	}
	
	@Override
	public List<Profile> findProfile( Profile profile ) throws DAOExceptionManhattan {
		
		List<Profile> returnList = null;
		try {
			if ( profile != null ){
				
				if ( profile.getId() != null ){
					profile = findById( profile.getId() );
	
					if (profile != null ){
						returnList = new ArrayList<Profile>();
						returnList.add(profile);
					}
				} else {
					returnList = findByExample( profile );
				}
			} 
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		return returnList;
	}

	public Long generate( int qtd ) throws DAOExceptionManhattan {
		
		Long qtRegs = 4L;
		
		saveProfile( new Profile("SUPPORT") );
		saveProfile( new Profile("TRADER") );
		saveProfile( new Profile("SUPERVISOR") );
		saveProfile( new Profile("ADMINISTRATIVE") );
		return qtRegs;
	}
	
	public Profile getByIndex( int index ) throws DAOExceptionManhattan  {
		return findAll().get( index );
	}

	public void setProfileAuditDAO(IProfileAuditDAO profileAuditDAO) {
		this.profileAuditDAO = profileAuditDAO;
	}

	public void setUser(User user) {
		this.user = user;
	}
}