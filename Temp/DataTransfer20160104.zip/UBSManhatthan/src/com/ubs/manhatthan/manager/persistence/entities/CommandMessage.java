/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.entities;

import java.io.Serializable;

import com.ubs.manhatthan.manager.enums.CommandTypeEnum;


/**
 * @author galdinoa
 *
 */
public class CommandMessage implements Message, Serializable {
	
	public CommandMessage() {
		super();
		this.header = new Header();
	}


	public CommandMessage(Header header, CommandTypeEnum commandType) {
		super();
		this.header = header;
		this.commandType = commandType;
	}

	private Header header;
	
	private CommandTypeEnum commandType;

	public Header getHeader() {
		return header;
	}


	public void setHeader(Header header) {
		this.header = header;
	}


	public CommandTypeEnum getCommandType() {
		return commandType;
	}


	public void setCommandType(CommandTypeEnum commandType) {
		this.commandType = commandType;
	} 
}