package com.ubs.manhatthan.manager.persistence.dao;

import java.io.Serializable;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IStrategyOrdersAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IStrategyOrdersDAO;
import com.ubs.manhatthan.manager.persistence.entities.StrategyOrders;
import com.ubs.manhatthan.manager.persistence.entities.audit.StrategyOrdersAudit;
import com.ubs.manhatthan.manager.persistence.entities.id.StrategyOrdersPK;

@Repository
@Scope("singleton")
public class StrategyOrdersDAO extends GenericDAO<StrategyOrders, StrategyOrdersPK> implements IStrategyOrdersDAO, Serializable {
	
	@Autowired
	private IStrategyOrdersAuditDAO strategyOrdersAuditDAO;
	
	@Autowired
	private User user;
	
	@Override
	public StrategyOrders saveStrategyOrder( StrategyOrders order ) throws DAOExceptionManhattan {
		try {
			ActionTypeEnum action = order.getId().getOrderId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;
			
			findById( order.getId() );
	
			order = update( order );
	
			StrategyOrdersAudit soa = new StrategyOrdersAudit( order, action, user.getLogin(), new Date() );
			
			strategyOrdersAuditDAO.update( soa );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return order;
	}

	public void setStrategyOrdersAuditDAO(IStrategyOrdersAuditDAO strategyOrdersAuditDAO) {
		this.strategyOrdersAuditDAO = strategyOrdersAuditDAO;
	}

	public void setUser(User user) {
		this.user = user;
	}
}