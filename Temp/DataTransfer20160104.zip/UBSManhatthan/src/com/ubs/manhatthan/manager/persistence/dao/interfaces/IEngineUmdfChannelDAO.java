/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.persistence.entities.EngineUmdfChannel;


/**
 * @author galdinoa
 *
 */
public interface IEngineUmdfChannelDAO extends IGenericDAO<EngineUmdfChannel, Long> {

	EngineUmdfChannel saveEngineUmdfChannel(EngineUmdfChannel engineUmdfChannel) throws DAOExceptionManhattan;

}
