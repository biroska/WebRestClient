/**
 * 
 */
package com.ubs.manhatthan.manager.cache;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.ubs.manhatthan.manager.facade.Facade;
import com.ubs.manhatthan.manager.facade.FacadeService;
import com.ubs.manhatthan.manager.lmdsadapter.LmdsManager;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.basicimplementation.BasicBookSnapshot;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.BookSnapshot;
import com.ubs.manhatthan.manager.network.client.NetworkClientManager;
import com.ubs.manhatthan.manager.persistence.entities.ClientAccount;
import com.ubs.manhatthan.manager.persistence.entities.Exchange;
import com.ubs.manhatthan.manager.persistence.entities.StrategyType;
import com.ubs.manhatthan.manager.persistence.entities.Trader;

/**
 * @author galdinoa
 *
 */
public class CacheHelper {
	
//	The manager can connect with several Engines  <EngineId, NetworkClient>
	public static HashMap< Long, NetworkClientManager > engineCommunicatorInstance;

//	The manager can connect with a unique LMDS Channel < ManagerId, LMDSManager >
	public static HashMap< Integer, LmdsManager > lmdsCommunicatorInstance;
	
	public static HashMap< Integer, StrategyType > strategyTypeCache;
	public static List< com.ubs.manhatthan.model.StrategyType > strategyTypeVOList;
	
	public static HashMap< Long, Exchange > exchangeCache;
	public static List< Exchange > exchangeListCache;
	
	private static HashMap< Long, ClientAccount > clientAccountCache;
	
	private static HashMap< String, Trader > traderCache;
	
	public static Facade facade;
	
	public static FacadeService facadeService;
	
	public static String logPath;
	
	public static Double dollarValue;
	
	static {
		engineCommunicatorInstance = new HashMap< Long, NetworkClientManager>();
		lmdsCommunicatorInstance = new HashMap< Integer, LmdsManager>();
		strategyTypeCache = new HashMap< Integer, StrategyType > ();
		strategyTypeVOList = new ArrayList< com.ubs.manhatthan.model.StrategyType >();
		exchangeCache = new HashMap< Long, Exchange >();
		exchangeListCache = new ArrayList< Exchange >();
		traderCache = new HashMap<String, Trader>();
		clientAccountCache = new HashMap< Long, ClientAccount >();
		dollarValue = null;
	}
	
	public static boolean putClientAccount( ClientAccount account ){
		
		if ( account == null || account.getCode() == null )
			return false;
		
		clientAccountCache.put( account.getCode(), account );
		return true;
	}
	
	public static ClientAccount getClientAccount( Long code ){
		
		if ( code == null )
			return null;
		
		return clientAccountCache.get( code );
	}
	
	public static Trader getTrader( String login ){
		
		if ( StringUtils.isBlank( login ) )
			return null;
		
		return traderCache.get( login );
	}
	
	public static boolean putTrader( Trader trader ){
		
		if ( trader == null || StringUtils.isBlank( trader.getLogin() ) )
			return false;
		
		traderCache.put( trader.getLogin(), trader );
		
		return true;
	}
}