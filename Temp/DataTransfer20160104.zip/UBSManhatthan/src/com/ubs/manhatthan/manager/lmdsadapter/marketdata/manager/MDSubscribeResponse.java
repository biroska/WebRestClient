package com.ubs.manhatthan.manager.lmdsadapter.marketdata.manager;

import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.BookSnapshot;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.Trade;

public class MDSubscribeResponse {
	
	private final boolean success;
	private final BookSnapshot snapshot;
	private final Trade lastTrade;
	
	public MDSubscribeResponse(boolean success, BookSnapshot snapshot,
			Trade lastTrade) {
		this.success = success;
		this.snapshot = snapshot;
		this.lastTrade = lastTrade;
	}

	public synchronized boolean isSuccess() {
		return success;
	}

	public synchronized BookSnapshot getSnapshot() {
		return snapshot;
	}

	public synchronized Trade getLastTrade() {
		return lastTrade;
	}
	
}
