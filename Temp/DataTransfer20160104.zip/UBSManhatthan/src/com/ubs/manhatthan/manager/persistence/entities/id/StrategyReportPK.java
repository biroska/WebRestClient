package com.ubs.manhatthan.manager.persistence.entities.id;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Embeddable
public class StrategyReportPK implements Serializable {

	private static final long serialVersionUID = 6355197541985682756L;

	public StrategyReportPK() {
		super();
	}

	/**
	 * @param engineId
	 * @param strategyId
	 * @param strategyDate
	 */
	public StrategyReportPK(Long engineId, Long strategyId, Date strategyDate) {
		super();
		this.engineId = engineId;
		this.strategyId = strategyId;
		this.strategyDate = strategyDate;
	}

	@Column ( name = "ENGINE_ID", nullable=false)
	private Long engineId;
	
	@Column ( name = "STRATEGY_ID", nullable=false)
	private Long strategyId;
	
	@Temporal(TemporalType.DATE)
	@Column ( name = "STRATEGY_DATE", nullable=false)
	private Date strategyDate;

	public Long getEngineId() {
		return engineId;
	}

	public void setEngineId(Long engineId) {
		this.engineId = engineId;
	}

	public Long getStrategyId() {
		return strategyId;
	}

	public void setStrategyId(Long strategyId) {
		this.strategyId = strategyId;
	}

	public Date getStrategyDate() {
		return strategyDate;
	}

	public void setStrategyDate(Date strategyDate) {
		this.strategyDate = strategyDate;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((engineId == null) ? 0 : engineId.hashCode());
		result = prime * result
				+ ((strategyDate == null) ? 0 : strategyDate.hashCode());
		result = prime * result
				+ ((strategyId == null) ? 0 : strategyId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StrategyReportPK other = (StrategyReportPK) obj;
		if (engineId == null) {
			if (other.engineId != null)
				return false;
		} else if (!engineId.equals(other.engineId))
			return false;
		if (strategyDate == null) {
			if (other.strategyDate != null)
				return false;
		} else if (!strategyDate.equals(other.strategyDate))
			return false;
		if (strategyId == null) {
			if (other.strategyId != null)
				return false;
		} else if (!strategyId.equals(other.strategyId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "StrategyReportPK [engineId=" + engineId + ", strategyId="
				+ strategyId + ", strategyDate=" + strategyDate + "]";
	}
}