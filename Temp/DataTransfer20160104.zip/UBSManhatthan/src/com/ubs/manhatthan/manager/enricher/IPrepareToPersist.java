/**
 * 
 */
package com.ubs.manhatthan.manager.enricher;

import com.ubs.manhatthan.manager.persistence.entities.StrategyOrders;
import com.ubs.manhatthan.manager.persistence.entities.StrategyReport;

/**
 * @author galdinoa
 *
 */
public interface IPrepareToPersist {

	public StrategyOrders saveOrder(StrategyOrders order);

	public StrategyReport saveReport(StrategyReport report);

	/**
	  * <p>
	 * The saveOrder is responsible for Conversion between 
	 * IPrepareToPersist to StrategyOrders.
	 * </p>
	 *
	 * @author galdinoa
	 *
	 * @since 1.7
	 * 
	 */
	StrategyOrders saveOrder(StrategyReport strategyReport, StrategyOrders order);

}
