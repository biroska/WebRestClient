package com.ubs.manhatthan.manager.persistence.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name="TB_REL_SESSIONS_PER_ENGINE",
uniqueConstraints={
		   @UniqueConstraint(columnNames={"ENGINE_ID", "SESSION_ID"}, name = "CK_SESSIONS_PER_ENGINE"),
		   @UniqueConstraint(columnNames={"SESSION_ID"}, name = "CK_UNIQUE_SESSIONS_PER_ENGINE")
		})
public class SessionByEngine implements Serializable {
	
    public SessionByEngine(){}
	
	public SessionByEngine(EngineInstance engine, OrderFixSession orderFixSession) {
		super();
		this.engine = engine;
		this.orderFixSession = orderFixSession;
	}

	@Id
	@Column ( name = "ID")
	@SequenceGenerator(name = "TB_REL_SESSIONS_PER_ENGINE_ID_GENERATOR", sequenceName = "SEQ_REL_SESSIONS_PER_ENGINE", allocationSize = 1)
	@GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "TB_REL_SESSIONS_PER_ENGINE_ID_GENERATOR" )
	private Long id;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "ENGINE_ID", nullable = false )
	private EngineInstance engine;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "SESSION_ID", nullable = false )
	private OrderFixSession orderFixSession;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public EngineInstance getEngine() {
		return engine;
	}

	public void setEngine(EngineInstance engine) {
		this.engine = engine;
	}

	public OrderFixSession getOrderFixSession() {
		return orderFixSession;
	}

	public void setOrderFixSession(OrderFixSession orderFixSession) {
		this.orderFixSession = orderFixSession;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((engine == null) ? 0 : engine.hashCode());
		result = prime
				* result
				+ ((orderFixSession == null) ? 0 : orderFixSession
						.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SessionByEngine other = (SessionByEngine) obj;
		if (engine == null) {
			if (other.engine != null)
				return false;
		} else if (!engine.equals(other.engine))
			return false;
		if (orderFixSession == null) {
			if (other.orderFixSession != null)
				return false;
		} else if (!orderFixSession.equals(other.orderFixSession))
			return false;
		return true;
	}
}