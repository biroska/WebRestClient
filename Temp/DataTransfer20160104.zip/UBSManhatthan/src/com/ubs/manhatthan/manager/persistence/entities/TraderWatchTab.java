package com.ubs.manhatthan.manager.persistence.entities;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="TB_TRADER_WATCH_TABS")
public class TraderWatchTab implements Serializable {
	
	public TraderWatchTab(){}
	
	public TraderWatchTab(String login, String description) {
		super();
		this.login = login;
		this.description = description;
	}

	@Id
	@Column ( name = "ID")
	@SequenceGenerator(name = "TB_TRADER_WATCH_TABS_ID_GENERATOR", sequenceName = "SEQ_TRADER_WATCH_TABS", allocationSize = 1)
	@GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "TB_TRADER_WATCH_TABS_ID_GENERATOR" )
	private Long id;
	
	@Column(name = "LOGIN", nullable = false, length = 64 )
	private String login;
	
	@Column ( name = "DESCRIPTION", nullable=false, length = 12 )
	private String description;
	
	@OneToMany(mappedBy = "tab", fetch=FetchType.LAZY, cascade = CascadeType.ALL )
	private List<StrategyByTab> strategyByTabs;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	public List<StrategyByTab> getStrategyByTabs() {
		return strategyByTabs;
	}

	public void setStrategyByTabs(List<StrategyByTab> strategyByTabs) {
		this.strategyByTabs = strategyByTabs;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((description == null) ? 0 : description.hashCode());
		result = prime * result + ((login == null) ? 0 : login.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TraderWatchTab other = (TraderWatchTab) obj;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (login == null) {
			if (other.login != null)
				return false;
		} else if (!login.equals(other.login))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "TraderWatchTab [id=" + id + ", login=" + login
				+ ", description=" + description + "]";
	}
}