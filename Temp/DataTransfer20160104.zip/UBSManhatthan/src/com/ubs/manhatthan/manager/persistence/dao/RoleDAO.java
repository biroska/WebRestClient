package com.ubs.manhatthan.manager.persistence.dao;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IRoleAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IRoleDAO;
import com.ubs.manhatthan.manager.persistence.entities.Role;
import com.ubs.manhatthan.manager.persistence.entities.audit.RoleAudit;

@Repository
@Scope("singleton")
public class RoleDAO extends GenericDAO<Role, Long> implements IRoleDAO , Serializable {
	
	@Autowired
	private IRoleAuditDAO roleAuditDAO;
	
	@Autowired
	private User user;
	
	@Override
	public Role saveRole( Role role ) throws DAOExceptionManhattan {
		
		try {
			ActionTypeEnum action = role.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;
			
			role = update( role );
			
			RoleAudit pa = new RoleAudit( role, action, user.getLogin(), new Date() );
			
			roleAuditDAO.update( pa );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return role;
	}
	
	@Override
	public List<Role> findRole( Role role ) throws DAOExceptionManhattan {
		
		List<Role> returnList = null;
		try {
			if ( role != null ){
				
				if ( role.getId() != null ){
					role = findById( role.getId() );
	
					if (role != null ){
						returnList = new ArrayList<Role>();
						returnList.add(role);
					}
				} else {
					returnList = findByExample( role );
				}
			} 
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		return returnList;
	}

	public Long generate( int qtd ) throws DAOExceptionManhattan {
		
		Long qtRegs = 4L;
		
		saveRole( new Role("CONSULTAR") );
		saveRole( new Role("CANCEL_ALL") );
		saveRole( new Role("PAUSE_ALL") );
		saveRole( new Role("CREATE_STRATEGY") );
		
		return qtRegs;
	}
	
	public void setUser(User user) {
		this.user = user;
	}
	
	public void setRoleAuditDAO(IRoleAuditDAO roleAuditDAO) {
		this.roleAuditDAO = roleAuditDAO;
	}
}