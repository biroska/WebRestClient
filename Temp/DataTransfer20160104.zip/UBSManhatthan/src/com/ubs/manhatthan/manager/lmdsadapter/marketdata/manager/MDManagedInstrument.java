package com.ubs.manhatthan.manager.lmdsadapter.marketdata.manager;

import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.Book;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.SecurityDefinition;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.Trade;

final public class MDManagedInstrument {
	
	private final SecurityDefinition securityDefinition;
	private Trade lastTrade;
	private final Book book;
	
	public MDManagedInstrument(SecurityDefinition securityDefinition, Book book) {
		this.securityDefinition = securityDefinition;
		this.book = book;
	}

	public SecurityDefinition getSecurityDefinition() {
		return securityDefinition;
	}

	public Book getBook() {
		return book;
	}

	public synchronized Trade getLastTrade() {
		return lastTrade;
	}

	public synchronized void setLastTrade(Trade lastTrade) {
		this.lastTrade = lastTrade;
	}	

}
