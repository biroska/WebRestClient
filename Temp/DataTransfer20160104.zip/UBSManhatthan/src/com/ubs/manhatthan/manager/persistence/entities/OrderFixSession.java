package com.ubs.manhatthan.manager.persistence.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name="TB_ORDER_FIX_SESSION",
	   uniqueConstraints={
		   @UniqueConstraint(columnNames={"HOST", "PORT"}, name = "CK_ORDER_FIX_SESSION_HOST_PORT"),
		   @UniqueConstraint(columnNames={"TARGET_COMP_ID", "SENDER_COMP_ID"}, name = "CK_ORDER_FIX_SESS_TARGET_SEND" )
		})
public class OrderFixSession implements Serializable {
	
    @Transient
    private Long engineId;

	@Transient
	private Integer idEngine;

    public OrderFixSession(Integer id){
		super();
		this.id = id;
	}
	
	public OrderFixSession(){}
	
    public OrderFixSession(Integer id, Exchange exchange, String host, Long port,
            String targetCompId, String senderCompId, String password, String description,
            Integer idEngine, Long engineId) {
	     super();
	     this.id = id;
	     this.exchange = exchange;
	     this.host = host;
	     this.port = port;
	     this.targetCompId = targetCompId;
	     this.senderCompId = senderCompId;
	     this.password = password;
	     this.description = description;
	     this.idEngine = idEngine;
	     this.engineId = engineId;
    }

    public OrderFixSession(Exchange exchange, String host, Long port,
			String targetCompId, String senderCompId, String password,
			String description ) {
		super();
		this.host = host;
		this.port = port;
		this.targetCompId = targetCompId;
		this.senderCompId = senderCompId;
		this.password = password;
		this.description = description;
		this.setExchange( exchange );
	}

	@Id
	@Column ( name = "ID")
//	@SequenceGenerator(name = "TB_ORDER_FIX_SESSIONS_ID_GENERATOR", sequenceName = "SEQ_ORDER_FIX_SESSION", allocationSize = 1)
//	@GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "TB_ORDER_FIX_SESSIONS_ID_GENERATOR" )
	private Integer id;
	
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name = "EXCHANGE", nullable = false )
	private Exchange exchange;
	
	@Column ( name = "HOST", nullable=false, length = 256 )
	private String host;
	
	@Column ( name = "PORT", nullable=false )
	private Long port;
	
	@Column ( name = "TARGET_COMP_ID", nullable=false, length = 256 )
	private String targetCompId;
	
	@Column ( name = "SENDER_COMP_ID", nullable=false, length = 256 )
	private String senderCompId;
	
	@Column ( name = "PASSWORD", nullable=false, length = 32 )
	private String password;
	
	@Column ( name = "DESCRIPTION", nullable = false, length = 1024 )
	private String description;
	
//	@OneToMany(mappedBy = "routeId", fetch=FetchType.LAZY )
//	private List<StrategyOrders> strategyOrdersList;
//	
//	@OneToMany(mappedBy = "routeId", fetch=FetchType.LAZY )
//	private List<LegStrategyReport> legStrategyReportList;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

//	public String getExchange() {
//		return exchange;
//	}
//
//	public void setExchange(String exchange) {
//		this.exchange = exchange;
//	}
	
	public String getHost() {
		return host;
	}

	public Exchange getExchange() {
		return exchange;
	}

	public void setExchange(Exchange exchange) {
		this.exchange = exchange;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public Long getPort() {
		return port;
	}

	public void setPort(Long port) {
		this.port = port;
	}

	public String getTargetCompId() {
		return targetCompId;
	}

	public void setTargetCompId(String targetCompId) {
		this.targetCompId = targetCompId;
	}

	public String getSenderCompId() {
		return senderCompId;
	}

	public void setSenderCompId(String senderCompId) {
		this.senderCompId = senderCompId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	public Integer getIdEngine() {
		return idEngine;
	}

	public void setIdEngine(Integer idEngine) {
		this.idEngine = idEngine;
	}
	
    public Long getEngineId() {
		return engineId;
	}

	public void setEngineId(Long engineId) {
		this.engineId = engineId;
	}

//	public List<StrategyOrders> getStrategyOrdersList() {
//		return strategyOrdersList;
//	}
//
//	public void setStrategyOrdersList(List<StrategyOrders> strategyOrdersList) {
//		this.strategyOrdersList = strategyOrdersList;
//	}
//	
//	public List<LegStrategyReport> getLegStrategyReportList() {
//		return legStrategyReportList;
//	}
//
//	public void setLegStrategyReportList(
//			List<LegStrategyReport> legStrategyReportList) {
//		this.legStrategyReportList = legStrategyReportList;
//	}

	//	Seta o relacionamento entre OrderFixSessions e StrategyOrders
//	public StrategyOrders addStrategyOrder( StrategyOrders strategyOrder ){
//		if ( getStrategyOrdersList() == null )
//			setStrategyOrdersList( new ArrayList<StrategyOrders>() );
//		
//		getStrategyOrdersList().add( strategyOrder );
//		strategyOrder.setRouteId( this );
//		
//		return strategyOrder;
//	}
//	
//	public StrategyOrders removeStrategyOrder( StrategyOrders strategyOrder ){
//		getStrategyOrdersList().remove( strategyOrder );
//		strategyOrder.setRouteId( null );
//		
//		return strategyOrder;
//	}
//	
//	//	Seta o relacionamento entre OrderFixSessions e LegStrategyReport
//	public LegStrategyReport addLegStrategyReport( LegStrategyReport legStrategyReport ){
//		if ( getLegStrategyReportList() == null )
//			setLegStrategyReportList( new ArrayList<LegStrategyReport>() );
//		
//		getLegStrategyReportList().add( legStrategyReport );
//		legStrategyReport.setRouteId( this );
//		
//		return legStrategyReport;
//	}
//	
//	public LegStrategyReport removeLegStrategyReport( LegStrategyReport legStrategyReport ){
//		getLegStrategyReportList().remove( legStrategyReport );
//		legStrategyReport.setRouteId( null );
//		
//		return legStrategyReport;
//	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OrderFixSession other = (OrderFixSession) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "OrderFixSession [id=" + id + ", exchange=" + exchange
				+ ", host=" + host + ", port=" + port + ", targetCompId="
				+ targetCompId + ", senderCompId=" + senderCompId
				+ ", password=" + password + ", description=" + description
				+ "]";
	}
}