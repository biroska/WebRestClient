package com.ubs.manhatthan.manager.lmdsadapter.adapter;

public class AdapterRuntimeException extends Exception
{
	private static final long serialVersionUID = 5587556281497855545L;

	public AdapterRuntimeException(String message)
	{
		super(message);
	}

	public AdapterRuntimeException(Throwable cause)
	{
		super(cause);
	}

	public AdapterRuntimeException(String message, Throwable cause)
	{
		super(message, cause);
	}

	public AdapterRuntimeException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace)
	{
		super(message, cause, enableSuppression, writableStackTrace);
	}

}
