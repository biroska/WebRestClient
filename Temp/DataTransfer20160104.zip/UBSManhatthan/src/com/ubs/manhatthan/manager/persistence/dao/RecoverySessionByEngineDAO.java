package com.ubs.manhatthan.manager.persistence.dao;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IEngineInstanceDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IRecoverySessionByEngineDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.ITcpRecoverySessionDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IUmdfRecoverySessionByEngineAuditDAO;
import com.ubs.manhatthan.manager.persistence.entities.EngineInstance;
import com.ubs.manhatthan.manager.persistence.entities.RecoverySessionByEngine;
import com.ubs.manhatthan.manager.persistence.entities.TcpRecoverySession;
import com.ubs.manhatthan.manager.persistence.entities.audit.RecoverySessionByEngineAudit;

@Repository
@Scope("singleton")
public class RecoverySessionByEngineDAO extends GenericDAO<RecoverySessionByEngine, Long> implements IRecoverySessionByEngineDAO, Serializable {
	
	private static final long serialVersionUID = -687322878817905932L;

	String deleteQuery = "DELETE FROM RecoverySessionByEngine o WHERE o.engine.id = ? and o.tcpRecoverySession.id = ?";
	
	@Autowired
	private IEngineInstanceDAO engineInstanceDAO;
	
	@Autowired
	private ITcpRecoverySessionDAO tcpRecoverySessionDAO;
	
	@Autowired
	private IUmdfRecoverySessionByEngineAuditDAO umdfRecoverySessionByEngineAuditDAO;
	
	@Autowired
	private User user;
	
	@Override
	public RecoverySessionByEngine saveRecoverySessionByEngine( RecoverySessionByEngine umdfRecoverySessionByEngine ) throws DAOExceptionManhattan {
		try {
			ActionTypeEnum action = umdfRecoverySessionByEngine.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;
	
			umdfRecoverySessionByEngine  = update( umdfRecoverySessionByEngine );
	
			RecoverySessionByEngineAudit ursbea = new RecoverySessionByEngineAudit( umdfRecoverySessionByEngine, action, user.getLogin(), new Date() );
			
			umdfRecoverySessionByEngineAuditDAO.update( ursbea );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return umdfRecoverySessionByEngine;
	}

	@Override
	public void deleteRecoverySessionByEngine (RecoverySessionByEngine recoverySessionByEngine) throws DAOExceptionManhattan {		
		if ((recoverySessionByEngine != null) && (recoverySessionByEngine.getEngine() != null && recoverySessionByEngine.getEngine().getId() != null)
				 && (recoverySessionByEngine.getTcpRecoverySession() != null && recoverySessionByEngine.getTcpRecoverySession().getId() != null)) {
			
			try {
				Query createQuery = getEm().createQuery(deleteQuery);
				createQuery.setParameter(1, recoverySessionByEngine.getEngine().getId());
				createQuery.setParameter(2, recoverySessionByEngine.getTcpRecoverySession().getId());
				
				createQuery.executeUpdate();
			} catch ( Exception e ) {
				throw new DAOExceptionManhattan( e );
			}
		}
	}
	
	public Long generate( int qtd ) throws DAOExceptionManhattan {
		
		List<EngineInstance> engineInstanceList = engineInstanceDAO.findAll();
		List<TcpRecoverySession> tcpRecoverySessionList = tcpRecoverySessionDAO.findAll();
		
		Long qtRegs = 0L;
		
		for ( int i = 1; i<= qtd; i++ ){
			saveRecoverySessionByEngine( new RecoverySessionByEngine( engineInstanceList.get( i -1 ), tcpRecoverySessionList.get( qtd -i ) ) );
			qtRegs++;
		}
		
		return qtRegs;
	}
	
		
	public boolean verifyExistByEngineId(Long engineId) throws DAOExceptionManhattan{		
		boolean exist = false;
		List<Long> resultList = null;
		try {
			
			if (engineId!=null) {
				String query = " SELECT  o.id " +
		            	   " FROM RecoverySessionByEngine o "
		            	   + " WHERE o.engine.engineId = :engineId ";
			
				TypedQuery<Long> typedQuery = getEm().createQuery( query, Long.class );
				typedQuery.setParameter("engineId", engineId);
				
				resultList = typedQuery.getResultList();
				if (resultList!=null && !resultList.isEmpty()) {
					exist = true;
				}
			}			
			
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return exist;		
	}

	public void setEngineInstanceDAO(IEngineInstanceDAO engineInstanceDAO) {
		this.engineInstanceDAO = engineInstanceDAO;
	}

	public void setTcpRecoverySessionDAO(ITcpRecoverySessionDAO tcpRecoverySessionDAO) {
		this.tcpRecoverySessionDAO = tcpRecoverySessionDAO;
	}

	public void setUmdfRecoverySessionByEngineAuditDAO(
			IUmdfRecoverySessionByEngineAuditDAO umdfRecoverySessionByEngineAuditDAO) {
		this.umdfRecoverySessionByEngineAuditDAO = umdfRecoverySessionByEngineAuditDAO;
	}

	public void setUser(User user) {
		this.user = user;
	}
}