/**
 * 
 */
package com.ubs.manhatthan.manager.utils;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.cache.CacheHelper;
import com.ubs.manhatthan.manager.enums.EnviromentEnum;
import com.ubs.manhatthan.manager.facade.Facade;
import com.ubs.manhatthan.manager.facade.FacadeService;
import com.ubs.manhatthan.manager.lmdsadapter.LmdsManager;
import com.ubs.manhatthan.manager.lmdsadapter.adapter.AdapterConfigurationException;
import com.ubs.manhatthan.manager.lmdsadapter.adapter.AdapterRuntimeException;
import com.ubs.manhatthan.manager.logger.ApplicationLogger;
import com.ubs.manhatthan.manager.network.client.NetworkClientManager;
import com.ubs.manhatthan.manager.persistence.PersistenceThread;
import com.ubs.manhatthan.manager.persistence.entities.ClientAccount;
import com.ubs.manhatthan.manager.persistence.entities.EngineInstance;
import com.ubs.manhatthan.manager.persistence.entities.Exchange;
import com.ubs.manhatthan.manager.persistence.entities.StrategyType;
import com.ubs.manhatthan.manager.persistence.entities.Trader;
import com.ubs.manhatthan.manager.service.ServiceException;
import com.ubs.manhatthan.service.MarketWatchFacade;


/**
 * @author galdinoa
 *
 */

/* Objeto que � criado no deploy da aplica��o e possui um m�todo init que 
 * inicializa as conex�es com o engine e com o LMDS
 */
public class DeployInitialize {
	
	@Autowired
	private PersistenceThread persistenceThread;
	
	@Autowired
	private Facade facade;
	
	@Autowired
	private FacadeService facadeService;
	
	@Autowired
	private MarketWatchFacade marketWatchFacade;
	
	@Autowired
	ApplicationContext applicationContext;

	private LmdsManager lmds;
	
	private boolean engineStarted = false;
	
	private List<EngineInstance> engineList;
	
	private String fileName;
	
	public void init(){
		
		try {
			
			setApplicationLog();
			
			listOfAllNonSpringBeans();
			
			/* Busca os strategies types para colocar em cache, caso n�o encontre h� algum 
			 *  problema de conex�o ou de integridade dos dados
			 */
			if ( !loadDomainsToCache() ){
				ApplicationLogger.logError("======================================================================================");
				ApplicationLogger.logError("Ocorreu um erro ao carregar as tabelas de dominio");
				ApplicationLogger.logError("======================================================================================");
				
				System.exit( 1 );
			}
			
			CacheHelper.facade = facade; //Using in JSF convereter's because a injection problem of Spring in this type classes
			CacheHelper.facadeService = facadeService; //Using in JSF convereter's because a injection problem of Spring in this type classes
			
	//		Se a aplica��o estiver rodando em ambiente local, n�o startar as conex�es
			if ( EnviromentEnum.LOCAL.name().equals( com.ubs.manhatthan.manager.utils.Util.getPropertyFromFile( "manhattan.enviroment" ) ) ){
				ApplicationLogger.logInfo("======================================================================================");
				ApplicationLogger.logInfo("Enviroment is local! \t Engine and LMDS are not started");
				ApplicationLogger.logInfo("======================================================================================");
			} else {
				try {
					
					if ( !connectToEngines() )
						System.exit( 1 );
					
				} catch (ServiceException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					ApplicationLogger.logError("Erro: ", e);
					System.exit( 1 );
				}
				if(Boolean.valueOf(com.ubs.manhatthan.manager.utils.Util.getPropertyFromFile( "manhattan.lmds.enabled" ))){
					try {
	
						if ( !connectToLMDS() ){
							ApplicationLogger.logError("======================================================================================");
							ApplicationLogger.logError( "Ocorreu um erro ao iniciar o lmds" );
							ApplicationLogger.logError("======================================================================================");
							System.exit( 1 );
						}
	
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						ApplicationLogger.logError("Erro: ", e);
						System.exit( 1 );
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						ApplicationLogger.logError("Erro: ", e);
						System.exit( 1 );
					} catch (AdapterConfigurationException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						ApplicationLogger.logError("Erro: ", e);
						System.exit( 1 );
					} catch (AdapterRuntimeException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						ApplicationLogger.logError("Erro: ", e);
						System.exit( 1 );
					} /*catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} */
					
				}
				if ( engineStarted ){
					Thread threadForPersistence = new Thread( persistenceThread, "Persistence Thread");
					threadForPersistence.start();				
				}
			}
		} catch (DAOExceptionManhattan /*| IOException*/ e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			ApplicationLogger.logError("Erro: ", e1);
			System.exit( 1 );
		}
	}
	
	private boolean loadDomainsToCache() throws DAOExceptionManhattan{

		/* Busca os strategies types para colocar em cache, caso n�o encontre h� algum 
		 *  problema de conex�o ou de integridade dos dados
		 */
		List<StrategyType> findAllStrategyType;
		List<Exchange> findAllExchange;
		
		findAllStrategyType = facade.findAllStrategyType();
		
		findAllExchange = facade.findAllExchange();

		if ( findAllStrategyType == null || findAllStrategyType.isEmpty() ){
			ApplicationLogger.logError("======================================================================================");
			ApplicationLogger.logError( "Ocorreu um erro ao carregar os tipos de strat�gia" );
			ApplicationLogger.logError("======================================================================================");
			return false;
		}
		
//		Gera cache do strategy type
		for (StrategyType strategyType : findAllStrategyType) {
			CacheHelper.strategyTypeCache.put( strategyType.getStrategyCode(), strategyType );
			if (!strategyType.getStrategyTypeLegList().isEmpty()) {
				com.ubs.manhatthan.model.StrategyType converted = marketWatchFacade.convertEntityStrategyTypeToVO( strategyType );	
				CacheHelper.strategyTypeVOList.add( converted );
			}
			
			ApplicationLogger.logInfo( "StrategyType added in cache: " +  strategyType );
//			System.out.println( "StrategyType added in cache: " +  strategyType );
		}
		
		
		if ( findAllExchange == null || findAllExchange.isEmpty() ){
			ApplicationLogger.logError("======================================================================================");
			ApplicationLogger.logError( "Ocorreu um erro ao carregar os dados de Exchange" );
			ApplicationLogger.logError("======================================================================================");
			return false;
		}
		
		
		//		Gera cache do Exchange
		ApplicationLogger.logInfo("======================================================================================");

		CacheHelper.exchangeListCache.addAll( findAllExchange );
		
		for (Exchange exchange : findAllExchange) {
			
			CacheHelper.exchangeCache.put( exchange.getId(), exchange );
			
			ApplicationLogger.logInfo( "Exchange added in cache: " +  exchange );
		}
		ApplicationLogger.logInfo("======================================================================================");
		
//		gera cache do client account
		ApplicationLogger.logInfo("======================================================================================");
		
		List<ClientAccount> allClientAccount;
		allClientAccount= facade.findAllClientAccount();
		
		if ( allClientAccount == null || allClientAccount.isEmpty() ){
			ApplicationLogger.logError("======================================================================================");
			ApplicationLogger.logError( "Nao foi possivel carregar as contas dos clientes" );
			ApplicationLogger.logError("======================================================================================");
			return false;
		}
		
		int qtd = 0;
		for (ClientAccount account : allClientAccount) {
			
			if ( account == null || account.getCode() == null )
				continue;
			
			CacheHelper.putClientAccount( account );
			
			qtd++;
		}
		
		if( qtd == 0 ){
			ApplicationLogger.logError("======================================================================================");
			ApplicationLogger.logError( "Ocorreu um erro ao carregar as contas dos clientes" );
			ApplicationLogger.logError("======================================================================================");
			return false;
		}
		
		ApplicationLogger.logInfo( "Foram adcicionadas: " + qtd +" contas no cache");
		ApplicationLogger.logInfo("======================================================================================");
		
		
		List<Trader> allActiveTraders = facade.getAllActiveTraders();
		
		if ( allActiveTraders == null || allActiveTraders.isEmpty() ){
			ApplicationLogger.logError("======================================================================================");
			ApplicationLogger.logError( "Ocorreu um erro ao carregar os Traders" );
			ApplicationLogger.logError("======================================================================================");
			return false;	
		}
		
		qtd = 0;
		for (Trader trader : allActiveTraders) {
			CacheHelper.putTrader( trader );
			qtd++;
		}
		
		ApplicationLogger.logInfo("======================================================================================");
		ApplicationLogger.logInfo( "Foram adcicionados: " + qtd +" traders no cache");
		ApplicationLogger.logInfo("======================================================================================");
		
		return true;
	}
	
	
	private boolean connectToEngines() throws DAOExceptionManhattan, ServiceException{
		
		int qtdEngineStrated = 0;
		
		
		if ( engineList == null || engineList.isEmpty() ){
			ApplicationLogger.logError("======================================================================================");
			ApplicationLogger.logError( "Ocorreu um erro ao carregar as instancias dos Engines" );
			ApplicationLogger.logError("======================================================================================");
			return false;
		}
		
		for (EngineInstance engineInstance : engineList) {
			
			if( engineInstance.getEngineId() != null && engineInstance.getEngineId() > 0 ){
				
				if ( engineInstance.getEngineId() != 33 )
					continue;
				
				ApplicationLogger.logInfo("======================================================================================");
				ApplicationLogger.logInfo("Starting Engine " + engineInstance.getEngineId() + " Service");
				ApplicationLogger.logInfo("======================================================================================");
				

				//Start & Register Network Service
				NetworkClientManager client = new NetworkClientManager( engineInstance.getHost(), 
																	    Integer.valueOf( ""+engineInstance.getPort() ) );
				
				//Start
				if (client.Start() ){
					qtdEngineStrated++;
//				Put the instance of engine in the cache
					CacheHelper.engineCommunicatorInstance.put( engineInstance.getEngineId(), client );
					
					engineStarted = true;
				}
				
			}
		}
		
		if ( qtdEngineStrated == 0 ){
			ApplicationLogger.logError("======================================================================================");
			ApplicationLogger.logError( "Nao foi possivel conectar em nenhum engine" );
			ApplicationLogger.logError("======================================================================================");
			System.exit( 1 );
		}
		
		
		return true;
	}
	
	private boolean connectToLMDS() throws FileNotFoundException, IOException, AdapterConfigurationException, AdapterRuntimeException{
		
		ApplicationLogger.logInfo("======================================================================================");
		ApplicationLogger.logInfo("Starting LMDS Service");
		ApplicationLogger.logInfo("======================================================================================");
		
		lmds = new LmdsManager();
		
		//Print start
		ApplicationLogger.logInfo( "Starting LMDS..." );
		
		//Initializing the LMDS Adapter

		ExternalContext ec = FacesContext.getCurrentInstance().getExternalContext();
		
		lmds.startLmdsAdapter( ec.getResourceAsStream("/WEB-INF/lmds-client-api.cfg") );
		
		CacheHelper.lmdsCommunicatorInstance.put( Util.getManagerId() , lmds );
		
		lmds.subscribeSymbol( Constant.SYMBOL.DOLLAR );
		
		return true;
	}
	
	
	public void destroy() throws Exception {
		
		
		Set<Long> keySet = CacheHelper.engineCommunicatorInstance.keySet();
		
		for (Long key : keySet) {
			CacheHelper.engineCommunicatorInstance.get( key ).Stop();
		}
		
		System.out.println("======================================================================================");
		System.out.println("Spring Container is destroy! Customer clean up");
		System.out.println("======================================================================================");
		
		ApplicationLogger.logInfo("======================================================================================");
		ApplicationLogger.logInfo("Spring Container is destroy! Customer clean up");
		ApplicationLogger.logInfo("======================================================================================");
	}
	
	private void listOfAllNonSpringBeans(){
		
		ApplicationLogger.logInfo("======================================================================================");
		
		for (String beanName : applicationContext.getBeanDefinitionNames()) {
			if ( beanName.contains("org.springframework") )
				continue;
			
			ApplicationLogger.logInfo("Bean name: " + beanName);
		}
		ApplicationLogger.logInfo("======================================================================================");
	}
	
	private void setApplicationLog(){
		
		try {
			engineList = facade.getEngines();
		} catch (DAOExceptionManhattan e) {
			e.printStackTrace();
			ApplicationLogger.logError("Erro: ", e);
			System.exit(1);
		}
		
		if ( engineList == null || engineList.isEmpty() ){
			ApplicationLogger.logError("======================================================================================");
			ApplicationLogger.logError("N�o foi poss�vel recuperar os engines");
			ApplicationLogger.logError("======================================================================================");
			System.exit(1);
		}
		
		EngineInstance engineInstance = engineList.get( engineList.size() -1);
		engineInstance.setLogPath( engineInstance.getLogPath() );
		
		CacheHelper.logPath = engineInstance.getLogPath();
		
		fileName = engineInstance.getLogPath() + Constant.LOG_CONFIGURATION.FILE_NAME + 
				   Util.convertDatePattern( new Date(), "yyyyMMdd") + Constant.LOG_CONFIGURATION.FILE_EXTENSION;
		
		ApplicationLogger.configureLogger( fileName );
		
		ApplicationLogger.logInfo("======================================================================================");
		ApplicationLogger.logInfo("Logfile configured: " + fileName );
		ApplicationLogger.logInfo("======================================================================================");
	}
	
	public void setPersistenceThread(PersistenceThread persistenceThread) {
		this.persistenceThread = persistenceThread;
	}

	public void setFacade(Facade facade) {
		this.facade = facade;
	}

	public void setMarketWatchFacade(MarketWatchFacade marketWatchFacade) {
		this.marketWatchFacade = marketWatchFacade;
	}

	public void setFacadeService(FacadeService facadeService) {
		this.facadeService = facadeService;
	}
}