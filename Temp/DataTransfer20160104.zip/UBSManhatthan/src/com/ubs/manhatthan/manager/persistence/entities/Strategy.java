/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.entities;

import java.io.Serializable;


/**
 * <p>
 * This is a super obj to agregate StrategyReport, LegStrategyReport and StrategyOrders
 * </p>
 * 
 * @author <a href="mailto:aimbere.galdino@ubs.com">Aimbere Galdino</a>
 * @since 1.7
 */
public abstract class Strategy implements Message, Serializable {

	
	private long counter;

	public long getCounter() {
		return counter;
	}

	public void setCounter(long counter) {
		this.counter = counter;
	}
}
