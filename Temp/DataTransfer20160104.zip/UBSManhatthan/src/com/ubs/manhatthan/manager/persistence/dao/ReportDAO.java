package com.ubs.manhatthan.manager.persistence.dao;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.TemporalType;
import javax.persistence.TypedQuery;

import org.apache.commons.lang.StringUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IReportDAO;
import com.ubs.manhatthan.manager.persistence.entities.OrderTrade;

@Repository
@Scope("singleton")
public class ReportDAO extends GenericDAO<OrderTrade, Long> implements IReportDAO, Serializable {

	private static final long serialVersionUID = -3132699292510619994L;

	private final String queryByStrategy = " SELECT  new OrderTrade( o.strategyOrder.legStrategyReport.strategyReport.id.strategyId , " +
									       "                         o.strategyOrder.legStrategyReport.strategyReport.strategyType.description , " +
									       "                         CASE WHEN ( o.side = 1 ) THEN 'C' WHEN ( o.side = 2 ) THEN 'V' ELSE '-' END , " + // Side C/V
									       "                         o.symbol, " +																	   // Symbol
								           "                         SUM(o.quantity), " +                                                              // Quantidade 
								           " 						 CASE WHEN ( SUM( o.quantity ) > 0 ) THEN ( SUM( o.quantity * o.price ) / SUM( o.quantity ) ) ELSE 0 END " +                         // Pre�o - m�dia ponderada  Sum( Qtd * R$ ) / sum(Qtd) 
		                   //              "                       , CASE WHEN ( SUM( o.quantity ) > 0 ) THEN ( SUM( o.quantity ) * ( SUM( o.quantity * o.price ) / SUM( o.quantity ) ) ) ELSE 0 END " + // Produto entre os valores das colunas Quantidade e Pre�o
						            	   "                        ) " +
						            	   "   FROM OrderTrade o ";

	private final String queryByAverage = " SELECT  new OrderTrade( o.strategyOrder.legStrategyReport.strategyReport.id.strategyId , " +
								          "                         o.strategyOrder.legStrategyReport.strategyReport.strategyType.description , " +
							        	  "                         CASE WHEN ( o.side = 1 ) THEN 'C' WHEN ( o.side = 2 ) THEN 'V' ELSE '-' END , " + // Side C/V
										  "                         o.symbol, " +																	   // Symbol
										  "                         SUM(o.quantity), " +                                                              // Quantidade 
										  " 						 CASE WHEN ( SUM( o.quantity ) > 0 ) THEN ( SUM( o.quantity * o.price ) / SUM( o.quantity ) ) ELSE 0 END " +                         // Pre�o - m�dia ponderada  Sum( Qtd * R$ ) / sum(Qtd) 
							  			  "                        ) " +
										  "   FROM OrderTrade o ";
	
	private final String queryByExecution = " SELECT  new OrderTrade( o.strategyOrder.legStrategyReport.strategyReport.id.strategyId , " +
								        	"                         o.strategyOrder.legStrategyReport.strategyReport.strategyType.description , " +
								        	" 						  CASE WHEN ( o.side = 1 ) THEN 'C' WHEN ( o.side = 2 ) THEN 'V' ELSE '-' END , " + // Side C/V
											"                         o.symbol, " +																	   // Symbol
											"						  o.orderTimestamp,	" +															   // hora da Execu��o
											"                         o.quantity , " +                                                             // Quantidade 
											" 						  o.price, " +                         // Pre�o - m�dia ponderada  Sum( Qtd * R$ ) / sum(Qtd)
											"                         o.account.description " +           // Descri��o do cliente da conta 
											"                        ) " +
											"   FROM OrderTrade o ";
	
	private final String queryByPrice = " SELECT  new OrderTrade( o.strategyOrder.legStrategyReport.strategyReport.id.strategyId , " +
								        "                         o.strategyOrder.legStrategyReport.strategyReport.strategyType.description , " +
									    " 						  CASE WHEN ( o.side = 1 ) THEN 'C' WHEN ( o.side = 2 ) THEN 'V' ELSE '-' END , " + // Side C/V
									    "                         o.symbol, " +																	   // Symbol
									    "                         SUM( o.quantity ) , " +                                                             // Quantidade 
									    " 						  o.price " +                         // Pre�o - m�dia ponderada  Sum( Qtd * R$ ) / sum(Qtd) 
									    "                        ) " +
									    "   FROM OrderTrade o ";
	
	private Map<String, Object> parametersMap;
	
	/*
	 * Retorna a lista de trades j� com a quebra pelo StrategyId + StrategyType
	 * 
	 * 
	 * */
	@Override
	public List<OrderTrade> reportByStrategy( OrderTrade orderTrade ) throws DAOExceptionManhattan {
		List<OrderTrade> resultList = null;
		try {
			String queryTemp = queryByStrategy;
			
			queryTemp = buildRestrictions( orderTrade, queryTemp );
			
			queryTemp += " GROUP BY o.strategyOrder.legStrategyReport.strategyReport.id.strategyId, " +
					   	 "          o.strategyOrder.legStrategyReport.strategyReport.strategyType.description, " +
					     "          o.symbol, " +
					     "          o.side " + 
			             " ORDER BY o.strategyOrder.legStrategyReport.strategyReport.id.strategyId, o.symbol ";
			
			TypedQuery<OrderTrade> typedQuery = getEm().createQuery( queryTemp, OrderTrade.class );
	
	//		Setting the parameters
			for ( String param : parametersMap.keySet() ) {
				typedQuery.setParameter( param, parametersMap.get( param ) );
	        }
			
			resultList = typedQuery.getResultList();
			
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		if ( resultList!=null && !resultList.isEmpty() ) {
//			System.out.println("------------------------------------------------------------------");
//			System.out.println( resultList );
//			System.out.println("------------------------------------------------------------------");
			
			/*
			 * Monta na quebra pelo strategyId + StrategyType
			 * 
			 * */
			resultList = buildGroupingByStrategy( resultList );
			
//			System.out.println("------------------------------------------------------------------");
//			System.out.println( resultList );
//			System.out.println("------------------------------------------------------------------");
					
		}
		
		return resultList;
	}
	
	@Override
	public List<OrderTrade> reportByAverage( OrderTrade orderTrade ) throws DAOExceptionManhattan {
		List<OrderTrade> resultList = null;
		try {
			String queryTemp = queryByAverage;
			
			queryTemp = buildRestrictions( orderTrade, queryTemp );
			
			queryTemp += " GROUP BY o.strategyOrder.legStrategyReport.strategyReport.id.strategyId, " +
					   	 "          o.strategyOrder.legStrategyReport.strategyReport.strategyType.description, " +
					   	 "          o.symbol, " +
					     "          o.side " + 
			             " ORDER BY o.strategyOrder.legStrategyReport.strategyReport.id.strategyId, " + 
					     "          o.symbol, o.side ";
			
			TypedQuery<OrderTrade> typedQuery = getEm().createQuery( queryTemp, OrderTrade.class );
	
	//		Setting the parameters
			for ( String param : parametersMap.keySet() ) {
				typedQuery.setParameter( param, parametersMap.get( param ) );
	        }
			
			resultList = typedQuery.getResultList();
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		if (resultList!=null && !resultList.isEmpty()) {
//			System.out.println("------------------------------------------------------------------");
//			System.out.println( resultList );
//			System.out.println("------------------------------------------------------------------");
			
			/*
			 * Monta na quebra pelo strategyId + StrategyType
			 * 
			 * */
			resultList = buildGroupingByStrategy( resultList );
			
//			System.out.println("------------------------------------------------------------------");
//			System.out.println( resultList );
//			System.out.println("------------------------------------------------------------------");
			
			/*
			 * Feita a quebra uma unica vez com o valor total
			 * */
			resultList = buildTotalNoGrouping( resultList );
			
//			System.out.println("------------------------------------------------------------------");
//			System.out.println( resultList );
//			System.out.println("------------------------------------------------------------------");
		}
		
		
		return resultList;
	}
	
	@Override
	public List<OrderTrade> reportByExecution( OrderTrade orderTrade ) throws DAOExceptionManhattan{
		List<OrderTrade> resultList = null;
		try {
			String queryTemp = queryByExecution;
			
			queryTemp = buildRestrictions( orderTrade, queryTemp );
			
			queryTemp += " ORDER BY o.strategyOrder.legStrategyReport.strategyReport.id.strategyId, " + 
			             " o.account.description, o.symbol, o.side ";
			
			TypedQuery<OrderTrade> typedQuery = getEm().createQuery( queryTemp, OrderTrade.class  );
			
	//		Setting the parameters
			for ( String param : parametersMap.keySet() ) {
				typedQuery.setParameter( param, parametersMap.get( param ) );
			}
			
			resultList = typedQuery.getResultList();
		
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		if (resultList!=null && !resultList.isEmpty()) {
			
//			System.out.println("------------------------------------------------------------------");
//			System.out.println( resultList );
//			System.out.println("------------------------------------------------------------------");
			
			/*
			 * Feita a quebra por StrategyId + StrategyType
			 * */
			
			resultList = buildGroupingByStrategy( resultList );
			
//			System.out.println("------------------------------------------------------------------");
//			System.out.println( resultList );
//			System.out.println("------------------------------------------------------------------");
			
			/*
			 * Feita a quebra por Buy/Sell + Symbol
			 * */
			resultList = buildGroupingByBSSymbol( resultList );
			
//			System.out.println("------------------------------------------------------------------");
//			System.out.println( resultList );
//			System.out.println("------------------------------------------------------------------");
		}
		
		return resultList;
	}
	
	@Override
	public List<OrderTrade> reportByPrice( OrderTrade orderTrade ) throws DAOExceptionManhattan{
		List<OrderTrade> resultList = null;
		try {
			String queryTemp = queryByPrice;
			
			queryTemp = buildRestrictions( orderTrade, queryTemp );
			
			queryTemp += " GROUP BY o.strategyOrder.legStrategyReport.strategyReport.id.strategyId, " +
					   	 "          o.strategyOrder.legStrategyReport.strategyReport.strategyType.description, " +
					     "          o.symbol, " +
					     "          o.side, " + 
					     "          o.price " + 
			             " ORDER BY o.strategyOrder.legStrategyReport.strategyReport.id.strategyId, o.symbol, o.side ";
			
			TypedQuery<OrderTrade> typedQuery = getEm().createQuery( queryTemp, OrderTrade.class );
			
	//		Setting the parameters
			for ( String param : parametersMap.keySet() ) {
				
				if ( param.equals("startDt") || param.equals("endDt") ){
					typedQuery.setParameter( param, (Date) parametersMap.get( param ) , TemporalType.TIMESTAMP );
				} else {
					typedQuery.setParameter( param, parametersMap.get( param ) );
				}
			}
			
			resultList = typedQuery.getResultList();
		
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		if ( resultList!=null && !resultList.isEmpty() ) {
//			System.out.println("------------------------------------------------------------------");
//			System.out.println( resultList );
//			System.out.println("------------------------------------------------------------------");
			
			/*
			 * Feita a quebra por StrategyId + StrategyType
			 * */
			resultList = buildGroupingByStrategy( resultList );
			
//			System.out.println("------------------------------------------------------------------");
//			System.out.println( resultList );
//			System.out.println("------------------------------------------------------------------");
			
			/*
			 * Feita a quebra por Buy/Sell + Symbol
			 * */
			resultList = buildGroupingByBSSymbol( resultList );
			
//			System.out.println("------------------------------------------------------------------");
//			System.out.println( resultList );
//			System.out.println("------------------------------------------------------------------");
		}
		
		return resultList;
	}
	
	private String buildRestrictions( OrderTrade orderTrade, String query ){
		
		boolean whereWasSet = false;
        
		parametersMap = new HashMap<String, Object>();
		
		if ( StringUtils.isNotBlank( orderTrade.getLogin() ) ){
			query += buildWhere( whereWasSet );
			query += " o.login = :login ";
			whereWasSet = true;
			parametersMap.put("login", orderTrade.getLogin() );
	    }
		
		if ( orderTrade.getAccount() != null ){
			
			if ( orderTrade.getAccount().getCode() != null ){
				query += buildWhere( whereWasSet );
				query += " o.account.code = :code ";
				parametersMap.put("code", orderTrade.getAccount().getCode() );
			} else
				if ( orderTrade.getAccount().getName() != null ){
					query += buildWhere( whereWasSet );
					query += " o.account.name = :name ";
					parametersMap.put("name", orderTrade.getAccount().getName() );
				}
			
			whereWasSet = true;
		}
		
		if ( orderTrade.getStartDt() != null ){
			query += buildWhere( whereWasSet );
			query += " o.orderTimestamp >= :startDt ";
			parametersMap.put("startDt", orderTrade.getStartDt() );
		}
		
		if ( orderTrade.getEndDt() != null ){
			query += buildWhere( whereWasSet );
			query += " o.orderTimestamp <= :endDt ";
//			parametersMap.put("endDt", Util.convertDatePattern( orderTrade.getEndDt(), "dd-MMM-yy HH.mm.ss.SSSSSSSSS a" ) );
			parametersMap.put("endDt",  orderTrade.getEndDt() );
		}
		
		return query;
	}
	
	private List<OrderTrade> buildGroupingByBSSymbol( List<OrderTrade> inputList ){
		
		if ( inputList == null || inputList.isEmpty() && inputList.size() > 1 )
			return inputList;

		long   qtdSum = 0L;
		double priceSum = 0.0;
		OrderTrade totalAux = null;
		OrderTrade item = null;
		String criterioAnterior = null; 
		List<OrderTrade> returnList = new ArrayList<OrderTrade>();
		
		returnList.add( inputList.get( 0 ) );
		
		item = inputList.get( 1 );
		returnList.add( item );
		qtdSum = item.getQuantitySum();
		priceSum = ( item.getQuantitySum() * item.getPriceAverage() );
		
		if ( inputList.size() > 2 ){
			
			criterioAnterior = item.getBuySellDesc().concat( item.getSymbol() );
			
			for (int i = 2; i < inputList.size(); i++) {
				item = inputList.get( i );
				
				if ( isOnlyStrategyDescription( item ) ){
					returnList.add( item );
					continue;
				}
				
				if ( criterioAnterior.equals( item.getBuySellDesc().concat( item.getSymbol() ) ) ){
					item.setStrategyDescription( null );
					returnList.add( item );
					qtdSum += item.getQuantitySum();
					priceSum += ( item.getQuantitySum() * item.getPriceAverage() );
				} else {
					totalAux = new OrderTrade();
					totalAux.setSymbol("Total");
					totalAux.setQuantitySum( qtdSum );
					totalAux.setPriceAverage( priceSum / qtdSum );
					
					returnList.add( totalAux );
					returnList.add( item );
					
					qtdSum = item.getQuantitySum();
					priceSum = ( item.getQuantitySum() * item.getPriceAverage() );
				}
				criterioAnterior = item.getBuySellDesc() + item.getSymbol();	
			}
			
			totalAux = new OrderTrade();
			totalAux.setSymbol("Total");
			totalAux.setQuantitySum( qtdSum );
			totalAux.setPriceAverage( priceSum / qtdSum );
			
			returnList.add( totalAux );
		}
		
		return returnList;
	}
	
	private List<OrderTrade> buildTotalNoGrouping( List<OrderTrade> inputList ){
		
		if ( inputList == null || inputList.isEmpty() && inputList.size() > 1 )
			return inputList;

		long   qtdSum = 0L;
		double priceSum = 0.0;
		OrderTrade totalAux = null;
		OrderTrade item = null;
		List<OrderTrade> returnList = new ArrayList<OrderTrade>();
		
		returnList.add( inputList.get( 0 ) );
		
		item = inputList.get( 1 );
		returnList.add( item );
		qtdSum = item.getQuantitySum();
		priceSum = ( item.getQuantitySum() * item.getPriceAverage() );
		
		if ( inputList.size() > 2 ){
						
			for (int i = 2; i < inputList.size(); i++) {
				item = inputList.get( i );								
				returnList.add( item );
				qtdSum += item.getQuantitySum();
				priceSum += ( item.getQuantitySum() * item.getPriceAverage() );	
			}
			
			totalAux = new OrderTrade();
			totalAux.setSymbol("Total");
			totalAux.setQuantitySum( qtdSum );
			totalAux.setPriceAverage( priceSum / qtdSum );
			
			returnList.add( totalAux );
		}
		
		return returnList;
	}
	
	private List<OrderTrade> buildGroupingByStrategy( List<OrderTrade> inputList ){
		
		OrderTrade item = null;
		String descAux = null;
		String descAnterior = null;
		
		if ( inputList == null || inputList.isEmpty() )
			return inputList;
		
		List<OrderTrade> returnList = new ArrayList<OrderTrade>();
		
		OrderTrade orderTrade = new OrderTrade( inputList.get(0) );
		
		returnList.add( clearFieldsReportByStrategy( orderTrade )  );
		descAnterior = inputList.get( 0 ).getStrategyDescription(); 
		
		inputList.get( 0 ).setStrategyDescription( null );
		returnList.add( inputList.get( 0 ) );
		
		if ( inputList.size() > 1 ){
			
			for (int i = 1; i < inputList.size(); i++) {
				
				item = inputList.get( i );
				descAux = item.getStrategyDescription();
				
				if ( descAnterior.equals( item.getStrategyDescription() ) ){
					item.setStrategyDescription( null );
					returnList.add( item );
					
				} else {
//					Gera a lina a mais para o StrategyId + Strategy type
					orderTrade = new OrderTrade( item );
					returnList.add( clearFieldsReportByStrategy( orderTrade )  );
					item.setStrategyDescription( null );
					returnList.add( item );
				}
				descAnterior = descAux;
			}
		}
		
		return returnList;
	}
	
	private OrderTrade clearFieldsReportByStrategy( OrderTrade trade ){
		
		trade.setSymbol( null );
		trade.setBuySellDesc( null );
		trade.setQuantitySum( null );
		trade.setPriceAverage( null );
		trade.setStrategyId( null );
		
		return trade;
	}
	
	private boolean isOnlyStrategyDescription( OrderTrade trade ){
		
		if ( StringUtils.isNotBlank( trade.getStrategyDescription() ) &&
			 trade.getSymbol() == null && 
			 trade.getBuySellDesc() == null && 
			 trade.getQuantitySum() == null && 
			 trade.getPriceAverage() == null && 
			 trade.getStrategyId() == null ){
			return true;
		}
		return false;
	}
	
	private String buildWhere( boolean flag ){
		return flag ? " AND " : " WHERE  ";
	}
}