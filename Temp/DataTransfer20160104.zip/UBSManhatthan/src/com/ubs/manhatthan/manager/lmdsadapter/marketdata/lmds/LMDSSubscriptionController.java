package com.ubs.manhatthan.manager.lmdsadapter.marketdata.lmds;

import java.util.Date;

import quickfix.Message;
import quickfix.SessionNotFound;

import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.SecurityDefinition;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.lmds.builders.MarketDataSubscribeBuilder;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.lmds.builders.SecurityListRequestBuilder;

class LMDSSubscriptionController
{
	private final QuickFixLMDSApplication application;
	private int reqCounter;
	private Long requestTimeStamp;

	public LMDSSubscriptionController(QuickFixLMDSApplication application)
	{
		this.application = application;
		Date date = new Date();
		this.requestTimeStamp = date.getTime();
	}

	public synchronized void requestSecurityList() throws SessionNotFound
	{
		String reqId = generateUniqueRequestID();
		Message request = SecurityListRequestBuilder.build(reqId);
		this.application.sendToConnectedSession(request);
	}
 
	
	public synchronized void subscribeSymbol(SecurityDefinition instrument) {
		
		
		Message subscribeMessage = MarketDataSubscribeBuilder.buildSubscribe(
				instrument.getSecurity().getExchange(), instrument.getSecurity().getSymbol(), instrument.getSecurity().getSecurityID(), generateUniqueRequestID());
		
		try
		{
//			System.out.println( "Subscribing on LMDS symbol: " + instrument.getSecurity().getSymbol() );
			this.application.sendToConnectedSession(subscribeMessage);
		} catch (SessionNotFound e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}


	private synchronized String generateUniqueRequestID()
	{
		this.reqCounter++;
		return "REQ." + requestTimeStamp + this.reqCounter;
	}


}
