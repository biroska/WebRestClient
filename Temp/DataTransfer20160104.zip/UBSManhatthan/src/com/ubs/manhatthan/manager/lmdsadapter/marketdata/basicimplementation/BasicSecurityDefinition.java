package com.ubs.manhatthan.manager.lmdsadapter.marketdata.basicimplementation;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;

import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.Security;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.SecurityDefinition;
import com.ubs.manhatthan.manager.utils.Constant;

public class BasicSecurityDefinition implements SecurityDefinition {
	
	private final Security security;
	private final long roundLot;
	private final BigDecimal minPriceIncrement;
	private final Date maturityDate;

	private Integer businessDays;
	private boolean isBusinessDaysDefined;

//	remover aim*
	public BasicSecurityDefinition(Security security, long roundLot,
			BigDecimal minPriceIncrement) {
		this.security = security;
		this.roundLot = roundLot;
		this.minPriceIncrement = minPriceIncrement;
		
		/* Mock para o Maturity Date */
		Calendar cal = Calendar.getInstance();
		cal.add( Calendar.DATE  , 5 );
		this.maturityDate = cal.getTime();
	}
	
	public BasicSecurityDefinition(Security security,
								   long roundLot,
								   BigDecimal minPriceIncrement,
								   Date maturityDate)
	{
		this.security = security;
		this.roundLot = roundLot;
		this.minPriceIncrement = minPriceIncrement;
		this.maturityDate = maturityDate;
		this.businessDays = Constant.SIMULATION.INITIAL_BUSINESS_DAYS;
		this.isBusinessDaysDefined = false;
	}

	@Override
	public Security getSecurity()
	{
		return this.security;
	}

	@Override
	public long getRoundLot()
	{
		return this.roundLot;
	}

	@Override
	public BigDecimal getMinPriceIncrement()
	{
		return this.minPriceIncrement;
	}

	@Override
	public Date getMaturityDate()
	{
		return this.maturityDate;
	}
	
	@Override
	public Integer getBusinessDays()
	{
		return businessDays;
	}
	
	@Override
	public void setBusinessDays(Integer businessDays)
	{
		if( !this.isBusinessDaysDefined )
		{
			this.businessDays = businessDays;
			this.isBusinessDaysDefined = true;
		}
	}

	@Override
	public boolean isBusinessDaysDefined()
	{
		return isBusinessDaysDefined;
	}

}