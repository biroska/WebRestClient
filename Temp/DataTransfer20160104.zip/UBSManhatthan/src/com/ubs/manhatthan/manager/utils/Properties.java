package com.ubs.manhatthan.manager.utils;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;

import com.ubs.manhatthan.manager.enums.FilePropertiesEnum_remover;

public class Properties {

    private PropertiesConfiguration configuration;

    public Properties(FilePropertiesEnum_remover property) {
        try {
            configuration = new PropertiesConfiguration( property.getPath() );
        } catch (ConfigurationException e) {
            e.printStackTrace();
        }
    }

    public Properties(String fileName) {
        try {
            configuration = new PropertiesConfiguration(fileName);
        } catch (ConfigurationException e) {
            e.printStackTrace();
        }
    }

    public String getValue(String key) {
        if ( !configuration.containsKey( key ) ) {
            return null;
        }

        return configuration.getString(key);
    }
}