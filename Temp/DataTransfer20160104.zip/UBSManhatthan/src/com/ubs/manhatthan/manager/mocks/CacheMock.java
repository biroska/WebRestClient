/**
 * 
 */
package com.ubs.manhatthan.manager.mocks;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.persistence.dao.LegStrategyReportDAO;
import com.ubs.manhatthan.manager.persistence.dao.StrategyOrdersDAO;
import com.ubs.manhatthan.manager.persistence.dao.StrategyReportDAO;
import com.ubs.manhatthan.manager.persistence.entities.LegStrategyReport;
import com.ubs.manhatthan.manager.persistence.entities.StrategyOrders;
import com.ubs.manhatthan.manager.persistence.entities.StrategyReport;
import com.ubs.manhatthan.manager.persistence.entities.id.LegStrategyReportPK;
import com.ubs.manhatthan.manager.persistence.entities.id.StrategyOrdersPK;
import com.ubs.manhatthan.manager.persistence.entities.id.StrategyReportPK;

/**
 * @author galdinoa
 *
 */
public class CacheMock {
	
	public void generateStrategyReport( ConcurrentHashMap< StrategyReportPK, StrategyReport > strategyReportMap ) throws DAOExceptionManhattan {
	
		StrategyReportDAO reportDAO = new StrategyReportDAO();
	
//		Busca os 5 primeiros registros
		List<StrategyReport> reportByCriteria = reportDAO.findByCriteria(null, false, -1, 5);
		
		if ( reportByCriteria != null ){
			for (StrategyReport strategyReport : reportByCriteria) {
				strategyReportMap.put( strategyReport.getId(), strategyReport );
			}
		}
	}
	
	public void generateStrategyOrder( ConcurrentHashMap< StrategyOrdersPK, StrategyOrders > strategyOrderMap ) throws DAOExceptionManhattan {
		
		StrategyOrdersDAO dao = new StrategyOrdersDAO();
		
//		Busca os 5 primeiros registros
		List<StrategyOrders> findByCriteria = dao.findByCriteria(null, false, -1, 5);
		
		if ( findByCriteria != null ){
			for (StrategyOrders item : findByCriteria) {
				strategyOrderMap.put( item.getId(), item );
			}
		}
	}
	
	public void generateLegStrategy( ConcurrentHashMap< LegStrategyReportPK, LegStrategyReport > legStrategyReportMap ) throws DAOExceptionManhattan {
		
		LegStrategyReportDAO dao = new LegStrategyReportDAO();
		
//		Busca os 5 primeiros registros
		List<LegStrategyReport> findByCriteria = dao.findByCriteria(null, false, -1, 5);
		
		if ( findByCriteria != null ){
			for (LegStrategyReport item : findByCriteria) {
				legStrategyReportMap.put( item.getId(), item );
			}
		}
	}
}
