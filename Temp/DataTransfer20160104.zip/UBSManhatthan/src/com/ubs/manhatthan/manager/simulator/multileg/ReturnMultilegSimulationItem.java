package com.ubs.manhatthan.manager.simulator.multileg;

public class ReturnMultilegSimulationItem
{
	private Long quantity;
	private Long rank;
	private Double div1;
	private Long legSeq;
	
	public ReturnMultilegSimulationItem()
	{
		this.quantity = null;
		this.rank     = null;
		this.div1     = null;
		this.legSeq   = null;
	}

	public Long getQuantity()
	{
		return quantity;
	}
	
	public void setQuantity(Long quantity)
	{
		this.quantity = quantity;
	}
	
	public Long getRank()
	{
		return rank;
	}
	
	public void setRank(Long rank)
	{
		this.rank = rank;
	}
	
	public Double getDiv1()
	{
		return div1;
	}
	
	public void setDiv1(Double div1)
	{
		this.div1 = div1;
	}
	
	public Long getLegSeq()
	{
		return legSeq;
	}

	public void setLegSeq(Long legSeq)
	{
		this.legSeq = legSeq;
	}
	
}
