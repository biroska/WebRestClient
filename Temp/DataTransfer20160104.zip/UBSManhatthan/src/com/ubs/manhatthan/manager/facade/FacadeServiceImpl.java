/**
 * 
 */
package com.ubs.manhatthan.manager.facade;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.ubs.manhatthan.exception.BussinessExceptionManhattan;
import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.exception.EngineExceptionManhattan;
import com.ubs.manhatthan.exception.MessageExceptionManhattan;
import com.ubs.manhatthan.manager.cache.CacheHelper;
import com.ubs.manhatthan.manager.cache.LmdsCache;
import com.ubs.manhatthan.manager.cache.StrategyCache;
import com.ubs.manhatthan.manager.dispatcher.manager.Manager;
import com.ubs.manhatthan.manager.dto.ReceiveSymbolSyntheticItem;
import com.ubs.manhatthan.manager.dto.ReceiveSynthetic;
import com.ubs.manhatthan.manager.enums.SideEnum;
import com.ubs.manhatthan.manager.enums.StrategyTypeEnum;
import com.ubs.manhatthan.manager.lmdsadapter.LmdsManager;
import com.ubs.manhatthan.manager.lmdsadapter.SimulationItem;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.BookSnapshot;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.SecurityDefinition;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.Trade;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.manager.MDSubscribeResponse;
import com.ubs.manhatthan.manager.logger.ApplicationLogger;
import com.ubs.manhatthan.manager.logger.ManhattanLogger;
import com.ubs.manhatthan.manager.network.client.NetworkClientManager;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_to_engine_message;
import com.ubs.manhatthan.manager.persistence.entities.Message;
import com.ubs.manhatthan.manager.persistence.entities.Strategy;
import com.ubs.manhatthan.manager.simulator.multileg.InputMultilegSimulation;
import com.ubs.manhatthan.manager.simulator.multileg.InputMultilegSimulationItem;
import com.ubs.manhatthan.manager.simulator.multileg.MultilegSimulation;
import com.ubs.manhatthan.manager.simulator.multileg.ReturnMultilegSimulation;
import com.ubs.manhatthan.manager.simulator.multileg.ReturnMultilegSimulationItem;
import com.ubs.manhatthan.manager.utils.Constant;
import com.ubs.manhatthan.manager.utils.Util;
import com.ubs.manhatthan.model.LegStrategyReport;
import com.ubs.manhatthan.model.StrategyReport;

@Service
@Scope("singleton")
public class FacadeServiceImpl implements FacadeService, Serializable {
	
	private static final long serialVersionUID = 1968099373557398172L;

	@Autowired
	private Manager managerDispatcher;
	
	private LmdsManager lmds;
	
	private MultilegSimulation simulation = new MultilegSimulation();
	
	/**
	 * <p>
	 * The calculate is responsible for the calculus of the values of the market and strategy
	 * </p>
	 * 
	 * @author <a href="mailto:aimbere.galdino@ubs.com">Aimbere Galdino</a>
	 * @param <M>
	 *            contains the {@link InputMultilegSimulation}.
	 * @param <E>
	 *            contains the {@link ReturnMultilegSimulation}.
	 * @since 1.7
	 */
	@Override
	public ReturnMultilegSimulation calculate( InputMultilegSimulation input ) {

		return simulation.simulate( input );
	}
	
	/**
	 * <p>
	 * The subscribe is responsible to subscribe a symbol to lmds and put
	 * the symbol subscribed in the cache map
	 * </p>
	 * 
	 * @author <a href="mailto:aimbere.galdino@ubs.com">Aimbere Galdino</a>
	 * @param <M>
	 *            contains the {@link ReceiveSynthetic}.
	 * @param <E>
	 *            contains the {@link boolean}.
	 * @throws DAOExceptionManhattan 
	 * @since 1.7
	 */
	@Override
	public String subscribe( ReceiveSynthetic synthetic ) throws DAOExceptionManhattan{
		
		if ( synthetic == null || synthetic.getStrategyType() == null ||
			 synthetic.getSyntheticList() == null || synthetic.getSyntheticList().isEmpty() )
				return "Object null or invalid";
		
		LmdsManager lmdsManager = CacheHelper.lmdsCommunicatorInstance.get( Util.getManagerId() );
		
		
		for (ReceiveSymbolSyntheticItem syntheticItem : synthetic.getSyntheticList() ) {
			
			if ( syntheticItem.getSymbol().equals( Constant.SYMBOL.DOLLAR ) )
				continue;
			
			if ( lmdsManager.getIntrumentDefinitionBySymbol( syntheticItem.getSymbol() ) == null ){
				return "Invalid symbol: " + syntheticItem.getSymbol();
			}
		}
		
		boolean subscribeManager = lmdsManager.subscribeManager( synthetic );
		
		if ( !subscribeManager ){
			return "An error occurred while performing the subscription";
		}
		
		return null;
	}
	
	/**
	 * <p>
	 * The subscribe is responsible to subscribe a symbol to lmds and put
	 * the symbol subscribed in the cache map
	 * </p>
	 * 
	 * @author <a href="mailto:aimbere.galdino@ubs.com">Aimbere Galdino</a>
	 * @param <M>
	 *            contains the {@link ReceiveSynthetic}.
	 * @param <E>
	 *            contains the {@link boolean}.
	 * @throws DAOExceptionManhattan 
	 * @since 1.7
	 */	
	@Override
	public String subscribe( String symbol ) throws DAOExceptionManhattan{
		
		if ( StringUtils.isBlank( symbol ) )
			return null;
		
		LmdsManager lmdsManager = CacheHelper.lmdsCommunicatorInstance.get( Util.getManagerId() );
		
		ReceiveSynthetic synthetic = new ReceiveSynthetic();
		
		List<ReceiveSymbolSyntheticItem> syntheticList = new ArrayList<ReceiveSymbolSyntheticItem>();
		ReceiveSymbolSyntheticItem item = new ReceiveSymbolSyntheticItem();
		item.setLegSeq(0);
		item.setSymbol(symbol);
		
		syntheticList.add(item);
		
		synthetic.setSyntheticList(syntheticList);	
		
		boolean subscribeManager = lmdsManager.subscribeManager( synthetic );
		
		if ( !subscribeManager ){
			return "An error occurred while performing the subscription";
		}
		
		return null;
	}
	
	/**
	 * <p>
	 * The unSubscribe is responsible to unSubscribe a symbol to lmds
	 * </p>
	 * 
	 * @author <a href="mailto:aimbere.galdino@ubs.com">Aimbere Galdino</a>
	 * @param <M>
	 *            contains the {@link String}.
	 * @param <E>
	 *            contains the {@link boolean}.
	 * @return 
	 * @since 1.7
	 */
	@Override
	public void unSubscribe( String symbol ){
		
		if ( StringUtils.isBlank( symbol ) )
			return;

		LmdsManager lmdsManager = CacheHelper.lmdsCommunicatorInstance.get( Util.getManagerId() );
		
		lmdsManager.unsubscribeSymbol( symbol );
	}
	
	/**
	 * <p>
	 * The getSymbol is responsible to access the lmds to retrieve the symbol by instrument
	 * </p>
	 * 
	 * @author <a href="mailto:aimbere.galdino@ubs.com">Aimbere Galdino</a>
	 * @param <M>
	 *            contains the {@link String}.
	 * @param <E>
	 *            contains the {@link String}.
	 * @return 
	 * @throws DAOExceptionManhattan 
	 * @since 1.7
	 */
	@Override
	public String getSymbol( String instrument ) throws DAOExceptionManhattan{
		
		if ( StringUtils.isBlank( instrument ) )
			return null;

		LmdsManager lmdsManager = CacheHelper.lmdsCommunicatorInstance.get( Util.getManagerId() );
		
		SecurityDefinition securityDefinition = lmdsManager.getIntrumentDefinitionBySecurityId( instrument );
		
		if ( securityDefinition == null || securityDefinition.getSecurity() == null )
			return "";
		
		return securityDefinition.getSecurity().getSymbol();
	}
	
	/**
	 * <p>
	 * The getInstrument is responsible to access the lmds to retrieve the instrument by Symbol
	 * </p>
	 * 
	 * @author <a href="mailto:aimbere.galdino@ubs.com">Aimbere Galdino</a>
	 * @param <M>
	 *            contains the {@link String}.
	 * @param <E>
	 *            contains the {@link String}.
	 * @return 
	 * @throws DAOExceptionManhattan 
	 * @since 1.7
	 */
	@Override
	public String getInstrument( String symbol ) throws DAOExceptionManhattan{
		
		if ( StringUtils.isBlank( symbol ) )
			return null;
		
		LmdsManager lmdsManager = CacheHelper.lmdsCommunicatorInstance.get( Util.getManagerId() );
		
		SecurityDefinition securityDefinition = lmdsManager.getIntrumentDefinitionBySymbol( symbol );
		
		if ( securityDefinition == null || securityDefinition.getSecurity() == null )
			return "";
		
		LmdsCache.securityDefinitionByInstrument.put( securityDefinition.getSecurity().getSecurityID(), securityDefinition );
		
		return securityDefinition.getSecurity().getSecurityID();
	}
	
	@Override
	public List<SimulationItem> getSimulationListBySymbol( String symbol ){
		
		if ( StringUtils.isBlank( symbol ) )
			return null;
		
		return LmdsCache.getSimulationListBySymbol( symbol );
	}
	

	/**
	 * <p>
	 * The sendToEngine is responsible to send CommandMessages, orders, Strategies, etc...
	 * to the Engine
	 * </p>
	 * 
	 * @author <a href="mailto:aimbere.galdino@ubs.com">Aimbere Galdino</a>
	 * @param <M>
	 *            contains the {@link Message}.
	 * @param <E>
	 *            contains the {@link boolean}.
	 * @throws EngineExceptionManhattan 
	 * @since 1.7
	 */
	@Override
	public boolean sendToEngine( Message message) throws EngineExceptionManhattan , MessageExceptionManhattan, IOException {
		
		try {
			pb_to_engine_message engineMessage = managerDispatcher.managerMessage( message );
			
			if ( engineMessage.getHeader().getEngineInstanceId() < 1 ){
				ApplicationLogger.logError("EngineId Invalido: ");
				return false;
			}
			
			if ( !CacheHelper.engineCommunicatorInstance.containsKey( engineMessage.getHeader().getEngineInstanceId() ) ){
				ApplicationLogger.logError("O engineId: " + engineMessage.getHeader().getEngineInstanceId() + 
						                   " nao possui um client associado");
				
				throw new EngineExceptionManhattan("Engine with no clients associated.");
			}
			
			CacheHelper.engineCommunicatorInstance.get( engineMessage.getHeader().getEngineInstanceId() ).send( engineMessage );
			
			ManhattanLogger.log( ""+engineMessage.getHeader().getEngineInstanceId(), "Message sent to the engine:\n" + engineMessage , Level.INFO );
			
		} catch (EngineExceptionManhattan e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			ApplicationLogger.logError("Erro: ", e);
			throw e;
		} catch (MessageExceptionManhattan e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			ApplicationLogger.logError("Erro: ", e);
			throw e;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
			ApplicationLogger.logError("Erro: ", e);
			
			throw e;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
			ApplicationLogger.logError("Erro: ", e);
			
			throw new EngineExceptionManhattan(e.getMessage());
		}
		
		return true;
	}
	
	@Override
	public Message getMessage( String requestIdFromView ) {
		
		if ( StringUtils.isBlank( requestIdFromView ) )
			return null;

		return StrategyCache.removeMessage( requestIdFromView );
	}

	@Override
	public boolean putMessageByUser( String login, Strategy message ){
		
		if ( message == null || StringUtils.isBlank( login ) )
			return false;
		
		return StrategyCache.putMessageByUser( login, message );
	}
	
//	@Override
//	public List<Strategy> getMessagesByUser( String login, int index ){
//		
//		if ( StringUtils.isBlank( login ) )
//			return null;
//		
//		return StrategyCache.getMessagesByUser( login, index );
//	}
	
	@Override
	public List<Strategy> getMessagesByUser( String login ){
		
		if ( StringUtils.isBlank( login ) )
			return null;
		
		return StrategyCache.getMessagesByUser( login );
	}
		
//	@Override
//	public List<Strategy> getAllMessagesByUser(long index ){
//		return StrategyCache.getAllMessages( index );
//	}
	
	@Override
	public List<Strategy> getAllMessages(){
		return StrategyCache.getAllMessages();
	}

	@Override
	public List<Strategy> getMessagesSnapshotByUser( String login ){
		return StrategyCache.getMessagesSnapshotByUser( login );
	}
	
	@Override
	public List<Strategy> getMessagesBySupervisor(  ){
		return StrategyCache.getMessagesBySupervisor( );
	}
	
	@Override
	public StrategyReport calculate(StrategyReport report, boolean isOnlyTarget) throws BussinessExceptionManhattan {
		
		/* VALIDA��ES */
		if ( report == null || report.getTarget() == null || report.getLegStrategyList() == null ||
			 report.getLegStrategyList().isEmpty() || report.getLegStrategyList().size() < 2 ) {
			
			ApplicationLogger.logError( "Error on calculate. Strategy Report Validation" );
			
			return null;
		}
		
		for (LegStrategyReport leg : report.getLegStrategyList() ) {
			
			if ( StringUtils.isBlank( leg.getContract() ) ||  
				 leg.getLegSeq() == null || leg.getSide() == null ) {
				
				ApplicationLogger.logError( "Error on calculate. Leg Strategy Report Validation (Contract, Seq, Side)" );
				
				return null;
			}
		}
		
		if(!isOnlyTarget){
			
			for (LegStrategyReport leg : report.getLegStrategyList() ) {

//				Se legSeq == o size da listab de legs -1 � a �ltima leg e deve ter ou a qtd ou o div1 informado
				if ( leg.getLegSeq() == (report.getLegStrategyList().size() -1) ) {
					if (  leg.getDiv1() == null && leg.getTotalQuantity() == null ) {

						ApplicationLogger.logError( "Error on calculate. Leg Strategy Report Validation (Div1, TotalQuantity)" );

						return null;
					}
				}
			}
		}
		
		/* VALIDA��ES - TERMINO */

		InputMultilegSimulation inputSimulation = buildInputMultilegSimulation( report,  isOnlyTarget );
		
		ReturnMultilegSimulation calculate = calculate( inputSimulation );
		
		if ( calculate.isValid() ){
			report = updateStrategyReport( report, calculate,  isOnlyTarget);
		} else {
			report = clearStrategyReport( report );
			throw new BussinessExceptionManhattan("Error on strategy data calculate");
		}
		
		return report;
	}
	
	private InputMultilegSimulation buildInputMultilegSimulation( StrategyReport report, boolean isOnlyTarget ){
		
		InputMultilegSimulation inputSimulation = new InputMultilegSimulation();
		List<InputMultilegSimulationItem> legList = new ArrayList<InputMultilegSimulationItem>();
		lmds = CacheHelper.lmdsCommunicatorInstance.get( Util.getManagerId() );
		
		inputSimulation.setOnlyTarget( isOnlyTarget );
		inputSimulation.setUserDefinedTarget( report.getTarget() );
		
		if ( !isOnlyTarget){
//			dollarSpot = lmds.getDollarSpot();
			inputSimulation.setDollarSpot(CacheHelper.dollarValue);
		}
		
//		arrumar, dar� erro aim* - Workarround no banco para funcionar
		inputSimulation.setSimulationMode( StrategyTypeEnum.fromValue( Integer.valueOf( ""+report.getStrategyType().getId() ) ) );
		
		for (int i = 0; i < report.getLegStrategyList().size(); i++) {
			
			LegStrategyReport leg = report.getLegStrategyList().get( i );
			
			InputMultilegSimulationItem inputLeg = new InputMultilegSimulationItem();
//			inputLeg.setInstrument( MarketDataMock.getInstrument( leg.getContract() ) );
			
			SecurityDefinition intrumentDefinitionBySymbol;
			try {
				intrumentDefinitionBySymbol = lmds.getIntrumentDefinitionBySymbol( leg.getContract().toUpperCase() );
				
				if ( intrumentDefinitionBySymbol != null && intrumentDefinitionBySymbol.getSecurity() != null &&
					 intrumentDefinitionBySymbol.getSecurity().getSecurityID() != null	){
					
					inputLeg.setInstrument( Long.valueOf( intrumentDefinitionBySymbol.getSecurity().getSecurityID() ) );
					inputLeg.setSecurityDefinition( intrumentDefinitionBySymbol );
					
				}
			} catch (DAOExceptionManhattan e) {
				e.printStackTrace();
				
				ApplicationLogger.logError( "Ocorreu um erro ao recuperar o IntrumentDefinitionBySymbol via lmds" );
			}
			
			inputLeg.setLegSeq( leg.getLegSeq() );
			inputLeg.setSide( SideEnum.fromValue( leg.getSide() ) );
			
			if ( !isOnlyTarget ) {
				
//				ultima perna
				if ( inputLeg.getLegSeq() == (report.getLegStrategyList().size() -1) ){
					
					if ( leg.getTotalQuantity() != null ){
						inputLeg.setQuantity( leg.getTotalQuantity() );
						inputLeg.setByQuantity(true);
					} else {
						inputLeg.setDiv1( leg.getDiv1() );
					}
					
					inputLeg.setSimulationLeg( true );	
				}
			}
			
			BookSnapshot lastBookSnapshot = lmds.getLastBookSnapshot( leg.getContract() );
			
			inputLeg = setBookValues( inputLeg, lastBookSnapshot );
			
			Trade lastTrade = lmds.getLastTrade(leg.getContract());
			if( null != lastTrade )
			{
				if( null != lastTrade.getPrice() && 0.0 < lastTrade.getPrice().doubleValue() && 0L < lastTrade.getQuantity() )
				{
					inputLeg.setLastTrade(lastTrade.getPrice().doubleValue(), lastTrade.getQuantity());
				}
			}
			
			legList.add( inputLeg );
		}
		
//		legList.get( legList.size() -1 ).setSimulationLeg( true );
		
		inputSimulation.setInputItens( legList );
		
		return inputSimulation;
	}
	
	private InputMultilegSimulationItem setBookValues( InputMultilegSimulationItem leg, BookSnapshot bookSnapshot ){
		
		if ( leg.getInstrument() == null || bookSnapshot == null || bookSnapshot.isEmpty() ) { return leg; }
		
		leg.setBidDepth( Math.min( bookSnapshot.getBidSize(), Constant.SIMULATION.DEFAULT_BOOK_LEVEL ) );
		leg.setAskDepth( Math.min( bookSnapshot.getAskSize(), Constant.SIMULATION.DEFAULT_BOOK_LEVEL ) );
		
		for(int i = 0; i < leg.getBidDepth(); i++)
		{
			if( bookSnapshot.getBidAt(i).getPrice().doubleValue() >= 0.0 && bookSnapshot.getBidAt(i).getQuantity() >= 0L )
			{
				leg.getBidPrices().add( 0.0 );
				leg.getBidPrices().set( i , bookSnapshot.getBidAt( i ).getPrice().doubleValue() );
				
				leg.getBidQuantities().add( 0L );
				leg.getBidQuantities().set( i , bookSnapshot.getBidAt( i ).getQuantity() );
			}
			else
			{
				return leg;
			}
		}
		
		for(int i = 0; i < leg.getAskDepth(); i++)
		{
			if( bookSnapshot.getAskAt(i).getPrice().doubleValue() >= 0.0 && bookSnapshot.getAskAt(i).getQuantity() >= 0L )
			{
				leg.getAskPrices().add( 0.0 );
				leg.getAskPrices().set( i , bookSnapshot.getAskAt( i ).getPrice().doubleValue() );
				leg.getAskQuantities().add( 0L );
				leg.getAskQuantities().set( i , bookSnapshot.getAskAt( i ).getQuantity() );
			}
			else
			{
				return leg;
			}
		}
		
		return leg;
	}
	
	private StrategyReport updateStrategyReport(StrategyReport report, ReturnMultilegSimulation calculate, boolean isOnlyTarget){
		
		report.setTargetDif( calculate.getTargetDif() );
		report.setMarket( calculate.getMarketTarget() );
		report.setTargetWarning(false);
		
		if ( isOnlyTarget ) {
			return report;
		}
		
		if ( calculate.getReturnItens().size() == report.getLegStrategyList().size() ){

			for (ReturnMultilegSimulationItem returnItem : calculate.getReturnItens() ) {
				
				for ( LegStrategyReport leg : report.getLegStrategyList() ) {
					
					if ( Long.valueOf( leg.getLegSeq() ).equals( returnItem.getLegSeq() )  ){
						leg.setTotalQuantity( returnItem.getQuantity() != null ? Long.valueOf( returnItem.getQuantity() ) : leg.getTotalQuantity() );
						leg.setRestingRank( Long.valueOf( returnItem.getRank() ) != null ? Long.valueOf( returnItem.getRank() ) : null );
						leg.setDiv1( returnItem.getDiv1() != null ? returnItem.getDiv1() : leg.getDiv1() );
						if (returnItem.getRank()==null || returnItem.getRank().equals(0L)) {
							report.setTargetWarning(true);
						}
						
						break;
					}
				}
			}
		}
		
		return report;
	}
	
	private StrategyReport clearStrategyReport(StrategyReport report ){
		
		report.setTargetDif( null );
		report.setMarket( null );
			
		for ( LegStrategyReport leg : report.getLegStrategyList() ) {
//			leg.setTotalQuantity( null );
			leg.setRestingRank( null );
//			leg.setDiv1( null );
		}
		
		return report;
	}
	
	
	
	public void setManagerDispatcher(Manager managerDispatcher) {
		this.managerDispatcher = managerDispatcher;
	}
	
	@Override
	public List<Long> isLoggedOff(){
		
		Set<Long> keySet = CacheHelper.engineCommunicatorInstance.keySet();
		
		List<Long> engineListOff = new ArrayList<Long>();

		for (Long key : keySet) {
			NetworkClientManager networkClientManager = CacheHelper.engineCommunicatorInstance.get( key );
			
			if ( !networkClientManager.isLoggedOn() ){
				engineListOff.add( key );
			}
		}
		
		return engineListOff;
	}
}