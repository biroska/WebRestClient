package com.ubs.manhatthan.manager.persistence.dao;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IExchangeDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.ITcpRecoverySessionAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.ITcpRecoverySessionDAO;
import com.ubs.manhatthan.manager.persistence.entities.Exchange;
import com.ubs.manhatthan.manager.persistence.entities.TcpRecoverySession;
import com.ubs.manhatthan.manager.persistence.entities.audit.TcpRecoverySessionAudit;

@Repository
@Scope("singleton")
public class TcpRecoverySessionDAO extends GenericDAO<TcpRecoverySession, Long> implements ITcpRecoverySessionDAO, Serializable {
	
	private static final long serialVersionUID = 5615727106437827676L;

	private final String queryByEngine = " SELECT  new TcpRecoverySession( o.tcpRecoverySession.id , " +
            "                                 	o.tcpRecoverySession.exchange , " + 
            "                                 	o.tcpRecoverySession.host , " + 
            "                     				o.tcpRecoverySession.port, " +
            "                                 	o.tcpRecoverySession.targetCompId, " +
            "									o.tcpRecoverySession.senderCompId, " + 
            "									o.engine.id, " +
            "                                 	o.engine.engineId)" +
            "   							FROM RecoverySessionByEngine o ";

    @Autowired
	private IExchangeDAO exchangeDAO;
	
	@Autowired
	private ITcpRecoverySessionAuditDAO tcpRecoverySessionAuditDAO;
	
	@Autowired
	private User user;
	
	@Override
	public TcpRecoverySession saveTcpRecoverySession( TcpRecoverySession tcpRecoverySession ) throws DAOExceptionManhattan {
		try {
			ActionTypeEnum action = tcpRecoverySession.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;
	
			tcpRecoverySession  = update( tcpRecoverySession );
	
			TcpRecoverySessionAudit trsa = new TcpRecoverySessionAudit( tcpRecoverySession, action, user.getLogin(), new Date() );
			
			tcpRecoverySessionAuditDAO.update( trsa );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return tcpRecoverySession;
	}

	@Override
	public void delete( TcpRecoverySession tcpRecovery ) throws DAOExceptionManhattan {
		try {
			deleteById(tcpRecovery.getId());
			
			TcpRecoverySessionAudit pa = new TcpRecoverySessionAudit( tcpRecovery, ActionTypeEnum.DELETE, user.getLogin(), new Date() );
			
			tcpRecoverySessionAuditDAO.update( pa );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
	}

	public Long generate( int qtd ) throws DAOExceptionManhattan {
		
		List<Exchange> exchangeList = exchangeDAO.findAll();
		
		Long qtRegs = 0L;
		
		for ( int i = 1; i<= qtd; i++ ){
			saveTcpRecoverySession( new TcpRecoverySession( exchangeList.get( i % 2), "255.255.255.0"+i, (long) 8079 +i,
															"targetCompId_"+i, "senderCompId_"+i ) );
			qtRegs++;
		}
		
		return qtRegs;
	}

	@Override
	public List<TcpRecoverySession> getTcpRecoveries() throws DAOExceptionManhattan {
		List<TcpRecoverySession> resultList = null;
		try {
			TypedQuery<TcpRecoverySession> typedQuery = getEm().createQuery( queryByEngine, TcpRecoverySession.class );
			
			resultList = typedQuery.getResultList();
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return resultList;
	}

	public void setExchangeDAO(IExchangeDAO exchangeDAO) {
		this.exchangeDAO = exchangeDAO;
	}

	public void setTcpRecoverySessionAuditDAO(ITcpRecoverySessionAuditDAO tcpRecoverySessionAuditDAO) {
		this.tcpRecoverySessionAuditDAO = tcpRecoverySessionAuditDAO;
	}

	public void setUser(User user) {
		this.user = user;
	}
}