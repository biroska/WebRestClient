package com.ubs.manhatthan.manager.facade;

import java.util.Date;
import java.util.List;

import com.ubs.manhatthan.exception.BussinessExceptionManhattan;
import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.enums.StrategyTypeEnum;
import com.ubs.manhatthan.manager.persistence.entities.AccountType;
import com.ubs.manhatthan.manager.persistence.entities.ClientAccount;
import com.ubs.manhatthan.manager.persistence.entities.EngineInstance;
import com.ubs.manhatthan.manager.persistence.entities.EngineUmdfChannel;
import com.ubs.manhatthan.manager.persistence.entities.Exchange;
import com.ubs.manhatthan.manager.persistence.entities.LegStrategyReport;
import com.ubs.manhatthan.manager.persistence.entities.OrderFixSession;
import com.ubs.manhatthan.manager.persistence.entities.OrderTrade;
import com.ubs.manhatthan.manager.persistence.entities.PasswordParameter;
import com.ubs.manhatthan.manager.persistence.entities.Profile;
import com.ubs.manhatthan.manager.persistence.entities.RecoverySessionByEngine;
import com.ubs.manhatthan.manager.persistence.entities.Role;
import com.ubs.manhatthan.manager.persistence.entities.RoleByProfile;
import com.ubs.manhatthan.manager.persistence.entities.SessionByAccount;
import com.ubs.manhatthan.manager.persistence.entities.SessionByEngine;
import com.ubs.manhatthan.manager.persistence.entities.StrategyByTab;
import com.ubs.manhatthan.manager.persistence.entities.StrategyByTabLeg;
import com.ubs.manhatthan.manager.persistence.entities.StrategyOrders;
import com.ubs.manhatthan.manager.persistence.entities.StrategyReport;
import com.ubs.manhatthan.manager.persistence.entities.StrategyType;
import com.ubs.manhatthan.manager.persistence.entities.StrategyTypeLeg;
import com.ubs.manhatthan.manager.persistence.entities.TcpRecoverySession;
import com.ubs.manhatthan.manager.persistence.entities.Trader;
import com.ubs.manhatthan.manager.persistence.entities.TraderExchangeCode;
import com.ubs.manhatthan.manager.persistence.entities.TraderWatchTab;
import com.ubs.manhatthan.manager.persistence.entities.UmdfChannelByEngine;

public interface Facade {
	
	public StrategyReport saveReport( StrategyReport report ) throws Exception;
	
	public StrategyOrders saveOrder( StrategyOrders report ) throws Exception;
	
	public OrderTrade saveOrderTrade( OrderTrade orderTrade ) throws Exception;
	
	public LegStrategyReport getLegStrategyByID( Integer legSeq, Long strategyReportId ) throws Exception;
	
	public List<LegStrategyReport> getLegStrategyByReportId ( Long strategyReportId ) throws Exception;
	
	public StrategyOrders findStrategyOrderById( StrategyOrders order ) throws Exception;
	
	public StrategyReport findStrategyReportById( StrategyReport report ) throws Exception;
	
	public EngineInstance saveEngineInstance( EngineInstance engine ) throws Exception;
	
	public Integer businessDayTotal( Date beginningDt, Date endingDt ) throws DAOExceptionManhattan;
	
	public Integer businessDayTotal2( Date beginningDt, Date endingDt ) throws DAOExceptionManhattan;
	
	public Role saveRole( Role role ) throws DAOExceptionManhattan;

	public AccountType saveAccountType(AccountType accountType) throws DAOExceptionManhattan;

	public EngineUmdfChannel saveEngineUmdfChannel(EngineUmdfChannel engineUmdfChannel) throws DAOExceptionManhattan;

	public Exchange saveExchange(Exchange exchange) throws DAOExceptionManhattan;

	public OrderFixSession saveOrderFixSession(OrderFixSession orderFixSession, ActionTypeEnum action) throws DAOExceptionManhattan, BussinessExceptionManhattan ;

	public List<Exchange> findExchange(Exchange exchange) throws DAOExceptionManhattan;

	public PasswordParameter savePasswordParameter(PasswordParameter passwordParameter) throws DAOExceptionManhattan;

	public Profile saveProfile(Profile profile) throws DAOExceptionManhattan;

	public RoleByProfile saveRoleByProfile(RoleByProfile role) throws DAOExceptionManhattan;

	public List<SessionByAccount> getAccountSessions() throws DAOExceptionManhattan;
	
	public SessionByAccount saveOrderFixSession(SessionByAccount sessionByAccount) throws DAOExceptionManhattan;

	public ClientAccount getClientAccountByIndex(int index) throws DAOExceptionManhattan;
	
	public ClientAccount findClientAccountByCode(Long code) throws DAOExceptionManhattan;
	
	public List<ClientAccount> FindClientAccount(ClientAccount clientAccount) throws DAOExceptionManhattan;

	public OrderFixSession getOrderFixSessionByIndex(int index) throws DAOExceptionManhattan;
	
	public OrderFixSession findOrderFixSessionById(int id) throws DAOExceptionManhattan;

	public SessionByEngine saveSessionByEngine(SessionByEngine sessionByEngine) throws DAOExceptionManhattan;

	public EngineInstance getEngineInstanceByIndex(int index) throws DAOExceptionManhattan;

	public EngineInstance findEngineInstanceByIndex(int id) throws DAOExceptionManhattan;
	
	public StrategyByTab saveStrategyByTab(StrategyByTab strategyByTab) throws DAOExceptionManhattan;

	public TraderWatchTab saveTraderWatchTab(TraderWatchTab traderWatchTab) throws DAOExceptionManhattan;

	public StrategyType saveStrategyType(StrategyType strategyType) throws DAOExceptionManhattan;

	public Exchange getExchangeByIndex(int index) throws DAOExceptionManhattan;

	public TraderWatchTab getTraderWatchTabByIndex(int index) throws DAOExceptionManhattan;
	
	public StrategyType getStrategyTypeByIndex(int index) throws DAOExceptionManhattan;

	public StrategyByTabLeg saveStrategyByTabLeg(StrategyByTabLeg strategyByTabLeg) throws DAOExceptionManhattan;

	public StrategyTypeLeg saveStrategyTypeLeg(StrategyTypeLeg strategyTypeLeg) throws DAOExceptionManhattan;

	public StrategyByTab getStrategyByTabByIndex(int index) throws DAOExceptionManhattan;

	public StrategyTypeLeg getStrategyTypeLegByIndex(int index) throws DAOExceptionManhattan;

	public TcpRecoverySession saveTcpRecoverySession(TcpRecoverySession tcpRecoverySession) throws DAOExceptionManhattan;

	public Trader saveTrader(Trader trader) throws DAOExceptionManhattan;

	public Profile getProfileByIndex(int index) throws DAOExceptionManhattan;

	public TraderExchangeCode saveTraderExchangeCode(TraderExchangeCode traderExchangeCode) throws DAOExceptionManhattan;

	public UmdfChannelByEngine saveUmdfChannelByEngine(UmdfChannelByEngine umdfChannelByEngine) throws DAOExceptionManhattan;

	public EngineUmdfChannel getEngineUmdfChannelByIndex(int index) throws DAOExceptionManhattan;

	public RecoverySessionByEngine saveUmdfRecoverySessionByEngine(RecoverySessionByEngine umdfRecoverySessionByEngine) throws DAOExceptionManhattan;

	public TcpRecoverySession getTcpRecoverySessionByIndex(int index) throws DAOExceptionManhattan;

	public StrategyReport saveStrategyReport(StrategyReport strategy) throws DAOExceptionManhattan;

	public List<OrderTrade> reportByStrategy(OrderTrade orderTrade) throws DAOExceptionManhattan;

	public List<TraderWatchTab> getListTraderWatchsTabsByLogin(String login) throws DAOExceptionManhattan;

	public Role findRole(int index) throws DAOExceptionManhattan;

	public Profile findProfile(int index) throws DAOExceptionManhattan;

	public List<OrderTrade> reportByAverage(OrderTrade orderTrade) throws DAOExceptionManhattan;

	public List<OrderTrade> reportByExecution(OrderTrade orderTrade) throws DAOExceptionManhattan;

	public List<OrderTrade> reportByPrice(OrderTrade orderTrade) throws DAOExceptionManhattan;

	public List<EngineInstance> getEngines() throws DAOExceptionManhattan;

	public void deleteEngineInstance(EngineInstance engine) throws DAOExceptionManhattan, BussinessExceptionManhattan;

	public List<Exchange> getExchanges() throws DAOExceptionManhattan;

	public List<EngineUmdfChannel> getUmdfChannels() throws DAOExceptionManhattan;
	
	public void deleteUmdfChannel(EngineUmdfChannel umdfChannel) throws DAOExceptionManhattan;

	public List<TcpRecoverySession> getTcpRecoveries() throws DAOExceptionManhattan;

	public void deleteTcpRecovery(TcpRecoverySession tcpRecovery) throws DAOExceptionManhattan;
	
	public List<OrderFixSession> getOrderFixSessions() throws DAOExceptionManhattan;

	public void deleteOrderFixSession(OrderFixSession tcpRecovery) throws DAOExceptionManhattan;

	public List<StrategyType> findAllStrategyType() throws DAOExceptionManhattan;
	
	public List<StrategyByTab> getListStrategyOrInstrumentByTab(TraderWatchTab traderWatchTab) throws DAOExceptionManhattan;

	public StrategyType getStrategyTypeById(Long id) throws DAOExceptionManhattan;

	public List<Exchange> findAllExchange() throws DAOExceptionManhattan;

	public EngineInstance findEngineInstanceById(int id) throws DAOExceptionManhattan;
	
	public StrategyTypeLeg findStrategyTypeLegById(StrategyTypeLeg strategyTypeLeg) throws DAOExceptionManhattan;
	
	public StrategyByTab getStrategyByTab(StrategyByTab strategyByTab) throws DAOExceptionManhattan;
	
	public SessionByAccount saveSessionByAccount(SessionByAccount sessionByAccount) throws DAOExceptionManhattan;

	public void deleteSessionByAccount(SessionByAccount sessionByAccount) throws DAOExceptionManhattan;

	public void deleteRecoverySessionByEngine(RecoverySessionByEngine recoverySessionByEngine) throws DAOExceptionManhattan;

	public void deleteSessionByEngine(SessionByEngine sessionByEngine) throws DAOExceptionManhattan;

	void deleteTraderWatchTabById(Long id) throws DAOExceptionManhattan;

	void deleteStrategyTabById(Long id) throws DAOExceptionManhattan;

	public Integer getNumberOfLegsFromStrategyType(StrategyTypeEnum strategyType)
			throws DAOExceptionManhattan;

	public List<EngineInstance> getEngineByAccount(Long accountId) throws DAOExceptionManhattan;

	public Long getEngineIdByAccount(Long accountId) throws DAOExceptionManhattan;

	public OrderFixSession getOrderFixByAccount(Long accountId)
			throws DAOExceptionManhattan;

	public String getEnteringTraderByLogin(String login) throws DAOExceptionManhattan;

	public List<ClientAccount> findAllClientAccount() throws DAOExceptionManhattan;

	public List<Trader> getAllActiveTraders() throws DAOExceptionManhattan;
}