/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.persistence.entities.RecoverySessionByEngine;

/**
 * @author galdinoa
 *
 */
public interface IRecoverySessionByEngineDAO extends IGenericDAO<RecoverySessionByEngine, Long> {

	public RecoverySessionByEngine saveRecoverySessionByEngine(RecoverySessionByEngine umdfRecoverySessionByEngine) throws DAOExceptionManhattan;

	public void deleteRecoverySessionByEngine(RecoverySessionByEngine recoverySessionByEngine) throws DAOExceptionManhattan;

}
