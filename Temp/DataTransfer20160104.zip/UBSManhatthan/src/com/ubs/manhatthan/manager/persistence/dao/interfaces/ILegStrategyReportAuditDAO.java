/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import java.util.List;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.persistence.entities.audit.LegStrategyReportAudit;

/**
 * @author galdinoa
 *
 */
public interface ILegStrategyReportAuditDAO extends IGenericDAO<LegStrategyReportAudit, Long> {

	List<LegStrategyReportAudit> save(List<LegStrategyReportAudit> list) throws DAOExceptionManhattan;}
