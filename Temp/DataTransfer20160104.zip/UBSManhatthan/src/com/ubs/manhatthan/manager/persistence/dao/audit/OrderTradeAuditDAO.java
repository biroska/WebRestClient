package com.ubs.manhatthan.manager.persistence.dao.audit;

import java.io.Serializable;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.persistence.dao.GenericDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IOrderTradeAuditDAO;
import com.ubs.manhatthan.manager.persistence.entities.OrderTrade;
import com.ubs.manhatthan.manager.persistence.entities.audit.OrderTradeAudit;

@Repository
@Scope("singleton")
public class OrderTradeAuditDAO extends GenericDAO<OrderTradeAudit, Long> implements IOrderTradeAuditDAO, Serializable {
	
	@Autowired
	private User user;
	
	@Override
	public OrderTradeAudit saveOrderTradeAudit( OrderTrade orderTrade ) throws DAOExceptionManhattan {
		return update( new OrderTradeAudit( orderTrade, ActionTypeEnum.INSERT, user.getLogin(), new Date() ) );
	}
	
}
