package com.ubs.manhatthan.manager.persistence.dao;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IEngineInstanceDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IEngineUmdfChannelDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IUmdfChannelByEngineAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IUmdfChannelByEngineDAO;
import com.ubs.manhatthan.manager.persistence.entities.EngineInstance;
import com.ubs.manhatthan.manager.persistence.entities.EngineUmdfChannel;
import com.ubs.manhatthan.manager.persistence.entities.UmdfChannelByEngine;
import com.ubs.manhatthan.manager.persistence.entities.audit.UmdfChannelByEngineAudit;

@Repository
@Scope("singleton")
public class UmdfChannelByEngineDAO extends GenericDAO<UmdfChannelByEngine, Long> implements IUmdfChannelByEngineDAO, Serializable {
	
	private static final long serialVersionUID = 4267896992567626971L;

	@Autowired
	private IEngineInstanceDAO engineInstanceDAO;
	
	@Autowired
	private IEngineUmdfChannelDAO engineUmdfChannelDAO;
	
	@Autowired
	private IUmdfChannelByEngineAuditDAO umdfChannelByEngineAuditDAO;
	
	@Autowired
	private User user;
	
	@Override
	public UmdfChannelByEngine saveUmdfChannelByEngine( UmdfChannelByEngine umdfChannelByEngine ) throws DAOExceptionManhattan {
		try {
			ActionTypeEnum action = umdfChannelByEngine.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;
	
			umdfChannelByEngine  = update( umdfChannelByEngine );
	
			UmdfChannelByEngineAudit ofsa = new UmdfChannelByEngineAudit( umdfChannelByEngine, action, user.getLogin(), new Date() );
			
			umdfChannelByEngineAuditDAO.update( ofsa );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return umdfChannelByEngine;
	}

	public Long generate( int qtd ) throws DAOExceptionManhattan {
		
		List<EngineInstance> engineInstanceList = engineInstanceDAO.findAll();
		List<EngineUmdfChannel> engineUmdfChannelList = engineUmdfChannelDAO.findAll();
		
		Long qtRegs = 0L;
		
		for ( int i = 1; i<= qtd; i++ ){
			saveUmdfChannelByEngine( new UmdfChannelByEngine( engineInstanceList.get( i -1 ), engineUmdfChannelList.get( qtd -i ) ) );
			qtRegs++;
		}
		
		return qtRegs;
	}
	
	public boolean verifyExistByEngineId(Long engineId) throws DAOExceptionManhattan{		
		
		boolean exist = false;
		List<Long> resultList = null;
		try {
			
			if (engineId!=null) {
				String query = " SELECT  o.id " +
		            	   " FROM UmdfChannelByEngine o "
		            	   + " WHERE o.engine.engineId = :engineId ";
			
				TypedQuery<Long> typedQuery = getEm().createQuery( query, Long.class );
				typedQuery.setParameter("engineId", engineId);
				
				resultList = typedQuery.getResultList();
				if (resultList!=null && !resultList.isEmpty()) {
					exist = true;
				}
			}			
			
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return exist;		
	}

	public void setEngineInstanceDAO(IEngineInstanceDAO engineInstanceDAO) {
		this.engineInstanceDAO = engineInstanceDAO;
	}

	public void setEngineUmdfChannelDAO(IEngineUmdfChannelDAO engineUmdfChannelDAO) {
		this.engineUmdfChannelDAO = engineUmdfChannelDAO;
	}

	public void setUmdfChannelByEngineAuditDAO(IUmdfChannelByEngineAuditDAO umdfChannelByEngineAuditDAO) {
		this.umdfChannelByEngineAuditDAO = umdfChannelByEngineAuditDAO;
	}

	public void setUser(User user) {
		this.user = user;
	}
}