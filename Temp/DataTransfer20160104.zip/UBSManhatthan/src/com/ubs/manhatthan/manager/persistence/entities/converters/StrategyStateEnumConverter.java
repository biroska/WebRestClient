package com.ubs.manhatthan.manager.persistence.entities.converters;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import com.ubs.manhatthan.manager.enums.StrategyStateEnum;

@Converter(autoApply = true)
public class StrategyStateEnumConverter implements AttributeConverter<StrategyStateEnum, Integer> {

	@Override
	public Integer convertToDatabaseColumn(StrategyStateEnum strategyStateEnum ) {
		return strategyStateEnum.getCode();
	}

	@Override
	public StrategyStateEnum convertToEntityAttribute(Integer dbData) {
		for ( StrategyStateEnum tif : StrategyStateEnum.values() ) {
			if ( tif.getCode().equals(dbData) ) {
				return tif;
			}
		}

		throw new IllegalArgumentException("Unknown database value:" + dbData );
	}
}