package com.ubs.manhatthan.manager.lmdsadapter.marketdata.lmds.handlers;

public interface QuickFixHandler<T extends quickfix.Message> extends Handler<T>
{

}
