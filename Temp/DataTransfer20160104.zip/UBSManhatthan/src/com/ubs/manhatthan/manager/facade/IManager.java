/**
 * 
 */
package com.ubs.manhatthan.manager.facade;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.persistence.entities.StrategyReport;

/**
 * @author galdinoa
 *
 */
public interface IManager {


}
