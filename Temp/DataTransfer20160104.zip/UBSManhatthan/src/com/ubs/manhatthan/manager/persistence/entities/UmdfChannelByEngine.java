package com.ubs.manhatthan.manager.persistence.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name="TB_REL_UMDF_CHANNEL_PER_ENGINE",
uniqueConstraints={
		   @UniqueConstraint(columnNames={"ENGINE_ID", "CHANNEL_ID"}, name = "CK_UMDFCHANNELS_PER_ENGINE" )
		})
public class UmdfChannelByEngine implements Serializable {
	
	public UmdfChannelByEngine(){}

	public UmdfChannelByEngine(EngineInstance engine, EngineUmdfChannel engineUmdfChannel) {
		super();
		this.engine = engine;
		this.engineUmdfChannel = engineUmdfChannel;
	}

	@Id
	@Column ( name = "ID")
	@SequenceGenerator(name = "TB_REL_UMDFCHANNELS_PER_ENGINE_ID_GENERATOR", sequenceName = "SEQ_REL_UMDFCHANNEL_PER_ENGINE", allocationSize = 1)
	@GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "TB_REL_UMDFCHANNELS_PER_ENGINE_ID_GENERATOR" )
	private Long id;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "ENGINE_ID", nullable = false )
	private EngineInstance engine;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "CHANNEL_ID", nullable = false )
	private EngineUmdfChannel engineUmdfChannel;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public EngineInstance getEngine() {
		return engine;
	}

	public void setEngine(EngineInstance engine) {
		this.engine = engine;
	}

	public EngineUmdfChannel getEngineUmdfChannel() {
		return engineUmdfChannel;
	}

	public void setEngineUmdfChannel(EngineUmdfChannel engineUmdfChannel) {
		this.engineUmdfChannel = engineUmdfChannel;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((engine == null) ? 0 : engine.hashCode());
		result = prime
				* result
				+ ((engineUmdfChannel == null) ? 0 : engineUmdfChannel
						.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UmdfChannelByEngine other = (UmdfChannelByEngine) obj;
		if (engine == null) {
			if (other.engine != null)
				return false;
		} else if (!engine.equals(other.engine))
			return false;
		if (engineUmdfChannel == null) {
			if (other.engineUmdfChannel != null)
				return false;
		} else if (!engineUmdfChannel.equals(other.engineUmdfChannel))
			return false;
		return true;
	}
}