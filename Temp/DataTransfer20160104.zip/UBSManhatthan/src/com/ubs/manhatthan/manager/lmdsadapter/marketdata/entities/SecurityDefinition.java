package com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities;

import java.math.BigDecimal;
import java.util.Date;

/**
 * This is the security definition for a given symbol
 * 
 * @author pretof
 *
 */
public interface SecurityDefinition {

	/**
	 * Get the security identification
	 * 
	 * @return Security Identification
	 */
	Security getSecurity();
	
	/**
	 * Round lot
	 * 
	 * @return round lot
	 */
	long getRoundLot();
	
	/**
	 * Minimal price increment for the a price variation
	 * on the instrument
	 * 
	 * @return minimal price increment
	 */
	BigDecimal getMinPriceIncrement();
	
	
	/**
	 * Maturity date of the instrument
	 * 
	 * @return Maturity Date
	 */	
	Date getMaturityDate();
	
	/**
	 * Numbers of business days to the MaturityDate
	 * 
	 * @return BusinessDays Integer
	 */
	Integer getBusinessDays();
	
	/**
	 * Method to define the business days
	 * 
	 * @param businessDays Integer
	 */
	void setBusinessDays(Integer businessDays);
	
	/**
	 * Method to return if the business days was already defined
	 * 
	 * @return is defined boolean
	 */
	boolean isBusinessDaysDefined();
	
}