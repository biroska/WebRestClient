/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.persistence.entities.UmdfChannelByEngine;

/**
 * @author galdinoa
 *
 */
public interface IUmdfChannelByEngineDAO extends IGenericDAO<UmdfChannelByEngine, Long> {

	UmdfChannelByEngine saveUmdfChannelByEngine(UmdfChannelByEngine umdfChannelByEngine) throws DAOExceptionManhattan;

	
}
