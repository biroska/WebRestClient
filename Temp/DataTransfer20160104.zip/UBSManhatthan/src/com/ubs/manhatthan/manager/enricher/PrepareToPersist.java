package com.ubs.manhatthan.manager.enricher;

import java.util.Date;

import org.apache.log4j.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ubs.manhatthan.manager.cache.StrategyCache;
import com.ubs.manhatthan.manager.converters.ConverterToEntity;
import com.ubs.manhatthan.manager.enums.ExecutionTypeEnum;
import com.ubs.manhatthan.manager.facade.Facade;
import com.ubs.manhatthan.manager.logger.ManhattanLogger;
import com.ubs.manhatthan.manager.persistence.entities.LegStrategyReport;
import com.ubs.manhatthan.manager.persistence.entities.OrderFixSession;
import com.ubs.manhatthan.manager.persistence.entities.OrderTrade;
import com.ubs.manhatthan.manager.persistence.entities.StrategyOrders;
import com.ubs.manhatthan.manager.persistence.entities.StrategyReport;
import com.ubs.manhatthan.manager.utils.Util;

@Component
@Scope("singleton")
public class PrepareToPersist implements IPrepareToPersist {
	
	
	@Autowired
	private Facade facade;
	
	@Override
	public StrategyReport saveReport(StrategyReport report) {
		
		try{
			report = facade.saveReport( report );
		
		} catch (Exception e){
			e.printStackTrace();
			
			ManhattanLogger.log( ""+Util.getManagerId(), e.toString(), Level.ERROR, e );
		} 
		
		return report;
	}

	@Override
	public StrategyOrders saveOrder(StrategyOrders order ) {
		
		try {
			StrategyReport strategyReport = StrategyCache.strategyReportMap.get( order.getLegStrategyReport().getId().getStrategyId() );
			
			Integer legSeq = order.getLegStrategyReport().getId().getLegSeq();
			LegStrategyReport legStrategyReport = strategyReport.getLegStrategyList().get( legSeq -1 );
			OrderFixSession route = legStrategyReport.getRouteId();
			
			order.setOrderTimestamp( new Date() );
			order.setRouteId( route );
			order.setOrderType( legStrategyReport.getOrderType() );
			order.setTimeInForce( legStrategyReport.getTimeInForce() );
			order.setAccount( legStrategyReport.getAccount() );
			
			System.out.println( "\n\n\n\n\n" + order );
			
			order = facade.saveOrder( order );
			
	//		If Execution type == TRADE ( 70 or F ) build the OrderTrade entity
			if ( ExecutionTypeEnum.TRADE.getCode().equals( order.getExecutionType().getCode() ) ){
				OrderTrade orderTrade = ConverterToEntity.convertToOrderTrade( order );
				
				facade.saveOrderTrade( orderTrade );
			} 
			
		} catch (Exception e){
			e.printStackTrace();
			
			ManhattanLogger.log( ""+Util.getManagerId(), e.toString(), Level.ERROR, e );
		}
		
		return order;
	}
	
	/* 	REMOVER -- USADO PARA TESTE   */
	@Override
	public StrategyOrders saveOrder(StrategyReport strategyReport, StrategyOrders order ) {
		
		try {
//			StrategyReport strategyReport = StrategyCache.strategyReportMap.get( order.getLegStrategyReport().getId().getStrategyId() );
			
			Integer legSeq = order.getLegStrategyReport().getId().getLegSeq();
			LegStrategyReport legStrategyReport = strategyReport.getLegStrategyList().get( legSeq );
			OrderFixSession route = legStrategyReport.getRouteId();
			
			order.setOrderTimestamp( new Date() );
			order.setRouteId( route );
			order.setOrderType( legStrategyReport.getOrderType() );
			order.setTimeInForce( legStrategyReport.getTimeInForce() );
			order.setAccount( legStrategyReport.getAccount() );
			
			System.out.println( "\n\n\n\n\n" + order );
			
			order = facade.saveOrder( order );
			
			//		If Execution type == TRADE ( 70 or F ) build the OrderTrade entity
			if ( ExecutionTypeEnum.TRADE.getCode().equals( order.getExecutionType().getCode() ) ){
				OrderTrade orderTrade = ConverterToEntity.convertToOrderTrade( order );
				
				facade.saveOrderTrade( orderTrade );
			} 
			
		} catch (Exception e){
			e.printStackTrace();
			
			ManhattanLogger.log( ""+Util.getManagerId(), e.toString(), Level.ERROR, e );
		}
		
		return order;
	}

	public void setFacade(Facade facade) {
		this.facade = facade;
	}
}