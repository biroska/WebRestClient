package com.ubs.manhatthan.manager.simulator.multileg;

import java.util.ArrayList;
import java.util.List;

public class ReturnMultilegSimulation
{
	private boolean onlyTarget;
	private boolean isValid;
	private Double marketTarget;
	private Double targetDif;
	private String availableQuantity;
	private List<ReturnMultilegSimulationItem> returnItens;
	
	public ReturnMultilegSimulation()
	{
		this.marketTarget      = null;
		this.onlyTarget        = false;
		this.targetDif         = null;
		this.returnItens       = new ArrayList<ReturnMultilegSimulationItem>();
		this.isValid           = false;
		this.availableQuantity = null;
	}

	public Double getMarketTarget()
	{
		return marketTarget;
	}
	
	public void setMarketTarget(Double marketTarget)
	{
		this.marketTarget = marketTarget;
	}
	
	public boolean isOnlyTarget()
	{
		return onlyTarget;
	}

	public void setOnlyTarget(boolean onlyTarget)
	{
		this.onlyTarget = onlyTarget;
	}
	
	public Double getTargetDif()
	{
		return targetDif;
	}

	public void setTargetDif(Double targetDif)
	{
		this.targetDif = targetDif;
	}
	
	public List<ReturnMultilegSimulationItem> getReturnItens()
	{
		return returnItens;
	}
	
	public void setReturnItens(List<ReturnMultilegSimulationItem> itens)
	{
		this.returnItens = itens;
	}	

	public boolean isValid()
	{
		return isValid;
	}

	public void setValid(boolean isValid)
	{
		this.isValid = isValid;
	}
	
	public String getAvailableQuantity()
	{
		return availableQuantity;
	}

	public void setAvailableQuantity(String availableQuantity)
	{		
		this.availableQuantity = availableQuantity;
	}

	@Override
	public String toString()
	{
		return "ReturnMultilegSimulation [marketTarget=" + marketTarget
				+ ", onlyTarget=" + onlyTarget
				+ ", targetDif=" + targetDif
				+ ", availableQuantity=" + availableQuantity
				+ ", returnItens=" + returnItens
				+ ", isValid=" + isValid + "]";
	}	
}