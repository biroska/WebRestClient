/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import com.ubs.manhatthan.manager.persistence.entities.audit.TraderWatchTabAudit;


/**
 * @author galdinoa
 *
 */
public interface ITraderWatchTabAuditDAO extends IGenericDAO<TraderWatchTabAudit, Long> {}
