/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import com.ubs.manhatthan.manager.persistence.entities.audit.RecoverySessionByEngineAudit;

/**
 * @author galdinoa
 *
 */
public interface IUmdfRecoverySessionByEngineAuditDAO extends IGenericDAO<RecoverySessionByEngineAudit, Long> {}
