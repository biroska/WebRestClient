/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import com.ubs.manhatthan.manager.persistence.entities.audit.UmdfChannelByEngineAudit;

/**
 * @author galdinoa
 *
 */
public interface IUmdfChannelByEngineAuditDAO extends IGenericDAO<UmdfChannelByEngineAudit, Long> {}
