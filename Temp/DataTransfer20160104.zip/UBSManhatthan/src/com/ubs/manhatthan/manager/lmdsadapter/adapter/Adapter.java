package com.ubs.manhatthan.manager.lmdsadapter.adapter;

import java.util.Properties;

/** 
 * Adapter interface to control
 * 
 * @author pretof
 *
 */
public interface Adapter
{
	void configure(Properties config) throws AdapterConfigurationException;
	
	void start() throws AdapterRuntimeException;
	
	void stop() throws AdapterRuntimeException;
}
