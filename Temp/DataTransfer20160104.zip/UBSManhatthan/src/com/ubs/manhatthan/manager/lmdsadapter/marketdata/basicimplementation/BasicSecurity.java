package com.ubs.manhatthan.manager.lmdsadapter.marketdata.basicimplementation;

import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.Security;

public class BasicSecurity implements Security {
	
	private final String securityID;
	private final String exchange;
	private final String symbol;
	
	public BasicSecurity(String securityID, String exchange, String symbol) {
		super();
		this.securityID = securityID;
		this.exchange = exchange;
		this.symbol = symbol;
	}

	@Override
	public String getSecurityID() {
		return securityID;
	}

	@Override
	public String getExchange() {
		return exchange;
	}

	@Override
	public String getSymbol() {
		return symbol;
	}

}
