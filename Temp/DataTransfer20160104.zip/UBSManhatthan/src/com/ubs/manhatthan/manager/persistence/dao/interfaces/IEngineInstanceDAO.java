/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import java.util.List;

import com.ubs.manhatthan.exception.BussinessExceptionManhattan;
import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.persistence.entities.EngineInstance;


/**
 * @author galdinoa
 *
 */
public interface IEngineInstanceDAO extends IGenericDAO<EngineInstance, Integer> {

	EngineInstance saveEngineInstance(EngineInstance engine) throws DAOExceptionManhattan;
	
	void deleteEngineInstance(EngineInstance engine) throws DAOExceptionManhattan, BussinessExceptionManhattan;

	List<EngineInstance> getEngineByAccount(Long accountId) throws DAOExceptionManhattan;
}
