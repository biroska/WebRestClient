package com.ubs.manhatthan.model;

import java.io.Serializable;

public class Unlegging implements Serializable {

	private static final long serialVersionUID = -7571642659748705670L;
	
	private Long engineId;
	private Long strategyId;
	private Integer legSeq;
	private Long orderId;
	private Integer side;
	private String contract;
	private Long qty;
	private Double price;
	boolean market;
	
	public Unlegging() {}
	
	public Unlegging(Integer side, String contract, Long qty, Double price) {
		
		super();
		
		this.side = side;
		this.contract = contract;
		this.qty = qty;
		this.price = price;
	}
	
	/* Construtor para Mock */
	public Unlegging(Long strategyId, Integer legSeq, Long orderId,
			Integer side, String contract) {
		super();
		this.strategyId = strategyId;
		this.legSeq = legSeq;
		this.orderId = orderId;
		this.side = side;
		this.contract = contract;
	}

	public Unlegging(Long strategyId, Integer legSeq, Long orderId,
			Integer side, String contract, Long qty, Double price) {
		super();
		this.strategyId = strategyId;
		this.legSeq = legSeq;
		this.orderId = orderId;
		this.side = side;
		this.contract = contract;
		this.qty = qty;
		this.price = price;
	}
	
	public Long getStrategyId() {
		return strategyId;
	}

	public void setStrategyId(Long strategyId) {
		this.strategyId = strategyId;
	}

	public Integer getLegSeq() {
		return legSeq;
	}

	public void setLegSeq(Integer legSeq) {
		this.legSeq = legSeq;
	}

	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	public Integer getSide() {
		return side;
	}

	public void setSide(Integer side) {
		this.side = side;
	}

	public String getContract() {
		return contract;
	}

	public void setContract(String contract) {
		this.contract = contract;
	}

	public Long getQty() {
		return qty;
	}

	public void setQty(Long qty) {
		this.qty = qty;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public boolean isMarket() {
		return market;
	}

	public void setMarket(boolean market) {
		this.market = market;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((legSeq == null) ? 0 : legSeq.hashCode());
		result = prime * result + ((orderId == null) ? 0 : orderId.hashCode());
		result = prime * result
				+ ((strategyId == null) ? 0 : strategyId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Unlegging other = (Unlegging) obj;
		if (legSeq == null) {
			if (other.legSeq != null)
				return false;
		} else if (!legSeq.equals(other.legSeq))
			return false;
		if (orderId == null) {
			if (other.orderId != null)
				return false;
		} else if (!orderId.equals(other.orderId))
			return false;
		if (strategyId == null) {
			if (other.strategyId != null)
				return false;
		} else if (!strategyId.equals(other.strategyId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Unlegging [engineId=" + engineId + ", strategyId=" + strategyId + ", legSeq=" + legSeq + ", orderId=" + orderId + ", side=" + side
				+ ", contract=" + contract + ", qty=" + qty + ", price=" + price + ", market=" + market + "]";
	}

	public Long getEngineId() {
		return engineId;
	}

	public void setEngineId(Long engineId) {
		this.engineId = engineId;
	}
}