package com.ubs.manhatthan.model;

import java.io.Serializable;
import java.util.List;

public class StrategyByTab implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7976540110461653384L;

	public StrategyByTab(){}
	
	public StrategyByTab(MarketWhatchTab tab, StrategyType strategyType, Integer instrument) {
		super();
		this.tab = tab;
		this.strategyType = strategyType;
		this.instrument = instrument;
	}

	private Long id;
	
	private MarketWhatchTab tab;
	
	private StrategyType strategyType;
	
	private Integer instrument;
	
	private List<StrategyByTabLeg> strategyByTabLegs;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public MarketWhatchTab getTab() {
		return tab;
	}

	public void setTab(MarketWhatchTab tab) {
		this.tab = tab;
	}

	public StrategyType getStrategyType() {
		return strategyType;
	}

	public void setStrategyType(StrategyType strategyType) {
		this.strategyType = strategyType;
	}

	public Integer getInstrument() {
		return instrument;
	}

	public void setInstrument(Integer instrument) {
		this.instrument = instrument;
	}

	public List<StrategyByTabLeg> getStrategyByTabLegs() {
		return strategyByTabLegs;
	}

	public void setStrategyByTabLegs(List<StrategyByTabLeg> strategyByTabLegs) {
		this.strategyByTabLegs = strategyByTabLegs;
	}
}