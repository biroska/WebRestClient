package com.ubs.manhatthan.service;

import java.util.List;

import org.springframework.beans.BeansException;

import com.ubs.manhatthan.exception.BussinessExceptionManhattan;
import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.enums.MessageTypeEnum;
import com.ubs.manhatthan.manager.persistence.entities.StrategyReport;
import com.ubs.manhatthan.model.Account;
import com.ubs.manhatthan.model.LegStrategyReport;

public interface ManagerFacade {

	public Account findAccountById(Long id) throws DAOExceptionManhattan;

	public List<Account> findListAccountByName(String name) throws DAOExceptionManhattan;

	public StrategyReport convertStrategyReportToEntity(com.ubs.manhatthan.model.StrategyReport strategyReport) throws DAOExceptionManhattan, BussinessExceptionManhattan;

	public void createStrategyReport(com.ubs.manhatthan.model.StrategyReport strategyReport) throws DAOExceptionManhattan, BussinessExceptionManhattan;

	public com.ubs.manhatthan.model.StrategyReport calculateValuesStrategyReport(com.ubs.manhatthan.model.StrategyReport strategyReport, boolean isOnlyTarget) throws DAOExceptionManhattan, BussinessExceptionManhattan;

	public com.ubs.manhatthan.model.StrategyReport convertStrategyReportToModel(StrategyReport strategyReportEntity) throws BeansException, DAOExceptionManhattan;

	public void updateStrategyReport(com.ubs.manhatthan.model.StrategyReport strategyReport, MessageTypeEnum messageTypeEnum) throws DAOExceptionManhattan, BussinessExceptionManhattan;

	public void updateActionsStrategyReport(com.ubs.manhatthan.model.StrategyReport strategyReport, MessageTypeEnum messageTypeEnum) throws DAOExceptionManhattan, BussinessExceptionManhattan;

	public void sendOTC(com.ubs.manhatthan.model.StrategyReport strategyReport, LegStrategyReport legStrategyReport) throws DAOExceptionManhattan, BussinessExceptionManhattan;

	public void sendUnlegged(com.ubs.manhatthan.model.Unlegging unlegging) throws DAOExceptionManhattan, BussinessExceptionManhattan;
}
