package com.ubs.manhatthan.service;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Level;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.exception.BussinessExceptionManhattan;
import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.exception.EngineExceptionManhattan;
import com.ubs.manhatthan.exception.MessageExceptionManhattan;
import com.ubs.manhatthan.manager.cache.CacheHelper;
import com.ubs.manhatthan.manager.cache.LmdsCache;
import com.ubs.manhatthan.manager.enums.MessageTypeEnum;
import com.ubs.manhatthan.manager.enums.OrderTypeEnum;
import com.ubs.manhatthan.manager.enums.SideEnum;
import com.ubs.manhatthan.manager.enums.TimeInForceEnum;
import com.ubs.manhatthan.manager.facade.Facade;
import com.ubs.manhatthan.manager.facade.FacadeService;
import com.ubs.manhatthan.manager.logger.ManhattanLogger;
import com.ubs.manhatthan.manager.persistence.entities.ClientAccount;
import com.ubs.manhatthan.manager.persistence.entities.Header;
import com.ubs.manhatthan.manager.persistence.entities.OrderFixSession;
import com.ubs.manhatthan.manager.persistence.entities.StrategyOrders;
import com.ubs.manhatthan.manager.persistence.entities.StrategyReport;
import com.ubs.manhatthan.manager.persistence.entities.StrategyType;
import com.ubs.manhatthan.manager.persistence.entities.id.StrategyOrdersPK;
import com.ubs.manhatthan.manager.persistence.entities.id.StrategyReportPK;
import com.ubs.manhatthan.manager.utils.Util;
import com.ubs.manhatthan.model.Account;
import com.ubs.manhatthan.model.LegStrategyReport;

@Service
@Scope("singleton")
public class ManagerFacadeImpl implements ManagerFacade, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3731932450994430008L;

	@Autowired
	private Facade facade;

	@Autowired
	private FacadeService facadeService;

	@Autowired
	private User user;

	@Override
	public Account findAccountById(Long id) throws DAOExceptionManhattan {
		Account a = new Account();
		ClientAccount ca = facade.findClientAccountByCode(id);
		if (null != ca) {
			BeanUtils.copyProperties(ca, a);
		}
		return a;
	}

	@Override
	public List<Account> findListAccountByName(String name) throws DAOExceptionManhattan {

		List<Account> accounts = null;

		ClientAccount searchClientAccount = new ClientAccount();

		searchClientAccount.setDescription("%" + name + "%");

		List<ClientAccount> clientAccounts = new ArrayList<ClientAccount>();
		clientAccounts = facade.FindClientAccount(searchClientAccount);
		if (!clientAccounts.isEmpty()) {
			accounts = new ArrayList<Account>();
			for (ClientAccount ca : clientAccounts) {
				Account a = new Account();
				BeanUtils.copyProperties(ca, a);
				accounts.add(a);
			}

		}

		return accounts;
	}

	@Override
	public void createStrategyReport(com.ubs.manhatthan.model.StrategyReport strategyReport) throws DAOExceptionManhattan, BussinessExceptionManhattan {
		StrategyReport entity = convertStrategyReportToEntity(strategyReport);
		Header header = new Header(MessageTypeEnum.CREATE_STRATEGY);
		entity.setHeader(header);
		try {
			facadeService.sendToEngine(entity);
		} catch (EngineExceptionManhattan e) {		
			ManhattanLogger.log(Util.getManagerId().toString(), e.getMessage(), Level.ERROR);
			
			throw new BussinessExceptionManhattan("Error on connect to Engine");
		} catch (MessageExceptionManhattan e) {
			ManhattanLogger.log(Util.getManagerId().toString(), e.getMessage(), Level.ERROR);
			
			throw new BussinessExceptionManhattan("Error on connect to Engine");
		} catch (IOException e) {
			ManhattanLogger.log(Util.getManagerId().toString(), e.getMessage(), Level.ERROR);
			
			throw new BussinessExceptionManhattan("Error on connect to Engine");
		}
	}

	@Override
	public void updateStrategyReport(com.ubs.manhatthan.model.StrategyReport strategyReport, MessageTypeEnum messageTypeEnum)
			throws BussinessExceptionManhattan, DAOExceptionManhattan, BussinessExceptionManhattan {
		StrategyReport entity = convertStrategyReportToEntity(strategyReport);
		Header header = new Header(messageTypeEnum);
		header.setEngineInstanceId(entity.getId().getEngineId());
		entity.setHeader(header);
		entity.setLogin(user.getLogin());
		try {
			facadeService.sendToEngine(entity);
		} catch (EngineExceptionManhattan e) {

			ManhattanLogger.log(Util.getManagerId().toString(), e.getMessage(), Level.ERROR);
		} catch (MessageExceptionManhattan e) {

			ManhattanLogger.log(Util.getManagerId().toString(), e.getMessage(), Level.ERROR);
		} catch (IOException e) {

			ManhattanLogger.log(Util.getManagerId().toString(), e.getMessage(), Level.ERROR);
		}
	}

	@Override
	public void updateActionsStrategyReport(com.ubs.manhatthan.model.StrategyReport strategyReport, MessageTypeEnum messageTypeEnum)
			throws BussinessExceptionManhattan, DAOExceptionManhattan {
		StrategyReport entity = convertStrategyReportToEntityResume(strategyReport);
		Header header = new Header(messageTypeEnum);
		header.setEngineInstanceId(entity.getId().getEngineId());
		entity.setHeader(header);
		entity.setLogin(user.getLogin());
		try {
			facadeService.sendToEngine(entity);
		} catch (EngineExceptionManhattan e) {

			ManhattanLogger.log(Util.getManagerId().toString(), e.getMessage(), Level.ERROR);
		} catch (MessageExceptionManhattan e) {

			ManhattanLogger.log(Util.getManagerId().toString(), e.getMessage(), Level.ERROR);
		} catch (IOException e) {

			ManhattanLogger.log(Util.getManagerId().toString(), e.getMessage(), Level.ERROR);
		}
	}

	@Override
	public void sendOTC(com.ubs.manhatthan.model.StrategyReport strategyReport, com.ubs.manhatthan.model.LegStrategyReport legStrategyReport) throws DAOExceptionManhattan, BussinessExceptionManhattan {
		
		if (strategyReport == null) {
			ManhattanLogger.log(Util.getManagerId().toString(), "Error on send otc order. StrategyReport is null", Level.ERROR);

			throw new BussinessExceptionManhattan("Error on send OTC. Strategy Report is null");
		}
		
		if (legStrategyReport == null) {
			ManhattanLogger.log(Util.getManagerId().toString(), "Error on send otc order. LegStrategyReport is null", Level.ERROR);

			throw new BussinessExceptionManhattan("Error on send OTC. Leg Strategy Report is null");
		}
		
		StrategyOrders entityOrder = convertStrategyOrdersResume(legStrategyReport);

		Header header = new Header(MessageTypeEnum.REPORT_EXECUTION_ORDER);
		header.setEngineInstanceId(strategyReport.getEngineId());
		entityOrder.setHeader(header);
		try {
			facadeService.sendToEngine(entityOrder);
		} catch (EngineExceptionManhattan e) {
			ManhattanLogger.log(Util.getManagerId().toString(), e.getMessage(), Level.ERROR);

			throw new BussinessExceptionManhattan("Error on send OTC - EngineExceptionManhattan (" + e.getMessage() + ").");
		} catch (MessageExceptionManhattan e) {
			ManhattanLogger.log(Util.getManagerId().toString(), e.getMessage(), Level.ERROR);

			throw new BussinessExceptionManhattan("Error on send OTC - MessageExceptionManhattan (" + e.getMessage() + ").");
		} catch (IOException e) {
			ManhattanLogger.log(Util.getManagerId().toString(), e.getMessage(), Level.ERROR);

			throw new BussinessExceptionManhattan("Error on send OTC - IOException.");
		}
	}

	@Override
	public void sendUnlegged(com.ubs.manhatthan.model.Unlegging unlegging) throws DAOExceptionManhattan, BussinessExceptionManhattan {

		
		if (unlegging == null) {
			ManhattanLogger.log(Util.getManagerId().toString(), "Error on send unlegged order. Unlegging is null", Level.ERROR);

			throw new BussinessExceptionManhattan("Error on send unlegged order. Unlegging is null");
		}

		StrategyOrders entityOrder = convertStrategyLeggedOrder(unlegging);

		Header header = new Header(MessageTypeEnum.LEGGED_ORDER);
		header.setEngineInstanceId(unlegging.getEngineId());
		entityOrder.setHeader(header);
		
		try {
			facadeService.sendToEngine(entityOrder);
		} catch (EngineExceptionManhattan e) {
			ManhattanLogger.log(Util.getManagerId().toString(), e.getMessage(), Level.ERROR);

			throw new BussinessExceptionManhattan("Error on send unlegged order - EngineExceptionManhattan.");
		} catch (MessageExceptionManhattan e) {
			ManhattanLogger.log(Util.getManagerId().toString(), e.getMessage(), Level.ERROR);

			throw new BussinessExceptionManhattan("Error on send unlegged order - MessageExceptionManhattan.");
		} catch (IOException e) {
			ManhattanLogger.log(Util.getManagerId().toString(), e.getMessage(), Level.ERROR);

			throw new BussinessExceptionManhattan("Error on send unlegged order - IOException.");
		}
	}

	@Override
	public com.ubs.manhatthan.model.StrategyReport calculateValuesStrategyReport(com.ubs.manhatthan.model.StrategyReport strategyReport, boolean isOnlyTarget) throws DAOExceptionManhattan, BussinessExceptionManhattan {
		
		com.ubs.manhatthan.model.StrategyReport strategyReportResult = facadeService.calculate(strategyReport, isOnlyTarget);
		
		if (strategyReportResult == null) {
			throw new BussinessExceptionManhattan("Error on strategy data calculate");
		}
		
		return strategyReportResult;
	}

	private StrategyOrders convertStrategyOrdersResume(com.ubs.manhatthan.model.LegStrategyReport legStrategyReport) throws DAOExceptionManhattan {
		StrategyOrders entity = new StrategyOrders();
		// PK Populate
		StrategyOrdersPK pk = new StrategyOrdersPK();
		pk.setEngineId(legStrategyReport.getEngineId() == null ? null : legStrategyReport.getEngineId());
		pk.setOrderDate(new Date());
		entity.setId(pk);
		entity.setSymbol(legStrategyReport.getContract());
		entity.setStrategyId(legStrategyReport.getStrategyId());
		entity.setLegSeq(legStrategyReport.getLegSeq());
		entity.setLastPrice(legStrategyReport.getOtcPrice());
		entity.setLastQuantity(legStrategyReport.getOtcQuantity());
		entity.setLegStrategyReport(new com.ubs.manhatthan.manager.persistence.entities.LegStrategyReport());
		entity.setSide(SideEnum.fromValue(legStrategyReport.getSide()));
		BeanUtils.copyProperties(legStrategyReport, entity.getLegStrategyReport());
		return entity;
	}
	
	private StrategyOrders convertStrategyLeggedOrder(com.ubs.manhatthan.model.Unlegging legged ) throws DAOExceptionManhattan {
		
		StrategyOrders entity = new StrategyOrders();
		// PK Populate
		StrategyOrdersPK pk = new StrategyOrdersPK();
		pk.setEngineId( legged.getEngineId() == null ? null : legged.getEngineId() );
		pk.setOrderDate(new Date());
		entity.setId(pk);
		
		entity.setStrategyId( legged.getStrategyId() );
		entity.setLegSeq( legged.getLegSeq() );
		entity.setMarket( legged.isMarket() );
		entity.setPrice( legged.getPrice() );
		entity.setQuantity( legged.getQty() );
		
		com.ubs.manhatthan.manager.persistence.entities.LegStrategyReport leg = new com.ubs.manhatthan.manager.persistence.entities.LegStrategyReport();
		leg.getId().setStrategyId( legged.getStrategyId() );
		leg.getId().setLegSeq( legged.getLegSeq() );
		
		entity.setLegStrategyReport( leg );
		
		return entity;
	}

	private StrategyReport convertStrategyReportToEntityResume(com.ubs.manhatthan.model.StrategyReport strategyReport) throws DAOExceptionManhattan {
		StrategyReport entity = new StrategyReport();
		// PK Populate
		StrategyReportPK pk = new StrategyReportPK();
		pk.setEngineId(strategyReport.getEngineId() == null ? null : strategyReport.getEngineId());
		pk.setStrategyId(strategyReport.getStrategyId() == null ? null : strategyReport.getStrategyId());
		entity.setId(pk);
		return entity;
	}

	@Override
	public StrategyReport convertStrategyReportToEntity(com.ubs.manhatthan.model.StrategyReport strategyReport) throws BussinessExceptionManhattan,
			DAOExceptionManhattan {
		OrderFixSession orderFixByAccount = null;

		StrategyReport entity = new StrategyReport();

		BeanUtils.copyProperties(strategyReport, entity);

		// PK Populate
		StrategyReportPK pk = new StrategyReportPK();
		pk.setEngineId(strategyReport.getEngineId() == null ? null : strategyReport.getEngineId());
		pk.setStrategyId(strategyReport.getStrategyId() == null ? null : strategyReport.getStrategyId());
		entity.setId(pk);
		// init objetcs
		entity.setLegStrategyList(new ArrayList<com.ubs.manhatthan.manager.persistence.entities.LegStrategyReport>());
		entity.setStrategyType(new StrategyType());

		BeanUtils.copyProperties(strategyReport.getStrategyType(), entity.getStrategyType());

		entity.setStartTime(new Date(Util.dateToMicroSegundos(strategyReport.getStartTimeText())));
		entity.setEndTime(new Date(Util.dateToMicroSegundos(strategyReport.getEndTimeText())));
		entity.setLogin(user.getLogin());

		for (LegStrategyReport legStrategyReport : strategyReport.getLegStrategyList()) {
			
			Long instrument = LmdsCache.getLmdsInstrumentFromContract(legStrategyReport.getContract());
			
			if (instrument == null) {
				throw new BussinessExceptionManhattan("Strategy Create Operation Canceled  - Instrument not found in LMDS");
			}
			
			legStrategyReport.setInstrument(instrument);
			
			com.ubs.manhatthan.manager.persistence.entities.LegStrategyReport entityLegStrReport = new com.ubs.manhatthan.manager.persistence.entities.LegStrategyReport();

			orderFixByAccount = facade.getOrderFixByAccount(legStrategyReport.getAccount().getCode());

			if (null == orderFixByAccount) {
				throw new BussinessExceptionManhattan("Strategy Create Operation Canceled  - Order Per Account not found");
			}

			String trader = CacheHelper.getTrader(entity.getLogin()).getEnteringTrader();

			if (trader == null) {
				throw new BussinessExceptionManhattan("Strategy Create Operation Canceled - Entering Trader not found");
			}

			BeanUtils.copyProperties(legStrategyReport, entityLegStrReport);
			entityLegStrReport.setAccount(new ClientAccount());
			BeanUtils.copyProperties(legStrategyReport.getAccount(), entityLegStrReport.getAccount());
			entityLegStrReport.getId().setLegSeq(legStrategyReport.getLegSeq());
			entityLegStrReport.setSide(SideEnum.fromValue(legStrategyReport.getSide()));
			// Campos a validar
			entityLegStrReport.setRouteId(orderFixByAccount);
			entityLegStrReport.setOrderType(OrderTypeEnum.LIMIT);// Default
			entityLegStrReport.setTimeInForce(TimeInForceEnum.DAY);// Default
			entityLegStrReport.setTimeOut(2L);//
			entityLegStrReport.setInvestorId(null);// Use Future
			entityLegStrReport.setEnteringTrader(trader);// Bug find
			entityLegStrReport.setMaxQuantityDisplay( legStrategyReport.getClip() ); // Clip - bug find
			entity.addLegStrategyReport(entityLegStrReport);//
		}

		return entity;
	}

	@Override
	public com.ubs.manhatthan.model.StrategyReport convertStrategyReportToModel(StrategyReport strategyReportEntity) throws BeansException,
			DAOExceptionManhattan {
		com.ubs.manhatthan.model.StrategyReport strategyReportModel = null;

		if (strategyReportEntity != null) {
			strategyReportModel = new com.ubs.manhatthan.model.StrategyReport();

			BeanUtils.copyProperties(strategyReportEntity, strategyReportModel);

			strategyReportModel.setStrategyTimestamp(strategyReportEntity.getId().getStrategyDate());
			strategyReportModel.setStrategyId(strategyReportEntity.getId().getStrategyId());
			strategyReportModel.setEngineId(strategyReportEntity.getId().getEngineId());
			strategyReportModel.setStatus(strategyReportEntity.getStrategyState().getCode());
			strategyReportModel.setStrategyType(new com.ubs.manhatthan.model.StrategyType());
			BeanUtils.copyProperties(strategyReportEntity.getStrategyType(), strategyReportModel.getStrategyType());

			strategyReportModel.getStrategyType().setStrategyTypeLegList(new ArrayList<com.ubs.manhatthan.model.StrategyTypeLeg>());
			BeanUtils.copyProperties(strategyReportEntity.getStrategyType().getStrategyTypeLegList(), strategyReportModel.getStrategyType()
					.getStrategyTypeLegList());

			strategyReportModel.setLegStrategyList(new ArrayList<com.ubs.manhatthan.model.LegStrategyReport>());
			strategyReportModel.setStartTimeText(strategyReportEntity.getStartTime());
			strategyReportModel.setEndTimeText(strategyReportEntity.getEndTime());
			for (com.ubs.manhatthan.manager.persistence.entities.LegStrategyReport legStrategyReportEntity : strategyReportEntity.getLegStrategyList()) {								
				
				com.ubs.manhatthan.model.LegStrategyReport legStrategyReportModel = new com.ubs.manhatthan.model.LegStrategyReport();
				
				legStrategyReportModel.setContract(LmdsCache.getLmdsContractFromInstrument(legStrategyReportModel.getInstrument()));
				
				BeanUtils.copyProperties(legStrategyReportEntity, legStrategyReportModel);

				legStrategyReportModel.setAccount(new com.ubs.manhatthan.model.Account());
				BeanUtils.copyProperties(facade.findClientAccountByCode(legStrategyReportEntity.getAccount().getCode()), legStrategyReportModel.getAccount());

				legStrategyReportModel.setEngineId(strategyReportEntity.getId().getEngineId());
				legStrategyReportModel.setStrategyId(strategyReportEntity.getId().getStrategyId());
				legStrategyReportModel.setLegSeq(legStrategyReportEntity.getId().getLegSeq());

				legStrategyReportModel.setSide(legStrategyReportEntity.getSide().getCode());

				legStrategyReportModel.setStrategyReport(strategyReportModel);

				strategyReportModel.getLegStrategyList().add(legStrategyReportModel);
			}
		}

		return strategyReportModel;
	}	
}