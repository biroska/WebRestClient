/**
 * 
 */
package com.ubs.manhatthan.exception;

/**
 * @author galdinoa
 *
 */
public class MessageExceptionManhattan extends Exception {

	private static final long serialVersionUID = -2447454268260087242L;

	public MessageExceptionManhattan(){}
	
	public MessageExceptionManhattan( String message ){
		super( message );
	}
	
	public MessageExceptionManhattan( Throwable cause ){
		super( cause );
	}
	
	public MessageExceptionManhattan( String message, Throwable cause ){
		super( message, cause );
	}
	
	public MessageExceptionManhattan( String message, Throwable cause, 
			                      boolean enableSuppression, boolean writableStackTrace ){
		super( message, cause, enableSuppression, writableStackTrace );
	}
}
