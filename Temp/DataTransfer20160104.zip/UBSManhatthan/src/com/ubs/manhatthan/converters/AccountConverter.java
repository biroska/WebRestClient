package com.ubs.manhatthan.converters;



import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ubs.manhatthan.model.Account;
import com.ubs.manhatthan.service.ManagerFacade;

@Component(value = "accountConverter")
public class AccountConverter implements Converter {

	@Autowired
	protected ManagerFacade facade;

	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		Account c = null;

		try {
			c = facade.findAccountById(new Long(value));
		} catch (Exception ex) {

		}

		return c;
	}

	public String getAsString(FacesContext context, UIComponent component, Object object) {
		if (object != null) {
			String accountDisplayText = ((Account) object).getCode().toString();
			
			return accountDisplayText;
		} else {
			return null;
		}
	}
}