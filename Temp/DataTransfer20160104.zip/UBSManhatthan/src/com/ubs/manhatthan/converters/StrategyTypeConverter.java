package com.ubs.manhatthan.converters;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.model.StrategyType;
import com.ubs.manhatthan.service.MarketWatchFacade;

@Component(value="strategyTypeConverter")
public class StrategyTypeConverter implements Converter {

	@Autowired
	MarketWatchFacade marketWatchFacade;	
	
	

	@Override
    public Object getAsObject(FacesContext context, UIComponent component, String value) {
		StrategyType c = null;
		try {
			c = marketWatchFacade.getStrategyVOById(value);
		} catch (DAOExceptionManhattan e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return c;
    }

    @Override
    public String getAsString(FacesContext context, UIComponent component, Object value) {
    	if (value != null) {
    		return String.valueOf(((com.ubs.manhatthan.model.StrategyType) value).getId());
    	} else {
    		return null;    	
    	}
    }

	public void setMarketWatchFacade(MarketWatchFacade marketWatchFacade) {
		this.marketWatchFacade = marketWatchFacade;
	}
}