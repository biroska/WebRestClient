package com.ubs.manhatthan.converters;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import com.ubs.manhatthan.common.enuns.StrategyStatusEnum;


@FacesConverter(value="strategyStateEnumConverter")
public class StrategyStateEnumConverter implements Converter {
    
    @Override  
    public Object getAsObject(FacesContext context, UIComponent component, String value) {  
        if (value != null) {  
            return StrategyStatusEnum.valueOf(value);  
        }  
  
        return null;  
    }  
  
    @Override  
    public String getAsString(FacesContext context, UIComponent component, Object value) {  
        if (value != null) {
        	for (StrategyStatusEnum e : StrategyStatusEnum.values()) {
        		if (Integer.valueOf(value.toString()) == Integer.valueOf(e.getCode())) {
                    return e.getDescription();
				}
			}
        }  
        return null;  
    }  

}