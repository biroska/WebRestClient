package com.ubs.manhatthan.helper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeansException;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.cache.LmdsCache;
import com.ubs.manhatthan.manager.lmdsadapter.SimulationItem;
import com.ubs.manhatthan.manager.persistence.entities.StrategyOrders;
import com.ubs.manhatthan.manager.persistence.entities.StrategyReport;
import com.ubs.manhatthan.manager.utils.Util;
import com.ubs.manhatthan.model.Account;
import com.ubs.manhatthan.model.LegStrategyReport;
import com.ubs.manhatthan.model.Market;

public class PushHelper {
        
	public static boolean checkSimulationItemForUpdateData(Market market, SimulationItem simulationItem) {
    	    	
    	boolean simulationItemNeededUpdateData = false;
    	
    	if (market.getBp() == null & market.getBq() == null 
    			& market.getSq() == null & market.getLp() == null & market.getLq() == null) {
    		simulationItemNeededUpdateData = true;
		}else {
			simulationItemNeededUpdateData = market.getBp().equals(
				simulationItem.getBuyPx().toString())
				&& market.getBq().equals(simulationItem.getBuyQty())
				&& market.getSp().equals(simulationItem.getSellPx().toString())
				&& market.getSq().equals(simulationItem.getSellQty())
				&& market.getLp().equals(simulationItem.getLastPx().toString())
				&& market.getLq().equals(simulationItem.getLastQty().toString());
		}
			
		return simulationItemNeededUpdateData;
    }
    
    public static boolean checkStrategyForUpdateData(List<com.ubs.manhatthan.model.StrategyReport> strategiesReportInSession, LegStrategyReport legStrategyReportModel) {
    	boolean strategyNeededUpdateData = false;

    	for (com.ubs.manhatthan.model.StrategyReport strategyReportModelInSession: strategiesReportInSession) {
			List<LegStrategyReport> legsStrategyReportModelInSession = strategyReportModelInSession.getLegStrategyList();
			
			for (LegStrategyReport legStrategyReportModelInSession: legsStrategyReportModelInSession) {
				
				strategyNeededUpdateData = (legStrategyReportModelInSession.equals(legStrategyReportModel));
				
				if (strategyNeededUpdateData) break;
			}   	

			if (strategyNeededUpdateData) break;
    	}
   	
    	return !strategyNeededUpdateData;
    }

    public static com.ubs.manhatthan.model.StrategyReport convertStrategyReportToModel(StrategyReport strategyReportEntity) throws BeansException, DAOExceptionManhattan {

		com.ubs.manhatthan.model.StrategyReport strategyReportModel = null;

		
		
		if (strategyReportEntity != null) {
			strategyReportModel = new com.ubs.manhatthan.model.StrategyReport();
		
			BeanUtils.copyProperties(strategyReportEntity, strategyReportModel);
			
			strategyReportModel.setStrategyTimestamp(strategyReportEntity.getId().getStrategyDate());
			strategyReportModel.setStrategyId(strategyReportEntity.getId().getStrategyId());
			strategyReportModel.setEngineId(strategyReportEntity.getId().getEngineId());
			strategyReportModel.setStatus(strategyReportEntity.getStrategyState()==null?0:strategyReportEntity.getStrategyState().getCode());
			strategyReportModel.setStrategyType(new com.ubs.manhatthan.model.StrategyType());
			BeanUtils.copyProperties(strategyReportEntity.getStrategyType(), strategyReportModel.getStrategyType());
					
			strategyReportModel.getStrategyType().setStart(Util.convertDatePattern(strategyReportEntity.getStartTime(), "HH:mm"));
			strategyReportModel.getStrategyType().setEnd(Util.convertDatePattern(strategyReportEntity.getEndTime(), "HH:mm"));
						
			strategyReportModel.getStrategyType().setStrategyTypeLegList(new ArrayList<com.ubs.manhatthan.model.StrategyTypeLeg>());
			BeanUtils.copyProperties(strategyReportEntity.getStrategyType().getStrategyTypeLegList(), strategyReportModel.getStrategyType()
					.getStrategyTypeLegList());

			
//			strategyReportModel.setTargetDif( strategyReportEntity.get );
//			strategyReportModel.setMarket( strategyReportEntity.get );
			strategyReportModel.setStartPaused( strategyReportEntity.getStartPaused() );
			strategyReportModel.setRiskLevel( strategyReportEntity.getRiskLevel() );
			strategyReportModel.setRestingLevel( strategyReportEntity.getRestingLevel() );
			
			strategyReportModel.setStartTimeText(strategyReportEntity.getStartTime());
			strategyReportModel.setEndTimeText(strategyReportEntity.getEndTime());
			
			strategyReportModel.setLegStrategyList(new ArrayList<com.ubs.manhatthan.model.LegStrategyReport>());
			for (com.ubs.manhatthan.manager.persistence.entities.LegStrategyReport legStrategyReportEntity : strategyReportEntity.getLegStrategyList()) {
			
				com.ubs.manhatthan.model.LegStrategyReport legStrategyReportModel = convertLegStrategyReportEntityToReportModel(legStrategyReportEntity);
								
				legStrategyReportModel.setStrategyReport(strategyReportModel);
			
				strategyReportModel.getLegStrategyList().add(legStrategyReportModel);
			} 
		}
		
		return strategyReportModel;
	}
    
    public static com.ubs.manhatthan.model.LegStrategyReport convertLegStrategyReportEntityToReportModel(com.ubs.manhatthan.manager.persistence.entities.LegStrategyReport legStrategyReportEntity) throws BeansException, DAOExceptionManhattan {
    	com.ubs.manhatthan.model.LegStrategyReport legStrategyReportModel = null;
    	
    	if (legStrategyReportEntity != null) {
    		legStrategyReportModel = new com.ubs.manhatthan.model.LegStrategyReport();
    	
    		legStrategyReportModel.setEngineId(legStrategyReportEntity.getId().getEngineId());
    		legStrategyReportModel.setStrategyId(legStrategyReportEntity.getId().getStrategyId());
    		legStrategyReportModel.setLegSeq(legStrategyReportEntity.getId().getLegSeq());

    		com.ubs.manhatthan.model.StrategyReport strategyReportModel = new com.ubs.manhatthan.model.StrategyReport();
    		BeanUtils.copyProperties(legStrategyReportEntity.getStrategyReport(), strategyReportModel);
    		legStrategyReportModel.setStrategyReport(strategyReportModel);
    		
    		legStrategyReportModel.setSide(legStrategyReportEntity.getSide().getCode());
    		legStrategyReportModel.setTotalQuantity(legStrategyReportEntity.getTotalQuantity());
    		legStrategyReportModel.setExecutedQuantity(legStrategyReportEntity.getExecutedQuantity());
    		legStrategyReportModel.setRemainingQuantity(legStrategyReportEntity.getRemainingQuantity());
    		legStrategyReportModel.setText(legStrategyReportEntity.getText());
    		
    		legStrategyReportModel.setAveragePrice(legStrategyReportEntity.getAveragePrice());
    		legStrategyReportModel.setRestingQuantity(legStrategyReportEntity.getRestingQuantity());
    		legStrategyReportModel.setRestingPrice(legStrategyReportEntity.getRestingPrice());
    		legStrategyReportModel.setDuration(legStrategyReportEntity.getDuration());
    		legStrategyReportModel.setMaxQuantityDisplay(legStrategyReportEntity.getMaxQuantityDisplay());
    		legStrategyReportModel.setMinQuantityDisplay(legStrategyReportEntity.getMinQuantityDisplay());
    		legStrategyReportModel.setTimeInForce(legStrategyReportEntity.getTimeInForce());
    		legStrategyReportModel.setTimeOut(legStrategyReportEntity.getTimeOut());
    		legStrategyReportModel.setExecutedPercentage(legStrategyReportEntity.getExecutedPercentage());
    		legStrategyReportModel.setEnteringTrader(legStrategyReportEntity.getEnteringTrader());
    		legStrategyReportModel.setInvestorId(legStrategyReportEntity.getInvestorId());
    		legStrategyReportModel.setDuration(legStrategyReportEntity.getDuration());
    		legStrategyReportModel.setContract(LmdsCache.getLmdsContractFromInstrument(legStrategyReportEntity.getInstrument()));
    		legStrategyReportModel.setPassiveLeg(legStrategyReportEntity.getPassiveLeg());
    		legStrategyReportModel.setLeggedPrice(legStrategyReportEntity.getRestingPrice()); //Confirmar
    		
    		legStrategyReportModel.setClip( legStrategyReportEntity.getMaxQuantityDisplay() );
    		
    		Account account = new Account();
    		BeanUtils.copyProperties(legStrategyReportEntity.getAccount(), account);    		
    		legStrategyReportModel.setAccount(account);    		    		
    	}
    	
    	return legStrategyReportModel;
    }
    
    public static com.ubs.manhatthan.model.Unlegging convertStrategyOrderToUnleggingModel(StrategyOrders strategyOrderEntity) throws BeansException, DAOExceptionManhattan {
    	
    	com.ubs.manhatthan.model.Unlegging unleggingModel = null;
    	
    	if (strategyOrderEntity != null) {
    		unleggingModel = new com.ubs.manhatthan.model.Unlegging();
    		
    		unleggingModel.setStrategyId(strategyOrderEntity.getStrategyId());
    		unleggingModel.setLegSeq(strategyOrderEntity.getLegSeq());
    		unleggingModel.setOrderId(strategyOrderEntity.getId().getOrderId());
    		unleggingModel.setPrice(strategyOrderEntity.getPrice());
    		unleggingModel.setQty(strategyOrderEntity.getQuantity());
    		unleggingModel.setContract(strategyOrderEntity.getSymbol());
    		unleggingModel.setSide(strategyOrderEntity.getSide().getCode());
    		
    		if (strategyOrderEntity.getId()!=null) {
    			unleggingModel.setEngineId(strategyOrderEntity.getId().getEngineId());
			}
    		//unleggingModel.setMarket(strategyOrderEntity.getLegStrategyReport().);
    	}
    	
    	return unleggingModel;
    }
        
    public static com.ubs.manhatthan.model.LegStrategyReport convertStrategyOrderEntityToLegModel(StrategyOrders strategyOrderEntity) throws BeansException, DAOExceptionManhattan {
    	
    	com.ubs.manhatthan.model.LegStrategyReport legStrategyReportModel = null;
    	
    	if (strategyOrderEntity != null) {    		
    		legStrategyReportModel = new com.ubs.manhatthan.model.LegStrategyReport();
			
    		legStrategyReportModel.setEngineId(strategyOrderEntity.getId().getEngineId());
    		legStrategyReportModel.setStrategyId(strategyOrderEntity.getStrategyId());
    		legStrategyReportModel.setLegSeq(strategyOrderEntity.getLegSeq());
    		
    		legStrategyReportModel.setSide(strategyOrderEntity.getSide().getCode());
    		legStrategyReportModel.setExecutedQuantity(strategyOrderEntity.getExecutedQuantity());
    		legStrategyReportModel.setRemainingQuantity(strategyOrderEntity.getRemainingQuantity());
    		legStrategyReportModel.setText(strategyOrderEntity.getText());
    		
    		legStrategyReportModel.setAveragePrice(strategyOrderEntity.getLegStrategyReport().getAveragePrice());
    		legStrategyReportModel.setRestingQuantity(strategyOrderEntity.getLegStrategyReport().getRestingQuantity());
    		legStrategyReportModel.setRestingPrice(strategyOrderEntity.getLegStrategyReport().getRestingPrice());
    		legStrategyReportModel.setDuration(strategyOrderEntity.getLegStrategyReport().getDuration());
    		legStrategyReportModel.setMaxQuantityDisplay(strategyOrderEntity.getLegStrategyReport().getMaxQuantityDisplay());
    		legStrategyReportModel.setMinQuantityDisplay(strategyOrderEntity.getLegStrategyReport().getMinQuantityDisplay());
    		legStrategyReportModel.setTimeInForce(strategyOrderEntity.getLegStrategyReport().getTimeInForce());
    		legStrategyReportModel.setTimeOut(strategyOrderEntity.getLegStrategyReport().getTimeOut());
    		legStrategyReportModel.setExecutedPercentage(strategyOrderEntity.getLegStrategyReport().getExecutedPercentage());
    		legStrategyReportModel.setEnteringTrader(strategyOrderEntity.getLegStrategyReport().getEnteringTrader());
    		legStrategyReportModel.setInvestorId(strategyOrderEntity.getLegStrategyReport().getInvestorId());
    		legStrategyReportModel.setDuration(strategyOrderEntity.getLegStrategyReport().getDuration());
    		legStrategyReportModel.setContract(strategyOrderEntity.getSymbol());
    		legStrategyReportModel.setPassiveLeg(strategyOrderEntity.getLegStrategyReport().getPassiveLeg());
    		legStrategyReportModel.setLeggedPrice(strategyOrderEntity.getPrice());
    		
    		Account account = new Account();
    		BeanUtils.copyProperties(strategyOrderEntity.getLegStrategyReport().getAccount(), account);    		
    		legStrategyReportModel.setAccount(account);    		    		
    	}
    	
    	return legStrategyReportModel;
    }
}