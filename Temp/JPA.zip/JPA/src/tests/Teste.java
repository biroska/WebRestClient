package tests;

import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.persistence.EntityTransaction;

import mocks.StrategyWithLegsMock;
import entities.StrategyReport;
import factory.FactoryManager;

public class Teste {
	
		private static final Logger LOGGER = Logger.getLogger("JPA");

		public static void main(String[] args) {
			Teste main = new Teste();
//			main.run(); // gera 4.005 registros
			main.POC(); // gera 4.005.000 registros
		}

		public void run() {
			
			Date startTime = null;
			
			try {
				
				EntityTransaction transaction = FactoryManager.entityManager.getTransaction();
				try {
					startTime = new Date();
					
					System.out.println("Transactio Begin " + startTime );
					transaction.begin();
	
					StrategyReport strategy = new StrategyReport();
	
//					strategy = ( new StrategyWithLegsMock() ).insert( 4 );
					
//					load e update test
//					strategy = ( new StrategyWithLegsMock() ).loadStrategyReportMock( 426L );
//					
//					System.out.println("Teste.run(): " + strategy.getStrategyId() );
//					System.out.println("Teste.run(): " + strategy.getLegStrategyList().get( 0 ).getId() );
//					System.out.println("Teste.run(): " + strategy.getLegStrategyList().get( 1 ).getId() );
	
//					strategy = ( new StrategyWithLegsMock() ).updateStrategyReportMock( 426L );					
					
//					FactoryManager.entityManager.persist( strategy );
					
//					remove test
//					strategy = ( new StrategyWithLegsMock() ).loadStrategyReportMock( 426L );
//					
//					FactoryManager.entityManager.remove( strategy );
					
//					Teste com Strategy, Legs e Ordens
					
					StrategyWithLegsMock mock = new StrategyWithLegsMock();
					
					strategy = mock.insert( 4 );
					strategy = mock.generateOrders( strategy );
					
					FactoryManager.entityManager.persist( strategy );
	
					transaction.commit();
					
					System.out.println("Transactio End " + new Date() );
					
				} catch (Exception e) {
					if (transaction.isActive()) {
						System.out.println("Rollback " + new Date() );
						transaction.rollback();
					}
				}
				
			} catch (Exception e) {
				LOGGER.log(Level.SEVERE, e.getMessage(), e);
				e.printStackTrace();
			} finally {
				
				System.out.println("finally " + new Date() );
				
				if ( FactoryManager.entityManager != null) {
					 FactoryManager.entityManager.close();
				}
				if ( FactoryManager.factory != null) {
					 FactoryManager.factory.close();
				}
			}
			
			System.out.println("Elapsed time: " + ( new Date().getTime() - startTime.getTime() ) / 1000 + "s"  );
		}
		
		
		
		
		public void POC() {
			
			Date startTime = null;
			
			try {
				
				EntityTransaction transaction = FactoryManager.entityManager.getTransaction();
				
				try {
					startTime = new Date();
					
					System.out.println("Transactio Begin " + startTime );
	
					StrategyWithLegsMock mock = new StrategyWithLegsMock();
					
					for (int i = 1; i <= 1000; i++) {
						StrategyReport strategy = new StrategyReport();
						transaction.begin();
					
	//					Teste com Strategy, Legs e Ordens
						strategy = mock.insert( 4 );
						strategy = mock.generateOrders( strategy );
						
						FactoryManager.entityManager.persist( strategy );
		
						transaction.commit();
					}
					
					System.out.println("Loop End " + new Date() );
					
				} catch (Exception e) {
					if (transaction.isActive()) {
						System.out.println("Rollback " + new Date() );
						transaction.rollback();
					}
				}
				
			} catch (Exception e) {
				LOGGER.log(Level.SEVERE, e.getMessage(), e);
				e.printStackTrace();
			} finally {
				
				System.out.println("finally " + new Date() );
				
				if ( FactoryManager.entityManager != null) {
					 FactoryManager.entityManager.close();
				}
				if ( FactoryManager.factory != null) {
					 FactoryManager.factory.close();
				}
			}
			
			System.out.println("Elapsed time: " + ( new Date().getTime() - startTime.getTime() ) / 1000 + "s"  );
		}
}