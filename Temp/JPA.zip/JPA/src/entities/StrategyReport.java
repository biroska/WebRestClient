package entities;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="TB_STRATEGY_REPORT")
public class StrategyReport {
	
	@Id
	@Column ( name = "ID")
//	@GeneratedValue(strategy=GenerationType.IDENTITY) para MySQL Aim*
	@SequenceGenerator(name = "TB_STRATEGY_REPORT_ID_GENERATOR", sequenceName = "SEQ_STRATEGY_REPORT", allocationSize = 1)
	@GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "TB_STRATEGY_REPORT_ID_GENERATOR" )
	private Long id;
	
	@Column ( name = "STRATEGYID", nullable=false, unique = true)
	private Long strategyId;
	
	@Temporal ( TemporalType.TIMESTAMP )
	@Column ( name = "REGISTRY_TIMESTAMP", nullable=false )
	private Date registryTimestamp;
	
	@Column ( name = "REGISTRY_USER", nullable=false)
	private Long registryUser;
	
	@Temporal ( TemporalType.TIMESTAMP )
	@Column ( name = "START_TIME", nullable=false)
	private Date startTime;
	
	@Temporal ( TemporalType.TIMESTAMP )
	@Column ( name = "END_TIME", nullable=false)
	private Date endTime;
	
	@Column ( name = "EXECUTED_PERCENTAGE")
	private Double executedPercentage;
	
	@Column ( name = "TARGET_EXECUTED")
	private Double executedTarget;
	
	@Column ( name = "START_PAUSED", nullable=false)
	private Boolean startPaused;
	
	@Column ( name = "TEXT")
	private String text;
	
	@Column ( name = "PRICE_LIMIT")
	private Double priceLimit;
	
	@Column ( name = "TARGET", nullable=false)
	private Double target;
	
	@Column ( name = "AGRESSIVINESS")
	private Double agressiviness;
	
	@Column ( name = "RISK_LEVEL")
	private Long riskLevel;
	
	@OneToMany(mappedBy = "strategyReport", fetch=FetchType.LAZY, cascade = CascadeType.ALL)
	private List<LegStrategyReport> legStrategyList; // strategyReport
	
	public StrategyReport(){}
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getStrategyId() {
		return strategyId;
	}
	public void setStrategyId(Long strategyId) {
		this.strategyId = strategyId;
	}
	public Date getRegistryTimestamp() {
		return registryTimestamp;
	}

	public void setRegistryTimestamp(Date registryTimestamp) {
		this.registryTimestamp = registryTimestamp;
	}
	public Long getRegistryUser() {
		return registryUser;
	}
	public void setRegistryUser(Long registryUser) {
		this.registryUser = registryUser;
	}

	public Date getStartTime() {
		return startTime;
	}
	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}
	public Date getEndTime() {
		return endTime;
	}
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}
	public Double getExecutedPercentage() {
		return executedPercentage;
	}
	public void setExecutedPercentage(Double executedPercentage) {
		this.executedPercentage = executedPercentage;
	}
	public Double getExecutedTarget() {
		return executedTarget;
	}
	public void setExecutedTarget(Double executedTarget) {
		this.executedTarget = executedTarget;
	}
	public Boolean getStartPaused() {
		return startPaused;
	}
	public void setStartPaused(Boolean startPaused) {
		this.startPaused = startPaused;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public Double getPriceLimit() {
		return priceLimit;
	}
	public void setPriceLimit(Double priceLimit) {
		this.priceLimit = priceLimit;
	}
	public Double getTarget() {
		return target;
	}
	public void setTarget(Double target) {
		this.target = target;
	}
	public Double getAgressiviness() {
		return agressiviness;
	}
	public void setAgressiviness(Double agressiviness) {
		this.agressiviness = agressiviness;
	}
	public Long getRiskLevel() {
		return riskLevel;
	}
	public void setRiskLevel(Long riskLevel) {
		this.riskLevel = riskLevel;
	}
	
	public List<LegStrategyReport> getLegStrategyList() {
		return legStrategyList;
	}

	public void setLegStrategyList(List<LegStrategyReport> legStrategyList) {
		this.legStrategyList = legStrategyList;
	}
	
//	Seta o relacionamento entre as entidades
	public LegStrategyReport addLegStrategyReport( LegStrategyReport legStrategy ){
		if ( getLegStrategyList() == null )
			setLegStrategyList( new ArrayList<LegStrategyReport>() );
		
		getLegStrategyList().add( legStrategy );
		legStrategy.setStrategyReport( this );
		
		return legStrategy;
	}
	
	public LegStrategyReport removeLegStrategyReport( LegStrategyReport legStrategy ){
		getLegStrategyList().remove( legStrategy );
		legStrategy.setStrategyReport( null );
		
		return legStrategy;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((strategyId == null) ? 0 : strategyId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StrategyReport other = (StrategyReport) obj;
		if (strategyId == null) {
			if (other.strategyId != null)
				return false;
		} else if (!strategyId.equals(other.strategyId))
			return false;
		return true;
	}
}