package entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="TB_STRATEGY_ORDERS")
public class StrategyOrders {
	
	@Id
	@Column ( name = "ID")
//	@GeneratedValue(strategy=GenerationType.IDENTITY) MySql Aim*
	@SequenceGenerator(name = "TB_STRATEGY_ORDERS_ID_GENERATOR", sequenceName = "SEQ_STRATEGY_ORDERS", allocationSize = 1)
	@GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "TB_STRATEGY_ORDERS_ID_GENERATOR" )
	private Long id;
	
	@Temporal ( TemporalType.TIMESTAMP )
	@Column ( name = "REGISTRY_TIMESTAMP", nullable=false )
	private Date registryTimestamp;
	
	@ManyToOne
	@JoinColumn(name = "STRATEGYID", nullable = false )
	private LegStrategyReport legStrategyReport;
	
	@Column ( name = "EXECUTED_QUANTITY", nullable = false)
	private Long executedQuantity;
	
	@Column ( name = "AVERAGE_PRICE", nullable = false)
	private Double averagePrice;
	
	@Column ( name = "SIDE", nullable = false)
	private Long side;
	
	@Column ( name = "ORDER_ID", nullable=false, unique=true)
	private Long orderId;
	
	@Column ( name = "REMAINING_QTY", nullable = false)
	private Long remainingQuantity;
	
	@Column ( name = "ROUTE_ID", nullable = false)
	private Long routeId;
	
	@Column ( name = "ORDER_TYPE", nullable = false)
	private String orderType;
	
	@Column ( name = "TIME_IN_FORCE", nullable = false)
	private String timeInForce;
	
	@Column ( name = "ACCOUNT", nullable = false)
	private String account;
	
	@Column ( name = "CLIENT_ORDER_ID", nullable = false)
	private String clientOrderId;
	
	@Column ( name = "ORDER_STATUS", nullable = false)
	private String orderStatus;
	
	@Column ( name = "EXECUTION_TYPE", nullable = false)
	private String executionType;
	
	@Column ( name = "PRICE")
	private Double price;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getRegistryTimestamp() {
		return registryTimestamp;
	}

	public void setRegistryTimestamp(Date registryTimestamp) {
		this.registryTimestamp = registryTimestamp;
	}

	public LegStrategyReport getLegStrategyReport() {
		return legStrategyReport;
	}

	public void setLegStrategyReport(LegStrategyReport legStrategyReport) {
		this.legStrategyReport = legStrategyReport;
	}

	public Long getExecutedQuantity() {
		return executedQuantity;
	}

	public void setExecutedQuantity(Long executedQuantity) {
		this.executedQuantity = executedQuantity;
	}

	public Double getAveragePrice() {
		return averagePrice;
	}

	public void setAveragePrice(Double averagePrice) {
		this.averagePrice = averagePrice;
	}

	public Long getSide() {
		return side;
	}

	public void setSide(Long side) {
		this.side = side;
	}

	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	public Long getRemainingQuantity() {
		return remainingQuantity;
	}

	public void setRemainingQuantity(Long remainingQuantity) {
		this.remainingQuantity = remainingQuantity;
	}

	public Long getRouteId() {
		return routeId;
	}

	public void setRouteId(Long routeId) {
		this.routeId = routeId;
	}

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	public String getTimeInForce() {
		return timeInForce;
	}

	public void setTimeInForce(String timeInForce) {
		this.timeInForce = timeInForce;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getClientOrderId() {
		return clientOrderId;
	}

	public void setClientOrderId(String clientOrderId) {
		this.clientOrderId = clientOrderId;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	public String getExecutionType() {
		return executionType;
	}

	public void setExecutionType(String executionType) {
		this.executionType = executionType;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((orderId == null) ? 0 : orderId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StrategyOrders other = (StrategyOrders) obj;
		if (orderId == null) {
			if (other.orderId != null)
				return false;
		} else if (!orderId.equals(other.orderId))
			return false;
		return true;
	}
}