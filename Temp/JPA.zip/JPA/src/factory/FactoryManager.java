package factory;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class FactoryManager {
	
	public static EntityManagerFactory factory;
	public static EntityManager entityManager = null;
	
	static {
		factory = Persistence.createEntityManagerFactory("PersistenceUnit");
		entityManager = factory.createEntityManager();
	}
}
