package mocks;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import entities.LegStrategyReport;
import entities.StrategyOrders;
import entities.StrategyReport;
import factory.FactoryManager;

public class StrategyWithLegsMock {
	
	private Random random;
	
	final CriteriaBuilder criteriaBuilder =  FactoryManager.entityManager.getCriteriaBuilder();
	long idGenerico;
	
	public StrategyWithLegsMock(){
		random = new Random();
		idGenerico = System.currentTimeMillis();
	}
	
	public StrategyReport insert( int legQtd ){
		
		StrategyReport strategy = new StrategyReport();
		strategy.setLegStrategyList( new ArrayList<LegStrategyReport>() );

//		StrategyReport fields
		strategy.setStrategyId( idGenerico++ );
		strategy.setRegistryTimestamp( new Date() );
		strategy.setRegistryUser( (long) random.nextInt( 1000 ) );
		strategy.setStartTime( new Date() );
		strategy.setEndTime( new Date() );
		strategy.setStartPaused( (long) random.nextInt( 1000 ) % 2 == 0 );
		strategy.setTarget( random.nextDouble() );
		strategy.setExecutedPercentage( random.nextDouble() );
		strategy.setExecutedTarget( random.nextDouble() );
		strategy.setText( "Random Text" + random.nextGaussian() );	
		strategy.setPriceLimit( random.nextDouble() );
		strategy.setAgressiviness( random.nextDouble() );
		strategy.setRiskLevel( (long) random.nextInt( 1000 ) );
		
//		LegStrategyReport fields
		for (int i = 1; i <= legQtd; i++) {
			LegStrategyReport leg = new LegStrategyReport();
			leg.setLegNumber( Long.valueOf( i ) );
			leg.setInstrument( (long) random.nextInt( 1000 )  );
			leg.setTotalQuantity( (long) random.nextInt( 1000 )  );
			
			leg.setExecutedPercentage( random.nextDouble() );
			leg.setRemainingQuantity( (long) random.nextInt( 1000 )  );
			leg.setExecutedQuantity( (long) random.nextInt( 1000 )  );
			leg.setAveragePrice( random.nextDouble() );
			leg.setText( "Random Text" + random.nextGaussian() );
			leg.setSide( (long) ( (i % 2) +1 )  );
			leg.setRouteId( (long) random.nextInt( 1000 )  );
			leg.setOrderType( "Order Type" );
			leg.setTimeInForce( "Time In Force" );
			leg.setAccount( "Account" );
			leg.setPassiveLeg( i % 2 == 0 );
			leg.setMaxQuantityDisplay( (long) random.nextInt( 1000 ) );
			leg.setMinQuantityDisplay( (long) random.nextInt( 1000 ) );
			leg.setRestingQuantity( (long) random.nextInt( 1000 ) );
			leg.setRestingPrice( random.nextDouble() );
			leg.setRestingRank( (long) random.nextInt( 1000 ) );
			leg.setTimeOut( (long) random.nextInt( 1000 ) );
			leg.setInvestorId( "Investor Id" );
			leg.setEnteringTrader( "Entering Trader" );
			
//			Seta o relacionamento entre as entidades
			strategy.addLegStrategyReport( leg );
		}
		
		return strategy;
	}
	
	public StrategyReport loadStrategyReportMock( Long strategyId ){
		
		CriteriaQuery<StrategyReport> criteriaQuery = criteriaBuilder.createQuery( StrategyReport.class );
		Root<StrategyReport> strategyRoot = criteriaQuery.from( StrategyReport.class );
		
		criteriaQuery.select( strategyRoot );
		criteriaQuery.where( criteriaBuilder.equal( strategyRoot.get("strategyId") , strategyId ) );
		
		List<StrategyReport> strategy = FactoryManager.entityManager.createQuery( criteriaQuery ).getResultList();
		
		return strategy.get( 0 );
	}
	
	public StrategyReport updateStrategyReportMock( Long strategyId ){
		
		StrategyReport strategy = loadStrategyReportMock( strategyId );
		
//		StrategyReport fields
		strategy.setText( "Alterado " + random.nextGaussian() );
		
//		LegStrategyReport fields
		for (LegStrategyReport leg : strategy.getLegStrategyList() ) {
			leg.setText( "Alterado " + random.nextGaussian() );
			leg.setOrderType( "Alterado Order Type" );
			leg.setTimeInForce( "Alterado Time In Force" );
			leg.setAccount( "Alterado Account" );
			leg.setInvestorId( "Alterado Investor Id" );
			leg.setEnteringTrader( "Alterado Entering Trader" );
		}
		
		return strategy;
	}
	
	public StrategyReport generateOrders( StrategyReport strategy ){
		
		if( strategy != null && strategy.getLegStrategyList() != null ){
			
			for (LegStrategyReport leg : strategy.getLegStrategyList() ) {
				
				for (int i = 1; i <= 1000; i++) {
					StrategyOrders order = new StrategyOrders();
					
					order.setRegistryTimestamp( new Date() );
					order.setLegStrategyReport( leg );
					order.setExecutedQuantity( (long) random.nextInt( 1000 ) );
					order.setAveragePrice( random.nextDouble() );
					order.setSide( (long) ( (i % 2) +1 ) );
					order.setOrderId( idGenerico );
					order.setRemainingQuantity( (long) random.nextInt( 1000 ) );
					order.setRouteId( (long) random.nextInt( 1000 ) );
					order.setOrderType( "Order Type: " + i );
					order.setTimeInForce( "Time in Force: " + i );
					order.setAccount( "Account: " + i );
					order.setClientOrderId( "Client Order: " + i );
					order.setOrderStatus( "Order Status: " + i );
					order.setExecutionType( "Execution Type: " + i );
					order.setPrice( random.nextDouble() );
					
					leg.addStrategyOrder( order );
					
					idGenerico++;
				}
			}
		}
		return strategy;
	}
}