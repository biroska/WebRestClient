package com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities;

/**
 * This is an incremental book update. The book is always updated by an
 * incremental update.
 * 
 * @author pretof
 *
 */
public interface IncrementalBookUpdate {
	
	/**
	 * Define the possible types of action.
	 * 
	 * @author pretof
	 *
	 */
	public static enum IncrementalUpdateType {
		ADD,
		UPDATE,
		DELETE
	}
	
	/**
	 * Unique id of this incremental update
	 * 
	 * @return
	 */
	long getIncrementalID();
	
	/**
	 * Get type of book increment.
	 * 
	 * @return Book increment type
	 */
	IncrementalUpdateType getUpdateType();
	
	/**
	 * Position that will be affected by this incremental update.
	 * 0 is the first position of the book.
	 * 
	 * @return The book position from 0
	 */
	int getPosition();
	
	/**
	 * Get the entry that will be added or updated. If this is a delete action
	 * then it might contain a null entry (not required).
	 * 
	 * @return the entry to be updated on the book
	 */
	BookEntry getEntry();

}
