/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import com.ubs.manhatthan.manager.persistence.entities.audit.StrategyByTabLegAudit;


/**
 * @author galdinoa
 *
 */
public interface IStrategyByTabLegAuditDAO extends IGenericDAO<StrategyByTabLegAudit, Long> {}
