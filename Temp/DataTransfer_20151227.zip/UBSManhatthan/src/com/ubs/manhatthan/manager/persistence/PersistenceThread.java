/**
 * 
 */
package com.ubs.manhatthan.manager.persistence;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.ubs.manhatthan.manager.cache.PersistenceCache;
import com.ubs.manhatthan.manager.enricher.PrepareToPersist;
import com.ubs.manhatthan.manager.logger.ApplicationLogger;
import com.ubs.manhatthan.manager.persistence.entities.Strategy;
import com.ubs.manhatthan.manager.persistence.entities.StrategyOrders;
import com.ubs.manhatthan.manager.persistence.entities.StrategyReport;

/**
 * @author galdinoa
 *
 */
@Service
@Scope("singleton")
public class PersistenceThread implements Runnable {
	
	@Autowired
	private PrepareToPersist persist;

	@Override
	public void run() {
		ApplicationLogger.logInfo("======================================================================================");
		ApplicationLogger.logInfo("Thread: " + Thread.currentThread().getName() + " iniciada");
		ApplicationLogger.logInfo("======================================================================================");
		
		Strategy message = null;
		
//		PrepareToPersist persist = new PrepareToPersist();
		
		StrategyOrders order = null;
		StrategyReport report = null;
		
		while ( true ){
			
			try {
				
				if ( PersistenceCache.isEmpty() )
					continue;
				
				message = PersistenceCache.extractFirst();
				
				ApplicationLogger.logInfo("Message will be persisted: " + message );
				
				if ( message == null )
					continue;
				
				if ( message instanceof StrategyReport ){
					report = (StrategyReport) message;
					persist.saveReport( report );
					
				} else
					if ( message instanceof StrategyOrders ){
						order = (StrategyOrders) message;
						persist.saveOrder( order );
						
					} else {
						ApplicationLogger.logWarn("======================================================================================");
						ApplicationLogger.logWarn("Objeto n�o tratado: \t" + message );
						ApplicationLogger.logWarn("======================================================================================");
					}
				
				Thread.sleep( 1000 );
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				ApplicationLogger.logError("Error: ", e );
			}
		}
	}

	public void setPersist(PrepareToPersist persist) {
		this.persist = persist;
	}
}