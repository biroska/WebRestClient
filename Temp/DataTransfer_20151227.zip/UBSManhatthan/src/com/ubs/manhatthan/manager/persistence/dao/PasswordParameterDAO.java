package com.ubs.manhatthan.manager.persistence.dao;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IPasswordParameterAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IPasswordParameterDAO;
import com.ubs.manhatthan.manager.persistence.entities.PasswordParameter;
import com.ubs.manhatthan.manager.persistence.entities.audit.PasswordParameterAudit;

@Repository
@Scope("singleton")
public class PasswordParameterDAO extends GenericDAO<PasswordParameter, Long> implements IPasswordParameterDAO {
	
	@Autowired
	private IPasswordParameterAuditDAO passwordParameterAuditDAO;
	
	@Autowired
	private User user;
	
	@Override
	public PasswordParameter savePasswordParameter( PasswordParameter passwordParameter ) throws DAOExceptionManhattan {
		try {
			ActionTypeEnum action = passwordParameter.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;
	
			passwordParameter = update( passwordParameter );
	
			PasswordParameterAudit pa = new PasswordParameterAudit( passwordParameter, action, user.getLogin(), new Date() );
			
			passwordParameterAuditDAO.update( pa );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return passwordParameter;
	}

	public Long generate( int qtd ) throws DAOExceptionManhattan {
		
		Long qtRegs = 0L;
		
		savePasswordParameter( new PasswordParameter() );
		savePasswordParameter( new PasswordParameter( 1, 2, 3, 4, 120 ) );
		savePasswordParameter( new PasswordParameter( 5, 6, 7, 8, 100 ) );
		savePasswordParameter( new PasswordParameter( 9, 9, 9, 9, 30 ) );
		savePasswordParameter( new PasswordParameter( 5, 5, 5, 5, 60 ) );
		
		return qtRegs;
	}
	
	public PasswordParameter getByIndex( int index ) throws DAOExceptionManhattan  {
		return findAll().get( index );
	}

	public void setPasswordParameterAuditDAO(IPasswordParameterAuditDAO passwordParameterAuditDAO) {
		this.passwordParameterAuditDAO = passwordParameterAuditDAO;
	}

	public void setUser(User user) {
		this.user = user;
	}
}