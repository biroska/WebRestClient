/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import java.util.List;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.persistence.entities.audit.StrategyOrdersAudit;

/**
 * @author galdinoa
 *
 */
public interface IStrategyOrdersAuditDAO extends IGenericDAO<StrategyOrdersAudit, Long> {

	List<StrategyOrdersAudit> save(List<StrategyOrdersAudit> list) throws DAOExceptionManhattan;

}
