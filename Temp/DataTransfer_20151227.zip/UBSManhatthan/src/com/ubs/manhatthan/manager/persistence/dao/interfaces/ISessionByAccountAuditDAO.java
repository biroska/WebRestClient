/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import com.ubs.manhatthan.manager.persistence.entities.audit.SessionByAccountAudit;

/**
 * @author galdinoa
 *
 */
public interface ISessionByAccountAuditDAO extends IGenericDAO<SessionByAccountAudit, Long> {}
