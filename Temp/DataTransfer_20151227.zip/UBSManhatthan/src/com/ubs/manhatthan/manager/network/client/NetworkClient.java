/*
 * NetworkClient.java
 *
 *  Created on: Set 25, 2015
 *      Author: vanputtg
 */


//Package
package com.ubs.manhatthan.manager.network.client;

//NOTES: cannot call Service methods at same time - undefined behavior
//                           request_id should be superior 0 (>0)
//                           manager_id should be superior 0 (>0)

//Import
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.HashSet;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import com.ubs.manhatthan.exception.EngineExceptionManhattan;
import com.ubs.manhatthan.exception.MessageExceptionManhattan;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_header_message;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_legged_order;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_logoff_message;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_logon_message;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_message_type_enum;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_reject_create_modify_cancel_strategy_message;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_report_order_message;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_report_strategy_message;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_statistics_message;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_to_engine_message;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_to_manager_message;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_warning_message;
import com.ubs.manhatthan.manager.service.ServiceException;
import com.ubs.manhatthan.manager.service.ServiceLifecycle;
import com.ubs.manhatthan.manager.utils.Constant;
import com.ubs.manhatthan.manager.utils.Util;
//Import Local


//Network Client Class
final public class NetworkClient implements ServiceLifecycle {
			
	//Network Client Callback
	public interface NetworkClientCallback {
		
		//Application Callback
		void onStart();
		void onStop();
		void onLoad();
		void onUnLoad();

		//Socket Callback
		void onConnect();
		void onLogon();
		void onDisconnect();
		void onLogoff(String str);
		
		//Message Callback
		void onMessage_ReportStrategy(long manager_id, long request_id, pb_report_strategy_message msg);
		void onMessage_RejectStrategy(long manager_id, long request_id, pb_reject_create_modify_cancel_strategy_message msg);
		void onMessage_RejectExecutionOrder(long manager_id, long request_id, pb_reject_create_modify_cancel_strategy_message msg);
		void onMessage_ReportOrder(long manager_id, long request_id, pb_report_order_message msg);
		void onMessage_Statistics(long manager_id, long request_id, pb_statistics_message msg);
		void onMessage_Warning(long manager_id, long request_id, pb_warning_message msg);
		void onMessage_LeggedOrder(long manager_id, long request_id, pb_legged_order msg);
		
		//Print
		void onPrint(String msg);
	}
	
	//Static nested class
	private static class NestedStaticClass{

		//Private Static Member
		private static HashSet<String> server_set = new HashSet<String>();
		
		//Public Method
		protected synchronized static boolean add(String server){

			return !server_set.add(server);
		}
		
		protected synchronized static boolean remove(String server){

			return server_set.remove(server);
		}
	}
	
	//Enum Status
	static public enum NetworkSatus{
		
		//Status Client
		Idled,
		Idling,
		Starting,
		Started,
		Stopping,
		Stopped,
		
		//Status socket
		Connecting,
		Connected,
		Disconnecting,
		Disconnected;
		
		//Methods
		private static   NetworkSatus[] allValues = values();
	    protected static NetworkSatus fromInt(int n) { return allValues[n];}
	    protected static int toInt(NetworkSatus s) { return s.ordinal();}
	}
	
	//Private members - thread
	private Thread 						m_thread_hearbeat;
	private Thread 						m_thread_socket;
	
	//Private members - socket
	private Socket 						m_socket;
	private OutputStream 				m_output_stream;
	private InputStream 				m_input_stream;
	
	//Private members - regular
	private String						m_remote_address;
	private String						m_remote_server;
	private int							m_remote_port;
	private int							m_delay_hearbeat_s = Constant.MESSAGES_CONFIGURATION.HEARBEAT_DELAY_S;  
	private int							m_hearbeat_fail = Constant.MESSAGES_CONFIGURATION.HEARBEAT_FAILOUT_C; 
	private int							m_delay_statistics_s = Constant.MESSAGES_CONFIGURATION.DELAY_STATISTICS_S; 
	private int							m_delay_reconnection_s = Constant.MESSAGES_CONFIGURATION.DELAY_RECONNECTION_S;  
	private long						m_engine_id = 0; 
	
	//Constant members
	final private long					m_manager_id = Util.getManagerId(); //Constant.MESSAGES_CONFIGURATION.MANAGER_INSTANCE;

	//Atomic Members
	private final AtomicInteger			m_status_socket = new AtomicInteger(NetworkSatus.Disconnected.ordinal());
	private final AtomicInteger			m_status_client = new AtomicInteger(NetworkSatus.Idled.ordinal());
	private final AtomicInteger			m_hearbeat_counter = new AtomicInteger(0);
	private final AtomicBoolean			m_logon_accepted = new AtomicBoolean(false);
	
	//Callback class
	private NetworkClientCallback		m_callback;

		
	//Constructor & Destructor
	public NetworkClient(NetworkClientCallback callback, String address, int port){
		
		//Set Address and Port
		m_remote_address = address;
		m_remote_port = port;
		m_remote_server = address + ":" + port;
		
		//Set callback & Manager Id
		m_callback = callback;
	}

	//Public methods
	public NetworkSatus statusSocket(){
		
		return NetworkSatus.fromInt(m_status_socket.get());
	}
	
	public NetworkSatus statusClient(){
		
		return NetworkSatus.fromInt(m_status_client.get());
	}
	
	public String statusSocketStr(){
		
		return statusSocket().toString();
	}
	
	public String statusClientStr(){
		
		return statusClient().toString();
	}
	
	public long engineId(){
		
		return m_engine_id;
	}
	
	public long managerId(){
		
		return m_manager_id;
	}
	
	public boolean isLoggedOn(){
		
		return m_logon_accepted.get();
	}
	
	public pb_header_message getHeader(pb_message_type_enum type, long request_id){
		
		return NetworkProtobuf.pb_header_message.newBuilder() 
				.setMessageType(type) 
				.setManagerInstanceId(m_manager_id) 
				.setEngineInstanceId(m_engine_id) 
				.setManagerRequestId(request_id)
				.build();
	}
	
	//Service LifeCycle Methods
	public boolean onUnLoad() throws ServiceException {
		
		//Callback
		m_callback.onUnLoad();
		
		//Unregister Remote Server
		if(m_status_client.get() != NetworkSatus.Idled.ordinal())
			NetworkClient.NestedStaticClass.remove(m_remote_server);
		
		//Success
		return true;
	}
	
	public boolean onLoad() throws ServiceException {
		
		//Check Callback
		if(null == m_callback) return false;
		
		//Check
		if(m_manager_id <= 0) return false;
	
		//Atomic check
		if(m_status_client.compareAndSet(NetworkSatus.Idled.ordinal(), NetworkSatus.Idling.ordinal())){
			
			//Register Remote Server
			if(NetworkClient.NestedStaticClass.add(m_remote_server)){

				m_status_client.set(NetworkSatus.Idled.ordinal());
				return false;
			}
			
			//Callback
			m_callback.onLoad();
			
			//Success
			m_status_client.set(NetworkSatus.Stopped.ordinal());
			return true;
		}
			
		//Check result
		return m_status_client.get() != NetworkSatus.Idled.ordinal();
	}
	
	public boolean onStart() throws ServiceException {
		
		//Atomic check
		if(m_status_client.compareAndSet(NetworkSatus.Stopped.ordinal(), NetworkSatus.Starting.ordinal())){
			
			//Initialize socket Status
			m_status_socket.set(NetworkSatus.Disconnected.ordinal()); 
			
			//Start thread
			m_thread_socket = new Thread(new Runnable() { public void run() { process_run(); }});
			m_thread_socket.start();
		
			m_thread_hearbeat = new Thread(new Runnable() { public void run() { process_hearbeat(); }});
			m_thread_hearbeat.start();
			
			//Callback
			m_callback.onStart();
			
			//Success
			m_status_client.set(NetworkSatus.Started.ordinal());
			return true;
		}
		
		//Result		
		return m_status_client.get() == NetworkSatus.Started.ordinal();
	}

	public boolean onStop() throws ServiceException {
		
		//Atomic check
		if(m_status_client.compareAndSet(NetworkSatus.Started.ordinal(), NetworkSatus.Stopping.ordinal())){
			
			//Send Logoff
			logoff("Logoff asked by client's user");
			
			//Interrupt threads
			m_thread_hearbeat.interrupt();
			m_thread_socket.interrupt();
			
			//Disconnect
			disconnect();
			
			//Stop threads
			try {
				
				//Join threads
				m_thread_hearbeat.join();
				m_thread_socket.join();
				
				//Callback
				m_callback.onStop();
				
				//Update Status on success
				m_status_client.set(NetworkSatus.Stopped.ordinal());
				return true;
	
			} catch (InterruptedException e) {
				
				m_callback.onPrint( "Error while stopping NetworkClient threads for server " + m_remote_server + ":" + e.toString() );
				return false;
			}
		}
		
		//Result		
		return (m_status_client.get() == NetworkSatus.Stopped.ordinal()
			|| m_status_client.get() == NetworkSatus.Idled.ordinal());
	}

	public void send(pb_to_engine_message msg) throws EngineExceptionManhattan, MessageExceptionManhattan, IOException {
		
		//Check Basics
		if(null == msg)  throw new MessageExceptionManhattan("Null pointer - Message is null");
		if(!m_logon_accepted.get())  throw new EngineExceptionManhattan("Not logged on");
		if(!msg.isInitialized()) throw new MessageExceptionManhattan("Not initialized");
		if(msg.getSerializedSize() > m_socket.getSendBufferSize()) throw new MessageExceptionManhattan("Message exceed maximum size");
		
		//Check header
		if(!msg.hasHeader())   throw new MessageExceptionManhattan("No header");
		pb_header_message header = msg.getHeader();
		//m_engine_id - div for 1000 to round
		if((m_engine_id/1000) != header.getEngineInstanceId()) throw new MessageExceptionManhattan("Wrong engine Id:" + m_engine_id);
		
		//Check Message Type
		if(!header.hasMessageType()) throw new MessageExceptionManhattan("No msg type");
		pb_message_type_enum msg_type = header.getMessageType();
		switch(msg_type){
			case PB_LEGGED_ORDER: {
				
				if(!msg.hasLeggedMessage()) throw new MessageExceptionManhattan("Wrong Message Type: PB_LEGGED_ORDER");
			} break;
			case PB_COMMANDE_MESSAGE:{
				
				if(!msg.hasCommandMessage()) throw new MessageExceptionManhattan("Wrong Message Type: PB_COMMANDE_MESSAGE");
			} break;
			case PB_REPORT_EXECUTION_ORDER:{
				
				if(!msg.hasReportOrder()) throw new MessageExceptionManhattan("Wrong Message Type: PB_REPORT_EXECUTION_ORDER");
			} break;	
			case PB_CANCEL_ORDER:
			case PB_MODIFY_ORDER:{
				
				if(!msg.hasCancelModifyOrder()) throw new MessageExceptionManhattan("Wrong Message Type: PB_CANCELMODIFY_ORDER");
			} break;	
			case PB_NEW_ORDER:{
				
				if(!msg.hasNewOrder()) throw new MessageExceptionManhattan("Wrong Message Type: PB_NEW_ORDER");
			} break;
			case PB_CREATE_STRATEGY:
			case PB_MODIFY_STRATEGY:
			case PB_CANCEL_STRATEGY:
			case PB_RESUME_STRATEGY:
			case PB_PAUSE_STRATEGY:{
				
				if(!msg.hasStrategy()) throw new MessageExceptionManhattan("Wrong Message Type: PB_..._STRATEGY");
			} break;
			default:{	
				
				throw new MessageExceptionManhattan("Wrong Message Type: not valid --> " + msg_type.toString());	
			}
		}
		
		//Send message
		try {
			send_message(msg);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
			throw e;
		}
	}
	
	private synchronized void send_message(pb_to_engine_message msg) throws IOException{
		
		//Note: DO NOT SEND A MESSAGE SUPERIOR TO 2GB. IF SO, THE COUNTERPARTY WILL SEGFAULT
		try {
			
			msg.writeDelimitedTo(m_output_stream);

		} catch (IOException e) {

			throw new IOException("Error sending message: " + e.toString());
		}
	}
	
	private boolean sleep(long milli){
		
		//Sleep
		try {

			Thread.sleep(milli);
			
		} catch (InterruptedException e) {
		
			//Failure - Interruption
			return false;
		}
		
		//Success
		return true;
	}
	
	private boolean logoff(String text){
		
		//Check text
		if(null == text) return false;
		
		//Check Connected
		if(m_status_socket.get() != NetworkSatus.Connected.ordinal()) return false;
			
		//Prepare Logoff message
		pb_header_message msgHeader = NetworkProtobuf.pb_header_message.newBuilder()
				 .setMessageType(pb_message_type_enum.PB_LOGOFF)
		         .setManagerInstanceId(m_manager_id)
		         .setEngineInstanceId(m_engine_id)
		         .setManagerRequestId(0)
		         .build();
		
		pb_logoff_message msgLogoff = NetworkProtobuf.pb_logoff_message.newBuilder()
				 .setText(text)
				 .build();

		pb_to_engine_message msg = NetworkProtobuf.pb_to_engine_message.newBuilder()
				 .setHeader(msgHeader)
		         .setLogoff(msgLogoff)
		         .build();

		//Send Message
		try {
		
			send_message(msg);

		} catch (Exception e) {
			
			//Print Error
			m_callback.onPrint( "Error sending logoff message: " + e.toString() );
			return false;
		}
	
		//Print Success
		m_callback.onPrint( "Logoff message successfully sent to server: " + m_remote_server + " --> " + text );
		return true;
	}
	
	private boolean logon(){
		
		//Prepare Logon message
		pb_header_message msgHeader = NetworkProtobuf.pb_header_message.newBuilder()
				 .setMessageType(pb_message_type_enum.PB_LOGON)
		         .setManagerInstanceId(m_manager_id)
		         .setEngineInstanceId(m_engine_id)
		         .setManagerRequestId(0)
		         .build();
		
		pb_logon_message msgLogon = NetworkProtobuf.pb_logon_message.newBuilder()
				 .setHeartbeatDelayS(m_delay_hearbeat_s)
				 .setHeartbeatCounterFailOut(m_hearbeat_fail)
				 .setStatisticsDelayS(m_delay_statistics_s)
				 .build();
		
		pb_to_engine_message msg = NetworkProtobuf.pb_to_engine_message.newBuilder()
				 .setHeader(msgHeader)
		         .setLogon(msgLogon)
		         .build();

		//Send Message
		try {
		
			send_message(msg);

		} catch (Exception e) {
			
			//Print Error
			m_callback.onPrint( "Error sending logon message: " + e.toString() );
			return false;
		}
	
		//Print Success
		m_callback.onPrint( "Logon message successfully sent to server: " + m_remote_server );
		return true;
	}
	
	private synchronized boolean disconnect(){
		
		//Check last Status
		NetworkSatus last_status = NetworkSatus.fromInt(m_status_socket.get());
		
		//Atomic check - 'connected'
		if(m_status_socket.compareAndSet(NetworkSatus.Connected.ordinal(), NetworkSatus.Disconnecting.ordinal())
		|| m_status_socket.compareAndSet(NetworkSatus.Connecting.ordinal(), NetworkSatus.Disconnecting.ordinal())){
			
			//Shutdown Streams
			if(null != m_socket){
				
				try {m_socket.shutdownInput();
				}catch (IOException e) {}
				
				try { m_socket.shutdownOutput();	
				} catch (IOException e) {}
				
				try { m_socket.close();
				} catch (IOException e) {}
				
				//Set null
				m_socket = null;
			}
				
			//Update Status
			m_status_socket.set(NetworkSatus.Disconnected.ordinal());
			
			//Reset values
			m_logon_accepted.set(false);
			m_hearbeat_counter.set(0);
						
			//Callback
			if(last_status == NetworkSatus.Connected) m_callback.onDisconnect();
			
			//Success
			return true;	
		}
				
		//Result
		return m_status_socket.get() == NetworkSatus.Disconnected.ordinal();
	}

	private synchronized boolean connect(){
		
		//Atomic check
		if(m_status_socket.compareAndSet(NetworkSatus.Disconnected.ordinal(), NetworkSatus.Connecting.ordinal())){
			
			//Try connect
			try {
								
				int buffer_size = (int)(1048576. * Constant.MESSAGES_CONFIGURATION.SOCKET_BUFFER_SIZE_MB);
				m_socket = new Socket(m_remote_address, m_remote_port);
				m_socket.setSendBufferSize(buffer_size);
				m_socket.setReceiveBufferSize(buffer_size);
				m_socket.setKeepAlive(true); 
				m_output_stream = m_socket.getOutputStream();
				m_input_stream  = m_socket.getInputStream();
				m_callback.onPrint( "Socket created to server " + m_remote_server + " with " + Constant.MESSAGES_CONFIGURATION.SOCKET_BUFFER_SIZE_MB + " MB");
				
			//Error
			} catch (IOException e) {

				m_callback.onPrint( "Error while connecting to server " + m_remote_server + ": " + e.toString() );
				disconnect();
				return false;
			}
			
			//Update logon_accepted
			m_logon_accepted.set(false);
			m_hearbeat_counter.set(0);
			
			//Update Status
			m_status_socket.set(NetworkSatus.Connected.ordinal());
			
			//Send Login
			logon();
			
			//Success
			return true;
		}

		//Result
		return m_status_socket.get() == NetworkSatus.Connected.ordinal();
	}
	
	private void process_run(){
		
		//Print
		m_callback.onPrint( "NetworkClient listening thread starting for server " + m_remote_server );

		//Run while
		while (!Thread.interrupted()) {

			//Connect
			if(connect()){
				
				//Variable
				String error_str = null;
				
				//Callback
				m_callback.onConnect();
				
				//Variable
				boolean disconnection_server = false;
				
				//Listen to Server
				try{
					
					//Variables
					pb_to_manager_message incoming_message;

					//Listen to Input Stream
					while ((incoming_message = pb_to_manager_message.parseDelimitedFrom(m_input_stream)) != null) {

						//Check and process message
						if(!process_input(incoming_message)) 
							break;
					}
					
					//Set boolean
					disconnection_server = true;

				//Store Error
				} catch (IOException e) {

					error_str = e.toString();
				} 

				//Disconnect
				disconnect();
				
				//Print Client disconnection
				m_callback.onPrint( "Disconnection asked by " + (disconnection_server ? "server:" : "client for server:") + m_remote_server
						+ (error_str == null ? "" : " --> " + error_str) );

			}		
			
			//Sleep
			if(!sleep(1000 * m_delay_reconnection_s)){
				
				m_callback.onPrint( "Run thread InterruptedException for server " + m_remote_server );
				break;
			}
		}
		
		//Print
		m_callback.onPrint(  "NetworkClient listening thread stopped for server " + m_remote_server );
	}
	
	private boolean process_input(pb_to_manager_message msg){

		//Variable
		pb_message_type_enum 	msg_type = null;
		pb_header_message 		msg_Header = null;
		long 					manager_id = 0;
		long 					request_id = 0;
		
		//Check basics
		if(!msg.isInitialized()){
			
			m_callback.onPrint( "Incoming message not initialized properly: " + m_remote_server );
			return true;
		}
		
		//Check Header
		else{
		
			//Get Header
			msg_Header = msg.getHeader();
		
			//Get message type
			msg_type = msg_Header.getMessageType();
							
			//Check Engine Id
			if(!msg_Header.hasEngineInstanceId()){
				
				m_callback.onPrint( "Incoming message does not have server id: " + m_remote_server );
				return true;
			}
			
			//Set id
			manager_id = msg_Header.getManagerInstanceId();
			request_id = msg_Header.getManagerRequestId();
		}
		
		//Switch cases
		switch(msg_type){
			case PB_LOGON:{
				
				//Get Login message
				pb_logon_message msg_logon = (msg.hasLogon() ? msg.getLogon() : null);
				
				//Check already Logged on
				if(m_logon_accepted.get()){
	
					m_callback.onPrint( "Logon has already been received from server: " + m_remote_server );
					return true;	
				}
					
				//Check correctness login message
				if(null == msg_logon || !msg_logon.isInitialized()){
					
					//Send logoff message
					logoff("Logon message wrong format - force disconnection");
					return false;
				}
				
				//Set Engine Id
				m_engine_id = msg_Header.getEngineInstanceId();
				m_delay_hearbeat_s = msg_logon.getHeartbeatDelayS();
				m_hearbeat_fail = msg_logon.getHeartbeatCounterFailOut();
				m_delay_statistics_s = msg_logon.getStatisticsDelayS();
				
				//Set Logged
				m_logon_accepted.set(true);
				m_hearbeat_counter.set(0);
				
				//Callback
				m_callback.onLogon();
				return true;
			}
			case PB_HEARTBEAT:{
				
				m_hearbeat_counter.set(0);
				return true;	
			}
			case PB_LOGOFF:{
				
				if(!msg.hasLogoff()) break;
				if(!msg.getLogoff().hasText()) break;
				String text = msg.getLogoff().getText();
				m_callback.onLogoff(text);
				return true;	
			}
			case PB_REPORT_STRATEGY:{
				
				if(!msg.hasReportStrategy()) break;
				m_callback.onMessage_ReportStrategy(manager_id, request_id, msg.getReportStrategy());
				return true;	
			}
			case PB_REJECT_MODIFY_STRATEGY:
			case PB_REJECT_CANCEL_STRATEGY:
			case PB_REJECT_PAUSE_STRATEGY:
			case PB_REJECT_RESUME_STRATEGY:
			case PB_REJECT_CREATE_STRATEGY:
			{
			
				if(!msg.hasRejectStrategy()) break;
				m_callback.onMessage_RejectStrategy(manager_id, request_id, msg.getRejectStrategy());
				return true;
			}			
			case PB_REJECT_REPORT_EXECUTION_ORDER:
			{
			
				if(!msg.hasRejectStrategy()) break;
				m_callback.onMessage_RejectExecutionOrder(manager_id, request_id, msg.getRejectStrategy());
				return true;
			}			
			case PB_REPORT_ORDER:{
				
				if(!msg.hasReportOrder()) break;
				m_callback.onMessage_ReportOrder(manager_id, request_id, msg.getReportOrder());
				return true;
			}
			case PB_STATISTICS_MESSAGE:{
				
				if(!msg.hasStatisticsMessage()) break;
				m_callback.onMessage_Statistics(manager_id, request_id, msg.getStatisticsMessage());
				return true;
			}
			case PB_WARNING_MESSAGE:{
				
				if(!msg.hasWarning()) break;
				m_callback.onMessage_Warning(manager_id, request_id, msg.getWarning());
				return true;
			}
			case PB_LEGGED_ORDER:{
				
				if(!msg.hasLeggedMessage()) break;
				m_callback.onMessage_LeggedOrder(manager_id, request_id, msg.getLeggedMessage());
				return true;
			}
			default:{
				
				m_callback.onPrint( "Unknown incoming message type from server: " + m_remote_server );
				return true;
			}
		}
		
		//Error
		m_callback.onPrint( "Unknown body message from server: " + m_remote_server );
		return true;
	}
	
	private pb_to_engine_message getHearbeatMessage(){
		
		//Prepare Hearbeat Message
		pb_header_message msgHeader = NetworkProtobuf.pb_header_message.newBuilder()
				 .setMessageType(pb_message_type_enum.PB_HEARTBEAT)
		         .setManagerInstanceId(m_manager_id)
		         .setEngineInstanceId(m_engine_id)
		         .setManagerRequestId(0)
		         .build();
		
		//Set message
		pb_to_engine_message msg = NetworkProtobuf.pb_to_engine_message.newBuilder()
				 .setHeader(msgHeader)
		         .build();
		
		//Return message
		return msg;
	}
	
	private void process_hearbeat(){
		
		//Print
		m_callback.onPrint( "NetworkClient hearbeat thread starting for server " + m_remote_server );

		//Variable
		pb_to_engine_message msg = null;
		
		//Loop
		while (!Thread.interrupted()) {
			
			//Sleep
			if(!sleep(1000 * m_delay_hearbeat_s)){

				m_callback.onPrint( "Hearbeat thread InterruptedException for server " + m_remote_server );
				break;
			}
			
			//Hearbeat process
			if(m_logon_accepted.get()){
				
				//Variable
				boolean disconnect = false;
				
				//Get Hearbeat Message
				if(null == msg) msg = getHearbeatMessage();
				
				//Check Failout
				if(m_hearbeat_counter.incrementAndGet() > m_hearbeat_fail){
					
					//Send logoff message
					logoff("Hearbeat failout");
					disconnect = true;
				}
				
				//Send Hearbeat
				else{
					try {
					
						send_message(msg);
						
					} catch (Exception e) {
						
						//Print
						m_callback.onPrint( "Error sending hearbeat message: " + e.toString() );
						disconnect = true;
					}
				}
				
				//Disconnect
				if(disconnect) disconnect();
			}
			
		}
		
		//Print
		m_callback.onPrint( "NetworkClient hearbeat thread stopped for server " + m_remote_server );
	}

}