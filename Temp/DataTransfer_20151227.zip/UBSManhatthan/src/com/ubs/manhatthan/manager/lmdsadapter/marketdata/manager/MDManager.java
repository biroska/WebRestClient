package com.ubs.manhatthan.manager.lmdsadapter.marketdata.manager;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.cache.CacheHelper;
import com.ubs.manhatthan.manager.facade.Facade;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.Book;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.BookSnapshot;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.IncrementalBookUpdate;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.SecurityDefinition;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.Trade;
import com.ubs.manhatthan.manager.utils.Constant;

/**
 * This is an implementation of MDManager and should only be constructed by MDManagerFactory. 
 * 
 * Get out of here ;-)
 * 
 * @author pretof
 *
 */
final public class MDManager {
	
	private final static int DEPTH = 5;
	private final String market;
	private final MDPublisherSubscriber pubsub = new MDPublisherSubscriber();
	private final ConcurrentHashMap<String, MDManagedInstrument> instruments = new ConcurrentHashMap<String, MDManagedInstrument>();
	private final ConcurrentHashMap<String, MDManagedInstrument> instrumentsBySymbol = new ConcurrentHashMap<String, MDManagedInstrument>();
	private final HashSet<String> symbols = new HashSet<String>();
	private Facade facade = CacheHelper.facade;

	public MDManager(String market) {
		this.market = market;
	}

	public String getMarket() {
		return market;
	}
	
	public synchronized void registerInstrument(MDManagedInstrument instrument) {
		
		if (instrument == null)  { return; }
		
		if (instrument.getSecurityDefinition() == null) return;
		if (instrument.getSecurityDefinition().getSecurity() == null) return;
		if (instrument.getSecurityDefinition().getSecurity().getSymbol() == null) return;
		
		String symbol = instrument.getSecurityDefinition().getSecurity().getSymbol();
		
		this.instruments.put(instrument.getSecurityDefinition().getSecurity().getSecurityID(), instrument);
		this.instrumentsBySymbol.put(symbol, instrument);
		this.symbols.add(symbol);
	}
	
	public SecurityDefinition getInstrumentDefinitionBySecurityID(String securityID) throws DAOExceptionManhattan
	{
		MDManagedInstrument instrument =  this.instruments.get(securityID);
			
		if( instrument != null )
		{
			if( !Constant.SIMULATION.INITIAL_MATURITY_DATE.equals(instrument.getSecurityDefinition().getMaturityDate().toString())
				&& !instrument.getSecurityDefinition().isBusinessDaysDefined() )
			{
				instrument.getSecurityDefinition().setBusinessDays( facade.businessDayTotal2(new Date(), instrument.getSecurityDefinition().getMaturityDate()) );
			}
			
			return instrument.getSecurityDefinition();
		}
		
		return null;
	}
	
	public SecurityDefinition getInstrumentDefinitionBySymbol(String symbol) throws DAOExceptionManhattan
	{
		MDManagedInstrument instrument = this.instrumentsBySymbol.get(symbol);
		
		if( instrument != null )
		{
			if( !Constant.SIMULATION.INITIAL_MATURITY_DATE.equals(instrument.getSecurityDefinition().getMaturityDate().toString())
				&& !instrument.getSecurityDefinition().isBusinessDaysDefined() )
			{
				instrument.getSecurityDefinition().setBusinessDays( facade.businessDayTotal2(new Date(), instrument.getSecurityDefinition().getMaturityDate()) );
			}
			
			return instrument.getSecurityDefinition();
		}
		
		return null;
	}
	
	public synchronized List<String> getSymbols(String Symbol) {
		return new ArrayList<String>(this.symbols);
	}
	
	public synchronized BookSnapshot getLastBooksnapshot(String symbol) {
		
		if (!this.instrumentsBySymbol.containsKey(symbol)) {
			return null;
		}
		
		MDManagedInstrument instrument = this.instrumentsBySymbol.get(symbol);
		Book book = instrument.getBook();
		
		return book.getSnapshot(DEPTH);
	}
	
	public synchronized Trade getLastTrade(String symbol) {

		if (!this.instrumentsBySymbol.containsKey(symbol)) {
			return null;
		}
		
		MDManagedInstrument instrument = this.instrumentsBySymbol.get(symbol);
		
		return instrument.getLastTrade();
	}
	
	public synchronized MDSubscribeResponse subscribe(String symbol, MDSubscriberHandler subscriber) {

		if (!this.instrumentsBySymbol.containsKey(symbol)) {
			
			if (!pubsub.subscribe(symbol, subscriber)) {
				return new MDSubscribeResponse(false, null, null);
			}
			
			return new MDSubscribeResponse(true, null, null);
		}
		
		if (!pubsub.subscribe(symbol, subscriber)) {
			return new MDSubscribeResponse(false, null, null);
		}

		MDManagedInstrument instrument = this.instrumentsBySymbol.get(symbol);
		Book book = instrument.getBook();
		Trade trade = instrument.getLastTrade();
		
		return new MDSubscribeResponse(true, book.getSnapshot(DEPTH), trade);
	}
	
	public synchronized void unsubscribe(String symbol, MDSubscriberHandler subscriber) {
		
		if (!this.instrumentsBySymbol.containsKey(symbol)) {
			return;
		}
		
		pubsub.remove(symbol, subscriber);		
	}
	
	public synchronized boolean updateBook(String symbol, IncrementalBookUpdate update) {
		
		// Check if instrument is valid
		if (!this.instrumentsBySymbol.containsKey(symbol)) return false;
		
		MDManagedInstrument instrument = this.instrumentsBySymbol.get(symbol);
		
		Book book = instrument.getBook();
		boolean success = book.applyIncrementalUpdate(update);
		
		if (success) {
			
			BookSnapshot snapshot = book.getSnapshot(DEPTH);
			pubsub.publishBook(symbol, snapshot);
			
			return true;
			
		} else {
			return false;
		}
		
	}
	
	public synchronized boolean updateTrade(String symbol, Trade trade) {
		
		// Check if instrument is valid
		if (!this.instrumentsBySymbol.containsKey(symbol))
		{
			return false;
		}
		
		MDManagedInstrument instrument = instrumentsBySymbol.get(symbol);
		
		instrument.setLastTrade(trade);
		
		pubsub.publishTrade(symbol, trade);
		
		return true;

		
	}
	
}
