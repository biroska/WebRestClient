package com.ubs.manhatthan.manager.simulator.multileg;

import com.ubs.manhatthan.manager.enums.StrategyTypeEnum;
import com.ubs.manhatthan.manager.simulator.multileg.Common.CalculationInnerResult;
import com.ubs.manhatthan.manager.simulator.multileg.fra.FraTwoLegs;
import com.ubs.manhatthan.manager.simulator.multileg.spread.SpreadTwoLegs;

public class MultilegSimulation
{
	
	private	Common common;
	SpreadTwoLegs spreadTwoLegs;
	FraTwoLegs fraTwoLegs;	
	
	public MultilegSimulation()
	{
		this.common = new Common();
	}
	
	/**
	 * @brief This method calculates the market target by Spread
	 * 
	 * @return Double target
	 */
	private CalculationInnerResult calculate(InputMultilegSimulation input)
	{		
		switch(input.getInputItens().size())
		{
		
		case 2:
		{	
			if( StrategyTypeEnum.MULTILEG_FRA == input.getSimulationMode() )
			{
				this.fraTwoLegs = new FraTwoLegs(this.common);
				return fraTwoLegs.calculateTwoLegs(input);	
			}
			else if( StrategyTypeEnum.MULTILEG_SPREAD == input.getSimulationMode() )
			{
				this.spreadTwoLegs = new SpreadTwoLegs(this.common);
				return spreadTwoLegs.calculateTwoLegs(input);
			}
			else
			{
				return common.new CalculationInnerResult(input.getInputItens().size());
			}	
		}
		
		case 3:
		case 4:
		default: { return common.new CalculationInnerResult(input.getInputItens().size()); }

		}		
	}

	public ReturnMultilegSimulation simulate(InputMultilegSimulation input)
	{
		//Creating return object
		ReturnMultilegSimulation returnMultilegSimulation = new ReturnMultilegSimulation();
		for(int i = 0; i < input.getInputItens().size(); i++)
		{
			ReturnMultilegSimulationItem _item = new ReturnMultilegSimulationItem();
			_item.setLegSeq((long)i);
			returnMultilegSimulation.getReturnItens().add(_item);
		}
		
		
		CalculationInnerResult _calculationInner = calculate(input);
		if( null == _calculationInner ) { return returnMultilegSimulation; }
		if( input.isMarketWatch() && _calculationInner.availableQuantityArray.length != returnMultilegSimulation.getReturnItens().size() ) { return returnMultilegSimulation; }
		
		returnMultilegSimulation.setMarketTarget( _calculationInner.target );
		
		if( null != _calculationInner.targetDiff ) { returnMultilegSimulation.setTargetDif(_calculationInner.targetDiff); }
		
		//If is only to calculate the target, return method
		if( input.isOnlyTarget() )
		{
			returnMultilegSimulation.setOnlyTarget(true);
			returnMultilegSimulation.setValid(true);
			return returnMultilegSimulation;
		}
		
		if( input.isMarketWatch() )
		{
			String _availableQuantity = "";
			for(int i = 0; i < _calculationInner.availableQuantityArray.length; i++)
			{
				_availableQuantity += _calculationInner.availableQuantityArray[i];
				if( i < _calculationInner.availableQuantityArray.length - 1) { _availableQuantity += "/"; }
			}
			
			returnMultilegSimulation.setAvailableQuantity(_availableQuantity);
			
			returnMultilegSimulation.setValid(true);
			return returnMultilegSimulation;
		}
		
		for(int i = 0; i < _calculationInner.rankArray.length; i++)
		{
			if( null == _calculationInner.rankArray[i] )
			{
				returnMultilegSimulation.getReturnItens().get(i).setRank(6L);
				continue;
			}
			
			//Validar se existe
			returnMultilegSimulation.getReturnItens().get(i).setRank(_calculationInner.rankArray[i]);
		}
		
		for(int i = 0; i < _calculationInner.quantityArray.length; i++)
		{
			if( null == _calculationInner.quantityArray[i] )
			{
				returnMultilegSimulation.setValid(false);
				return returnMultilegSimulation;
			}
			
			if( null == _calculationInner.divOneArray[i] )
			{
				if( !input.isOnlyTarget() )
				{
					returnMultilegSimulation.setValid(false);
					return returnMultilegSimulation;
				}
				else
				{
					//Validar se existe
					returnMultilegSimulation.getReturnItens().get(i).setDiv1(0.0);
				}
			}
			else
			{
				returnMultilegSimulation.getReturnItens().get(i).setDiv1(_calculationInner.divOneArray[i]);
			}
			
			returnMultilegSimulation.getReturnItens().get(i).setQuantity(_calculationInner.quantityArray[i]);
			
		}
		
		returnMultilegSimulation.setValid(true);
		return returnMultilegSimulation;
	}
	
}
