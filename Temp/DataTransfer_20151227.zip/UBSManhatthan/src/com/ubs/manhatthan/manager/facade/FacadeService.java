/**
 * 
 */
package com.ubs.manhatthan.manager.facade;

import java.io.IOException;
import java.util.List;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.exception.EngineExceptionManhattan;
import com.ubs.manhatthan.exception.MessageExceptionManhattan;
import com.ubs.manhatthan.manager.dto.ReceiveSynthetic;
import com.ubs.manhatthan.manager.lmdsadapter.SimulationItem;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.manager.MDSubscribeResponse;
import com.ubs.manhatthan.manager.persistence.entities.Message;
import com.ubs.manhatthan.manager.persistence.entities.Strategy;
import com.ubs.manhatthan.manager.simulator.multileg.InputMultilegSimulation;
import com.ubs.manhatthan.manager.simulator.multileg.ReturnMultilegSimulation;
import com.ubs.manhatthan.model.StrategyReport;

public interface FacadeService {
	
	public ReturnMultilegSimulation calculate( InputMultilegSimulation input );
	
	public String subscribe( ReceiveSynthetic synthetic ) throws DAOExceptionManhattan;

	public MDSubscribeResponse subscribe(String symbol) throws DAOExceptionManhattan;

	public boolean sendToEngine(Message message) throws EngineExceptionManhattan, MessageExceptionManhattan, IOException;

	public Message getMessage(String requestIdFromView);

	public void unSubscribe(String symbol);

	public String getSymbol(String instrument) throws DAOExceptionManhattan;

	public String getInstrument(String symbol) throws DAOExceptionManhattan;

	public List<SimulationItem> getSimulationListBySymbol(String symbol);

	public boolean putMessageByUser(String login, Strategy message);
	
//	public List<Strategy> getMessagesByUser(String login, int index);

//	public List<Strategy> getAllMessagesByUser( long index );
	
//	public StrategyReport calculate( StrategyReport report );
//	
//	public StrategyReport calculateTarget( StrategyReport report );

	public StrategyReport calculate(StrategyReport report, boolean isOnlyTarget);

	public List<Strategy> getAllMessages();

	public List<Strategy> getMessagesByUser(String login);

	public List<Strategy> getMessagesSnapshotByUser(String login);

	public List<Long> isLoggedOff();

	public List<Strategy> getMessagesBySupervisor();
}
