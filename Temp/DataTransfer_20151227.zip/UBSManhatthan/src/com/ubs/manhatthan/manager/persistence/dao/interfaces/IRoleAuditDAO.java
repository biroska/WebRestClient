/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import com.ubs.manhatthan.manager.persistence.entities.audit.RoleAudit;

/**
 * @author galdinoa
 *
 */
public interface IRoleAuditDAO extends IGenericDAO<RoleAudit, Long> {}
