package com.ubs.manhatthan.manager.persistence.dao;

import java.io.Serializable;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IAccountTypeDAO;
import com.ubs.manhatthan.manager.persistence.entities.AccountType;

@Repository
@Scope("singleton")
public class AccountTypeDAO extends GenericDAO<AccountType, Long> implements IAccountTypeDAO, Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8447520191091855968L;

	@Override
	public AccountType saveAccountType( AccountType accountType ) throws DAOExceptionManhattan {
		AccountType update = null;
		try {
			update = update( accountType );
		
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return update;
	}
	
	public Long generateAccountType( int qtd ) throws DAOExceptionManhattan {
		
		Long qtRegs = 0L;
		
		for ( int i = 1; i<= qtd; i++ ){
			update( new AccountType( "AccountType_" + i  ) );
			qtRegs++;
		}
		return qtRegs;
	}
	
	public AccountType getAccountTypeByIndex( int index ) throws DAOExceptionManhattan  {
		return findAll().get( index );
	}

}
