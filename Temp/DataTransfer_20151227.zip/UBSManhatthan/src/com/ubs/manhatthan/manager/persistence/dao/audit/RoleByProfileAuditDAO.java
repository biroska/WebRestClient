package com.ubs.manhatthan.manager.persistence.dao.audit;

import java.io.Serializable;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.manager.persistence.dao.GenericDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IRoleByProfileAuditDAO;
import com.ubs.manhatthan.manager.persistence.entities.audit.RoleByProfileAudit;

@Repository
@Scope("singleton")
public class RoleByProfileAuditDAO extends GenericDAO<RoleByProfileAudit, Long> implements IRoleByProfileAuditDAO, Serializable {}
