package com.ubs.manhatthan.manager.persistence.dao;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IClientAccountDAO;
import com.ubs.manhatthan.manager.persistence.entities.ClientAccount;

@Repository
@Scope("singleton")
public class ClientAccountDAO extends GenericDAO<ClientAccount, Long> implements IClientAccountDAO, Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8102373448670810855L;

	@Override
	public List<ClientAccount> findClientAccount( ClientAccount clientAccount ) throws DAOExceptionManhattan {
		
		List<ClientAccount> returnList = null;
		
		try{
		
			if ( clientAccount != null ){
				
				if ( clientAccount.getCode() != null ){
					clientAccount = findById( clientAccount.getCode() );
	
					if (clientAccount != null ){
						returnList = new ArrayList<ClientAccount>();
						returnList.add(clientAccount);
					}
				} else {
					returnList = findByExample( clientAccount );
				}
			} 
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		return returnList;
	}
}