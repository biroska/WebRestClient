package com.ubs.manhatthan.manager.persistence.dao;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IStrategyTypeLegAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IStrategyTypeLegDAO;
import com.ubs.manhatthan.manager.persistence.entities.StrategyType;
import com.ubs.manhatthan.manager.persistence.entities.StrategyTypeLeg;
import com.ubs.manhatthan.manager.persistence.entities.audit.StrategyTypeLegAudit;

@Repository
@Scope("singleton")
public class StrategyTypeLegDAO extends GenericDAO<StrategyTypeLeg, Long> implements IStrategyTypeLegDAO {
	
	@Autowired
	private IStrategyTypeLegAuditDAO strategyTypeLegAuditDAO;
	
	@Autowired
	private User user;
	
	@Override
	public StrategyTypeLeg saveStrategyTypeLeg( StrategyTypeLeg strategyTypeLeg ) throws DAOExceptionManhattan {
		try {
			ActionTypeEnum action = strategyTypeLeg.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;
	
			strategyTypeLeg = update( strategyTypeLeg );
	
			StrategyTypeLegAudit sta = new StrategyTypeLegAudit( strategyTypeLeg, action, user.getLogin(), new Date() );
			
			strategyTypeLegAuditDAO.update( sta );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return strategyTypeLeg;
	}

	public Long generate( int qtd ) throws DAOExceptionManhattan {
		
		StrategyTypeDAO strategyTypeDAO = new StrategyTypeDAO();
		List<StrategyType> StrategyTypeList = strategyTypeDAO.findAll();
		
		Long qtRegs = 0L;
		
		for (int i = 1; i <= 10; i++) {
			saveStrategyTypeLeg( new StrategyTypeLeg( StrategyTypeList.get( i % 5), ( i % 2 ) +1, ( i % 4 ) +1 ) );
			qtRegs++;
		}
		
		return qtRegs;
	}

	public void setStrategyTypeLegAuditDAO(IStrategyTypeLegAuditDAO strategyTypeLegAuditDAO) {
		this.strategyTypeLegAuditDAO = strategyTypeLegAuditDAO;
	}

	public void setUser(User user) {
		this.user = user;
	}
}