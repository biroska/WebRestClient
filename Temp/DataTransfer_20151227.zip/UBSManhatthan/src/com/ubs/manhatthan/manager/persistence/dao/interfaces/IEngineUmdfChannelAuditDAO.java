/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import com.ubs.manhatthan.manager.persistence.entities.audit.EngineUmdfChannelAudit;

/**
 * @author galdinoa
 *
 */
public interface IEngineUmdfChannelAuditDAO extends IGenericDAO<EngineUmdfChannelAudit, Long> {}
