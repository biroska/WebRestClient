package com.ubs.manhatthan.manager.persistence.dao;

import java.util.Date;
import java.util.List;

import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IProfileDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.ITraderAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.ITraderDAO;
import com.ubs.manhatthan.manager.persistence.entities.Profile;
import com.ubs.manhatthan.manager.persistence.entities.Trader;
import com.ubs.manhatthan.manager.persistence.entities.audit.TraderAudit;

@Repository
@Scope("singleton")
public class TraderDAO extends GenericDAO<Trader, Long> implements ITraderDAO{
	
	@Autowired
	private IProfileDAO profileDAO;
	
	@Autowired
	private ITraderAuditDAO traderAuditDAO;
	
	@Autowired
	private User user;
	
	@Override
	public Trader saveTrader( Trader trader ) throws DAOExceptionManhattan {
		try {
			ActionTypeEnum action = trader.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;
	
			trader = update( trader );
	
			TraderAudit ta = new TraderAudit( trader, action, user.getLogin(), new Date() );
			
			traderAuditDAO.update( ta );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return trader;
	}
	
	@Override
	public List<Trader> findAllActive( boolean isActive ) throws DAOExceptionManhattan {
		List<Trader> clientsEngineQuery = null;
		try {
			CriteriaBuilder criteriaBuilder = getEm().getCriteriaBuilder();
	
			CriteriaQuery<Trader> criteriaQuery = criteriaBuilder.createQuery(Trader.class);
			Root<Trader> traderRoot = criteriaQuery.from(Trader.class);
			criteriaQuery.where( criteriaBuilder.equal( traderRoot.get( "enable" ), isActive ) );		
			
			criteriaQuery.select( traderRoot );
	
			clientsEngineQuery = getEm().createQuery(criteriaQuery).getResultList();
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		return clientsEngineQuery;
	}
	
	@Override
	public Trader getTraderByLogin( String login ) throws DAOExceptionManhattan {
		
		if ( StringUtils.isBlank( login ) )
			return null;
		
		try {
			Query query = getEm().createQuery("select obj from Trader obj where UPPER( obj.login ) = :login", Trader.class); 
			query.setParameter("login", login.toUpperCase() ); 
			Trader trader = (Trader) query.getSingleResult(); 
			return trader;
		} catch ( Exception e ){
			throw new DAOExceptionManhattan( e );
		}
	}
	
	public Long generateTraders( int qtd ) throws DAOExceptionManhattan {
		
		Profile profile = profileDAO.getByIndex( 1 );
		
		Long qtRegs = 0L;
		
		for ( int i = 1; i<= qtd; i++ ){
			saveTrader( new Trader( "Trader_" + i, "Login_" + i , "123456", new Date(), profile, i % 2 == 0 ) );
			qtRegs++;
		}
		
		return qtRegs;
	}

	public void setProfileDAO(IProfileDAO profileDAO) {
		this.profileDAO = profileDAO;
	}

	public void setTraderAuditDAO(ITraderAuditDAO traderAuditDAO) {
		this.traderAuditDAO = traderAuditDAO;
	}

	public void setUser(User user) {
		this.user = user;
	}
}