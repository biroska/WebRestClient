package com.ubs.manhatthan.manager.enums;

public enum TimeInForceEnum {
	
    DAY                          ( 48 ), // 0
    GOOD_TILL_CANCEL             ( 49 ), // 1
    FILL_AND_KILL                ( 51 ), // 3 (IMMEDIATE OR CANCEL)
    FILL_OR_KILL                 ( 52 ), // 4
    GOOD_TILL_DATE               ( 54 ), // 6
    AT_THE_CLOSE                 ( 55 ), // 7
    GOOD_FOR_AUCTION             ( 65 ); // A
    
    private final Integer code;
    
    private TimeInForceEnum( Integer code ) {
        this.code = code;
    }

    public Integer getCode() {
        return code;
    }
    
    public static TimeInForceEnum fromValue( Integer value ){
    	
		for (TimeInForceEnum item : TimeInForceEnum.values() ) {
			if ( item.getCode().equals( value ) ){
				return item;
			}
		}
		return null;
    }
}
