/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import com.ubs.manhatthan.manager.persistence.entities.audit.EngineInstanceAudit;

/**
 * @author galdinoa
 *
 */
public interface IEngineInstanceAuditDAO extends IGenericDAO<EngineInstanceAudit, Long> {}
