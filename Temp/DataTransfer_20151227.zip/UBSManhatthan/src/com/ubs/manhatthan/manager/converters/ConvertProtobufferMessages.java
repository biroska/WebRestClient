package com.ubs.manhatthan.manager.converters;



//Interface of Converters
public class ConvertProtobufferMessages {
	

	
}