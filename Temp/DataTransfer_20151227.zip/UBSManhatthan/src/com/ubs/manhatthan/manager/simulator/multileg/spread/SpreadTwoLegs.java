package com.ubs.manhatthan.manager.simulator.multileg.spread;

import com.ubs.manhatthan.manager.enums.SideEnum;
import com.ubs.manhatthan.manager.simulator.multileg.Common;
import com.ubs.manhatthan.manager.simulator.multileg.Common.CalculationInnerResult;
import com.ubs.manhatthan.manager.simulator.multileg.InputMultilegSimulation;
import com.ubs.manhatthan.manager.simulator.multileg.InputMultilegSimulationItem;

public class SpreadTwoLegs
{
	private Common common;
	CalculationInnerResult calculationInner;
	private InputMultilegSimulationItem simulationLeg;
	private InputMultilegSimulationItem firstLeg;
	
	public SpreadTwoLegs(Common common)
	{
		this.common             = common;
		this.calculationInner   = common.new CalculationInnerResult(1);
		this.simulationLeg      = new InputMultilegSimulationItem();
		this.firstLeg           = new InputMultilegSimulationItem();
	}

	public CalculationInnerResult calculateTwoLegs(InputMultilegSimulation input)
	{
		//Restarting global variables
		this.calculationInner   = common.new CalculationInnerResult(input.getInputItens().size());
		this.simulationLeg      = new InputMultilegSimulationItem();
		this.firstLeg           = new InputMultilegSimulationItem();
		
		//Local variables
		Double  _firstLegPU              = null;
		Double  _simulationLegPU         = null;
		Double  _quantitiesProportion    = null;	
		Long    _simulationLegQuantity   = null;
		Long    _firstLegQuantity        = null;
		Double  _simulationLegDivOneQty  = null;
		Double  _firstLegDivOneQty       = null;
		
		//Defining Legs
		if( input.getInputItens().get(0).isSimulationLeg() )
		{
			this.simulationLeg  = input.getInputItens().get(0);
			this.firstLeg       = input.getInputItens().get(1);
		}
		else
		{
			this.simulationLeg  = input.getInputItens().get(1);
			this.firstLeg       = input.getInputItens().get(0);
		}
		
		//Calculating Market Target
		this.calculationInner.target = calculateTwoLegsTarget(this.firstLeg, this.simulationLeg);
		
		if( null == this.calculationInner.target ) { return null; } 
		
		//Calculating TargetDiff
		if( null != input.getUserDefinedTarget() && !input.isMarketWatch() )
		{
			this.calculationInner.targetDiff =  this.calculationInner.target - input.getUserDefinedTarget();
		}
		
		if( input.isOnlyTarget() ) { return this.calculationInner; }
		
		//Calculating Rank
		if( null != input.getUserDefinedTarget() && !input.isMarketWatch() )
		{
			this.calculationInner.rankArray = calculateTwoLegsPriceRank(this.firstLeg, this.simulationLeg, input.getUserDefinedTarget());
		}
		
		if( null == this.simulationLeg.getBusinessDays() || 0 >= this.simulationLeg.getBusinessDays() ) { return null; }
		if( null == this.firstLeg.getBusinessDays()      || 0 >= this.firstLeg.getBusinessDays()      ) { return null; }
		if( null == this.simulationLeg.getLastPrice()    || 0.0 >= this.simulationLeg.getLastPrice()  ) { return null; }
		if( null == this.firstLeg.getLastPrice()         || 0.0 >= this.firstLeg.getLastPrice()       ) { return null; }
		
		//Calculating PU's
		_simulationLegPU = common.calculatePu(this.simulationLeg.getLastPrice(), this.simulationLeg.getBusinessDays());
		_firstLegPU      = common.calculatePu(this.firstLeg.getLastPrice(), this.firstLeg.getBusinessDays());
		
		if( 0.0 >= _firstLegPU ) { return null; }
		
		//Calculating quantities proportion
		_quantitiesProportion = ((double)this.simulationLeg.getBusinessDays()*_simulationLegPU)/(double)(this.firstLeg.getBusinessDays()*_firstLegPU);
		
		if( 0.0 == _quantitiesProportion ) { return null; }
		
		if( input.isMarketWatch() )
		{
			Long _simulationLegAvailableQty = null;
			Long _firstLegAvailableQty      = null;
			
			if( SideEnum.BUY == simulationLeg.getSide() )
			{
				_simulationLegAvailableQty = (long) (firstLeg.getBidQuantities().get(0)/_quantitiesProportion);
				_firstLegAvailableQty      = (long) (simulationLeg.getAskQuantities().get(0)*_quantitiesProportion);
			}
			else
			{
				_simulationLegAvailableQty = (long) (firstLeg.getAskQuantities().get(0)/_quantitiesProportion);
				_firstLegAvailableQty      = (long) (simulationLeg.getBidQuantities().get(0)*_quantitiesProportion);
			}
			
			this.calculationInner.availableQuantityArray[0]  = _firstLegAvailableQty;
			this.calculationInner.availableQuantityArray[1]  = _simulationLegAvailableQty;
			
			return this.calculationInner;
		}
		
		//Calculating Div1
		Double _simulationLegRivOne = common.calculatePuLessOnePoint(this.simulationLeg.getLastPrice(), this.simulationLeg.getBusinessDays()) - _simulationLegPU;
		Double _firstLegRivOne      = common.calculatePuLessOnePoint(this.firstLeg.getLastPrice(), this.firstLeg.getBusinessDays()) - _simulationLegPU;

		if( 0.0 >= input.getDollarSpot() )  { return null; }
		
		Double _simulationLegDivOne = _simulationLegRivOne/input.getDollarSpot();	
		Double _firstLegDivOne      = _firstLegRivOne/input.getDollarSpot();
		
		//Calculating quantities and DivOneQty
		if( this.simulationLeg.isByQuantity() )
		{
			_firstLegQuantity = (long) (this.simulationLeg.getQuantity()*_quantitiesProportion);
			_simulationLegQuantity = this.simulationLeg.getQuantity();

			//_firstLegDivOneQty = _firstLegQuantity*_firstLegDivOne;
			//_simulationLegDivOneQty = _simulationLegQuantity*_simulationLegDivOne;
			_firstLegDivOneQty = 0.0;
			_simulationLegDivOneQty = 0.0;
		}
		else
		{
			if( 0.0 == _simulationLegDivOne ) { return null; }
			
			_simulationLegQuantity = (long) (simulationLeg.getDiv1()/_simulationLegDivOne);
			_firstLegQuantity = (long) (_simulationLegQuantity*_quantitiesProportion);
			
			//_firstLegDivOneQty = _firstLegQuantity*_firstLegDivOne;
			_firstLegDivOneQty = 0.0;
			_simulationLegDivOneQty = simulationLeg.getDiv1();
			
		}

		this.calculationInner.quantityArray[0] = _firstLegQuantity;
		this.calculationInner.quantityArray[1] = _simulationLegQuantity;		
		this.calculationInner.divOneArray[0]   = _firstLegDivOneQty;
		this.calculationInner.divOneArray[1]   = _simulationLegDivOneQty;
		
		return this.calculationInner;
	}

	/**
	 * @brief This method calculates the market target by Spread
	 * 
	 * @return Double target
	 */
	private Double calculateTwoLegsTarget(InputMultilegSimulationItem firstLeg,
										  InputMultilegSimulationItem simulationLeg)
	{		
		if( SideEnum.BUY == simulationLeg.getSide() )
		{
			if( 0 >= simulationLeg.getAskDepth() || null == simulationLeg.getAskPrices().get(0) || 0.0 >= simulationLeg.getAskPrices().get(0)  ) { return null; }
			if( 0 >= firstLeg.getBidDepth()      || null == firstLeg.getBidPrices().get(0)      || 0.0 >= firstLeg.getBidPrices().get(0)       ) { return null; }
			
			//Leg1 = SELL, Leg2 = BUY | target = Leg2Ask - Leg1Bid
			return (simulationLeg.getAskPrices().get(0) - firstLeg.getBidPrices().get(0));
		}
		else if( SideEnum.SELL == simulationLeg.getSide() )
		{
			if( 0 >= simulationLeg.getBidDepth() || null == simulationLeg.getBidPrices().get(0) || 0.0 >= simulationLeg.getBidPrices().get(0)  ) { return null; }
			if( 0 >= firstLeg.getAskDepth()      || null == firstLeg.getAskPrices().get(0)      || 0.0 >= firstLeg.getAskPrices().get(0)       ) { return null; }
			
			//Leg1 = BUY, Leg2 = SELL | target = Leg2Bid - Leg1Ask
			return (simulationLeg.getBidPrices().get(0) - firstLeg.getAskPrices().get(0));		
		}
		
		return null;
	}
	
	/**
	 *
	 * @param firstLeg
	 * @param lastleg
	 * @param userDefinedTarget
	 * 
	 * @return Long[]
	 */
	private Long[] calculateTwoLegsPriceRank(InputMultilegSimulationItem firstLeg,
			  							     InputMultilegSimulationItem simulationLeg,
			  							     Double userDefinedTarget)
	{
		Long[] _ret_vector = new Long[2];
		
		if( SideEnum.BUY == simulationLeg.getSide() )
		{
			//Leg2Price = target + Leg1Bid
			Double simulationLegPrice = userDefinedTarget + firstLeg.getBidPrices().get(0);			
			_ret_vector[1] = common.searchBuyPriceRank(simulationLeg, simulationLegPrice);
			
			//Leg1Price = -target + Leg2Ask
			Double firstLegPrice = (-1.0*userDefinedTarget) + simulationLeg.getAskPrices().get(0);
			_ret_vector[0] = common.searchSellPriceRank(firstLeg, firstLegPrice);
		}
		else if( SideEnum.SELL == simulationLeg.getSide() )
		{
			//Leg2Price = target + Leg1Ask
			Double simulationLegPrice = userDefinedTarget + firstLeg.getAskPrices().get(0);
			_ret_vector[1] = common.searchSellPriceRank(simulationLeg, simulationLegPrice);
			
			//Leg1Price = -target + Leg2Bid
			Double firstLegPrice = (-1.0*userDefinedTarget) + simulationLeg.getBidPrices().get(0);
			_ret_vector[0] = common.searchBuyPriceRank(firstLeg, firstLegPrice);			
		}
		
		return _ret_vector;
	}
	
}
