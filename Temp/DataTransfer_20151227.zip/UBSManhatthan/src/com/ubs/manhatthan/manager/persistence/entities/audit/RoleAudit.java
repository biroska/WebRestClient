package com.ubs.manhatthan.manager.persistence.entities.audit;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.persistence.entities.Role;

@Entity
@Table(name="TB_AUDIT_DOMAIN_ROLES")
public class RoleAudit {
	
	public RoleAudit(){}
	
	public RoleAudit(String description) {
		super();
		this.description = description;
	}
	
	

	public RoleAudit( Role role, ActionTypeEnum action, String user, Date registryDate) {
		super();
		this.action = action;
		this.user = user;
		this.registryDate = registryDate;
		
		this.origId = role.getId();
		this.description = role.getDescription();
	}

	@Id
	@Column ( name = "PROFILE")
	@SequenceGenerator(name = "TB_AUDIT_DOMAIN_ROLES_ID_GENERATOR", sequenceName = "SEQ_AUDIT_DOMAIN_ROLES", allocationSize = 1)
	@GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "TB_AUDIT_DOMAIN_ROLES_ID_GENERATOR" )
	private Long id;
	
	@Enumerated(EnumType.STRING)
	@Column( name = "ACTION", nullable=false )
	private ActionTypeEnum action;
	
	@Column( name = "REGISTRY_USER", nullable=false )
	private String user;
	
	@Column( name = "REGISTRY_DATE", nullable=false )
	private Date registryDate;

	@Column ( name = "ORIG_ID", nullable=false )
	private Long origId;
	
	@Column ( name = "DESCRIPTION", nullable=false, length = 16 )
	private String description;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public ActionTypeEnum getAction() {
		return action;
	}

	public void setAction(ActionTypeEnum action) {
		this.action = action;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public Date getRegistryDate() {
		return registryDate;
	}

	public void setRegistryDate(Date registryDate) {
		this.registryDate = registryDate;
	}

	public Long getOrigId() {
		return origId;
	}

	public void setOrigId(Long origId) {
		this.origId = origId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "Role [id=" + id + ", description=" + description + "]";
	}
}