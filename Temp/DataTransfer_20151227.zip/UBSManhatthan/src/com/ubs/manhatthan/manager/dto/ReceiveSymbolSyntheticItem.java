/**
 * 
 */
package com.ubs.manhatthan.manager.dto;

import com.ubs.manhatthan.manager.enums.SideEnum;

public class ReceiveSymbolSyntheticItem {
	
	private String symbol;
	private Integer legSeq;
	private SideEnum side;

	public ReceiveSymbolSyntheticItem() {}
	
	public ReceiveSymbolSyntheticItem(String symbol) {
		super();
		this.symbol = symbol;
	}
	
	public ReceiveSymbolSyntheticItem(String symbol, Integer legSeq,
			SideEnum side) {
		super();
		this.symbol = symbol;
		this.legSeq = legSeq;
		this.side = side;
	}

	public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	public Integer getLegSeq() {
		return legSeq;
	}
	public void setLegSeq(Integer legSeq) {
		this.legSeq = legSeq;
	}
	public SideEnum getSide() {
		return side;
	}
	public void setSide(SideEnum side) {
		this.side = side;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((legSeq == null) ? 0 : legSeq.hashCode());
		result = prime * result + ((side == null) ? 0 : side.hashCode());
		result = prime * result + ((symbol == null) ? 0 : symbol.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ReceiveSymbolSyntheticItem other = (ReceiveSymbolSyntheticItem) obj;
		if (legSeq == null) {
			if (other.legSeq != null)
				return false;
		} else if (!legSeq.equals(other.legSeq))
			return false;
		if (side != other.side)
			return false;
		if (symbol == null) {
			if (other.symbol != null)
				return false;
		} else if (!symbol.equals(other.symbol))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ReceiveSymbolSyntheticItem [symbol=" + symbol + ", legSeq="
				+ legSeq + ", side=" + side + "]";
	}
}