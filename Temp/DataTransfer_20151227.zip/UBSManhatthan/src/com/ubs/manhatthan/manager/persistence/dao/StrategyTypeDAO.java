package com.ubs.manhatthan.manager.persistence.dao;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.enums.StrategyTypeEnum;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IStrategyTypeAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IStrategyTypeDAO;
import com.ubs.manhatthan.manager.persistence.entities.StrategyType;
import com.ubs.manhatthan.manager.persistence.entities.audit.StrategyTypeAudit;

@Repository
@Scope("singleton")
public class StrategyTypeDAO extends GenericDAO<StrategyType, Long> implements IStrategyTypeDAO {
	
	private StrategyType strategyTypeAux = new StrategyType(); 
	
	@Autowired
	private IStrategyTypeAuditDAO strategyTypeAuditDAO;
	
	@Autowired
	private User user;
	
	@Override
	public StrategyType saveStrategyType( StrategyType strategyType ) throws DAOExceptionManhattan {
		try {
			ActionTypeEnum action = strategyType.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;
	
			strategyType = update( strategyType );
	
			StrategyTypeAudit sta = new StrategyTypeAudit( strategyType, action, user.getLogin(), new Date() );
			
			strategyTypeAuditDAO.update( sta );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return strategyType;
	}
	
	@Override
	public Integer getNumberOfLegsFromStrategyType( StrategyTypeEnum strategyType ) throws DAOExceptionManhattan {
		
		if ( strategyType == null || strategyType.equals( StrategyTypeEnum.UNKNOWN ) )
			return null;
		
		try {
			strategyTypeAux.setDescription( strategyType.name() );
			
			List<StrategyType> strategyTypeList = findByExample( strategyTypeAux );
			
			if ( strategyTypeList != null && strategyTypeList.size() == 1 ){
				return strategyTypeList.get( 0 ).getNumberOfLegs();
			}
		
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return null;
	}

	public Long generate( int qtd ) throws DAOExceptionManhattan {
		
		Long qtRegs = 0L;
		
		for (int i = 1; i <= 10; i++) {
			saveStrategyType( new StrategyType( i, "Description_" + i , ( i % 4 ) +1 ) );
			qtRegs++;
		}
		
		return qtRegs;
	}

	public void setStrategyTypeAuditDAO(IStrategyTypeAuditDAO strategyTypeAuditDAO) {
		this.strategyTypeAuditDAO = strategyTypeAuditDAO;
	}

	public void setUser(User user) {
		this.user = user;
	}
}