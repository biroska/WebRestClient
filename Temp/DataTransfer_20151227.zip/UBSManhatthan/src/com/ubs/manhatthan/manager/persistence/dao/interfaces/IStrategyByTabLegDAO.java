/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.persistence.entities.StrategyByTabLeg;


/**
 * @author galdinoa
 *
 */
public interface IStrategyByTabLegDAO extends IGenericDAO<StrategyByTabLeg, Long> {

	StrategyByTabLeg saveStrategyByTabLeg(StrategyByTabLeg strategyByTabLeg) throws DAOExceptionManhattan;
}
