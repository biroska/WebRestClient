package com.ubs.manhatthan.manager.persistence.dao.audit;

import java.io.Serializable;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.manager.persistence.dao.GenericDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IEngineInstanceAuditDAO;
import com.ubs.manhatthan.manager.persistence.entities.audit.EngineInstanceAudit;

@Repository
@Scope("singleton")
public class EngineInstanceAuditDAO extends GenericDAO<EngineInstanceAudit, Long> implements IEngineInstanceAuditDAO, Serializable {}