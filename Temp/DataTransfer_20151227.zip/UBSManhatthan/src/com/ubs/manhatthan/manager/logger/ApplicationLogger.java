package com.ubs.manhatthan.manager.logger;

import java.io.IOException;

import org.apache.log4j.Appender;
import org.apache.log4j.FileAppender;
import org.apache.log4j.Layout;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;

public class ApplicationLogger {
	
	static Logger logger;
	static String logFileName;
	
	public static void configureLogger( String logFile ){
		
		logFileName = logFile;
		
		logger = Logger.getLogger( logFile );
//		logger.setLevel( logLevel  );
		
		PatternLayout layout = new PatternLayout();
		layout.setConversionPattern( "%d{HH:mm:ss.SSS} | %-5p | %m%n" );
		
		FileAppender appender = new FileAppender();
		appender.setFile( logFile );
		appender.setLayout( layout );
		appender.setName( logFile );
		appender.activateOptions();
		
		logger.addAppender( appender );
	}

	public static Logger getAppLogger(String path) throws IOException {
		
		Logger rootLogger = Logger.getLogger(ApplicationLogger.class.getCanonicalName());
		
		Layout pattern = new PatternLayout("%d{ABSOLUTE} %5p %c{1}:%L - %m%n");
		Appender newAppender = null;
		newAppender = new FileAppender(pattern, path, true);
		
		rootLogger.setAdditivity( false );
		rootLogger.setLevel( Level.INFO );
		rootLogger.addAppender( newAppender );
		
		return rootLogger;
	}

	public static void logDebug( String message ){
		Logger.getLogger( logFileName ).debug( message );
	}
	
	public static void logDebug( String message, Exception e ){
		Logger.getLogger( logFileName ).debug( message, e );
	}
	
	public static void logError( String message ){
		Logger.getLogger( logFileName ).error( message );
	}
	
	public static void logError( String message, Exception e ){
		Logger.getLogger( logFileName ).error( message, e );
	}
	
	public static void logInfo( String message ){
		Logger.getLogger( logFileName ).info( message );
	}
	
	public static void logInfo( String message, Exception e ){
		Logger.getLogger( logFileName ).info( message, e );
	}
	
	public static void logWarn( String message ){
		Logger.getLogger( logFileName ).warn( message );
	}
	
	public static void logWarn( String message, Exception e ){
		Logger.getLogger( logFileName ).warn( message, e );
	}
}