/**
 * 
 */
package com.ubs.manhatthan.manager.dto;

import java.util.ArrayList;
import java.util.List;

import com.ubs.manhatthan.manager.enums.StrategyTypeEnum;

/**
 * @author galdinoa
 *
 */
public class ReceiveSynthetic {
	
	public ReceiveSynthetic(){
		this.syntheticList = new ArrayList<ReceiveSymbolSyntheticItem>();
		this.strategyType = StrategyTypeEnum.UNKNOWN;
	}
	
	private StrategyTypeEnum strategyType;
	private List<ReceiveSymbolSyntheticItem> syntheticList;
	
	public StrategyTypeEnum getStrategyType() {
		return strategyType;
	}
	
	public void setStrategyType(StrategyTypeEnum type) {
		this.strategyType = type;
	}
	
	public List<ReceiveSymbolSyntheticItem> getSyntheticList() {
		return syntheticList;
	}
	
	public void setSyntheticList(List<ReceiveSymbolSyntheticItem> syntheticList) {
		this.syntheticList = syntheticList;
	}

	@Override
	public String toString() {
		return "ReceiveSynthetic [strategyType=" + strategyType
				+ ", syntheticList=" + syntheticList + "]";
	}
}