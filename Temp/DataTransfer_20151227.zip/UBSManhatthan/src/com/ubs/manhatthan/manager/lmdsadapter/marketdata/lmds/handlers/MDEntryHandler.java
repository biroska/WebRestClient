package com.ubs.manhatthan.manager.lmdsadapter.marketdata.lmds.handlers;

import java.math.BigDecimal;
import java.util.Date;

import quickfix.FieldNotFound;
import quickfix.Group;
import quickfix.field.MDEntryDate;
import quickfix.field.MDEntryPositionNo;
import quickfix.field.MDEntryPx;
import quickfix.field.MDEntrySize;
import quickfix.field.MDEntryTime;
import quickfix.field.MDEntryType;
import quickfix.field.MDUpdateAction;
import quickfix.field.NumberOfOrders;
import quickfix.field.SecurityExchange;
import quickfix.field.Symbol;
import quickfix.field.TradeCondition;

import com.ubs.manhatthan.manager.lmdsadapter.marketdata.basicimplementation.BasicBookEntry;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.basicimplementation.BasicIncrementalBookUpdate;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.basicimplementation.BasicTrade;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.BookEntry;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.IncrementalBookUpdate;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.IncrementalBookUpdate.IncrementalUpdateType;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.Side;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.Trade;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.manager.MDManager;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.manager.MDManagerFactory;

public class MDEntryHandler implements Handler<Group>
{
	private final static char MDENTRY_AGGREGATED_BID = 'e';
	private final static char MDENTRY_AGGREGATED_OFFER = 'f';
	
	private final MDEntryDate mdEntryDate;
	private final MDEntryTime mdEntryTime;
	private MDManager manager;
	private String symbol;
	private long incrementalId;

	public MDEntryHandler()
	{
		this.mdEntryDate = new MDEntryDate();
		this.mdEntryTime = new MDEntryTime();
	}
	
	public void setManager(MDManager manager, String symbol) {
		this.manager = manager;
		this.symbol = symbol;
	}
	
	public void setManagerFromGroup(Group event) throws FieldNotFound {

		this.symbol = event.getString(Symbol.FIELD);
		String exchange = event.getString(SecurityExchange.FIELD);
		
		this.manager = MDManagerFactory.getManager(exchange);
	}

	@Override
	public void handle(Group event)
	{
		
		if (symbol == null || manager == null)
			return;
			
		
		try
		{
			char mdEntryType = event.getChar(MDEntryType.FIELD);

			switch (mdEntryType) {
			case MDENTRY_AGGREGATED_BID:
			case MDENTRY_AGGREGATED_OFFER:
				//System.out.println("Received BOOK from symbol: " + symbol + ", event: " + event );
				handleBookUpdate(event);
				break;
			case MDEntryType.TRADE:
				//System.out.println("Received TRADE from symbol: " + symbol);
				handleTrade(event);
				break;
			case MDEntryType.BID:
			case MDEntryType.OFFER:
			{
				//System.out.println("Received BOOK from symbol: " + symbol);
				break;
			}
			default:
				break;
			}
			
		} catch (FieldNotFound e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
	}
	
	protected void handleBookUpdate(Group event) throws FieldNotFound
	{

		Side side = event.getChar(MDEntryType.FIELD) == MDENTRY_AGGREGATED_BID ? Side.BUY : Side.SELL;
		
		long size = event.isSetField(MDEntrySize.FIELD) ? (long) event.getDouble(MDEntrySize.FIELD) : 0;
		BigDecimal price = event.isSetField(MDEntryPx.FIELD) ?  event.getDecimal(MDEntryPx.FIELD) : BigDecimal.ZERO;	

		event.getField(mdEntryDate);
		event.getField(mdEntryTime);
		
		//long timestamp = MDEntryHandler.getTimestamp(mdEntryDate, mdEntryTime);
		
		int numberoforders = event.getInt(NumberOfOrders.FIELD);
		
		BookEntry entry = new BasicBookEntry(side, size, price, true, numberoforders);

		int position = event.getInt(MDEntryPositionNo.FIELD) - 1;
		
		
		
		IncrementalBookUpdate.IncrementalUpdateType updateType;
		if (event.isSetField(MDUpdateAction.FIELD)) {
			switch (event.getChar(MDUpdateAction.FIELD)) {
			case MDUpdateAction.NEW:
				updateType = IncrementalUpdateType.ADD;
				break;
			case MDUpdateAction.DELETE:
				updateType = IncrementalUpdateType.DELETE;
				break;
			case MDUpdateAction.CHANGE:
				updateType = IncrementalUpdateType.UPDATE;
				break;
			default:
				updateType = IncrementalUpdateType.ADD;
				break;
			}
		} else {
			updateType = IncrementalUpdateType.ADD;
		}
		
		IncrementalBookUpdate update = new BasicIncrementalBookUpdate(updateType, position, entry, incrementalId++);
		this.manager.updateBook(symbol, update);
		
	}
	
	protected void handleTrade(Group event) throws FieldNotFound {
		
		long size = (long) event.getDouble(MDEntrySize.FIELD);
		BigDecimal price = event.getDecimal(MDEntryPx.FIELD);		
		
		if (event.isSetField(TradeCondition.FIELD)) {
			System.out.println(event.getString(TradeCondition.FIELD));
		}
		
		event.getField(mdEntryDate);
		event.getField(mdEntryTime);
		
		Date timestamp = new Date(MDEntryHandler.getTimestamp(mdEntryDate, mdEntryTime));
		
		Trade trade = new BasicTrade(price, size, timestamp);
		
		this.manager.updateTrade(symbol, trade);
		
	}
	
	public static long getTimestamp(MDEntryDate date, MDEntryTime time) {
		return date.getValue().getTime() + time.getValue().getTime();
	}

}
