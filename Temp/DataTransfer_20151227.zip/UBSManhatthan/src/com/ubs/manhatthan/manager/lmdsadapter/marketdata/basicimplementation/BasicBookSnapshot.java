package com.ubs.manhatthan.manager.lmdsadapter.marketdata.basicimplementation;

import java.util.Arrays;
import java.util.List;

import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.BookEntry;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.BookSnapshot;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.Security;

/**
 * Basic snapshot implementation
 * 
 * @author pretof
 *
 */
public class BasicBookSnapshot implements BookSnapshot {
	
	private final BookEntry[] buyEntries;
	private final BookEntry[] sellEntries;
	private final int buySize;
	private final int sellSize;
	private final Security security;
	private final long lastIncrementalID;
	
	public BasicBookSnapshot(Security security, int depth, List<BookEntry> bids, List<BookEntry> asks, long lastIncrementalID) {
		
		this.security = security;
		this.buyEntries = new BookEntry[depth];
		this.sellEntries = new BookEntry[depth];
		this.lastIncrementalID = lastIncrementalID;
		
		int i;
		
		i = 0;
		for (BookEntry entry : bids) {
			
			if (i >= depth) break;
			
			buyEntries[i] = entry;
			
			i++;
		}
		this.buySize = i;
		
		i = 0;
		for (BookEntry entry : asks) {
			
			if (i >= depth) break;
			
			sellEntries[i] = entry;
			
			i++;
		}
		this.sellSize = i;
		
	}

	@Override
	public Security getSecurity() {
		return this.security;
	}

	@Override
	public boolean isEmpty() {
		return (this.buySize + this.sellSize == 0);
	}

	@Override
	public int getBidSize() {
		return this.buySize;
	}

	@Override
	public int getAskSize() {
		return this.sellSize;
	}

	@Override
	public BookEntry getBidAt(int position) {
		return (position < this.buyEntries.length) ? this.buyEntries[position] : null;
	}

	@Override
	public BookEntry getAskAt(int position) {
		return (position < this.sellEntries.length) ? this.sellEntries[position] : null;
	}

	@Override
	public long getLastIncrementalID() {
		return this.lastIncrementalID;
	}

	@Override
	public String toString() {
		return "BasicBookSnapshot [buyEntries=" + Arrays.toString(buyEntries)
				+ ", sellEntries=" + Arrays.toString(sellEntries)
				+ ", buySize=" + buySize + ", sellSize=" + sellSize
				+ ", security=" + security + ", lastIncrementalID="
				+ lastIncrementalID + "]";
	}

	
	
}
