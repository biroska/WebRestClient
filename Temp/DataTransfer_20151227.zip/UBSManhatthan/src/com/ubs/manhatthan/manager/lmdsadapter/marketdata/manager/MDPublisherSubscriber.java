package com.ubs.manhatthan.manager.lmdsadapter.marketdata.manager;

import java.util.HashMap;
import java.util.HashSet;

import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.BookSnapshot;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.Trade;

/**
 * This is a simple publish/subscriber for book and trades.
 * 
 * @author pretof
 *
 */
final class MDPublisherSubscriber {
	
	HashMap<String, HashSet<MDSubscriberHandler>> subscribers = new HashMap<>();
	
	public synchronized boolean subscribe(String symbol, MDSubscriberHandler subscriber) {
		
		if (!subscribers.containsKey(symbol)) {
			this.subscribers.put(symbol, new HashSet<MDSubscriberHandler>());
		}
		
		return this.subscribers.get(symbol).add(subscriber);
		
	}
	
	public synchronized void remove(String symbol, MDSubscriberHandler subscriber) {
		
		if (subscribers.containsKey(symbol)) {	
			if (subscribers.get(symbol).remove(subscriber)) {

				if (subscribers.get(symbol).size() == 0) {
					subscribers.remove(symbol);
				}
				
			}
		}		
	}
	
	public synchronized void publishBook(String symbol, BookSnapshot bookSnapshot) {	

		if (subscribers.containsKey(symbol)) {	
			HashSet<MDSubscriberHandler> ss = subscribers.get(symbol);			
			for (MDSubscriberHandler s : ss) {
				s.onBookUpdate(symbol, bookSnapshot);
			}			
		}		
		
	}
	
	
	public synchronized void publishTrade(String symbol, Trade trade) {	
		
		if (subscribers.containsKey(symbol)) {	
			HashSet<MDSubscriberHandler> ss = subscribers.get(symbol);			
			for (MDSubscriberHandler s : ss) {
				s.onTrade(symbol, trade);
			}			
		}		
		
	}
	
	
	
}
