package com.ubs.manhatthan.manager.persistence.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name="TB_TRADERS",
	   uniqueConstraints={
			@UniqueConstraint(columnNames={"LOGIN"}, name = "CK_TRADERS_LOGIN") ,
			@UniqueConstraint(columnNames={"ENTERING_TRADER"}, name = "CK_TRADERS_ENTERING_TRADER")
		})
public class Trader {
	
	public Trader(){}
	
	public Trader(String username ) {
		super();
		this.username = username;
		this.enable = true;
	}
	
	public Trader(String username, String login, String password, Date passwordLastModification, Profile profile, boolean enable) {
		super();
		this.username = username;
		this.login = login;
		this.password = password;
		this.passwordLastModification = passwordLastModification;
		this.profile = profile;
		this.enable = enable;
	}
	
	public Trader(Long id, String username, String login,
			String enteringTrader, Profile profile, String password,
			Date passwordLastModification, boolean enable) {
		super();
		this.id = id;
		this.username = username;
		this.login = login;
		this.enteringTrader = enteringTrader;
		this.profile = profile;
		this.password = password;
		this.passwordLastModification = passwordLastModification;
		this.enable = enable;
	}

	@Id
	@Column ( name = "ID")
	@SequenceGenerator(name = "TB_TRADERS_ID_GENERATOR", sequenceName = "SEQ_TRADERS", allocationSize = 1)
	@GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "TB_TRADERS_ID_GENERATOR" )
	private Long id;
	
	@Column ( name = "NAME", nullable=false, length = 64 )
	private String username;
	
	@Column ( name = "LOGIN", nullable=false, length = 64 )
	private String login;
	
	@Column ( name = "ENTERING_TRADER", nullable=false, length = 10 )
	private String enteringTrader;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "PROFILE", nullable = false )
	private Profile profile;
	
	@Column ( name = "PASSWORD", nullable=false, length = 256 )
	private String password;
	
	@Temporal ( TemporalType.TIMESTAMP )
	@Column ( name = "PASSWORD_LAST_MODIFICATION" )
	private Date passwordLastModification;
	
	@Column ( name = "ENABLED", nullable=false )
	private boolean enable;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getEnteringTrader() {
		return enteringTrader;
	}

	public void setEnteringTrader(String enteringTrader) {
		this.enteringTrader = enteringTrader;
	}

	public Profile getProfile() {
		return profile;
	}

	public void setProfile(Profile profile) {
		this.profile = profile;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Date getPasswordLastModification() {
		return passwordLastModification;
	}

	public void setPasswordLastModification(Date passwordLastModification) {
		this.passwordLastModification = passwordLastModification;
	}

	public boolean isEnable() {
		return enable;
	}

	public void setEnable(boolean enable) {
		this.enable = enable;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (enable ? 1231 : 1237);
		result = prime * result
				+ ((enteringTrader == null) ? 0 : enteringTrader.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((login == null) ? 0 : login.hashCode());
		result = prime * result
				+ ((password == null) ? 0 : password.hashCode());
		result = prime
				* result
				+ ((passwordLastModification == null) ? 0
						: passwordLastModification.hashCode());
		result = prime * result + ((profile == null) ? 0 : profile.hashCode());
		result = prime * result
				+ ((username == null) ? 0 : username.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Trader other = (Trader) obj;
		if (enable != other.enable)
			return false;
		if (enteringTrader == null) {
			if (other.enteringTrader != null)
				return false;
		} else if (!enteringTrader.equals(other.enteringTrader))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (login == null) {
			if (other.login != null)
				return false;
		} else if (!login.equals(other.login))
			return false;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		if (passwordLastModification == null) {
			if (other.passwordLastModification != null)
				return false;
		} else if (!passwordLastModification
				.equals(other.passwordLastModification))
			return false;
		if (profile == null) {
			if (other.profile != null)
				return false;
		} else if (!profile.equals(other.profile))
			return false;
		if (username == null) {
			if (other.username != null)
				return false;
		} else if (!username.equals(other.username))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Trader [id=" + id + ", username=" + username + ", login="
				+ login + ", enteringTrader=" + enteringTrader + ", profile="
				+ profile + ", password=" + password
				+ ", passwordLastModification=" + passwordLastModification
				+ ", enable=" + enable + "]";
	}
}