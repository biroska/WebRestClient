package com.ubs.manhatthan.manager.mocks;

import java.util.ArrayList;
import java.util.List;

import com.ubs.manhatthan.manager.persistence.entities.AccountType;

public class AccountTypeMock {
	
	public AccountTypeMock(){}
	
	public List<AccountType> insert( int qtd ){
		
		ArrayList<AccountType> accountTypeList = new ArrayList<AccountType>();
		
		for ( int i = 0; i<= qtd; i++ )
			accountTypeList.add( new AccountType( "AccountType_" + i  ) );
		
		return accountTypeList;
	}
	
	public AccountType getAccountTypeByIndex( int index ) {
		
//		CriteriaBuilder criteriaBuilder =  FactoryManager.getEntityManager().getCriteriaBuilder();
//
//		CriteriaQuery<AccountType> criteriaQuery = criteriaBuilder.createQuery(AccountType.class);
//		Root<AccountType> accountTypeRoot = criteriaQuery.from(AccountType.class);
//
//		criteriaQuery.select( accountTypeRoot );
//
//		List<AccountType> accountType = FactoryManager.getEntityManager().createQuery(criteriaQuery).getResultList();

//		return accountType.get( index );
		
		return null;
	}
	
}