package com.ubs.manhatthan.manager.persistence.dao;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IClientAccountDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IOrderTradeAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IOrderTradeDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IStrategyOrdersDAO;
import com.ubs.manhatthan.manager.persistence.entities.OrderTrade;
import com.ubs.manhatthan.manager.persistence.entities.audit.OrderTradeAudit;

@Repository
@Scope("singleton")
public class OrderTradeDAO extends GenericDAO<OrderTrade, Long> implements IOrderTradeDAO {

	
	@Autowired
	private IStrategyOrdersDAO strategyOrdersDAO;
	
	@Autowired
	private IClientAccountDAO clientAccountDAO;

	@Autowired
	private IOrderTradeAuditDAO orderTradeAuditDAO;
	
	@Autowired
	private User user;
	
	@Override
	public OrderTrade saveOrderTrade( OrderTrade orderTrade ) throws DAOExceptionManhattan {
		
		try {
			ActionTypeEnum action = orderTrade.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;
			
			orderTrade.setOrderTimestamp( new Date() );
	
			orderTrade  = update( orderTrade );
	
			OrderTradeAudit teca = new OrderTradeAudit( orderTrade, action, user.getLogin(), new Date() );
			
			orderTradeAuditDAO.update( teca );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return orderTrade;
	}
	
	public Long generate( int qtd ) throws DAOExceptionManhattan {
		
		Long qtRegs = 0L;
		
//		StrategyOrders strategyOrder = strategyOrdersDAO.getByIndex( 0 );
//		List<ClientAccount> clientAccountList = clientAccountDAO.findAll();
//		
//		for ( int i = 1; i<= qtd; i++ ){
//			saveOrderTrade( new OrderTrade( strategyOrder, OrderStatusEnum.REPLACED , "SYMBOL",
//					                        SideEnum.fromValue( (i % 2) +1 ) ,
//					                        clientAccountList.get( i % 5), "TRADE_"+i,  i * 25L, (Math.random() * i * 100) ) );
//			qtRegs++;
//		}
		
		return qtRegs;
	}
	
	public void setStrategyOrdersDAO(IStrategyOrdersDAO strategyOrdersDAO) {
		this.strategyOrdersDAO = strategyOrdersDAO;
	}

	public void setClientAccountDAO(IClientAccountDAO clientAccountDAO) {
		this.clientAccountDAO = clientAccountDAO;
	}

	public void setOrderTradeAuditDAO(IOrderTradeAuditDAO orderTradeAuditDAO) {
		this.orderTradeAuditDAO = orderTradeAuditDAO;
	}

	public void setUser(User user) {
		this.user = user;
	}
}