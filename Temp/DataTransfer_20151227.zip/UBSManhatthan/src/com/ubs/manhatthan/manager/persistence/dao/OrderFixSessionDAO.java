package com.ubs.manhatthan.manager.persistence.dao;

import java.util.Date;
import java.util.List;

import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.exception.BussinessExceptionManhattan;
import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.persistence.dao.audit.OrderFixSessionAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IExchangeDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IOrderFixSessionAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IOrderFixSessionDAO;
import com.ubs.manhatthan.manager.persistence.entities.Exchange;
import com.ubs.manhatthan.manager.persistence.entities.OrderFixSession;
import com.ubs.manhatthan.manager.persistence.entities.audit.OrderFixSessionAudit;

@Repository
@Scope("singleton")
public class OrderFixSessionDAO extends GenericDAO<OrderFixSession, Integer> implements IOrderFixSessionDAO {
	
    private final String queryByEngine = " SELECT  new OrderFixSession( o.orderFixSession.id , " +
            "                                 	o.orderFixSession.exchange , " + 
            "                                 	o.orderFixSession.host , " + 
            "                     				o.orderFixSession.port, " +
            "                                 	o.orderFixSession.targetCompId, " +
            "									o.orderFixSession.senderCompId, " +
            "									o.orderFixSession.password, " +
            "									o.orderFixSession.description, " +
            "									o.engine.id, " +
            "                                 	o.engine.engineId)" +
            "   							FROM SessionByEngine o ";

    @Autowired
	private IExchangeDAO exchangeDAO;

	@Autowired
	private IOrderFixSessionAuditDAO orderFixSessionAuditDAO;
	
	@Autowired
	private User user;
	
	@Override
	public OrderFixSession saveOrderFixSession( OrderFixSession orderFixSession, ActionTypeEnum action) throws DAOExceptionManhattan, BussinessExceptionManhattan {
		try {
			
			if (action!=null && action.equals(ActionTypeEnum.INSERT)) {
				
				OrderFixSession orderFixSessionExist = findById(orderFixSession.getId());
				boolean exist = verifyExistRegisterWithSameHostPort(orderFixSession.getHost(), orderFixSession.getPort());
				if (orderFixSessionExist!=null) {
					throw new BussinessExceptionManhattan("OrderFixSession already exist!");
				}else if(exist){
					throw new BussinessExceptionManhattan("Already exist an OrderFixSession with same Host and Port!");
				}
				
			}
	
			orderFixSession  = update( orderFixSession );
	
			OrderFixSessionAudit ofsa = new OrderFixSessionAudit( orderFixSession, action, user.getLogin(), new Date() );
			
			orderFixSessionAuditDAO.save( ofsa );
		} catch ( BussinessExceptionManhattan e ) {
			throw e;
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return orderFixSession;
	}
	
	@Override
	public void delete( OrderFixSession orderFixSession ) throws DAOExceptionManhattan {
		try {
			deleteById(orderFixSession.getId());
			
			OrderFixSessionAudit pa = new OrderFixSessionAudit( orderFixSession, ActionTypeEnum.DELETE, user.getLogin(), new Date() );
			
			orderFixSessionAuditDAO.update( pa );
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<OrderFixSession> getOrderFixByAccount( Long accountId ) throws DAOExceptionManhattan {
		
		 String query = "	SELECT FIX_SES.ID, FIX_SES.DESCRIPTION, FIX_SES.HOST,  " +
						"       FIX_SES.PASSWORD, FIX_SES.PORT, FIX_SES.SENDER_COMP_ID, " +
						"       FIX_SES.TARGET_COMP_ID, FIX_SES.EXCHANGE " +
						"  FROM TB_ORDER_FIX_SESSION FIX_SES , " +
						"       TB_REL_SESSIONS_PER_ACCOUNT REL_SA " +
						" WHERE REL_SA.SESSION_ID = FIX_SES.ID  " +
						"   AND REL_SA.ACCOUNT_ID = :accountId ";
		
		List<OrderFixSession> resultList = null;
		try {
			Query createNativeQuery = getEm().createNativeQuery( query, OrderFixSession.class);
			createNativeQuery.setParameter("accountId", accountId);
			
			resultList = createNativeQuery.getResultList();
			
		} catch ( Exception e ){
			e.printStackTrace();
			throw new DAOExceptionManhattan( e );
		}
		return resultList;
	}
	
	public Long generateOrderFixSession( int qtd ) throws DAOExceptionManhattan {
		
		Long qtRegs = 0L;
		
		List<Exchange> allExchanges = exchangeDAO.findAll();
		
		for ( int i = 1; i<= qtd; i++ ){
			//saveOrderFixSession(  new OrderFixSession( allExchanges.get( i % 2 ), "255.255.255." + i, 8070L + i, "BVMF_" + i, "UBS_" + i, "123456" ,"description" ) );
			qtRegs++;
		}
		
		return qtRegs;
	}
	
	@Override
	public List<OrderFixSession> getOrderFixSessions() throws DAOExceptionManhattan {
		List<OrderFixSession> resultList = null;
		try {
			TypedQuery<OrderFixSession> typedQuery = getEm().createQuery( queryByEngine, OrderFixSession.class );
			
			resultList = typedQuery.getResultList();
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return resultList;
	}
	
	public boolean verifyExistRegisterWithSameHostPort(String host, Long port) throws DAOExceptionManhattan{		
		
		boolean exist = false;
		List<Integer> resultList = null;
		try {
			
			if (host!=null && port!=null) {
				String query = " SELECT  tab.id " +
		            	   " FROM OrderFixSession tab "
		            	   + " WHERE tab.host = :host "
		            	   + " AND tab.port = :port ";
			
				TypedQuery<Integer> typedQuery = getEm().createQuery( query, Integer.class );
				typedQuery.setParameter("host", host);
				typedQuery.setParameter("port", port);
				
				resultList = typedQuery.getResultList();
				if (resultList!=null && !resultList.isEmpty()) {
					exist = true;
				}
			}			
			
		} catch ( Exception e ) {
			throw new DAOExceptionManhattan( e );
		}
		
		return exist;		
	}

	public void setExchangeDAO(ExchangeDAO exchangeDAO) {
		this.exchangeDAO = exchangeDAO;
	}
	
	public void setOrderFixSessionAuditDAO(OrderFixSessionAuditDAO orderFixSessionAuditDAO) {
		this.orderFixSessionAuditDAO = orderFixSessionAuditDAO;
	}

	public void setUser(User user) {
		this.user = user;
	}
}
