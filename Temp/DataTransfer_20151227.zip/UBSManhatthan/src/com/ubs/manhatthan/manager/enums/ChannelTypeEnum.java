package com.ubs.manhatthan.manager.enums;

import java.util.ArrayList;
import java.util.List;

import com.ubs.manhatthan.admin.model.ChannelType;

public enum ChannelTypeEnum {
	
    MBP   ( "market by price" ) , 
    MBO   ( "market by order" ) ,
    TOP   ( "top of the book" );
    
    private final String description;
    
    private ChannelTypeEnum( String desc ) {
        this.description = desc;
    }

    public String getDescription() {
        return description;
    }
    
    public String getName() {
    	return this.name();
    }
    
    public static ChannelTypeEnum fromValue( String value ){
    	
		for (ChannelTypeEnum item : ChannelTypeEnum.values() ) {
			if ( item.name().equals( value ) ){
				return item;
			}
		}
		return null;
    }
    
    public static List<ChannelType> convertToList() {
    	
    	List<ChannelType> channelTypes = new ArrayList<ChannelType>();
    	
		for (ChannelTypeEnum item : ChannelTypeEnum.values() ) {
			channelTypes.add(new ChannelType(item.name(), item.description));
		}
		
		return channelTypes;
    }
}