/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import com.ubs.manhatthan.manager.persistence.entities.audit.ProfileAudit;

/**
 * @author galdinoa
 *
 */
public interface IProfileAuditDAO extends IGenericDAO<ProfileAudit, Long> {}
