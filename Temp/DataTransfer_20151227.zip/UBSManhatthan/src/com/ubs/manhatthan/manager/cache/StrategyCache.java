package com.ubs.manhatthan.manager.cache;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Level;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.enums.StrategyStateEnum;
import com.ubs.manhatthan.manager.lmdsadapter.LmdsManager;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.SecurityDefinition;
import com.ubs.manhatthan.manager.logger.ApplicationLogger;
import com.ubs.manhatthan.manager.logger.ManhattanLogger;
import com.ubs.manhatthan.manager.network.client.NetworkClientManager;
import com.ubs.manhatthan.manager.persistence.entities.LegStrategyReport;
import com.ubs.manhatthan.manager.persistence.entities.Message;
import com.ubs.manhatthan.manager.persistence.entities.Strategy;
import com.ubs.manhatthan.manager.persistence.entities.StrategyOrders;
import com.ubs.manhatthan.manager.persistence.entities.StrategyReport;
import com.ubs.manhatthan.manager.persistence.entities.id.LegStrategyReportPK;
import com.ubs.manhatthan.manager.persistence.entities.id.StrategyOrdersPK;
import com.ubs.manhatthan.manager.persistence.entities.id.StrategyReportPK;
import com.ubs.manhatthan.manager.utils.Constant;
import com.ubs.manhatthan.manager.utils.Util;

public class StrategyCache {
	
//	Map por user, cont�m todas as mensagens para o usu�rio
	public static ConcurrentHashMap< String, LinkedList<Strategy> > messageUserCache;
	public static ConcurrentHashMap< String, LinkedList<Strategy> > messageSupervisorCache;
	public static ConcurrentHashMap< String, LinkedList<Strategy> > messageHistoricalCache;
	
	private static Long requestId = 0L;
	private static Long maxRequestId = 9_223_372_036_854_775_807L;
	
	public static ConcurrentHashMap< StrategyReportPK, StrategyReport > strategyReportMap;
	public static ConcurrentHashMap< LegStrategyReportPK, LegStrategyReport > legStrategyReportMap;
	public static ConcurrentHashMap< StrategyOrdersPK, StrategyOrders > strategyOrderMap;
//	public static ConcurrentHashMap< StrategyOrdersPK, StrategyOrders > leggedOrderMap;
	
	public static ConcurrentHashMap< Long, StrategyReport > StrategyReportMapByRequestId;
	public static ConcurrentHashMap< Long, StrategyOrders > StrategyOrderMapByRequestId;
	
	private static ArrayList<StrategyReportPK> auxListStrategyReport;
	private static ArrayList<LegStrategyReportPK> auxListLegStrategyReport;
	
	private static LmdsManager lmds;
	
	
	static {
		// Map used to keep StrategyReport after persist
		strategyReportMap = new ConcurrentHashMap< StrategyReportPK, StrategyReport >();

		// Map used to keep LegStrategyReport after persist and avoid search the leg in all itens of strategyReportMap
		legStrategyReportMap = new ConcurrentHashMap< LegStrategyReportPK, LegStrategyReport >();
		
		// Map used to keep StrategyOrders after persist and avoid search the Order in all legs o each item of strategyReportMap
		strategyOrderMap = new ConcurrentHashMap< StrategyOrdersPK, StrategyOrders >();
		
		// Map used to keep Legged orders. This map is filled by the engine and consumed by view 
//		leggedOrderMap = new ConcurrentHashMap< StrategyOrdersPK, StrategyOrders >();
		
//		Map used to keep the information before sending the message to Engine, these maps are used 
//		to retrieve the original information in case of a rejection message
		StrategyReportMapByRequestId = new ConcurrentHashMap< Long, StrategyReport >();
		StrategyOrderMapByRequestId = new ConcurrentHashMap< Long, StrategyOrders >();
		
		auxListStrategyReport = new ArrayList<StrategyReportPK>( strategyReportMap.keySet() );
		auxListLegStrategyReport = new ArrayList<LegStrategyReportPK>( legStrategyReportMap.keySet() );
		
		messageUserCache = new ConcurrentHashMap< String, LinkedList<Strategy> >();
		messageSupervisorCache = new ConcurrentHashMap< String, LinkedList<Strategy> >();
		messageHistoricalCache = new ConcurrentHashMap< String, LinkedList<Strategy> >();
	}
	
	public static void putLegStrategyList( List<LegStrategyReport> list ) {
		
		if ( list != null ){
			for (LegStrategyReport leg : list) {
				if ( !legStrategyReportMap.containsKey( leg.getId() ) ){
					legStrategyReportMap.put( leg.getId(), leg );
				}
			}
		}
	}
	
	public static List<LegStrategyReport> getLegStrategyReportByStrategyId( Long strategyId ){
		List<LegStrategyReport> list = new ArrayList<LegStrategyReport>();
		
		for ( LegStrategyReportPK pk : legStrategyReportMap.keySet() ) {
			if ( pk.getStrategyId().equals( strategyId ) )
				list.add( legStrategyReportMap.get( pk )  );
		}
		
		return list.isEmpty() ? null : list;
	}
	
	public static List<LegStrategyReport> getLegStrategyReportList( StrategyReport report ){
	
		if ( report == null || report.getId() == null )
			return null;
		
		List<LegStrategyReport> list = new ArrayList<LegStrategyReport>();
		
		for ( LegStrategyReportPK key : StrategyCache.legStrategyReportMap.keySet() ) {
			if ( key.getStrategyId().equals( report.getId() ) ){
				list.add( legStrategyReportMap.get( key ) );
			}
		}
		return list;
	}
	
	public static StrategyReport putStrategyReport( StrategyReport report ){
		
		if ( report != null ){
			
			strategyReportMap.put( report.getId(), report );
			
			if ( report.getLegStrategyList() != null && !report.getLegStrategyList().isEmpty() ){
				
				for (LegStrategyReport leg : report.getLegStrategyList() ) {
					legStrategyReportMap.put( leg.getId(), leg );
				}
			}
			
		}
		return report;
	}
	
	public static StrategyOrders putStrategyOrder( StrategyOrders order ){
		
		if ( order != null ){
			strategyOrderMap.put( order.getId(), order);
		}
		
		return order;
	}
	
	public static StrategyOrders putLeggedOrder( StrategyOrders order ){
		
		if ( order != null ){
		}
		
		return order;
	}
	
	public static Message removeMessage( String requestIdFromView ){
		
		if ( StringUtils.isBlank( requestIdFromView ) )
			return null;
		
//		Sen�o encontrar o de para do requestId no mapa retorna null
		if ( requestId == null )
			return null;
		
		removeMessagesFromCache( requestId );
		return null;
	}
	
	private static void removeMessagesFromCache( Long requestId ){
		
		StrategyReport remove = StrategyReportMapByRequestId.remove( requestId );
				
		if ( remove != null && remove.getId() != null ){
			StrategyReport reportRemove = strategyReportMap.remove( remove.getId() );
			
			if ( reportRemove != null && reportRemove.getLegStrategyList() != null && !reportRemove.getLegStrategyList().isEmpty() ){
				for (LegStrategyReport leg : reportRemove.getLegStrategyList() ) {
					if ( leg.getId() != null )
						legStrategyReportMap.remove( leg.getId() );
				}
			}
		}
		
		StrategyOrders removeOrder = StrategyOrderMapByRequestId.remove( requestId );
		
		if ( removeOrder != null && removeOrder.getId() != null ){
		
		}
	}
	

	public static Long generateRequestId() {

		if ( requestId >= maxRequestId ) {
			requestId = 0L;
		}

		return requestId++;
	}
	
	public synchronized static List<Strategy> getAllMessages(){
		
		if ( messageHistoricalCache == null || messageHistoricalCache.isEmpty() )
			return null;
		
		Set<String> keySet = messageHistoricalCache.keySet();
		List<Strategy> list_result = new ArrayList<Strategy>();
		
		for (String key : keySet) {
			
			List<Strategy> list_temp = messageHistoricalCache.get(key);
			
			if (list_temp != null) {
				
//				Da lista original, que foi extraida do cache, copiamos as msg que existe simbolo no lmds
				List<Strategy> msgToSend = messagesWithLmdsSymbol( list_temp );
				
//				Da lista original, que foi extraida do cache, removemos as msg que ser�o enviadas, 
//				as remanescentes ser�o devolvidas para o cache 
				if ( msgToSend != null && !msgToSend.isEmpty() ){
					list_temp.removeAll( msgToSend );
					if ( list_temp != null && !list_temp.isEmpty() ){
						for (Strategy msg : list_temp) {
							putMessage( key, msg, messageHistoricalCache );
						}
					}
					list_result.addAll( msgToSend );
				}
			}	
		}
		
		ApplicationLogger.logInfo( "[Cache.getAllMessages] Messages removed from the cache: " + list_result );
		
		return list_result;
	}
	
//	public synchronized static List<Strategy> getAllMessages(long counter ){
//		
//		if ( messageSupervisorCache == null || messageSupervisorCache.isEmpty() )
//			return null;
//		
//		Set<String> keySet = messageSupervisorCache.keySet();
//		List<Strategy> list_result = new ArrayList<Strategy>();
//		
//		for (String key : keySet) {
//			
//			List<Strategy> list_temp = messageSupervisorCache.get( key );
//			
//			if (list_temp != null) {
//				for (Strategy strategy : list_temp) {
//					if ( strategy instanceof StrategyReport  ){
//						StrategyReport report = ( StrategyReport ) strategy;
//						if(report.getCounter() > counter) 
//							list_result.add( report );
//					}
//				}
//			}	
//		}
//		return list_result;
//	}
	
	public synchronized static List<Strategy> getMessagesBySupervisor(){
		
		if ( messageSupervisorCache == null || messageSupervisorCache.isEmpty() )
			return null;
		
		Set<String> keySet = messageSupervisorCache.keySet();
		List<Strategy> list_result = new ArrayList<Strategy>();
		
		for (String key : keySet) {
			
			List<Strategy> list_temp = messageSupervisorCache.remove(key);
			
			if (list_temp != null) {
				
//				Da lista original, que foi extraida do cache, copiamos as msg que existe simbolo no lmds
				List<Strategy> msgToSend = messagesWithLmdsSymbol( list_temp );
				
//				Da lista original, que foi extraida do cache, removemos as msg que ser�o enviadas, 
//				as remanescentes ser�o devolvidas para o cache 
				if ( msgToSend != null && !msgToSend.isEmpty() ){
					list_temp.removeAll( msgToSend );
					if ( list_temp != null && !list_temp.isEmpty() ){
						for (Strategy msg : list_temp) {
							putMessage( key, msg, messageSupervisorCache );
						}
					}
					list_result.addAll( msgToSend );
				}
			}	
		}
		
		ApplicationLogger.logInfo( "[Cache.getMessagesBySupervisor] Messages removed from the cache: " + list_result );
		
		return list_result;
	}
	
	
	public synchronized static List<Strategy> getMessagesByUser( String login ){
		
		if ( StringUtils.isBlank( login ) )
			return null;
		
		List<Strategy> list = messageUserCache.remove( login );
		
//		Da lista original, que foi extraida do cache, copiamos as msg que existe simbolo no lmds
		List<Strategy> msgToSend = messagesWithLmdsSymbol( list );

//		Da lista original, que foi extraida do cache, removemos as msg que ser�o enviadas, 
//		as remanescentes ser�o devolvidas para o cache 
		if ( msgToSend != null && !msgToSend.isEmpty() ){
			list.removeAll( msgToSend );
			if ( list != null && !list.isEmpty() ){
				for (Strategy msg : list) {
					putMessage( login, msg, messageUserCache );
				}
			}
		}
		ApplicationLogger.logInfo( "[Cache.getMessagesByUser] will be sent to view: " + msgToSend + " msg mantidas em cache: " + messageUserCache );

		manageDisconectEngineMessage( msgToSend );
		
		ApplicationLogger.logInfo( "[Cache.getMessagesByUser] Messages removed from the cache: " + msgToSend );
		
		return msgToSend;
	}
	
	
	public synchronized static List<Strategy> getMessagesSnapshotByUser( String login ){
		
		if ( StringUtils.isBlank( login ) )
			return null;
		
		List<Strategy> list = messageHistoricalCache.get( login );
		
//		Da lista original, que foi extraida do cache, copiamos as msg que existe simbolo no lmds
		List<Strategy> msgToSend = messagesWithLmdsSymbol( list );

		ApplicationLogger.logInfo( "[Cache.getMessagesByUser] will be sent to view: " + msgToSend + " msg em cache: " + messageHistoricalCache );
		
		manageDisconectEngineMessage( msgToSend );
		
		ApplicationLogger.logInfo( "[Cache] Snapshot from the cache: " + msgToSend );
		
		return msgToSend;
	}
	
	public synchronized static boolean putMessage( String login, Strategy message, ConcurrentHashMap< String, LinkedList<Strategy> > map ){
		
//		Verifica o recebimento dos parametros
		if ( message == null || StringUtils.isBlank( login ) )
			return false;
		
//		Verifica se o usuario j� possui mensagens, se posuir inicia analise, sen�o adiciona no map
		if ( map.containsKey( login ) ) {
		
//			pega a lista de mensagens do usu�rio
			LinkedList<Strategy> messageList = map.get( login );
			
//			Se por alguma raz�o o usuario existir no map (deveria ter mensagens)
//			mas a lista de mensagens � vazia instancia-se uma nova
			if ( messageList == null || messageList.isEmpty() ){
				messageList = new LinkedList<Strategy>();
			}
			
//			M�todo verifica o tipo da inst�ncia do objeto e se deve 
//			ser atualizado ou inserido na lista
			manageMessage( messageList, message );
			
//		O usu�rio ainda n�o possui mensagens ent�o adiciona no map
		} else {
			LinkedList<Strategy> arrayList = new LinkedList<Strategy>();
			arrayList.addLast( message );
			map.put( login, arrayList );
			ApplicationLogger.logInfo( "[Cache] Message added to Cache:  " + message );
			ManhattanLogger.log( ""+Util.getManagerId(), "[Cache] Message added to Cache:  " + message, Level.INFO );
		}
		
		return true;
	}
	
	public synchronized static boolean putMessageByUser( String login, Strategy message ){
		   putMessage(  login,  message, messageHistoricalCache );
		   putMessage(  login,  message, messageSupervisorCache );
		   putMessage(  login,  message, messageUserCache );
	   return true;
	}
	
	public synchronized static List<Strategy> messagesWithLmdsSymbol( List<Strategy> list){
		
		List<Strategy> msgToSend = new ArrayList<Strategy>();
		
		lmds = CacheHelper.lmdsCommunicatorInstance.get( Util.getManagerId() );
		
//		Verifica todas as legs do objeto para tentar recuperar o instrumento/simbolo, se conseguir, disponibiliza para o push
		for (Strategy item : list) {
			if ( item instanceof StrategyReport ){
				StrategyReport report = (StrategyReport) item;
				
				if ( report != null && report.getLegStrategyList() != null && !report.getLegStrategyList().isEmpty() ){
					
					int count = 0;
					
//					conta a qtd de instrumento que conseguem ser recuperados do lmds, se a qtd 
//					coincidir com a qtd de legs , disponibiliza para o push
					for (LegStrategyReport leg : report.getLegStrategyList()) {
						
						if ( leg.getInstrument() == null )
							break;
						
							try {
								SecurityDefinition intrumentDefinition = lmds.getIntrumentDefinitionBySecurityId( ""+leg.getInstrument() );
								
								if ( intrumentDefinition != null && intrumentDefinition.getSecurity() != null &&
									 StringUtils.isNotBlank( intrumentDefinition.getSecurity().getSymbol() ) ){
									ApplicationLogger.logInfo("[StrategyCache.getMessagesByUser] Simbolo: " + intrumentDefinition.getSecurity().getSymbol()  + " Instrumento: " +leg.getInstrument() );
									count++;	
								} else {
									ApplicationLogger.logWarn("[StrategyCache.getMessagesByUser] Simbolo: Null para o Instrumento: " +leg.getInstrument() );
								}
							} catch (DAOExceptionManhattan e) {
								e.printStackTrace();
								ApplicationLogger.logError("[StrategyCache.getMessagesByUser] N�o foi possivel recuperar o simbolo pelo instrumento: " + leg.getInstrument() );
							}
					}
					
					if ( count == report.getLegStrategyList().size() ){
						msgToSend.add( item );
					}
				}
				
			} else {
				if ( item instanceof StrategyOrders ){
					StrategyOrders order = (StrategyOrders) item;
					
					if ( order != null ){
						
						if ( StringUtils.isNotBlank( order.getSymbol() ) ){
							msgToSend.add( item );
						}
					}
				}
			}
		}
		
		return msgToSend;
	}

//	public synchronized static boolean putMessageSupervisor( String login, Strategy message ){
//			putMessage(  login,  message, messageHistoricalCache );
//		return putMessage(  login,  message, messageSupervisorCache );
////		Verifica o recebimento dos parametros
//		if ( message == null || StringUtils.isBlank( login ) )
//			return false;
//		
////		Verifica se o usuario j� possui mensagens, se posuir inicia analise, sen�o adiciona no map
//		if ( messageSupervisorCache.containsKey( login ) ) {
//		
////			pega a lista de mensagens do usu�rio
//			LinkedList<Strategy> messageList = messageSupervisorCache.get( login );
//			
////			Se por alguma raz�o o usuario existir no map (deveria ter mensagens)
////			mas a lista de mensagens � vazia instancia-se uma nova
//			if ( messageList == null || messageList.isEmpty() ){
//				messageList = new LinkedList<Strategy>();
//			}
//			
////			M�todo verifica o tipo da inst�ncia do objeto e se deve 
////			ser atualizado ou inserido na lista
//			manageMessage( messageList, message );
//			
////		O usu�rio ainda n�o possui mensagens ent�o adiciona no map
//		} else {
//			ApplicationLogger.logInfo( "Message added to messageSupervisorCache:  " + message );
//			LinkedList<Strategy> arrayList = new LinkedList<Strategy>();
//			arrayList.addLast( message );
//			messageSupervisorCache.put( login, arrayList );
//		}
//		return true;
//	}
	
	private static void manageDisconectEngineMessage( List<Strategy> list ){
		
		Long engineId;
		NetworkClientManager clientInstance;
		
		if ( list == null || list.isEmpty() )
			return;
		
		for (Strategy strategy : list) {
			if ( strategy instanceof StrategyReport ){
				StrategyReport report = (StrategyReport) strategy;
				
				engineId = report.getHeader().getEngineInstanceId() / 1000;
				
				clientInstance = CacheHelper.engineCommunicatorInstance.get( engineId );
				
				if ( clientInstance == null || !clientInstance.isLoggedOn() ){
					report.setStrategyState( StrategyStateEnum.ERROR );
					report.setText( Constant.MESSAGES_CONFIGURATION.ENGINE_DISCONNECTED );
					continue;
				}
			}
		}
	}
	
	private static void manageMessage( LinkedList<Strategy> messageList, Strategy message ){
		
		StrategyReport reportTemp = null;
		StrategyOrders orderTemp = null;
		
		if ( message instanceof StrategyReport ){
			StrategyReport report = ( StrategyReport ) message;
			
			for (int i = 0; i < messageList.size(); i++) {
				
				Message messageTemp = messageList.get( i );
				
//				Verifica se o tipo de mensagem coincide
				if ( messageTemp instanceof StrategyReport ){
				
					reportTemp = ( StrategyReport ) messageTemp;
					
//					Se for o mesmo tipo de mensagem, verifica se � a mesma mensagem pelo id
//					se for atualiza a referencia
					if ( reportTemp.getId().equals( report.getId() ) ){
						messageList.set( i , message);
						ApplicationLogger.logInfo( "[Cache] Message updated to messageCache:  " + message );
						ManhattanLogger.log( ""+Util.getManagerId(), "[Cache] Message updated to messageCache:  " + message, Level.INFO );						
						return;
					}
				}
			}
			
//			Se a mensagem ainda n�o existir na lista insere-se uma nova
			messageList.addLast( message );
			ApplicationLogger.logInfo( "[Cache] Message added to messageCache:  " + message );
			ManhattanLogger.log( ""+Util.getManagerId(), "[Cache] Message added to messageCache:  " + message, Level.INFO );						
			
			return;
		} else 
			if ( message instanceof StrategyOrders ){
				StrategyOrders order = ( StrategyOrders ) message;
				
				for (int i = 0; i < messageList.size(); i++) {
					
					Message messageTemp = messageList.get( i );
					
//					Verifica se o tipo de mensagem coincide
					if ( messageTemp instanceof StrategyOrders ){
					
						orderTemp = ( StrategyOrders ) messageTemp;
						
//						Se for o mesmo tipo de mensagem, verifica se � a mesma mensagem pelo id
//						se for atualiza a referencia
						if ( orderTemp.getId().equals( order.getId() ) ){
							messageList.set( i , message);
							ApplicationLogger.logInfo( "[Cache] Message updated to messageCache:  " + message );
							ManhattanLogger.log( ""+Util.getManagerId(), "[Cache] Message updated to messageCache:  " + message, Level.INFO );							
							return;
						}
					}
				}
				
//				Se a mensagem ainda n�o existir na lista insere-se uma nova
				messageList.addLast( message );
				ApplicationLogger.logInfo( "[Cache] Message added to messageCache:  " + message );
				ManhattanLogger.log( ""+Util.getManagerId(), "[Cache] Message added to messageCache:  " + message, Level.INFO );
				return;
			}
	}
		
//	m�todos para mock, remover.... aim*

	public static StrategyReportPK getStrategyReportByIndex( Integer index ){
		
		if ( strategyReportMap == null || strategyReportMap.isEmpty() ||
			 index == null || index < 0 )
			return null;
		
		auxListStrategyReport = new ArrayList<StrategyReportPK>( strategyReportMap.keySet() );
		
		if ( auxListStrategyReport.size() > index ){
			StrategyReportPK strategyReportPK = auxListStrategyReport.get( index );
			return strategyReportPK;
		}

		return null;
	}
	
	public static LegStrategyReport getLegStrategyReportByIndex( Integer index ){
		
		if ( index == null || index < 0 )
			return null;
		
		auxListLegStrategyReport = new ArrayList<LegStrategyReportPK>( legStrategyReportMap.keySet() );
			
		if ( auxListLegStrategyReport.size() > index ){
			return legStrategyReportMap.get( auxListLegStrategyReport.get( index ) );
		}
		
		return null;
	}
}