package com.ubs.manhatthan.manager.persistence.entities.converters;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import com.ubs.manhatthan.manager.enums.ExecutionTypeEnum;

@Converter(autoApply = true)
public class ExecutionTypeEnumConverter implements AttributeConverter<ExecutionTypeEnum, Integer> {

	@Override
	public Integer convertToDatabaseColumn(ExecutionTypeEnum executionTypeEnum ) {
		return executionTypeEnum.getCode();
	}

	@Override
	public ExecutionTypeEnum convertToEntityAttribute(Integer dbData) {
		for ( ExecutionTypeEnum et : ExecutionTypeEnum.values() ) {
			if ( et.getCode().equals(dbData) ) {
				return et;
			}
		}

		throw new IllegalArgumentException("Unknown database value:" + dbData );
	}
}