/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import java.util.List;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.persistence.entities.ClientAccount;

/**
 * @author galdinoa
 *
 */
public interface IClientAccountDAO extends IGenericDAO<ClientAccount, Long> {

	List<ClientAccount> findClientAccount(ClientAccount clientAccount) throws DAOExceptionManhattan;

}
