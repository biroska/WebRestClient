package com.ubs.manhatthan.manager.persistence.dao.audit;

import java.io.Serializable;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.manager.persistence.dao.GenericDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IExchangeAuditDAO;
import com.ubs.manhatthan.manager.persistence.entities.audit.ExchangeAudit;

@Repository
@Scope("singleton")
public class ExchangeAuditDAO extends GenericDAO<ExchangeAudit, Long> implements IExchangeAuditDAO, Serializable {}
