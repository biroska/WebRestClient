/**
 * 
 */
package com.ubs.manhatthan.manager.simulator.multileg;


public class Common {
	
	public final Long    PRICE_OUT_OF_BOOK             = 6L;
	public final Double  PU_CONTRACT_MULTIPLIES_CONST  = 100000.0;
	public final Double  PU_TO_PERCENTAGE_CONST        = 100.0;
	public final Double  ANUAL_WORKING_DAYS            = 252.0;
	
	/**
	 * 
	 *
	 */
	public class CalculationInnerResult
	{
		public Double     target;
		public Double     targetDiff;
		public Long[]     rankArray;
		public Long[]     quantityArray;
		public Long[]     availableQuantityArray;
		public Double[]   divOneArray;
		
		public CalculationInnerResult(Integer numberOfLegs)
		{
			target                 = null;
			targetDiff             = null;
			rankArray              = new Long[numberOfLegs];
			quantityArray          = new Long[numberOfLegs];
			availableQuantityArray = new Long[numberOfLegs];
			divOneArray            = new Double[numberOfLegs];
		}
	}

	/**
	 * 
	 * @param leg
	 * @param price
	 * @return
	 */
	public Long searchBuyPriceRank(InputMultilegSimulationItem leg,
								   Double price)
	{
		boolean _skipCouterPart = false;
		if( 0 >= leg.getAskDepth() || null == leg.getAskPrices().get(0) || 0.0 >= leg.getAskPrices().get(0) ) { _skipCouterPart = true; }
		
		int i = 0;
		for(i = 0; i < leg.getBidDepth(); i++)
		{
			if ( null == leg.getBidPrices().get(i) ) { return i+1L; }
				
			if( leg.getBidPrices().get(i) <= price )
			{
				if( !_skipCouterPart && 0 == i && leg.getAskPrices().get(i) <= price )
				{
					return (long) i;
				}
				return i+1L;
			}
		}
		
		if( i == 4) { return PRICE_OUT_OF_BOOK; } else { return (long) i+1; }
	}
	
	/**
	 * 
	 * @param leg
	 * @param price
	 * @return
	 */
	public Long searchSellPriceRank(InputMultilegSimulationItem leg,
			                        Double price)
	{
		boolean _skipCouterPart = false;
		if( 0 >= leg.getBidDepth() || null == leg.getBidPrices().get(0) || 0.0 >= leg.getBidPrices().get(0) ) { _skipCouterPart = true; }
		
		int i = 0;
		for(i = 0; i < leg.getAskDepth(); i++)
		{
			if ( null == leg.getAskPrices().get(i) ) { return i+1L; }
			
			if( leg.getAskPrices().get(i) >= price )
			{
				if( !_skipCouterPart && 0 == i && leg.getBidPrices().get(i) >= price )
				{
					return (long) i;
				}
				return (long) i+1;
			}
		}
		
		if( i == 4) { return PRICE_OUT_OF_BOOK; } else { return (long) i+1; }
	}
	
	public Double calculatePu(Double price,
							  Integer businessDays)
	{
		Double _denominator = Math.pow( ((price/PU_TO_PERCENTAGE_CONST)+1) , (businessDays/ANUAL_WORKING_DAYS) );
		return (PU_CONTRACT_MULTIPLIES_CONST/_denominator);
	}
	
	public Double calculatePuLessOnePoint(Double price,
			                              Integer businessDays)
	{
		Double _denominator = Math.pow( (((price-0.01)/PU_TO_PERCENTAGE_CONST)+1) , (businessDays/ANUAL_WORKING_DAYS) );
		return (PU_CONTRACT_MULTIPLIES_CONST/_denominator);
	}
	
	public Double calculatePuPlusOnePoint(Double price,
                                          Integer businessDays)
	{
		Double _denominator = Math.pow( (((price+0.01)/PU_TO_PERCENTAGE_CONST)+1) , (businessDays/ANUAL_WORKING_DAYS) );
		return (PU_CONTRACT_MULTIPLIES_CONST/_denominator);
	}
	
}
