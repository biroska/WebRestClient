/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import java.util.List;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.persistence.entities.LegStrategyReport;
import com.ubs.manhatthan.manager.persistence.entities.id.LegStrategyReportPK;

/**
 * @author galdinoa
 *
 */
public interface ILegStrategyReportDAO extends IGenericDAO<LegStrategyReport, LegStrategyReportPK> {

	List<LegStrategyReport> findByStrategyId(Long reportId) throws DAOExceptionManhattan;
}
