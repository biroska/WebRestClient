/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.persistence.entities.SessionByAccount;

/**
 * @author galdinoa
 *
 */
public interface ISessionByAccountDAO extends IGenericDAO<SessionByAccount, Long> {

	public SessionByAccount saveOrderFixSession(SessionByAccount sessionByAccount) throws DAOExceptionManhattan;

	public void deleteSessionByAccount(SessionByAccount sessionByAccount) throws DAOExceptionManhattan;
}
