package com.ubs.manhatthan.admin.beans;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.event.ActionEvent;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ubs.manhatthan.exception.BussinessExceptionManhattan;
import com.ubs.manhatthan.manager.cache.CacheHelper;
import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.persistence.entities.EngineInstance;
import com.ubs.manhatthan.manager.persistence.entities.Exchange;
import com.ubs.manhatthan.manager.persistence.entities.OrderFixSession;
import com.ubs.manhatthan.manager.persistence.entities.SessionByEngine;

@SuppressWarnings("serial")
@Component("orderEntryBean")
@Scope("session")
@ViewScoped
@ManagedBean(name="orderEntryBean")
public class OrderEntryBean extends BaseBean {

	private List<OrderFixSession> orderEntries;
	private OrderFixSession selectedOrderEntry;
		
	private List<OrderFixSession> filteredOrderEntries;

	private List<EngineInstance> engines;
	private EngineInstance engine;
		
	@PostConstruct
	public void init() {
		try {
			this.selectedOrderEntry = new OrderFixSession();
			
			if (orderEntries == null){
				orderEntries = new ArrayList<OrderFixSession>();
				
				List<OrderFixSession> orderFixSessions = facade.getOrderFixSessions();
				
				if ( orderFixSessions != null ){
					orderEntries.addAll( orderFixSessions );
				}
			}
	
			if (engines == null){
				engines = new ArrayList<EngineInstance>();
				
				List<EngineInstance> engines2 = facade.getEngines();
				
				if ( engines2 != null ){
					engines.addAll( engines2 );
				}
				
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			
			logError(ex.getMessage());
		}
	}
	
	public List<OrderFixSession> getOrderEntries() {
		return orderEntries;
	}

	public void setOrderEntries(List<OrderFixSession> orderEntries) {
		this.orderEntries = orderEntries;
	}

	public OrderFixSession getSelectedOrderEntry() {
		return selectedOrderEntry;
	}

	public void setSelectedOrderEntry(OrderFixSession selectedOrderEntry) {
		this.selectedOrderEntry = selectedOrderEntry;
	}

	public List<OrderFixSession> getFilteredOrderEntries() {
		return filteredOrderEntries;
	}

	public void setFilteredOrderEntries(List<OrderFixSession> filteredOrderEntries) {
		this.filteredOrderEntries = filteredOrderEntries;
	}
	
	public EngineInstance getEngine() {
		return engine;
	}
	
	public void setEngine(EngineInstance engine) {
		this.engine = engine;
	}
	
	public List<EngineInstance> getEngines() {
		return engines;
	}
	
	public Exchange getExchange() {
		return this.selectedOrderEntry.getExchange();
	}
	
	public void setExchange(Exchange exchange) {
		this.selectedOrderEntry.setExchange(exchange);
	}
	
	public List<Exchange> getExchanges() {
		return CacheHelper.exchangeListCache;
	}

	public void newOrderEntry(ActionEvent actionEvent) {
		this.selectedOrderEntry = new OrderFixSession();
	}
	
	public void addOrderEntry(ActionEvent actionEvent) {		
		boolean recordExists = false;
		
		try {
			if (this.selectedOrderEntry != null) {
				
				if ( engine != null && ( this.selectedOrderEntry.getEngineId() == null ||
						                 this.selectedOrderEntry.getIdEngine() == null ) ){
					this.selectedOrderEntry.setEngineId( engine.getEngineId() );
					this.selectedOrderEntry.setIdEngine( engine.getId() );
				}
				
				recordExists = validation();
				
				if (!recordExists) {
					this.selectedOrderEntry.setEngineId(engine.getEngineId());					
					this.selectedOrderEntry = facade.saveOrderFixSession(this.selectedOrderEntry, ActionTypeEnum.INSERT);
					
					SessionByEngine sessionByEngine = new SessionByEngine( engine, this.selectedOrderEntry );
					
					facade.saveSessionByEngine(sessionByEngine);
					
					
					this.selectedOrderEntry.setEngineId( engine.getEngineId() );
					this.selectedOrderEntry.setIdEngine( engine.getId() );
					
					this.orderEntries.add(this.selectedOrderEntry);		
					
					refreshView();
				} else {
					this.warnMessage("Item already registered!");
				}
			}
		} catch (BussinessExceptionManhattan ex) {
			ex.printStackTrace();
			
			logError(ex.getMessage());
			this.errorMessage(ex.getMessage());
		} catch (Exception ex) {
			ex.printStackTrace();
			
			logError(ex.getMessage());

			this.errorMessage("Error on save Order Entry!");
		}			
	}

	public void deleteOrderEntry(ActionEvent actionEvent) {		
		try {
			EngineInstance engineToDelete = new EngineInstance();
			
			engineToDelete.setId(this.selectedOrderEntry.getIdEngine());
						
			SessionByEngine sessionByEngine = new SessionByEngine(engineToDelete, this.selectedOrderEntry);
						
			
			facade.deleteSessionByEngine(sessionByEngine);
			
			facade.deleteOrderFixSession(this.selectedOrderEntry);
			
			this.orderEntries.remove(this.selectedOrderEntry);
			refreshView();
		} catch (Exception ex) {
			logError(ex.getMessage());
			
			this.errorMessage("Error on delete Engine!");
		}
	}

	public void saveOrderEntry(ActionEvent actionEvent) {
		boolean recordExists = false;
		
		try {
			if (this.selectedOrderEntry != null) {
				
				if (engine != null && (this.selectedOrderEntry.getEngineId() == null
						|| this.selectedOrderEntry.getIdEngine() == null)) {
					this.selectedOrderEntry.setEngineId(engine.getEngineId());
					this.selectedOrderEntry.setIdEngine(engine.getId());
				}

				recordExists = validation();
				
				if (!recordExists) {
					facade.saveOrderFixSession(this.selectedOrderEntry, ActionTypeEnum.UPDATE);
					refreshView();
				} else {
					this.errorMessage("Error on save Order Entry!");
				}
			}
		} catch (Exception ex) {
			logError(ex.getMessage());

			this.errorMessage("Error on save Order Entry!");
		}			
	}
	
	
	private boolean validation(){
		
		boolean recordExists = true;
		
		for (OrderFixSession item: this.orderEntries) {
			
			if ( !item.getId().equals( selectedOrderEntry.getId() ) ){
			
				recordExists = (selectedOrderEntry.getExchange().getId().equals(item.getExchange().getId()) && 
						        selectedOrderEntry.getEngineId().equals(item.getEngineId()));
				
				if (recordExists) return !recordExists;
				
				recordExists = (selectedOrderEntry.getId().equals(item.getId()));
		
				if (recordExists) return !recordExists;
				
				recordExists = (selectedOrderEntry.getHost().equals(item.getHost()) && 
								selectedOrderEntry.getPort().equals(item.getPort()));
				
				if (recordExists) return !recordExists;
				
				recordExists = (selectedOrderEntry.getTargetCompId().equals(item.getTargetCompId()) && 
								selectedOrderEntry.getSenderCompId().equals(item.getSenderCompId()));
				
				if (recordExists) return !recordExists;
			}
		}
		
		return recordExists;
	}
	
}