package com.ubs.manhatthan.admin.beans;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.bean.ViewScoped;
import javax.faces.event.ActionEvent;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ubs.manhatthan.manager.persistence.entities.EngineInstance;
import com.ubs.manhatthan.manager.persistence.entities.Exchange;
import com.ubs.manhatthan.manager.persistence.entities.RecoverySessionByEngine;
import com.ubs.manhatthan.manager.persistence.entities.TcpRecoverySession;

@SuppressWarnings("serial")
@Component("recoveryBean")
@Scope("session")
@ViewScoped
@ManagedBean(name="recoveryBean")
public class RecoveryBean extends BaseBean {

	private List<TcpRecoverySession> recoveries;
	private TcpRecoverySession selectedRecovery;

	private List<TcpRecoverySession> filteredRecoveries;

	private List<EngineInstance> engines;
	private EngineInstance engine;
		
	private List<Exchange> exchanges;
		
	@PostConstruct
	public void init() {
		try {
			selectedRecovery = new TcpRecoverySession();
			engine = new EngineInstance();
			
			if (recoveries == null)
				recoveries = new ArrayList<TcpRecoverySession>(facade.getTcpRecoveries());
		
			if (engines == null)
				engines = new ArrayList<EngineInstance>(facade.getEngines());

			if (exchanges == null)
				exchanges = new ArrayList<Exchange>(facade.getExchanges());
			
		} catch (Exception ex) {
			ex.printStackTrace();
			
			logError(ex.getMessage());
		}
	}

	public List<TcpRecoverySession> getRecoveries() {
		return recoveries;
	}

	public void setRecoveries(List<TcpRecoverySession> recoveries) {
		this.recoveries = recoveries;
	}

	public TcpRecoverySession getSelectedRecovery() {
		return selectedRecovery;
	}

	public void setSelectedRecovery(TcpRecoverySession selectedRecovery) {
		this.selectedRecovery = selectedRecovery;
	}
	
	public List<TcpRecoverySession> getFilteredRecoveries() {
		return filteredRecoveries;
	}

	public void setFilteredRecoveries(List<TcpRecoverySession> filteredRecoveries) {
		this.filteredRecoveries = filteredRecoveries;
	}

	public EngineInstance getEngine() {
		return engine;
	}
	
	public void setEngine(EngineInstance engine) {
		this.engine = engine;
	}
	
	public List<EngineInstance> getEngines() {
		return engines;
	}
		
	public Exchange getExchange() {
		return this.selectedRecovery.getExchange();
	}
	
	public void setExchange(Exchange exchange) {
		this.selectedRecovery.setExchange(exchange);
	}
	
	public List<Exchange> getExchanges() {
		return exchanges;
	}

	public void newRecovery(ActionEvent actionEvent) {
		this.selectedRecovery = new TcpRecoverySession();
	}
	
	public void addRecovery(ActionEvent actionEvent) {		
		boolean recordExists = false;
		
		try {
			if (this.selectedRecovery != null) {
				
				if ( engine != null ){
					this.selectedRecovery.setEngineId( engine.getEngineId() );
					this.selectedRecovery.setIdEngine( engine.getId() );
				}
				
				recordExists = validation();
				
				if (!recordExists) {
					this.selectedRecovery.setEngineId(engine.getEngineId());					
					this.selectedRecovery = facade.saveTcpRecoverySession(this.selectedRecovery);
					
					this.selectedRecovery.setEngineId( engine.getEngineId() );
					this.selectedRecovery.setIdEngine( engine.getId() );
					
					RecoverySessionByEngine recoverySessionByEngine = new RecoverySessionByEngine();					
					recoverySessionByEngine.setTcpRecoverySession(this.selectedRecovery);					
					recoverySessionByEngine.setEngine(engine);					
					facade.saveUmdfRecoverySessionByEngine(recoverySessionByEngine);
					
					this.recoveries.add(this.selectedRecovery);
					
					refreshView();
				} else {
					this.warnMessage("Item already registered!");
				}
			}
		} catch (Exception ex) {			
			ex.printStackTrace();
			
			this.errorMessage("Error on save TCP Recovery!");
		}
	}

	public void deleteRecovery(ActionEvent actionEvent) {		
		try {
			EngineInstance engineToDelete = new EngineInstance();
			
			engineToDelete.setId(this.selectedRecovery.getIdEngine());
						
			RecoverySessionByEngine recoverySessionByEngine = new RecoverySessionByEngine(engineToDelete, this.selectedRecovery);
						
			facade.deleteRecoverySessionByEngine(recoverySessionByEngine);
			
			facade.deleteTcpRecovery(this.selectedRecovery);
			
			this.recoveries.remove(this.selectedRecovery);
			refreshView();
		} catch (Exception ex) {
			ex.printStackTrace();
			
			this.errorMessage("Error on delete Engine!");
		}
	}

	public void saveRecovery(ActionEvent actionEvent) {
		boolean recordExists = false;
		
		try {
			if (this.selectedRecovery != null) {
				
				if ( engine != null ){
					this.selectedRecovery.setEngineId( engine.getEngineId() );
					this.selectedRecovery.setIdEngine( engine.getId() );
				}
				
				recordExists = validation();
				
				if (!recordExists) {
					this.selectedRecovery.setEngineId(engine.getEngineId());
					
					facade.saveTcpRecoverySession(this.selectedRecovery);
					refreshView();
				} else {
					this.warnMessage("Item already registered!");
				}
			}
		} catch (Exception ex) {			
			this.errorMessage("Error on save TCP Recovery!");
		}
	}
	
	
	private boolean validation(){
		
		boolean recordExists = true;
		
		for (TcpRecoverySession item: this.recoveries) {
			
			if ( !item.getId().equals( selectedRecovery.getId() ) ){
			
				recordExists = (selectedRecovery.getExchange().getId().equals(item.getExchange().getId()) && 
								selectedRecovery.getEngineId().equals(item.getEngineId()));
				
				if (recordExists) return !recordExists;
				
				recordExists = (selectedRecovery.getTargetCompId().equals(item.getTargetCompId()) && 
								selectedRecovery.getSenderCompId().equals(item.getSenderCompId()));
				
				if (recordExists) return !recordExists;
				
				recordExists = (selectedRecovery.getHost().equals(item.getHost()) && 
								selectedRecovery.getPort().equals(item.getPort()));
				
				if (recordExists) return !recordExists;
			}
		}
		
		return recordExists;
		
	}
	
	
}