package com.ubs.manhatthan.admin.beans;

import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;

import com.ubs.manhatthan.admin.helper.Messages;

@ApplicationScoped
@ManagedBean(name="messageBean")
public class MessageBean {
	public MessageBean() {		

	}
	
	public String getMessageForRequiredId() {
		return Messages.msgRequiredId;
	}
	
	public String getMessageForRequiredEngine() {
		return Messages.msgRequiredEngine;
	}

	public String getMessageForRequiredDescription() {
		return Messages.msgRequiredDescription;
	}

	public String getMessageForRequiredHost() {
		return Messages.msgRequiredHost;
	}

	public String getMessageForRequiredIp() {
		return Messages.msgRequiredIp;
	}

	public String getMessageForRequiredPort() {
		return Messages.msgRequiredPort;
	}

	public String getMessageForRequiredLogPath() {
		return Messages.msgRequiredLogPath;
	}

	public String getMessageForRequiredChannelId() {
		return Messages.msgRequiredChannelId;
	}

	public String getMessageForRequiredSenderCompId() {
		return Messages.msgRequiredSenderCompId;
	}

	public String getMessageForRequiredIncrementalHost() {
		return Messages.msgRequiredIncrementalHost;
	}

	public String getMessageForRequiredIncrementalIp() {
		return Messages.msgRequiredIncrementalIp;
	}

	public String getMessageForRequiredIncrementalPort() {
		return Messages.msgRequiredIncrementalPort;
	}

	public String getMessageForRequiredRecoveryHost() {
		return Messages.msgRequiredRecoveryHost;
	}

	public String getMessageForRequiredRecoveryPort() {
		return Messages.msgRequiredRecoveryPort;
	}

	public String getMessageForRequiredInstDefinitionHost() {
		return Messages.msgRequiredInstDefinitionHost;
	}

	public String getMessageForRequiredInstDefinitionPort() {
		return Messages.msgRequiredInstDefinitionPort;
	}

	public String getMessageForRequiredAccount() {
		return Messages.msgRequiredAccount;
	}

	public String getMessageForValidatorEngine() {
		return Messages.msgValidatorEngine;
	}

	public String getMessageForValidatorChannel() {
		return Messages.msgValidatorChannel;
	}
}