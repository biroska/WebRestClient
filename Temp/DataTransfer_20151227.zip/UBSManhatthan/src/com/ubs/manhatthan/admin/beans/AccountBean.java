package com.ubs.manhatthan.admin.beans;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.event.ActionEvent;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.persistence.entities.ClientAccount;
import com.ubs.manhatthan.manager.persistence.entities.OrderFixSession;
import com.ubs.manhatthan.manager.persistence.entities.SessionByAccount;

@SuppressWarnings("serial")
@Component("accountBean")
@Scope("session")
@ViewScoped
@ManagedBean(name="accountBean")
public class AccountBean extends BaseBean {

	private List<SessionByAccount> accounts;
	private List<SessionByAccount> filteredAccounts;
	private SessionByAccount selectedAccount;
	
	private List<ClientAccount> clientAccounts;
	private List<OrderFixSession> orderFixSessions;
			
	@PostConstruct
	public void init() {
		//try {
		if (accounts == null) {
			try {
				accounts = facade.getAccountSessions();

				orderFixSessions = facade.getOrderFixSessions();
			} catch (DAOExceptionManhattan e) {
				e.printStackTrace();
			}
		}
	}
			
	public List<SessionByAccount> getAccounts() {
		return accounts;
	}

	public void setAccounts(List<SessionByAccount> accounts) {
		this.accounts = accounts;
	}

	public SessionByAccount getSelectedAccount() {
		return selectedAccount;
	}

	public void setSelectedAccount(SessionByAccount selectedAccount) {
		this.selectedAccount = selectedAccount;
	}

	public List<SessionByAccount> getFilteredAccounts() {
		return filteredAccounts;
	}

	public void setFilteredAccounts(List<SessionByAccount> filteredAccounts) {
		this.filteredAccounts = filteredAccounts;
	}

	public List<OrderFixSession> getOrderFixSessions() {
		return orderFixSessions;
	}

	public List<ClientAccount> completeAccount(String account) {
		ClientAccount searchClientAccount = new ClientAccount();
		
		searchClientAccount.setDescription("%" + account + "%");

		try {
			clientAccounts = facade.FindClientAccount(searchClientAccount);
		} catch (DAOExceptionManhattan e) {
			e.printStackTrace();
		}
		
		return clientAccounts;
	}
		
	public void newAccount(ActionEvent actionEvent) {		
		this.selectedAccount = new SessionByAccount();
	}
	
	public void deleteAccount(ActionEvent actionEvent) {		
		try {
			facade.deleteSessionByAccount(this.selectedAccount);
			
			this.accounts.remove(this.selectedAccount);
			refreshView();
		} catch (Exception ex) {			
			ex.printStackTrace();
			
			this.errorMessage("Error on save Account Session!");
		}
	}
	
	public void addAccount(ActionEvent actionEvent) {
		boolean recordExists = false;
		
		try {
			if (this.selectedAccount != null) {
				for (SessionByAccount item: this.accounts) {
					recordExists = (selectedAccount.getId() != null) && 
							(selectedAccount.getClientAccount().getCode().equals(item.getClientAccount().getCode())) &&
							(selectedAccount.getOrderFixSession().getId().equals(item.getOrderFixSession().getId()));
		
					if (recordExists) break;
				}
				
				if (recordExists) {
					this.warnMessage("Item already registered!");
				} else {
					
					this.selectedAccount = facade.saveSessionByAccount(this.selectedAccount);
					
					this.accounts.add(this.selectedAccount);	
					refreshView();
				}
			}
		} catch (Exception ex) {			
			ex.printStackTrace();
			
			this.errorMessage("Error on save Account Session!");
		}
	}

	public void saveAccount(ActionEvent actionEvent) {
		boolean recordExists = false;

		try {
			if (this.selectedAccount != null) {
				for (SessionByAccount item: this.accounts) {
					recordExists = (selectedAccount.getId().equals(item.getId()));
					
					if (recordExists) break;
				}
				
				if (recordExists) {
					facade.saveSessionByAccount(this.selectedAccount);
					refreshView();
				} else {
					this.errorMessage("Error on save Account!");
				}
			}
						
		} catch (Exception ex) {
			logError(ex.getMessage());

			this.errorMessage("Error on save Account!");
		}
	}
}