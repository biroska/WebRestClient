package com.ubs.manhatthan.admin.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import com.ubs.manhatthan.admin.model.ChannelType;
import com.ubs.manhatthan.manager.enums.ChannelTypeEnum;

@FacesConverter(value="channelTypeConverter")
public class ChannelTypeConverter implements Converter {

    public Object getAsObject(FacesContext context, UIComponent component, String value) {
    	ChannelType c = null;
    	
		for (ChannelType item: ChannelTypeEnum.convertToList()) {
			if (item.getName().equals(value)) {
				c = item;
				
				break;
			}
		}
    	
        return c;
    }

    public String getAsString(FacesContext context, UIComponent component, Object object) {
    	if (object != null) {
    		String item = String.valueOf(((ChannelType) object).getName());
    		
    		return item;
    	} else {
    		return null;    	
    	}
    }
}
