package com.ubs.manhatthan.admin.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import org.apache.log4j.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.facade.Facade;
import com.ubs.manhatthan.manager.logger.ManhattanLogger;
import com.ubs.manhatthan.manager.persistence.entities.EngineInstance;
import com.ubs.manhatthan.manager.utils.Util;

@Component
@Scope(WebApplicationContext.SCOPE_REQUEST)
@FacesConverter(value="engineConverter")
public class EngineConverter implements Converter {

	@Autowired
	protected Facade facade;

    public Object getAsObject(FacesContext context, UIComponent component, String value) {
    	EngineInstance c = null;
		try {
			c = facade.findEngineInstanceById(new Integer(value));
		} catch (NumberFormatException | DAOExceptionManhattan ex) {
			ex.printStackTrace();
			
    		ManhattanLogger.log(Util.getManagerId().toString(), ex.getMessage(), Level.ERROR);
		}
		
		return c;
    }

    public String getAsString(FacesContext context, UIComponent component, Object object) {
    	if (object != null) {
    		return String.valueOf(((EngineInstance) object).getId());
    	} else {
    		return null;    	
    	}
    }

    public void setFacade(Facade facade) {
    	this.facade = facade;
    }
}