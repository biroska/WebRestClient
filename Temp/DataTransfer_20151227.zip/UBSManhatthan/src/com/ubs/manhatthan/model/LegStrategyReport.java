package com.ubs.manhatthan.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.ubs.manhatthan.manager.enums.OrderTypeEnum;
import com.ubs.manhatthan.manager.enums.TimeInForceEnum;

public class LegStrategyReport implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1328056343206358963L;
	
	public LegStrategyReport() {
		this.unleggingList = new ArrayList<Unlegging>();
		this.contract = "";
		this.totalQuantity = null;
		this.clip = null;
		this.div1 = null;
	}

	private Integer legSeq;

	private Long engineId;

	private Long strategyId;

	private StrategyReport strategyReport;

	// Security Id
	private Long instrument;

	private String contract;

	// Total Qty - manager
	private Long totalQuantity;

	// Total Qty - manager
	private Long previusTotalQuantity;

	private Double executedPercentage;

	private Long remainingQuantity;

	private Long executedQuantity;
	// Avg Px
	private Double averagePrice;

	private String text;

	private Integer side;

	private OrderTypeEnum orderType;

	private TimeInForceEnum timeInForce;

	private Account account;

	private boolean passiveLeg;

	private Long maxQuantityDisplay;

	private Long minQuantityDisplay;

	// market Po Qtd
	private Long restingQuantity;

	// market PO Px
	private Double restingPrice;

	private Double leggedPrice;

	private Long leggedQuantity;

	// market Otc Px
	private Double otcPrice;

	// market Otc Qtd
	private Long otcQuantity;

	// Rank
	private Long restingRank;

	// Div
	private String div;

	// Div1
	private Double div1;
	
	private boolean protectDiv1;

	// Clip
	private Long clip;

	private Long timeOut;

	private String investorId;

	private String enteringTrader;

	private Integer duration;

	private String login;
	
	private List<Unlegging> unleggingList;
	
	public StrategyReport getStrategyReport() {
		return strategyReport;
	}

	public void setStrategyReport(StrategyReport strategyReport) {
		this.strategyReport = strategyReport;
	}

	public Long getInstrument() {
		return instrument;
	}

	public void setInstrument(Long instrument) {
		this.instrument = instrument;
	}

	public Long getTotalQuantity() {
		return totalQuantity;
	}

	public void setTotalQuantity(Long totalQuantity) {
		this.totalQuantity = totalQuantity;
	}

	public Double getExecutedPercentage() {
		return executedPercentage;
	}

	public void setExecutedPercentage(Double executedPercentage) {
		this.executedPercentage = executedPercentage;
	}

	public Long getRemainingQuantity() {
		return remainingQuantity;
	}

	public void setRemainingQuantity(Long remainingQuantity) {
		this.remainingQuantity = remainingQuantity;
	}

	public Long getExecutedQuantity() {
		return executedQuantity;
	}

	public void setExecutedQuantity(Long executedQuantity) {
		this.executedQuantity = executedQuantity;
	}

	public Double getAveragePrice() {
		return averagePrice;
	}

	public void setAveragePrice(Double averagePrice) {
		this.averagePrice = averagePrice;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public Integer getSide() {
		return side;
	}

	public void setSide(Integer side) {
		this.side = side;
	}

	public OrderTypeEnum getOrderType() {
		return orderType;
	}

	public void setOrderType(OrderTypeEnum orderType) {
		this.orderType = orderType;
	}

	public TimeInForceEnum getTimeInForce() {
		return timeInForce;
	}

	public void setTimeInForce(TimeInForceEnum timeInForce) {
		this.timeInForce = timeInForce;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public boolean getPassiveLeg() {
		return passiveLeg;
	}

	public void setPassiveLeg(boolean passiveLeg) {
		this.passiveLeg = passiveLeg;
	}

	public Long getMaxQuantityDisplay() {
		return maxQuantityDisplay;
	}

	public void setMaxQuantityDisplay(Long maxQuantityDisplay) {
		this.maxQuantityDisplay = maxQuantityDisplay;
	}

	public Long getMinQuantityDisplay() {
		return minQuantityDisplay;
	}

	public void setMinQuantityDisplay(Long minQuantityDisplay) {
		this.minQuantityDisplay = minQuantityDisplay;
	}

	public Long getRestingQuantity() {
		return restingQuantity;
	}

	public void setRestingQuantity(Long restingQuantity) {
		this.restingQuantity = restingQuantity;
	}

	public Double getRestingPrice() {
		return restingPrice;
	}

	public void setRestingPrice(Double restingPrice) {
		this.restingPrice = restingPrice;
	}

	public Long getRestingRank() {
		return restingRank;
	}

	public void setRestingRank(Long restingRank) {
		this.restingRank = restingRank;
	}

	public Long getTimeOut() {
		return timeOut;
	}

	public void setTimeOut(Long timeOut) {
		this.timeOut = timeOut;
	}

	public String getInvestorId() {
		return investorId;
	}

	public void setInvestorId(String investorId) {
		this.investorId = investorId;
	}

	public String getEnteringTrader() {
		return enteringTrader;
	}

	public void setEnteringTrader(String enteringTrader) {
		this.enteringTrader = enteringTrader;
	}

	public Integer getDuration() {
		return duration;
	}

	public void setDuration(Integer duration) {
		this.duration = duration;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getContract() {
		
		if (contract != null)
			return contract.toUpperCase();
		else
			return contract;
		
//		if (null != instrument) {
//			
//			try {
//				System.out.println( this.contract );
//				intrumentDefinition = lmds.getIntrumentDefinitionBySecurityId( ""+instrument );
//				
//				if ( intrumentDefinition != null && intrumentDefinition.getSecurity() != null && 
//					 StringUtils.isNotBlank( intrumentDefinition.getSecurity().getSymbol() ) ){
//					return intrumentDefinition.getSecurity().getSymbol().toUpperCase();
//				}
//			} catch (DAOExceptionManhattan e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		}
		
	}

	public void setContract(String contract) {
		this.contract = contract;
	}

	public Long getClip() {
		return clip;
	}

	public void setClip(Long clip) {
		this.clip = clip;
	}

	public String getDiv() {
		return div;
	}

	public void setDiv(String div) {
		this.div = div;
	}

	public Double getLeggedPrice() {
		return leggedPrice;
	}

	public void setLeggedPrice(Double leggedPrice) {
		this.leggedPrice = leggedPrice;
	}

	public Integer getLegSeq() {
		return legSeq;
	}

	public void setLegSeq(Integer legSeq) {
		this.legSeq = legSeq;
	}

	public Long getEngineId() {
		return engineId;
	}

	public void setEngineId(Long engineId) {
		this.engineId = engineId;
	}

	public Long getStrategyId() {
		return strategyId;
	}

	public void setStrategyId(Long strategyId) {
		this.strategyId = strategyId;
	}

	public Long getLeggedQuantity() {
		return leggedQuantity;
	}

	public void setLeggedQuantity(Long leggedQuantity) {
		this.leggedQuantity = leggedQuantity;
	}

	public Double getOtcPrice() {
		return otcPrice;
	}

	public void setOtcPrice(Double otcPrice) {
		this.otcPrice = otcPrice;
	}

	public Long getOtcQuantity() {
		return otcQuantity;
	}

	public void setOtcQuantity(Long otcQuantity) {
		this.otcQuantity = otcQuantity;
	}

	public Long getPreviusTotalQuantity() {
		if (previusTotalQuantity == null && totalQuantity != null) {
			previusTotalQuantity = totalQuantity;
		}
		return previusTotalQuantity;
	}

	public Double getDiv1() {
		return div1;
	}

	public void setDiv1(Double div1) {
		this.div1 = div1;
	}

	// Using in html page for id controls and after push / subscriber update information
	private String getHtmlRowdId() {
		return this.engineId.toString() + "_" + 
				this.strategyId.toString() + "_" + 
				this.legSeq.toString() + "_";
	}

	public String getTotalQuantityHtmlId() {
		return (getHtmlRowdId() + "totalQuantity");
	}

	public String getExecutedPercentageHtmlId() {
		return (getHtmlRowdId() + "executedPercentage");
	}

	public String getRemainingQuantityHtmlId() {
		return (getHtmlRowdId() + "remainingQuantity");
	}

	public String getExecutedQuantityHtmlId() {
		return (getHtmlRowdId() + "executedQuantity");
	}

	public String getAveragePriceHtmlId() {
		return (getHtmlRowdId() + "averagePrice");
	}

	public String getOtcPriceHtmlId() {
		return (getHtmlRowdId() + "otcPrice");
	}

	public String getOtcQuantityHtmlId() {
		return (getHtmlRowdId() + "otcQuantity");
	}

	public String getPoPriceHtmlId() {
		return (getHtmlRowdId() + "poPrice");
	}

	public String getPoQuantityHtmlId() {
		return (getHtmlRowdId() + "poQuantity");
	}

	public String getLeggedQuantityHtmlId() {
		return (getHtmlRowdId() + "leggedQuantity");
	}

	public String getLeggedPriceHtmlId() {
		return (getHtmlRowdId() + "leggedPrice");
	}

	public String getTextHtmlId() {
		return (getHtmlRowdId() + "text");
	}

	public List<Unlegging> getUnleggingList() {
		return unleggingList;
	}

	public void setUnleggingList(List<Unlegging> unleggingList) {
		this.unleggingList = unleggingList;
	}

	public boolean getIsUnlegging() {		
		return (this.unleggingList != null && !this.unleggingList.isEmpty());
	}

	public boolean isProtectDiv1() {
		return protectDiv1;
	}

	public void setProtectDiv1(boolean protectDiv1) {
		this.protectDiv1 = protectDiv1;
	}
}