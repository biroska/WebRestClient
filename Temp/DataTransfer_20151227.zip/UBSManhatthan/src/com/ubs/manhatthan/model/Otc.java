package com.ubs.manhatthan.model;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Otc implements Serializable {

	private String instrument;
	private String side;
	private long price;
	private int qty;
	
	public Otc(String instrument, String side,  long price, int qty) {
		
		super();
		
		this.instrument = instrument;
		this.side = side;
		this.price = price;
		this.qty = qty;	

	}

	public String getInstrument() {
		return instrument;
	}



	public void setInstrument(String instrument) {
		this.instrument = instrument;
	}



	public String getSide() {
		return side;
	}



	public void setSide(String side) {
		this.side = side;
	}



	public long getPrice() {
		return price;
	}



	public void setPrice(long price) {
		this.price = price;
	}



	public int getQty() {
		return qty;
	}



	public void setQty(int qty) {
		this.qty = qty;
	}



	@Override
	public String toString() {
		return "Otc [instrument=" + instrument + ", side=" + side + ",  qty=" + qty + ", price=" + price + "]";
	}
}
