package com.ubs.manhatthan.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("serial")
public class PushManager implements Serializable {

	private String messageId = "2";
	
	private String refreshTableIsNeeded = "N";
	
	private String notificationMessage = "";
	
	private List<PushManagerFields> fields = null;
	
	private boolean mustBeUnlegging = false;

	public PushManager() {

	}
	
	public PushManager(LegStrategyReport legStrategyReport) {		
		addLegStrategyReport(legStrategyReport);
	}
	
	public String getMessageId() {
		return this.messageId;
	}
	
	public String getRefreshTableIsNeeded() {
		return refreshTableIsNeeded;
	}

	public void setRefreshTableIsNeeded(String refreshTableIsNeeded) {
		this.refreshTableIsNeeded = refreshTableIsNeeded;
	}

	public String getNotificationMessage() {
		return notificationMessage;
	}

	public void setNotificationMessage(String notificationMessage) {
		this.notificationMessage = notificationMessage;
	}

	public boolean isMustBeUnlegging() {
		return mustBeUnlegging;
	}

	public void setMustBeUnlegging(boolean mustBeUnlegging) {
		this.mustBeUnlegging = mustBeUnlegging;
	}

	public List<PushManagerFields> getFields() {
		return fields;
	}

	public void addLegStrategyReport(StrategyReport strategyReport) {
		if (strategyReport != null) {
			
			if (fields == null) {
				fields = new ArrayList<PushManagerFields>();
			}
			
			PushManagerFields pushManagerField = new PushManagerFields(strategyReport);
			
			this.fields.add(pushManagerField);
		}
	}

	public void addLegStrategyReport(LegStrategyReport legStrategyReport) {
		if (legStrategyReport != null) {
			
			if (fields == null) {
				fields = new ArrayList<PushManagerFields>();
			}
			
			PushManagerFields pushManagerField = new PushManagerFields(legStrategyReport);
			
			this.fields.add(pushManagerField);
		}
	}
		
	@Override
	public String toString() {
		return "PushManager [messageId=" + messageId
				+ ", refreshTableIsNeeded=" + refreshTableIsNeeded
				+ ", notificationMessage=" + notificationMessage + ", fields="
				+ fields + "]";
	}
}