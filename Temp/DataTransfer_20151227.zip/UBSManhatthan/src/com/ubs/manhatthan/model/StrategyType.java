package com.ubs.manhatthan.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.cache.CacheHelper;
import com.ubs.manhatthan.manager.lmdsadapter.LmdsManager;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.SecurityDefinition;
import com.ubs.manhatthan.manager.utils.Util;

public class StrategyType implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private boolean createStrategyInPause;

	private Long id;
	
	private Integer strategyCode;
	
	private String description;
	
	private Integer numberOfLegs;
	
	private Integer instrument;
	
	private String instrumentByName;
	
	private int defaultStrag;
	
	private int totalQtd;
		
	private int status;
	
	private int percent;
	
	private long target;
	
	private long dif;
	
	private long efectiveTarget;
	
	private String start;
	
	private String end;

	private List<StrategyTypeLeg> strategyTypeLegList;
	
	private LmdsManager lmds;
	
	public StrategyType() {
		super();
		strategyTypeLegList = new ArrayList<StrategyTypeLeg>();
		lmds = CacheHelper.lmdsCommunicatorInstance.get( Util.getManagerId() );
	}
	
	public  StrategyType(Long id, Integer strategyCode, String description, Integer numberOfLegs, int defaultStrag,
			List<StrategyTypeLeg> strategyTypeLegList, Account account, String start, String end, int status, int percent) {
		this.id = id;
		this.strategyCode = strategyCode;
		this.description = description;
		this.numberOfLegs = numberOfLegs;
		this.defaultStrag = defaultStrag;
		this.start = start;
		this.end = end;
		this.status = status;
		this.percent = percent;
		this.strategyTypeLegList = strategyTypeLegList;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Integer getStrategyCode() {
		return strategyCode;
	}

	public void setStrategyCode(Integer strategyCode) {
		this.strategyCode = strategyCode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getNumberOfLegs() {
		return numberOfLegs;
	}

	public void setNumberOfLegs(Integer numberOfLegs) {
		this.numberOfLegs = numberOfLegs;
	}

	public List<StrategyTypeLeg> getStrategyTypeLegList() {
		if (null == strategyTypeLegList) {
			strategyTypeLegList = new ArrayList<StrategyTypeLeg>();
			
		}
		return strategyTypeLegList;
	}

	public void setStrategyTypeLegList(List<StrategyTypeLeg> strategyTypeLegList) {
		this.strategyTypeLegList = strategyTypeLegList;
	}

	public int getDefaultStrag() {
		return defaultStrag;
	}

	public void setDefaultStrag(int defaultStrag) {
		this.defaultStrag = defaultStrag;
	}
	
	public int getTotalQtd() {
		int sum = 0;
		totalQtd = 0;
		for (StrategyTypeLeg strategyTypeLeg : strategyTypeLegList) {
			sum += strategyTypeLeg.getLegged().getTotalQty();
		}
		totalQtd = sum;
		return totalQtd;
	}

	public String getStart() {
		return start;
	}

	public void setStart(String start) {
		this.start = start;
	}

	public String getEnd() {
		return end;
	}

	public void setEnd(String end) {
		this.end = end;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public int getPercent() {
		return percent;
	}

	public void setPercent(int percent) {
		this.percent = percent;
	}

	public void setTotalQtd(int totalQtd) {
		this.totalQtd = totalQtd;
	}

	public long getTarget() {
		return target;
	}

	public void setTarget(long target) {
		this.target = target;
	}

	public long getEfectiveTarget() {
		return efectiveTarget;
	}

	public void setEfectiveTarget(long efectiveTarget) {
		this.efectiveTarget = efectiveTarget;
	}

	public long getDif() {
		return dif;
	}

	public void setDif(long dif) {
		this.dif = dif;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public boolean isCreateStrategyInPause() {
		return createStrategyInPause;
	}

	public void setCreateStrategyInPause(boolean createStrategyInPause) {
		this.createStrategyInPause = createStrategyInPause;
	}

	public Integer getInstrument() {
		return instrument;
	}

	public void setInstrument(Integer instrument) {
		this.instrument = instrument;
	}

	public void setInstrumentByName(String instrumentByName) {
		
		if (null != instrumentByName && !instrumentByName.trim().equals("")) {
			
			SecurityDefinition intrumentDefinition;
			try {
				intrumentDefinition = lmds.getIntrumentDefinitionBySymbol( instrumentByName.trim() );
				if ( intrumentDefinition == null || intrumentDefinition.getSecurity() == null || intrumentDefinition.getSecurity().getSecurityID() == null ){
					setInstrument( 0 );
				} else {
					setInstrument( Integer.valueOf( intrumentDefinition.getSecurity().getSecurityID() ) );
				}
//			setInstrument(MarketDataMock.getInstrument(instrumentByName.trim()) == null ? 0 : Integer.valueOf(MarketDataMock.getInstrument(instrumentByName).toString()));	
			} catch (DAOExceptionManhattan e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		this.instrumentByName = instrumentByName;
	}

	public String getInstrumentByName() {
		String name = null;
		if (null != instrumentByName && !instrumentByName.trim().equals("")) {
			
			try {
				SecurityDefinition intrumentDefinition = lmds.getIntrumentDefinitionBySecurityId( ""+instrument.longValue() );
				
				if ( intrumentDefinition == null || intrumentDefinition.getSecurity() == null || StringUtils.isBlank( intrumentDefinition.getSecurity().getSymbol() ) ){
					name = "";	
				} else {
					name = intrumentDefinition.getSecurity().getSymbol();
				}
//			name = MarketDataMock.getSymbol(instrument.longValue()) == null ? "" : MarketDataMock.getSymbol(instrument.longValue());	
			} catch (DAOExceptionManhattan e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}else {
			return this.instrumentByName = name;	
		}
		return this.instrumentByName = name;
	}
}
