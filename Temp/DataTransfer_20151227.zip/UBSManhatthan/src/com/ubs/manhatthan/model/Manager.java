package com.ubs.manhatthan.model;

import java.io.Serializable;

public class Manager implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5537769916985591429L;
	private long id;
	private boolean cancelAtive;
	private String user;
	private StrategyType strategyType;
	
	public Manager(){
		super();
	}
	
	public Manager(long id, boolean cancelAtive, String user, StrategyType strategyType) {
		this.id = id;
		this.cancelAtive = cancelAtive;
		this.user = user;
		this.strategyType = strategyType;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public boolean isCancelAtive() {
		return cancelAtive;
	}

	public void setCancelAtive(boolean cancelAtive) {
		this.cancelAtive = cancelAtive;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public StrategyType getStrategyType() {
		return strategyType;
	}

	public void setStrategyType(StrategyType strategyType) {
		this.strategyType = strategyType;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
