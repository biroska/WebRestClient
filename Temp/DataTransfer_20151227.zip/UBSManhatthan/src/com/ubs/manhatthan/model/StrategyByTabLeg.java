package com.ubs.manhatthan.model;


public class StrategyByTabLeg {

	public StrategyByTabLeg() {
	}

	public StrategyByTabLeg(StrategyByTab strategyByTab, StrategyTypeLeg strategyTypeLeg, Integer instrument) {
		super();
		this.strategyByTab = strategyByTab;
		this.strategyTypeLeg = strategyTypeLeg;
		this.instrument = instrument;
	}

	private Long id;

	private StrategyByTab strategyByTab;

	private StrategyTypeLeg strategyTypeLeg;

	private Integer instrument;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public StrategyByTab getStrategyByTab() {
		return strategyByTab;
	}

	public void setStrategyByTab(StrategyByTab strategyByTab) {
		this.strategyByTab = strategyByTab;
	}

	public StrategyTypeLeg getStrategyTypeLeg() {
		return strategyTypeLeg;
	}

	public void setStrategyTypeLeg(StrategyTypeLeg strategyTypeLeg) {
		this.strategyTypeLeg = strategyTypeLeg;
	}

	public Integer getInstrument() {
		return instrument;
	}

	public void setInstrument(Integer instrument) {
		this.instrument = instrument;
	}
}