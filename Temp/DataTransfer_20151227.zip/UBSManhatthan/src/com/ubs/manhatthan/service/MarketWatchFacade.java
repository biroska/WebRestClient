package com.ubs.manhatthan.service;

import java.util.List;

import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.persistence.entities.StrategyByTab;
import com.ubs.manhatthan.model.Market;
import com.ubs.manhatthan.model.MarketWhatchTab;
import com.ubs.manhatthan.model.StrategyType;

public interface MarketWatchFacade {

	List<MarketWhatchTab> getWatchTabMarkets(String userLogin) throws DAOExceptionManhattan;

	void addInstrument(MarketWhatchTab marketWhatchTab);

	List<StrategyType> getStrategyTypesDomain() throws DAOExceptionManhattan;

	StrategyType convertEntityStrategyTypeToVO(com.ubs.manhatthan.manager.persistence.entities.StrategyType strategyType);

	StrategyType getStrategyVOById(String id) throws DAOExceptionManhattan;

	StrategyByTab populateStrategyByTab(StrategyType vo, MarketWhatchTab marketWhatchTab) throws DAOExceptionManhattan;

	Market populateMarketVO(StrategyType strategyType);

	void deleteTabMarketWatch(Long id) throws DAOExceptionManhattan;
	
	void deleteMarketWatchList(List<MarketWhatchTab> marketWhatchTabsUnsave) throws DAOExceptionManhattan;

	void saveStrategiesByTabMarket(List<MarketWhatchTab> marketWhatchTabsUnsave, List<StrategyByTab> strategyByTabsUnsave) throws DAOExceptionManhattan;

	void saveViewTabsMarket(List<MarketWhatchTab> marketWhatchTabsUnsave) throws DAOExceptionManhattan;

	StrategyByTab getStrategyByTab(StrategyType strategyType, MarketWhatchTab marketWhatchTab) throws DAOExceptionManhattan;

	void deleteMarketsByList(List<Market> markets) throws DAOExceptionManhattan;

	void addSynthetic(MarketWhatchTab marketWhatchTab);

}
