package com.ubs.manhatthan.common.enuns;

public enum ActionTypeEnum{
	
    INSERT,
    UPDATE,
    DELETE;
    
    private ActionTypeEnum() {
    }
}
