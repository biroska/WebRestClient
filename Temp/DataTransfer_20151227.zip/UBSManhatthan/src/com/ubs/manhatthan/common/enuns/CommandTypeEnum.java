package com.ubs.manhatthan.common.enuns;


public enum CommandTypeEnum  {
	
	UNKNOWN          			  ( 0 ),
	CANCEL_ALL_STRATEGIES         ( 1 ),
	PAUSE_ALL_STRAEGIES           ( 2 );
    
	private Integer code;
	
    private CommandTypeEnum( Integer code) {
    	this.code = code;
    }

	public Integer getCode() {
		return code;
	}
}
