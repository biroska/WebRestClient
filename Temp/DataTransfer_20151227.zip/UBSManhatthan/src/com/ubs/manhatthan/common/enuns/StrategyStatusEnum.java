package com.ubs.manhatthan.common.enuns;

import com.ubs.manhatthan.manager.enums.StrategyTypeEnum;

public enum StrategyStatusEnum {
	
	UNKNOWN (0, "UNKNOWN"),
	INITIALIZING (1,"INITIALIZING"),
	PAUSING (2,"PAUSING"),
	RESUMING (3,"RESUMING"),
	CANCELLING (4,"CANCELLING"),
	SCHEDULED (5,"SCHEDULED"),
	PAUSED (6,"PAUSED"),
	RESUMED (7,"RUNNING"),
	COMPLETED (8,"COMPLETED"),
	CANCELLED (9,"CANCELLED"),
	ERROR (10, "ERROR");
	
    StrategyStatusEnum(Integer code) {
        this.code = code;
    }

    StrategyStatusEnum(Integer code, String description) {
		this.code = code;
		this.description = description;
	}

	private Integer code;
    
    private String description;

    public Integer getCode( ) {
    	return code;
    }

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
    public static StrategyStatusEnum fromValue( Integer value ){
    	
		for (StrategyStatusEnum item : StrategyStatusEnum.values() ) {
			if ( item.getCode().equals( value ) ){
				return item;
			}
		}
		return null;
    }	
}