package com.ubs.manhatthan.beans;

import javax.faces.application.NavigationHandler;
import javax.faces.context.FacesContext;
import javax.faces.event.PhaseEvent;
import javax.faces.event.PhaseId;
import javax.faces.event.PhaseListener;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import com.ubs.manhatthan.admin.model.User;

@Component
@Scope(WebApplicationContext.SCOPE_SESSION)
public class PhaseListenerFilter extends UBSCommonBean implements PhaseListener {

	private static final long serialVersionUID = -3621419189392860292L;

	User user;

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public PhaseListenerFilter() {
	}

	public void beforePhase(PhaseEvent event) {

		routePhaseTrace(event, false);

		FacesContext fc = event.getFacesContext();

		if (null == user) {
			setUser(fc.getApplication().evaluateExpressionGet(fc, "#{user}", User.class));
		}
	}

	public void afterPhase(PhaseEvent event) {

		FacesContext fc = event.getFacesContext();

		boolean loginPage = fc.getViewRoot().getViewId().lastIndexOf("login") > -1 ? true : false;

		if (!loginPage && !loggedIn()) {
			NavigationHandler nh = fc.getApplication().getNavigationHandler();

			nh.handleNavigation(fc, null, "login");
		}
	}

	private void routePhaseTrace(PhaseEvent event, boolean startTrace) {
		if (startTrace) {
			if (event.getPhaseId() == PhaseId.RESTORE_VIEW)
				System.out.println("Processing new  Request!");

			System.out.println("before - " + event.getPhaseId().toString());
		}
	}

	private boolean loggedIn() {
		return null != user && null != user.getLogin();
	}

	public PhaseId getPhaseId() {
		return PhaseId.ANY_PHASE;
	}
}