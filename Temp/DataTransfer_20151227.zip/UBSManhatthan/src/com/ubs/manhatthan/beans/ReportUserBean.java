package com.ubs.manhatthan.beans;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import org.apache.log4j.Level;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.logger.ManhattanLogger;
import com.ubs.manhatthan.manager.persistence.entities.OrderTrade;
import com.ubs.manhatthan.manager.utils.Util;

@SuppressWarnings("serial")
@SessionScoped
@ManagedBean(name="reportUserBean")
@Component("reportUserBean")
@Scope("session")
public class ReportUserBean extends ReportBaseBean {

	private List<OrderTrade> orders;
			
    @PostConstruct
    public void init() {

    }
    
    public void openDialog(){
    	this.orders = new ArrayList<OrderTrade>();
    	this.orderFilter = new OrderTrade();
    	this.selectAccount = null;
    	this.user = new User();
    }
    	
	public List<OrderTrade> getRecords() {
		return orders;
	}

	public void setRecords(List<OrderTrade> orders) {
		this.orders = orders;
	}


	public void execute() {
    	try {
    		orders = facade.reportByStrategy(this.orderFilter);
    		refreshView();
    	} catch (DAOExceptionManhattan daoEx) {
    		daoEx.printStackTrace();
    		
    		ManhattanLogger.log(Util.getManagerId().toString(), "Error on get data for report by user", Level.ERROR);
    		
    		this.errorMessage("Error on executing report.");
    	}
	}
}