package com.ubs.manhatthan.beans;

import java.io.Serializable;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.manager.cache.StrategyCache;
import com.ubs.manhatthan.manager.enricher.PrepareToPersist;
import com.ubs.manhatthan.manager.facade.Facade;
import com.ubs.manhatthan.manager.facade.FacadeService;
import com.ubs.manhatthan.manager.facade.IManager;
import com.ubs.manhatthan.manager.persistence.entities.Strategy;
import com.ubs.manhatthan.manager.persistence.entities.StrategyOrders;
import com.ubs.manhatthan.manager.persistence.entities.StrategyReport;
import com.ubs.manhatthan.manager.persistence.entities.id.StrategyOrdersPK;
import com.ubs.manhatthan.manager.persistence.entities.id.StrategyReportPK;
import com.ubs.manhatthan.manager.utils.Util;

@SuppressWarnings("serial")
@Component("userMergeBean")
@Scope("session")
public class UserMergeBean implements Serializable {  
	
	@Autowired
	private User user;
	
	@Autowired
	private Facade facade;
	
	@Autowired
	private FacadeService facadeService;

	@Autowired
	private IManager manager;
	
	@Autowired
	private PrepareToPersist prepareToPersist;
	
	public UserMergeBean(){}
	
	public String enviarMsg() {
		
//		try {
//			NetworkClientManager networkClientManager = CacheHelper.engineCommunicatorInstance.get( facade.getEngineIdByAccount( 2056L ) );
//		} catch (Exception e){
//			e.printStackTrace();
//		}
		
		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_WARN, "Mensagem Enviada", "Mensagem Enviada");

        FacesContext.getCurrentInstance().addMessage(null, message);
        
        return "sendEngine.xhtml";
		
	}
	public String login() {
		
		StrategyReport report  = new StrategyReport();
		report.setId( new StrategyReportPK( 33L, 1L, Util.convertDatePattern( "12/10/2015", "dd/MM/yyyy" ) ) );
		report.getHeader().setEngineInstanceId( 33001L );
		report.setText("First");
		
		StrategyCache.putMessageByUser( "admin", report );
		System.out.println(StrategyCache.messageUserCache);
		System.out.println("================================================================================");
		
		report  = new StrategyReport();
		report.setId( new StrategyReportPK( 33L, 2L, Util.convertDatePattern( "12/10/2015", "dd/MM/yyyy" ) ) );
		report.getHeader().setEngineInstanceId( 33001L );
		report.setText("Second");
		
		StrategyCache.putMessageByUser( "admin", report );
		System.out.println(StrategyCache.messageUserCache);
		System.out.println("================================================================================");
		
		report  = new StrategyReport();
		report.setId( new StrategyReportPK( 33L, 3L, Util.convertDatePattern( "12/10/2015", "dd/MM/yyyy" ) ) );
		report.getHeader().setEngineInstanceId( 33001L );
		report.setText("Third");
		
		StrategyCache.putMessageByUser( "admin", report );
		System.out.println(StrategyCache.messageUserCache);
		System.out.println("================================================================================");
		
		report  = new StrategyReport();
		report.setId( new StrategyReportPK( 33L, 1L, Util.convertDatePattern( "12/10/2015", "dd/MM/yyyy" ) ) );
		report.getHeader().setEngineInstanceId( 33001L );
		report.setText("First Atualizado");
		
		StrategyCache.putMessageByUser( "admin", report );
		System.out.println(StrategyCache.messageUserCache);
		System.out.println("================================================================================");
		
		report  = new StrategyReport();
		report.setId( new StrategyReportPK( 33L, 3L, Util.convertDatePattern( "12/10/2015", "dd/MM/yyyy" ) ) );
		report.getHeader().setEngineInstanceId( 33001L );
		report.setText("Third Atualizado");
		
		StrategyCache.putMessageByUser( "admin", report );
		System.out.println(StrategyCache.messageUserCache);
		System.out.println("================================================================================");
		
		StrategyOrders order = new StrategyOrders();
		order.setId( new StrategyOrdersPK( 33L, 1L, Util.convertDatePattern( "12/10/2015", "dd/MM/yyyy" ) ) );
		report.getHeader().setEngineInstanceId( 33001L );
		order.setText("Order 1");
		
		StrategyCache.putMessageByUser( "admin", order );
		System.out.println(StrategyCache.messageUserCache);
		System.out.println("================================================================================");
		
		order = new StrategyOrders();
		order.setId( new StrategyOrdersPK( 33L, 2L, Util.convertDatePattern( "12/10/2015", "dd/MM/yyyy" ) ) );
		report.getHeader().setEngineInstanceId( 33001L );
		order.setText("Order 2");
		
		StrategyCache.putMessageByUser( "admin", order );
		System.out.println(StrategyCache.messageUserCache);
		System.out.println("================================================================================");
		
		order = new StrategyOrders();
		order.setId( new StrategyOrdersPK( 33L, 3L, Util.convertDatePattern( "12/10/2015", "dd/MM/yyyy" ) ) );
		report.getHeader().setEngineInstanceId( 33001L );
		order.setText("Order 3");
		
		StrategyCache.putMessageByUser( "admin", order );
		System.out.println(StrategyCache.messageUserCache);
		System.out.println("================================================================================");
		
		order = new StrategyOrders();
		order.setId( new StrategyOrdersPK( 33L, 2L, Util.convertDatePattern( "12/10/2015", "dd/MM/yyyy" ) ) );
		report.getHeader().setEngineInstanceId( 33001L );
		order.setText("Order 2 Atualizada");
		
		StrategyCache.putMessageByUser( "admin", order );
		System.out.println(StrategyCache.messageUserCache);
		System.out.println("================================================================================");
		
		order = new StrategyOrders();
		order.setId( new StrategyOrdersPK( 33L, 1L, Util.convertDatePattern( "12/10/2015", "dd/MM/yyyy" ) ) );
		report.getHeader().setEngineInstanceId( 33001L );
		order.setText("Order 1 atualizada");
		
		StrategyCache.putMessageByUser( "admin", order );
		System.out.println(StrategyCache.messageUserCache);
		System.out.println("================================================================================");
		
		List<Strategy> messagesByUser = facadeService.getMessagesByUser( "admin" );
		List<Strategy> allMessages = facadeService.getAllMessages();
		
		System.out.println( messagesByUser );
		System.out.println( allMessages );

		/*
		try {
			//String enteringTraderByLogin = facade.getEnteringTraderByLogin( "admin" );
			String enteringTraderByLogin = "";
			System.out.printl n("UserMergeBean.login(): " + enteringTraderByLogin );
		} catch (DAOExceptionManhattan e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		*/
		
		return "merge.xhtml";
	}
	
//	public String login() {
//        FacesMessage message = null;
//         
//        if( "admin".equalsIgnoreCase( user.getLogin() ) && "admin".equalsIgnoreCase( user.getPassword() ) ) {
//        	
//        	try {
//        		
////    			StrategyReport generateStrategyReport = manager.generateStrategyReport( 2L, 30);
////    			
////    			for (LegStrategyReport leg : generateStrategyReport.getLegStrategyList() ) {
////					
////    				for (StrategyOrders order : leg.getStrategyOrdersList() ) {
////    					prepareToPersist.saveOrder( generateStrategyReport, order );
////					}
////				}
////    			facade.saveStrategyReport( generateStrategyReport );
//  
//        		
//        		Long engineIdByAccount = facade.getEngineIdByAccount( 2056L );
//        		System.out.println( engineIdByAccount );
//        		
//        		
//    			/*
//    			 * 
//    			 * Report by user
//    			 * 
//    			 * */
//        		
//        		OrderTrade orderTrade = new OrderTrade ();
//        		orderTrade.setLogin( user.getLogin() );
//        		
//        		orderTrade.setAccount( new ClientAccount(2056L) );
//        		
//        		Calendar cal = Calendar.getInstance();
//        		cal.add( Calendar.MONTH , -2 );
//        		Date startDt = cal.getTime();
//        		
//        		startDt.getTime();
//        		
//        		orderTrade.setStartDt( startDt );
//        		
//        		cal = Calendar.getInstance();
//        		cal.add( Calendar.DATE, +1 );
//        		Date endDt = cal.getTime();
//        		
//        		orderTrade.setEndDt( endDt );
//        		
//        		facade.reportByStrategy( orderTrade );
//        		
//        		facade.reportByAverage( orderTrade );
//        		
//        		facade.reportByExecution( orderTrade );
//        		
//        		facade.reportByPrice( orderTrade );
//        		
//        		
//    			/*
//    			 * 
//    			 * Save Password Parameter
//    			 * 
//    			 * */
//        		
//        		PasswordParameter passwordParameter = new PasswordParameter( Integer.valueOf( (""+new Date().getTime()).substring( 5 ) ), 
//													        				 Integer.valueOf( (""+new Date().getTime()).substring( 5 ) ), 
//													        				 Integer.valueOf( (""+new Date().getTime()).substring( 5 ) ), 
//													        				 Integer.valueOf( (""+new Date().getTime()).substring( 5 ) ), 
//													        				 Integer.valueOf( (""+new Date().getTime()).substring( 5 ) ) );
//        		
//        		facade.savePasswordParameter( passwordParameter );
//        		
//        		/*
//        		 * 
//        		 * Save Profile
//        		 * 
//        		 * */
//        		
//        		Profile profile = new Profile( ""+new Date().getTime() );
//
//        		facade.saveProfile( profile );
//    			
//			/*
//			 * 
//			 * Save Exchange
//			 * 
//			 * */
//			Exchange exchange = new Exchange( String.valueOf( new Date().getTime() ).substring(0, 8), "TESTE INTERFACE");
//						
//			facade.saveExchange( exchange );
//        	
//        	/* 
//        	 * Save Role 
//        	 * 
//        	 * */
//        	Role role = new Role( "Spring_" + StringUtils.reverse( String.valueOf( new Date().getTime() ) ).substring(0, 6)  );
//        	
//        	facade.saveRole(role);
//
//        	/*
//        	 * 
//        	 * Save RoleByProfile
//        	 * 
//        	 * */
//        	Role findRole = facade.findRole( 0 );
//        	
//        	Profile findProfile = facade.findProfile( 0 );
//        	
//        	RoleByProfile roleByProfile = new RoleByProfile( findRole, findProfile );
//        	
//        	facade.saveRoleByProfile( roleByProfile );
//
//        	/*
//        	 * 
//        	 * Save account type
//        	 * 
//        	 * */
//        	
//        	AccountType accountType = new AccountType( "Account_Type_" + (new Date().getTime()) );
//        	
//        	facade.saveAccountType( accountType );
//        	
//        	/*
//        	 * 
//        	 * Save Engine Instance
//        	 * 
//        	 * */
//        	
//        	EngineInstance engineInstance = new EngineInstance( (new Date().getTime()), " 255.255.255.", (long) 8079, String.valueOf("EngDesc_"+(new Date().getTime())).substring(0, 15) );
//			facade.saveEngineInstance( engineInstance );
//			
//			/*
//			 * 
//			 * Save EngineUmdfChannel
//			 * 
//			 * */
//			
//			Exchange exchangeByIndex4 = facade.getExchangeByIndex( 0 );
//			
//			EngineUmdfChannel engineUmdfChannel = new EngineUmdfChannel( (new Date().getTime()),
//																		 exchangeByIndex4,
//																		 "incrementalIp_", (new Date().getTime() ),
//																		 "marketRecIp_", (new Date().getTime() ),
//																		 "instrDefIp_", (new Date().getTime() ),
//																		 ChannelTypeEnum.MBO );
//			
//			facade.saveEngineUmdfChannel( engineUmdfChannel );
//			
//			
//			/*
//			 * 
//			 * Save Order Fix Session
//			 * 
//			 * */
//			
//			List<Exchange> findExchange = facade.findExchange(new Exchange("BVSP", "IBOVESPA") );
//			
//			if ( findExchange != null && !findExchange.isEmpty() ) {
//				OrderFixSession orderFixSession = new OrderFixSession( findExchange.get(0), "255.255.255."+(new Date().getTime()),
//						             (new Date().getTime()), "BVMF_"+(new Date().getTime()), "UBS_"+(new Date().getTime()),
//						             "123456"+(new Date().getTime()) ,"description"+(new Date().getTime()) );
//
//				facade.saveOrderFixSession( orderFixSession );
//			}
//			
//			/*
//			 * 
//			 * Save Tcp Recovery Session
//			 * 
//			 * */
//			
//			Exchange exchangeByIndex2 = facade.getExchangeByIndex( 0 );
//			
//			if ( exchangeByIndex2 != null ) {
//				
//				TcpRecoverySession tcpRecoverySession = new TcpRecoverySession( exchangeByIndex2, (""+new Date().getTime()),
//																	     	    new Date().getTime(), (""+new Date().getTime()),
//																	     	    (""+new Date().getTime()));
//				
//				facade.saveTcpRecoverySession( tcpRecoverySession );
//			}
//			
//			/*
//			 * 
//			 * Save Trader Watch Tab
//			 * 
//			 * */
//			
//			TraderWatchTab traderWatchTab = new TraderWatchTab( user.getLogin(), (""+new Date().getTime()).substring(1));
//			
//			facade.saveTraderWatchTab( traderWatchTab );
//			
//			/*
//			 * 
//			 * Save Strategy Type
//			 * 
//			 * */
//
//			StrategyType strategyType = new StrategyType( Integer.valueOf((""+new Date().getTime()).substring(5)), ""+new Date().getTime(), Integer.valueOf(""+( new Date().getTime() % 4 +1)) );
//			
//			facade.saveStrategyType( strategyType );
//			
//			/*
//			 * 
//			 * Save Strategy Type Leg
//			 * 
//			 * */
//			
//			StrategyType strategyTypeByIndex2 = facade.getStrategyTypeByIndex( 0 );
//			
//			if ( strategyTypeByIndex2 != null ) {
//				
//				StrategyTypeLeg strategyTypeLeg = new StrategyTypeLeg( strategyTypeByIndex2, SideEnum.BUY.getCode(), Integer.valueOf(""+(new Date().getTime() % 4 ) ) );
//				
//				facade.saveStrategyTypeLeg( strategyTypeLeg );
//			}
//			
//			/*
//			 * 
//			 * Save Trader
//			 * 
//			 * */
//			
//			Profile profileByIndex = facade.getProfileByIndex( 0 );
//			
//			if ( profileByIndex != null ){
//				
//				Trader trader = new Trader( ""+new Date().getTime(), ""+new Date().getTime(), user.getPassword(), new Date(),
//						profileByIndex, Boolean.TRUE);
//				
//				facade.saveTrader( trader );
//			}
//			
//			/*
//			 * 
//			 * Save Trader Exchange Code
//			 * 
//			 * */
//			
//			Exchange exchangeByIndex3 = facade.getExchangeByIndex( 0 );
//			
//			if ( profileByIndex != null ){
//				
//				TraderExchangeCode traderExchangeCode = new TraderExchangeCode(user.getLogin(), exchangeByIndex3, (""+new Date().getTime()).substring( 5 ) );
//				
//				facade.saveTraderExchangeCode( traderExchangeCode );
//			}
//			
//			/*
//			 * 
//			 * Save Strategy By Tab
//			 * 
//			 * */
//			
//			TraderWatchTab traderWatchTabByIndex = facade.getTraderWatchTabByIndex( 0 );
//			
//			StrategyType strategyTypeByIndex = facade.getStrategyTypeByIndex( 0 );
//			
//			if ( traderWatchTabByIndex != null && strategyTypeByIndex != null ) {
//				
//				StrategyByTab strategyByTab = new StrategyByTab( traderWatchTabByIndex, strategyTypeByIndex, 701325 );
//				
//				facade.saveStrategyByTab( strategyByTab );
//			}
//
//			
//			/*
//			 * 
//			 * Save Order Fix Session
//			 * 
//			 * */
//			
//			ClientAccount clientAccount = facade.getClientAccountByIndex( 0 );
//			
//			OrderFixSession orderFixSession = facade.getOrderFixSessionByIndex( 0 );
//			
//			if ( clientAccount != null && orderFixSession != null ) {
//				
//				SessionByAccount sessionByAccount = new SessionByAccount (clientAccount, orderFixSession );
//				
//				facade.saveOrderFixSession( sessionByAccount );
//			}
//			
//			/*
//			 * 
//			 * Save Session By Engine
//			 * 
//			 * */
//			
//			EngineInstance engineInstanceByIndex = facade.getEngineInstanceByIndex( 0 );
//			
//			OrderFixSession orderFixSessionByIndex = facade.getOrderFixSessionByIndex( 0 );
//			
//			if ( engineInstanceByIndex != null && orderFixSessionByIndex != null ) {
//				
//				SessionByEngine sessionByEngine = new SessionByEngine( engineInstanceByIndex, orderFixSessionByIndex);
//				
//				facade.saveSessionByEngine( sessionByEngine );
//			}
//			
//			/*
//			 * 
//			 * Save Strategy By Tab Leg
//			 * 
//			 * */
//			
//			StrategyByTab strategyByTabByIndex = facade.getStrategyByTabByIndex( 0 );
//			
//			StrategyTypeLeg strategyTypeLegByIndex = facade.getStrategyTypeLegByIndex( 0 );
//			
//			if ( strategyByTabByIndex != null && strategyTypeLegByIndex != null ) {
//				
//				StrategyByTabLeg strategyByTabLeg = new StrategyByTabLeg(strategyByTabByIndex, strategyTypeLegByIndex, 701325);
//				
//				facade.saveStrategyByTabLeg( strategyByTabLeg );
//			}
//			
//			/*
//			 * 
//			 * Save Umdf Channel By Engine
//			 * 
//			 * */
//			EngineInstance engineInstanceByIndex2 = facade.getEngineInstanceByIndex( 0 );
//			
//			EngineUmdfChannel engineUmdfChannelByIndex = facade.getEngineUmdfChannelByIndex( 0 );
//			
//			if ( engineInstanceByIndex2 != null && engineUmdfChannelByIndex != null ) {
//
//				UmdfChannelByEngine umdfChannelByEngine = new UmdfChannelByEngine( engineInstanceByIndex2, engineUmdfChannelByIndex );
//				
//				facade.saveUmdfChannelByEngine( umdfChannelByEngine );
//			}
//			
//			/*
//			 * 
//			 * Save Umdf Recovery Session By Engine
//			 * 
//			 * */
//			EngineInstance engineInstanceByIndex3 = facade.getEngineInstanceByIndex( 0 );
//			
//			TcpRecoverySession tcpRecoverySessionByIndex = facade.getTcpRecoverySessionByIndex( 0 );
//			
//			if ( engineInstanceByIndex3 != null && tcpRecoverySessionByIndex != null ) {
//
//				RecoverySessionByEngine umdfRecoverySessionByEngine = new RecoverySessionByEngine( engineInstanceByIndex3, tcpRecoverySessionByIndex);
//				
//				facade.saveUmdfRecoverySessionByEngine( umdfRecoverySessionByEngine );
//			}
//			
//			} catch (Exception e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//        	
//            return "teste.xhtml";
//            
//        } else {
//            message = new FacesMessage(FacesMessage.SEVERITY_WARN, "Loggin Error", "Invalid credentials");
//
//            FacesContext.getCurrentInstance().addMessage(null, message);
//            
//            return "merge.xhtml";
//        }
//   }

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public void setFacade(Facade facade) {
		this.facade = facade;
	}

	public void setManager(IManager manager) {
		this.manager = manager;
	}

	public void setPrepareToPersist(PrepareToPersist prepareToPersist) {
		this.prepareToPersist = prepareToPersist;
	}

	public void setFacadeService(FacadeService facadeService) {
		this.facadeService = facadeService;
	}
}