package com.ubs.manhatthan.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

import org.primefaces.event.CellEditEvent;

import com.ubs.manhatthan.model.Otc;

@SuppressWarnings("serial")
@SessionScoped
@ManagedBean(name="otcBean")
public class OtcBean implements Serializable {

	private List<Otc> otc;
	
	public OtcBean(){
		
		otc = new ArrayList<Otc>();
	}

	public List<String> completeString(String query) {
		List<String> results = new ArrayList<String>();
		for (int i = 0; i < 10; i++)
			results.add(query + i);
		return results;
	}
		
	public void onCellEdit( CellEditEvent event ) {
		
        Object oldValue = event.getOldValue();
        Object newValue = event.getNewValue();
        
        int rowIndex = event.getRowIndex();
        
        Otc otcs=  otc.get( rowIndex );
        
        otc.get( rowIndex ).setInstrument( otc.get( rowIndex ).getInstrument() + " Editado" );
         
        if( newValue != null && !newValue.equals(oldValue) ) {
            FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "otc: " + otcs.getInstrument() +  " Cell Changed", "Old: " + oldValue + ", New:" + newValue);
            FacesContext.getCurrentInstance().addMessage(null, msg);
        }
    }

	public List<Otc> getOtc() {
		return otc;
	}

	public void setOtc(List<Otc> otc) {
		this.otc = otc;
	}

}