package com.ubs.manhatthan.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Level;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ubs.manhatthan.common.enuns.StrategyStatusEnum;
import com.ubs.manhatthan.exception.BussinessExceptionManhattan;
import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.enums.CommandTypeEnum;
import com.ubs.manhatthan.manager.enums.MessageTypeEnum;
import com.ubs.manhatthan.manager.enums.SideEnum;
import com.ubs.manhatthan.manager.facade.FacadeService;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.manager.MDSubscribeResponse;
import com.ubs.manhatthan.manager.logger.ManhattanLogger;
import com.ubs.manhatthan.manager.persistence.entities.CommandMessage;
import com.ubs.manhatthan.manager.persistence.entities.Header;
import com.ubs.manhatthan.manager.persistence.entities.Message;
import com.ubs.manhatthan.manager.utils.Constant;
import com.ubs.manhatthan.manager.utils.Util;
import com.ubs.manhatthan.model.Account;
import com.ubs.manhatthan.model.LegStrategyReport;
import com.ubs.manhatthan.model.StrategyReport;
import com.ubs.manhatthan.model.StrategyType;
import com.ubs.manhatthan.model.StrategyTypeLeg;
import com.ubs.manhatthan.model.Unlegging;
import com.ubs.manhatthan.service.ManagerFacade;
import com.ubs.manhatthan.service.MarketWatchFacade;

@Component("managerBean")
@Scope("session")
@SessionScoped
@ManagedBean(name = "managerBean")
public class ManagerBean extends UBSCommonBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4696450270615840861L;

	private StrategyTypeLeg selectStrategyTypeLeg;
	private StrategyType selectStrategyType;
	private StrategyReport strategyReport;
	private StrategyReport selectStrategyReport;
	private LegStrategyReport selectLegStrategyReport;
	private Unlegging selectUnlegging;
	
	private Account selectAccount;

	private List<StrategyReport> strategyReports;
	private List<StrategyReport> selectStrategyReports;

	private String idSelectStrategyType;

	private long marketingExec;

	private boolean isStrategyPauseAll;
	private boolean isStrategyResumeAll;
	private boolean isOnlyMarket;
	
	private boolean checkAllPO;
	
	private MDSubscribeResponse subscribe;
	
	@Autowired
	MarketWatchFacade marketWatchFacade;

	@Autowired
	ManagerFacade managerFacade;

	@Autowired
	FacadeService facadeService;

	public ManagerBean() {
		isStrategyPauseAll = true;
		isStrategyResumeAll = false;
		selectStrategyTypeLeg = new StrategyTypeLeg();
	}

	@PostConstruct
	private void loadView() {
		loadInfo();
	}
	
	public void loadInfo() {
		try {
			strategyReports = new ArrayList<StrategyReport>();
			strategyTypes = marketWatchFacade.getStrategyTypesDomain();
			if (null != strategyTypes) {
				idSelectStrategyType = String.valueOf(strategyTypes.get(0).getId());
				selectStrategyType = strategyTypes.get(0);
				strategyReport = initInfoStrategyReport(idSelectStrategyType);
			}

		} catch (DAOExceptionManhattan e) {
			logError(e.getMessage());
		}
	}

	public void loadFormAddStrategy() {
		selectStrategyType = strategyTypes.get(0);
		idSelectStrategyType = selectStrategyType.getId().toString();
		strategyReport = initInfoStrategyReport(idSelectStrategyType);
		refresh();
	}

	public void changeComboStrategy(ValueChangeEvent event) {
		String tw = (String) event.getNewValue();
		idSelectStrategyType = tw;
		strategyReport = initInfoStrategyReport(idSelectStrategyType);
		refresh();
	}
	
	public void clearDialogFields() {
		clearStrategyParametersFields( false );
	}
	
	public void clearStrategyParameters() {
		clearStrategyParametersFields( true );
	}
	
	public void changeSideFromDoubleClick() {
//		No fim, n�o preciso do parametro vindo do remoteCommand,
//		mas fica como modelo quando precisar
//		FacesContext context = FacesContext.getCurrentInstance();
//	    Map map = context.getExternalContext().getRequestParameterMap();
//	    Object object = map.get("index" );
		
		for (LegStrategyReport leg : strategyReport.getLegStrategyList() ) {
			
			if ( SideEnum.BUY.getCode().equals( leg.getSide() ) ){
				leg.setSide( SideEnum.SELL.getCode() );
			} else {
				leg.setSide( SideEnum.BUY.getCode() );
			}
		}
		
		managerEmptyFields();
	}

	private StrategyReport initInfoStrategyReport(String value) {
		StrategyReport report = new StrategyReport();
		report.setRestingLevel( Constant.DEFAULT.RESTING_LEVEL );
		report.setRiskLevel( Constant.DEFAULT.RISK_LEVEL );
		report.setEndTimeText(Util.convertDateHourNowPattern( Constant.DEFAULT.END_TIME ));
		for (StrategyType strategyType : strategyTypes) {
			if (Long.valueOf(value).equals(strategyType.getId())) {
				selectStrategyType = strategyType;
				report.setStrategyType(selectStrategyType);
				if (null != selectStrategyType.getStrategyTypeLegList()) {
					report.setLegStrategyList(new ArrayList<LegStrategyReport>());
					for (StrategyTypeLeg typeLeg : selectStrategyType.getStrategyTypeLegList()) {
						LegStrategyReport legStrategyReport = new LegStrategyReport();
						BeanUtils.copyProperties(typeLeg, legStrategyReport);
						legStrategyReport.setSide(typeLeg.getDefaultSide());
						report.getLegStrategyList().add(legStrategyReport);
					}
				}
				break;
			}
		}
		return report;
	}

	public void changeSellBuy() {

		for (int i = 0; i < selectStrategyType.getStrategyTypeLegList().size(); i++) {
			if (null != selectStrategyType.getStrategyTypeLegList().get(i).getLegged().getTotalQty()
					&& selectStrategyType.getStrategyTypeLegList().get(i).getLegged().getTotalQty() < 0) {
				long positivo = selectStrategyType.getStrategyTypeLegList().get(i).getLegged().getTotalQty() * -1;
				selectStrategyType.getStrategyTypeLegList().get(i).getLegged().setTotalQty(positivo);
				selectStrategyType.getStrategyTypeLegList().get(i).setDefaultSide(2);
			} else {
				selectStrategyType.getStrategyTypeLegList().get(i).setDefaultSide(1);
			}
		}
	}
	
	public void changeSellBuyByQuantity( String indexParam ) {
			
		if ( StringUtils.isNotBlank( indexParam ) ){
		
			int lastIndexOfLegList = strategyReport.getLegStrategyList().size() -1;
			
			Integer intIndexParam = Integer.valueOf( indexParam );
			
			if ( lastIndexOfLegList == intIndexParam ){
			
//				Define o �ltimo objeto da lista, se for negativo, considera o m�dulo
//				e ajusta o side para Sell, caso contr�rio define o side como buy
				if ( null != strategyReport.getLegStrategyList().get( lastIndexOfLegList ).getTotalQuantity() &&
					 strategyReport.getLegStrategyList().get( lastIndexOfLegList ).getTotalQuantity() < 0) {
					
					Long positivo = Math.abs( strategyReport.getLegStrategyList().get( lastIndexOfLegList ).getTotalQuantity() );
					strategyReport.getLegStrategyList().get( lastIndexOfLegList ).setTotalQuantity(positivo);
					
					strategyReport.getLegStrategyList().get( lastIndexOfLegList ).setSide(SideEnum.SELL.getCode());
				} else { 
					strategyReport.getLegStrategyList().get( lastIndexOfLegList ).setSide(SideEnum.BUY.getCode());
				}
				
//				ajusta os buy/sell de todas as legs baseado na �ltima
				changeSideByLastLeg( strategyReport.getLegStrategyList().get( lastIndexOfLegList ).getSide(),
			             			 lastIndexOfLegList );
			} else {
				strategyReport.getLegStrategyList().get( intIndexParam ).setTotalQuantity( 
							   Math.abs( strategyReport.getLegStrategyList().get( intIndexParam ).getTotalQuantity() ) );
			}
		}
		
		managerEmptyFields();
	}
	
	public void changeSellBuyByDiv( String indexParam ) {
		
		if ( StringUtils.isNotBlank( indexParam ) ){
			
			int lastIndexOfLegList = strategyReport.getLegStrategyList().size() -1;
			
			if ( lastIndexOfLegList == Integer.valueOf( indexParam ) ){
				
//				Define o �ltimo objeto da lista, se for negativo, considera o m�dulo
//				e ajusta o side para Sell, caso contr�rio define o side como buy
				if ( null != strategyReport.getLegStrategyList().get( lastIndexOfLegList ).getDiv1() &&
					 strategyReport.getLegStrategyList().get( lastIndexOfLegList ).getDiv1() < 0) {
					
					double positivo = Math.abs( strategyReport.getLegStrategyList().get( lastIndexOfLegList ).getDiv1() );
					strategyReport.getLegStrategyList().get( lastIndexOfLegList ).setDiv1(positivo);
					
					strategyReport.getLegStrategyList().get( lastIndexOfLegList ).setSide(SideEnum.SELL.getCode());
				} else { 
					strategyReport.getLegStrategyList().get( lastIndexOfLegList ).setSide(SideEnum.BUY.getCode());
				}
				
//				ajusta os buy/sell de todas as legs baseado na �ltima
				changeSideByLastLeg( strategyReport.getLegStrategyList().get( lastIndexOfLegList ).getSide(),
						             lastIndexOfLegList );
			}
		}
		
		managerEmptyFields();
	}
	
	private void changeSideByLastLeg( Integer lastSide, Integer lastIndexOfLegList ){
		
		for (int i = lastIndexOfLegList -1; i >= 0; i--) {
			
			if ( SideEnum.BUY.equals( SideEnum.fromValue( lastSide ) ) ){
				strategyReport.getLegStrategyList().get( i ).setSide(SideEnum.SELL.getCode());	
			} else {
				strategyReport.getLegStrategyList().get( i ).setSide(SideEnum.BUY.getCode());	
			}
			lastSide = strategyReport.getLegStrategyList().get( i ).getSide();
		}
	}
	
	public void checkAll() {
		for (LegStrategyReport leg : strategyReport.getLegStrategyList()) {
			leg.setPassiveLeg( checkAllPO );
		}
		
		managerEmptyFields();
	}

	public void callSendOTC(ActionEvent actionEvent) {
		try {
			managerFacade.sendOTC(selectStrategyReport, selectLegStrategyReport);
			throw new BussinessExceptionManhattan("teste");
		} catch (BussinessExceptionManhattan e) {
			addMsgValidationError(e.getLocalizedMessage());
			
			logError(e.getMessage());
		} catch (DAOExceptionManhattan e) {
			logError(e.getMessage());
		}
	}

	public void callSendUnLegged(ActionEvent actionEvent) {
		try {
			managerFacade.sendUnlegged(selectStrategyReport, selectLegStrategyReport);
		} catch (BussinessExceptionManhattan e) {
			addMsgValidationError(e.getLocalizedMessage());
			
			logError(e.getMessage());
		} catch (DAOExceptionManhattan e) {
			
			logError(e.getMessage());
		}
	}

	public void changeOrderBSUnLegged() {
		if (SideEnum.BUY.getCode().equals(selectStrategyTypeLeg.getDefaultSide())) {
			selectStrategyTypeLeg.setDefaultSide(2);
		} else {
			selectStrategyTypeLeg.setDefaultSide(1);
		}
	}

	public void calculateIsOnlyTarget(ActionEvent actionEvent) {
//		descomentar aim*
//		try {
		if ( validation( true ) ){
//			strategyReport = managerFacade.calculateValuesStrategyReport(strategyReport, true);
			strategyReport.setTargetDif(66.66);
			strategyReport.setMarket(123.456);
		} else {
			strategyReport.setTargetDif( null );
			strategyReport.setMarket( null );
		}
			
		managerEmptyFields();
	}

	public void calculateStrategyValues(ActionEvent actionEvent) {
//		descomentar aim*
//		try {
			
			if ( validation( false ) ){
//			strategyReport = managerFacade.calculateValuesStrategyReport(strategyReport, false);
				strategyReport.setTargetDif(66.66);
				strategyReport.setMarket(123.456);
			} else {
				strategyReport.setTargetDif( null );
				strategyReport.setMarket( null );
			}
			
//		} catch (DAOExceptionManhattan e) {
//			e.printStackTrace();
//			logError(e.getMessage());
//		}
		managerEmptyFields();
	}
	
	public boolean validateStrategyCreation( ){
		boolean validationOK = true;
		
		validationOK = validation( false );
		
		for (int i = 0; i < strategyReport.getLegStrategyList().size(); i++) {
			LegStrategyReport leg = strategyReport.getLegStrategyList().get( i );
			
			if ( leg.getClip() == null ){
				addValidationMessage( "componentStrategyParameters:formManagerAddStrategy:clip"+i,
						  			  "Strategy Creation Error",
									  "Clip " + (i+1) + " is mandatory" );
				validationOK = false;
			}
		}
		
		if ( strategyReport.getRestingLevel() == null ){
			addValidationMessage( "componentStrategyParameters:formManagerAddStrategy:bookLevel_input",
					  			  "Strategy Creation Error",
								  "Book Level is mandatory" );
			validationOK = false;
		}
		
		if ( strategyReport.getRiskLevel() == null ){
			addValidationMessage( "componentStrategyParameters:formManagerAddStrategy:riskLevel_input",
								  "Strategy Creation Error",
								  "Risk Level is mandatory" );
			validationOK = false;
		}
		
		if ( strategyReport.getStartPaused() == false && 
			 ( strategyReport.getEndTimeText() == null || strategyReport.getStartTimeText() == null ) ){
			
			addValidationMessage( "componentStrategyParameters:formManagerAddStrategy:txtStart",
							      "Strategy Creation Error",
								  "Create Strategy Paused or set a time to start and end" );
			
			addValidationBorder( "componentStrategyParameters:formManagerAddStrategy:txtEnd" );
			addValidationBorder( "componentStrategyParameters:formManagerAddStrategy:createStrategyPaused" );
			
			validationOK = false;
		}
		
		return validationOK;
	}
	public boolean validation( boolean isOnlyTarget ){
		
		boolean validationOK = true;
		
		if ( strategyReport == null || strategyReport.getLegStrategyList() == null ||
			 strategyReport.getLegStrategyList().isEmpty() || strategyReport.getLegStrategyList().size() < 2  ){
			
			addMsgValidationError( "Generic Error", "The report structure is incorrect");

			return false;
		}
			
		for (int i = 0; i < strategyReport.getLegStrategyList().size(); i++) {
			
			LegStrategyReport leg = strategyReport.getLegStrategyList().get( i );
			
			if ( leg.getLegSeq() == null || leg.getSide() == null ){
				addMsgValidationError( "Generic Error", "The report structure is incorrect");
				return false;
			}
			
			if ( StringUtils.isBlank( leg.getContract() ) ){
				addValidationMessage( "componentStrategyParameters:formManagerAddStrategy:contracts"+i,
						  			  "Calculation Error",
									  "Contract " + (i+1) + " is mandatory" );
				validationOK = false;
			} else {
//				Descomentar aim* - Valida��o do contrato no lmds
//				try {
//					subscribe = facadeService.subscribe( leg.getContract() );
//					
//					if ( subscribe == null ){
//						addValidationMessage( "componentStrategyParameters:formManagerAddStrategy:contracts"+i,
//					  			  			  "Calculation Error",
//					  			  			  "Invalid contract: " + leg.getContract() );
//						validationOK = false;
//					}
//					
//				} catch (DAOExceptionManhattan e) {
//					e.printStackTrace();
//				}
			}
			
		}
		
		if ( strategyReport.getTarget() == null ){
			addValidationMessage( "componentStrategyParameters:formManagerAddStrategy:target",
								  "Calculation Error",
								  "Target is mandatory" );
			validationOK = false;
			
		}
			
		if( !isOnlyTarget ){
			
			Integer lastIndex = strategyReport.getLegStrategyList().size() -1;
			
			LegStrategyReport lastLeg = strategyReport.getLegStrategyList().get( lastIndex );
			
			if ( lastLeg.getTotalQuantity() == null && lastLeg.getDiv1() == null ){
				addValidationBorder( "componentStrategyParameters:formManagerAddStrategy:dv"+lastIndex );
				
				addValidationMessage( "componentStrategyParameters:formManagerAddStrategy:qty"+lastIndex,
									  "Calculation Error",
									  "Quantity or Div1 is mandatory" );
				
				validationOK = false;
			}
		}
		
		return validationOK;
	}

	public List<Account> completeAccount(String name) {
		List<Account> accounts = new ArrayList<Account>();
		try {
			accounts = managerFacade.findListAccountByName(name);
		} catch (DAOExceptionManhattan e) {
			logError(e.getMessage());
		}
		return accounts;
	}

	public void createStrategy(ActionEvent actionEvent) {
		try {
			
			if ( validateStrategyCreation() ){
				
				for (int i = 0; i < strategyReport.getLegStrategyList().size(); i++) {
					strategyReport.getLegStrategyList().get(i).setAccount(selectAccount);
				}
	
				managerFacade.createStrategyReport(strategyReport);
			}
		} catch (BussinessExceptionManhattan e) {
			addMsgValidationError(e.getMessage());
			
			logError(e.getMessage());
		} catch (DAOExceptionManhattan e) {
			addMsgValidationError(e.getMessage());
			
			logError(e.getMessage());
		}
		clearStrategyParametersFields( false );
	}
	
	private void managerEmptyFields(){
		
		for ( LegStrategyReport leg : strategyReport.getLegStrategyList() ) {
			leg.setDuration( leg.getDuration() == null || leg.getDuration() == 0 ? null : leg.getDuration() );
			leg.setTotalQuantity( leg.getTotalQuantity() == null || leg.getTotalQuantity() == 0L ? null : leg.getTotalQuantity() );
			leg.setClip( leg.getClip() == null || leg.getClip() == 0L ? null : leg.getClip()  );
			leg.setRestingRank( leg.getRestingRank() == null || leg.getRestingRank() == 0L ? null : leg.getRestingRank() );
			leg.setDiv1( leg.getDiv1() == null || leg.getDiv1() == 0.0 ? null : leg.getDiv1() );
		}
		strategyReport.setRestingLevel( Constant.DEFAULT.RESTING_LEVEL );
		strategyReport.setRiskLevel( Constant.DEFAULT.RISK_LEVEL );
		strategyReport.setTarget( strategyReport.getTarget() == null || strategyReport.getTarget() == 0.0 ? null : strategyReport.getTarget() );
		strategyReport.setTargetDif( strategyReport.getTargetDif() == null || strategyReport.getTargetDif() == 0.0 ? null : strategyReport.getTargetDif() );
		strategyReport.setMarket( strategyReport.getMarket() == null || strategyReport.getMarket() == 0.0 ? null : strategyReport.getMarket() );
	}
	
	private void clearStrategyParametersFields( boolean onlyStrategyParameters ){
		
		for ( LegStrategyReport leg : strategyReport.getLegStrategyList() ) {
			leg.setContract( "" );
			leg.setDuration( null );
			leg.setTotalQuantity( null );
			leg.setClip( null );
			leg.setRestingRank( null );
			leg.setDiv1( null );
			leg.setPassiveLeg( false );
		}
		this.setCheckAllPO( false );
		this.selectAccount = null;
		
		if ( !onlyStrategyParameters ){
			strategyReport.setRestingLevel( Constant.DEFAULT.RESTING_LEVEL );
			strategyReport.setRiskLevel( Constant.DEFAULT.RISK_LEVEL );
			strategyReport.setTarget( null );
			strategyReport.setTargetDif( null );
			strategyReport.setMarket( null );
			strategyReport.setEndTimeText(Util.convertDateHourNowPattern( Constant.DEFAULT.END_TIME));
		}
	}

	public void updateStrategy(ActionEvent actionEvent) {
		try {
			managerFacade.updateStrategyReport(strategyReport, MessageTypeEnum.MODIFY_STRATEGY);
		} catch (BussinessExceptionManhattan e) {
			addMsgValidationError(e.getMessage());
			
			logError(e.getMessage());
		} catch (DAOExceptionManhattan e) {
			addMsgValidationError(e.getMessage());
			
			logError(e.getMessage());
		}
		refresh();
	}

	public void resumeStrategy(ActionEvent actionEvent) {
		try {
			for (int i = 0; i < selectStrategyReports.size(); i++) {
				managerFacade.updateActionsStrategyReport(selectStrategyReports.get(i), MessageTypeEnum.RESUME_STRATEGY);
			}
		} catch (BussinessExceptionManhattan e) {
			addMsgValidationError(e.getMessage());
			logError(e.getMessage());
		} catch (DAOExceptionManhattan e) {
			logError(e.getMessage());
		}
		refresh();
	}

	public void cancelStrategy(ActionEvent actionEvent) {
		try {
			for (int i = 0; i < selectStrategyReports.size(); i++) {
				managerFacade.updateActionsStrategyReport(selectStrategyReports.get(i), MessageTypeEnum.CANCEL_STRATEGY);
			}
		} catch (BussinessExceptionManhattan e) {
			logError(e.getMessage());
		} catch (DAOExceptionManhattan e) {
			logError(e.getMessage());
		}
		refresh();
	}

	public void pauseStrategy(ActionEvent actionEvent) {
		try {
			for (int i = 0; i < selectStrategyReports.size(); i++) {
				managerFacade.updateActionsStrategyReport(selectStrategyReports.get(i), MessageTypeEnum.PAUSE_STRATEGY);
			}
		} catch (BussinessExceptionManhattan e) {
			addMsgValidationError(e.getMessage());
			logError(e.getMessage());
		} catch (DAOExceptionManhattan e) {
			logError(e.getMessage());
		}
		refresh();
	}

	public void statusStrategyClicked(ActionEvent actionEvent) {
		try {
			for (int i = 0; i < selectStrategyReports.size(); i++) {
				if (StrategyStatusEnum.RESUMED.getCode().equals(selectStrategyReports.get(i).getStatus())) {
					managerFacade.updateActionsStrategyReport(selectStrategyReports.get(i), MessageTypeEnum.PAUSE_STRATEGY);
				} if (StrategyStatusEnum.PAUSED.getCode().equals(selectStrategyReports.get(i).getStatus())) {
					managerFacade.updateActionsStrategyReport(selectStrategyReports.get(i), MessageTypeEnum.RESUME_STRATEGY);
				}				
			}
		} catch (BussinessExceptionManhattan e) {
			addMsgValidationError(e.getMessage());
			
			logError(e.getMessage());
		} catch (DAOExceptionManhattan e) {
			logError(e.getMessage());
		}
	}

	public void submitSend() {
		try {
			managerFacade.sendUnlegged(selectStrategyReport, selectLegStrategyReport);
		} catch (BussinessExceptionManhattan e) {
			addMsgValidationError(e.getLocalizedMessage());
			
			logError(e.getMessage());
		} catch (DAOExceptionManhattan e) {
			
			logError(e.getMessage());
		}
	}

	public void submitMarket() {
		try {
			managerFacade.sendUnlegged(selectStrategyReport, selectLegStrategyReport);
		} catch (BussinessExceptionManhattan e) {
			addMsgValidationError(e.getLocalizedMessage());
			
			logError(e.getMessage());
		} catch (DAOExceptionManhattan e) {
			
			logError(e.getMessage());
		}
	}

	public void submitAllSend() {
		try {
			managerFacade.sendUnlegged(selectStrategyReport, selectLegStrategyReport);
		} catch (BussinessExceptionManhattan e) {
			addMsgValidationError(e.getLocalizedMessage());
			
			logError(e.getMessage());
		} catch (DAOExceptionManhattan e) {
			
			logError(e.getMessage());
		}
	}

	public void submitAllMarket() {
		try {
			managerFacade.sendUnlegged(selectStrategyReport, selectLegStrategyReport);
		} catch (BussinessExceptionManhattan e) {
			addMsgValidationError(e.getLocalizedMessage());
			
			logError(e.getMessage());
		} catch (DAOExceptionManhattan e) {
			
			logError(e.getMessage());
		}
	}

	public void cancellAll() {
		try {
			Header header = new Header();

			Message messageCancelAll = new CommandMessage(header, CommandTypeEnum.CANCEL_ALL_STRATEGIES);

			boolean ret = facadeService.sendToEngine(messageCancelAll);

			if (ret == false) {
				ManhattanLogger.log(Util.getManagerId().toString(), "Return facade service function sendToEngine for cancell all order is false", Level.WARN);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			ManhattanLogger.log(Util.getManagerId().toString(), ex.getMessage(), Level.ERROR);
		}
	}

	public boolean getDisabledButtons() {
		return ((this.strategyReports != null) && (this.strategyReports.size() == 0));
	}
	
	public StrategyTypeLeg getSelectStrategyTypeLeg() {
		return selectStrategyTypeLeg;
	}

	public void setSelectStrategyTypeLeg(StrategyTypeLeg selectStrategyTypeLeg) {
		this.selectStrategyTypeLeg = selectStrategyTypeLeg;
	}

	public StrategyType getSelectStrategyType() {
		return selectStrategyType;
	}

	public void setSelectStrategyType(StrategyType selectStrategyType) {
		this.selectStrategyType = selectStrategyType;
	}

	public String getIdSelectStrategyType() {
		return idSelectStrategyType;
	}

	public void setIdSelectStrategyType(String idSelectStrategyType) {
		this.idSelectStrategyType = idSelectStrategyType;
	}

	public long getMarketingExec() {
		return marketingExec;
	}

	public void setMarketingExec(long marketingExec) {
		this.marketingExec = marketingExec;
	}

	public void setMarketWatchFacade(MarketWatchFacade marketWatchFacade) {
		this.marketWatchFacade = marketWatchFacade;
	}

	public StrategyReport getStrategyReport() {
		return strategyReport;
	}

	public void setStrategyReport(StrategyReport strategyReport) {
		this.strategyReport = strategyReport;
	}

	public List<StrategyReport> getStrategyReports() {
		return strategyReports;
	}

	public void setStrategyReports(List<StrategyReport> strategyReports) {
		this.strategyReports = strategyReports;
	}

	public List<StrategyReport> getSelectStrategyReports() {
		return selectStrategyReports;
	}

	public void setSelectStrategyReports(List<StrategyReport> selectStrategyReports) {
		this.selectStrategyReports = selectStrategyReports;
	}

	public Account getSelectAccount() {
		return selectAccount;
	}

	public void setSelectAccount(Account selectAccount) {
		this.selectAccount = selectAccount;
	}

	public StrategyReport getSelectStrategyReport() {
		return selectStrategyReport;
	}

	public void setSelectStrategyReport(StrategyReport selectStrategyReport) {
		this.selectStrategyReport = selectStrategyReport;
	}

	public LegStrategyReport getSelectLegStrategyReport() {
		return selectLegStrategyReport;
	}

	public void setSelectLegStrategyReport(LegStrategyReport selectLegStrategyReport) {
		this.selectLegStrategyReport = selectLegStrategyReport;
	}		
	
	public Unlegging getSelectUnlegging() {
		return selectUnlegging;
	}

	public void setSelectUnlegging(Unlegging selectUnlegging) {
		this.selectUnlegging = selectUnlegging;
	}

	public void setManagerFacade(ManagerFacade managerFacade) {
		this.managerFacade = managerFacade;
	}

	public void setFacade(FacadeService facade) {
		this.facadeService = facade;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public MarketWatchFacade getMarketWatchFacade() {
		return marketWatchFacade;
	}

	public boolean isStrategyPauseAll() {
		return isStrategyPauseAll;
	}

	public void setStrategyPauseAll(boolean isStrategyPauseAll) {
		this.isStrategyPauseAll = isStrategyPauseAll;
	}

	public boolean isStrategyResumeAll() {
		return isStrategyResumeAll;
	}

	public void setStrategyResumeAll(boolean isStrategyResumeAll) {
		this.isStrategyResumeAll = isStrategyResumeAll;
	}

	public boolean isOnlyMarket() {
		return isOnlyMarket;
	}

	public void setOnlyMarket(boolean isOnlyMarket) {
		this.isOnlyMarket = isOnlyMarket;
	}

	public boolean isCheckAllPO() {
		return checkAllPO;
	}

	public void setCheckAllPO(boolean checkAllPO) {
		this.checkAllPO = checkAllPO;
	}
}