package com.ubs.manhatthan.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;

import org.primefaces.component.tabview.TabView;
import org.primefaces.event.TabChangeEvent;
import org.primefaces.event.TabCloseEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.manager.enums.SideEnum;
import com.ubs.manhatthan.manager.persistence.entities.StrategyByTab;
import com.ubs.manhatthan.model.Account;
import com.ubs.manhatthan.model.Market;
import com.ubs.manhatthan.model.MarketWhatchTab;
import com.ubs.manhatthan.model.StrategyType;
import com.ubs.manhatthan.service.MarketWatchFacade;

@Component("marketBean")
@Scope("session")
@SessionScoped
@ManagedBean(name = "managerBean")
public class MarketWatchBean extends UBSCommonBean implements Serializable {

	private static final long serialVersionUID = -2334341418292057103L;

	@Autowired
	private MarketWatchFacade marketWatchFacade;

	private int indexTabActive = 0;

	private String idSelectMarket;

	private Account selectAccount;

	private MarketWhatchTab marketWhatchTab;

	private StrategyType selectStrategyType;

	private Market selectMarket;

	private StrategyType selectStrategyTypeInstrument;

	private Account selectedAccount;

	private List<MarketWhatchTab> marketWhatchTabs;

	private List<MarketWhatchTab> marketWhatchTabsUnSave;

	private List<StrategyByTab> strategyByTabsUnSave;

	private List<Market> marketByTabsToDelete;

	private List<Market> selectMarkets;

	private TabView tabView;

	private Boolean renderBtnSynt = false;

	public MarketWatchBean() {
		reset();
	}

	private void reset() {
		marketWhatchTabsUnSave = new ArrayList<MarketWhatchTab>();
		marketByTabsToDelete = new ArrayList<Market>();
		marketWhatchTabs = new ArrayList<MarketWhatchTab>();
		selectStrategyType = new StrategyType();
		selectStrategyTypeInstrument = new StrategyType();
		strategyByTabsUnSave = new ArrayList<StrategyByTab>();
	}

	public void loadInfo() {
		try {

			strategyTypes = marketWatchFacade.getStrategyTypesDomain();
			marketWhatchTabs = marketWatchFacade.getWatchTabMarkets(user.getLogin());
			if (null == marketWhatchTabs || marketWhatchTabs.isEmpty()) {
				renderBtnSynt = true;
			}

		} catch (DAOExceptionManhattan e) {
			logError(e.getMessage());
		}
	}

	public String clear() {
		this.selectAccount = null;
		return "";
	}

	public void loadFormMarketNewTab() {
		marketWhatchTab = new MarketWhatchTab();
		setMarketWhatchTab(new MarketWhatchTab());
	}

	public void loadFormAddSyntetic() throws DAOExceptionManhattan {
		selectStrategyType = new StrategyType();
		idSelectMarket = strategyTypes.get(0).getId().toString();
		selectStrategyType = marketWatchFacade.getStrategyVOById(idSelectMarket);
	}

	public void changeComboValueSyntetic(ValueChangeEvent event) {
		idSelectMarket = String.valueOf(event.getNewValue());
		try {
			selectStrategyType = marketWatchFacade.getStrategyVOById(idSelectMarket);
		} catch (DAOExceptionManhattan e) {
			logError(e.getMessage());
		}
		refresh();
	}

	public void changeOrderBS() {
		for (int i = 0; i < selectStrategyType.getStrategyTypeLegList().size(); i++) {
			if (SideEnum.BUY.getCode().equals(selectStrategyType.getStrategyTypeLegList().get(i).getDefaultSide())) {
				selectStrategyType.getStrategyTypeLegList().get(i).setDefaultSide(2);
			} else {
				selectStrategyType.getStrategyTypeLegList().get(i).setDefaultSide(1);
			}
		}

	}

	public String addInstrument() {

		try {
			List<Market> listTemp = this.marketWhatchTabs.get(indexTabActive).getMarkets();

			boolean isAllowed = true;

			for (Market market : listTemp) {
				if (market.getStrategyType().getId() == null
						&& (market.getStrategyType().getInstrumentByName().equals(selectStrategyTypeInstrument.getInstrumentByName().trim()))) {
					addMsgValidationWarn("", "Instrument not allowed, is already associated with view");
					isAllowed = false;
					return "";
				}
			}

			if (isAllowed) {
				this.marketWhatchTabs.get(indexTabActive).getMarkets().add(marketWatchFacade.populateMarketVO(selectStrategyTypeInstrument));
				refresh();
				strategyByTabsUnSave.add(marketWatchFacade.populateStrategyByTab(selectStrategyTypeInstrument, this.marketWhatchTabs.get(indexTabActive)));
			}
		} catch (DAOExceptionManhattan e) {

			logError(e.getMessage());
		}
		return "main.xhtml?faces-redirect=true";
	}

	public void addSyntetic(ActionEvent actionEvent) {
		try {
			List<Market> listTemp = this.marketWhatchTabs.get(indexTabActive).getMarkets();
			boolean isAllowed = true;
			if (null != idSelectMarket && !"0".equals(idSelectMarket.trim())) {
				for (Market market : listTemp) {
					if (market.getStrategyType().getId() == selectStrategyType.getId()) {
						addMsgValidationWarn("", "Association not allowed strategia is already associated with view");
						isAllowed = false;
						break;

					}
				}

			} else {
				isAllowed = false;
				addMsgValidationWarn("", "Select Strategy required - N�o foi possivel realizar opera��o");
			}
			if (isAllowed) {
				this.marketWhatchTabs.get(indexTabActive).getMarkets().add(marketWatchFacade.populateMarketVO(selectStrategyType));
				strategyByTabsUnSave.add(marketWatchFacade.populateStrategyByTab(selectStrategyType, this.marketWhatchTabs.get(indexTabActive)));
				selectStrategyType = new StrategyType();
			}

		} catch (DAOExceptionManhattan e) {
			e.printStackTrace();
			logError(e.getMessage());
		}

	}

	public void addTabMarketPerUser(ActionEvent actionEvent) {
		if (null != marketWhatchTab.getDescription() && !"".equals(marketWhatchTab.getDescription().trim())) {
			marketWhatchTab.setLogin(user.getLogin());
			if (null != marketWhatchTabs) {
				List<MarketWhatchTab> listTemp = marketWhatchTabs;
				if (listTemp.contains(marketWhatchTab)) {
					addMsgValidationError("", "Duplicate name Tab - Operation Canceled ");
				} else {
					marketWhatchTabs.add(marketWhatchTab);
					marketWhatchTab = new MarketWhatchTab();
				}
			}

			if (!marketWhatchTabs.isEmpty()) {
				renderBtnSynt = false;
			}
		}
	}

	public String onTabCloseMarket(TabCloseEvent event) {
		renderBtnSynt = false;

		String id = event.getTab().getTitle();
		if (null != marketWhatchTabs) {
			List<MarketWhatchTab> listTemp = marketWhatchTabs;
			for (MarketWhatchTab tabs : listTemp) {
				if (id.trim().equals(tabs.getDescription().trim())) {
					marketWhatchTabs.remove(tabs);
					marketWhatchTabsUnSave.add(tabs);
					break;
				}
			}
			if (marketWhatchTabs.isEmpty()) {
				renderBtnSynt = true;
			}
		}
		return "main.xhtml?faces-redirect=true";
	}

	public void onTabChange(TabChangeEvent event) {
		TabView tab = (TabView) event.getSource();
		indexTabActive = tab.getIndex();
	}

	public void deleteStrategy(ActionEvent actionEvent) {
		try {
			for (Market mk : marketWhatchTabs.get(indexTabActive).getMarkets()) {
				if (null != selectMarket.getStratagyTabId() && null != selectMarket.getTabViewId()) {
					marketWhatchTabs.get(indexTabActive).getMarkets().remove(selectMarket);
					marketByTabsToDelete.add(selectMarket);
					break;
				} else if (mk.getStrategyType().getId() == selectMarket.getStrategyType().getId()) {
					marketWhatchTabs.get(indexTabActive).getMarkets().remove(selectMarket);
					for (StrategyByTab t : strategyByTabsUnSave) {
						if (t.getTab().getDescription().equals(marketWhatchTabs.get(indexTabActive).getDescription())
								&& t.getStrategyType().getId() == selectMarket.getStrategyType().getId())
							strategyByTabsUnSave.remove(t);
						break;
					}
					break;
				}
			}
		} catch (Exception ex) {
			logError(ex.getMessage());
			addMsgValidationError("Error on delete Strategy!", "Error on delete Strategy" + "!");
		}
	}

	public void saveSession() {
		try {
			marketWatchFacade.deleteMarketWatchList(marketWhatchTabsUnSave);
			marketWatchFacade.deleteMarketsByList(marketByTabsToDelete);
			marketWatchFacade.saveViewTabsMarket(marketWhatchTabs);
			marketWhatchTabs = marketWatchFacade.getWatchTabMarkets(user.getLogin());
			marketWatchFacade.saveStrategiesByTabMarket(marketWhatchTabs, strategyByTabsUnSave);
			reset();
			loadInfo();
		} catch (Exception e) {
			addMsgValidationSucess(e.getMessage(), e.getMessage());
		}
		addMsgValidationSucess("Opera��o realizada com sucesso", "Opera��o realizada com sucesso");
	}

	public Account getSelectedAccount() {
		return selectedAccount;
	}

	public void setSelectedAccount(Account selectedAccount) {
		this.selectedAccount = selectedAccount;
	}

	public MarketWhatchTab getMarketWhatchTab() {
		return marketWhatchTab;
	}

	public void setMarketWhatchTab(MarketWhatchTab marketWhatchTab) {
		this.marketWhatchTab = marketWhatchTab;
	}

	public List<MarketWhatchTab> getMarketWhatchTabs() {
		return marketWhatchTabs;
	}

	public void setMarketWhatchTabs(List<MarketWhatchTab> marketWhatchTabs) {
		this.marketWhatchTabs = marketWhatchTabs;
	}

	public String getIdSelectMarket() {
		return idSelectMarket;
	}

	public void setIdSelectMarket(String idSelectMarket) {
		this.idSelectMarket = idSelectMarket;
	}

	public TabView getTabView() {
		return tabView;
	}

	public void setTabView(TabView tabView) {
		this.tabView = tabView;
	}

	public int getIndexTabActive() {
		return indexTabActive;
	}

	public void setIndexTabActive(int indexTabActive) {
		this.indexTabActive = indexTabActive;
	}

	public Boolean getRenderBtnSynt() {
		return renderBtnSynt;
	}

	public void setRenderBtnSynt(Boolean renderBtnSynt) {
		this.renderBtnSynt = renderBtnSynt;
	}

	public StrategyType getSelectStrategyType() {
		return selectStrategyType;
	}

	public void setSelectStrategyType(StrategyType selectStrategyType) {
		this.selectStrategyType = selectStrategyType;
	}

	public Account getSelectAccount() {
		return selectAccount;
	}

	public void setSelectAccount(Account selectAccount) {
		this.selectAccount = selectAccount;
	}

	public void setMarketWatchFacade(MarketWatchFacade marketWatchFacade) {
		this.marketWatchFacade = marketWatchFacade;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public StrategyType getSelectStrategyTypeInstrument() {
		return selectStrategyTypeInstrument;
	}

	public void setSelectStrategyTypeInstrument(StrategyType selectStrategyTypeInstrument) {
		this.selectStrategyTypeInstrument = selectStrategyTypeInstrument;
	}

	public List<StrategyByTab> getStrategyByTabsUnSave() {
		return strategyByTabsUnSave;
	}

	public void setStrategyByTabsUnSave(List<StrategyByTab> strategyByTabsUnSave) {
		this.strategyByTabsUnSave = strategyByTabsUnSave;
	}

	public List<Market> getMarketByTabsToDelete() {
		return marketByTabsToDelete;
	}

	public void setMarketByTabsToDelete(List<Market> marketByTabsToDelete) {
		this.marketByTabsToDelete = marketByTabsToDelete;
	}

	public Market getSelectMarket() {
		return selectMarket;
	}

	public void setSelectMarket(Market selectMarket) {
		this.selectMarket = selectMarket;
	}

	public List<Market> getSelectMarkets() {
		return selectMarkets;
	}

	public void setSelectMarkets(List<Market> selectMarkets) {
		this.selectMarkets = selectMarkets;
	}

	public List<MarketWhatchTab> getMarketWhatchTabsUnSave() {
		return marketWhatchTabsUnSave;
	}

	public void setMarketWhatchTabsUnSave(List<MarketWhatchTab> marketWhatchTabsUnSave) {
		this.marketWhatchTabsUnSave = marketWhatchTabsUnSave;
	}
}