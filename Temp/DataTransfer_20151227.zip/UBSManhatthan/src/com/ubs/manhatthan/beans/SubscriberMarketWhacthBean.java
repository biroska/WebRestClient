package com.ubs.manhatthan.beans;

import java.io.Serializable;
import java.util.List;
import java.util.UUID;

import javax.annotation.PostConstruct;

import org.apache.log4j.Level;
import org.primefaces.json.JSONObject;
import org.primefaces.push.EventBus;
import org.primefaces.push.EventBusFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.helper.PushHelper;
import com.ubs.manhatthan.manager.facade.FacadeService;
import com.ubs.manhatthan.manager.lmdsadapter.SimulationItem;
import com.ubs.manhatthan.manager.logger.ManhattanLogger;
import com.ubs.manhatthan.manager.utils.Util;
import com.ubs.manhatthan.model.Market;
import com.ubs.manhatthan.model.MarketWhatchTab;
import com.ubs.manhatthan.model.PushMarketWatch;
import com.ubs.manhatthan.service.MarketWatchFacade;

@Component("subscriberMarketWhatchBean")
@Scope("session")
public class SubscriberMarketWhacthBean implements Serializable, Runnable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 6787918110709028224L;

    private static Integer sleepTimeout = 1000;

    private String channel;
    
    @Autowired
    private ResourceChannelBean resourceChannelBean;
    
    @Autowired
    private MarketWatchBean marketBean;
    
    private User userLogged;
    
    private volatile boolean done;
    
	@Autowired
	protected FacadeService facadeService;
	
	@Autowired
	private MarketWatchFacade marketWatchFacade;
	
	@PostConstruct
    public void init() {
    	channel = "/" + UUID.randomUUID().toString();
    }
    
    public void setMarketBean(MarketWatchBean marketBean)
    {
    	this.marketBean = marketBean;
    }

    public void setResourceChannelBean(ResourceChannelBean resourceChannelBean)
    {
    	this.resourceChannelBean = resourceChannelBean;
    }

	public void setFacadeService(FacadeService facadeService) {
		this.facadeService = facadeService;
	}

	public String getChannel() {
		return this.channel;
	}
	
    public void start() {
    	
    	ManhattanLogger.log(Util.getManagerId().toString(), "SubscriberBean() - Start thread for user " + this.userLogged.getLogin() + " get market whatch and manager information", Level.DEBUG);
    	
        EventBus eventBus = null;
        
        if (eventBus == null)
        	eventBus = EventBusFactory.getDefault().eventBus();

        PushMarketWatch pushMarketWatchObject = null;
    	
        resourceChannelBean.addChannel(userLogged.getLogin(), channel);
    	
        if (EventBusFactory.getDefault() != null) {
        	while (!done) {
	            try {
		        	
		        	//Get simulation list
		        	pushMarketWatchObject = this.GetMarketWhatchSymbolsValues(); 
	        		
		        	if (pushMarketWatchObject != null) {
		        		JSONObject jsonObjectMarketWatch = new JSONObject(pushMarketWatchObject);	
				     
			        	eventBus.publish(resourceChannelBean.getChannel(userLogged.getLogin()), String.valueOf(jsonObjectMarketWatch));
		        	} else {
		        		ManhattanLogger.log(Util.getManagerId().toString(), "SubscriberBean() - 0 instruments to send for market whatch screen", Level.DEBUG);
		        	}
		        	
		            Thread.sleep(sleepTimeout);	        
		        } catch (Exception ex) {
		        	ex.printStackTrace();
		        	
		        	ManhattanLogger.log(Util.getManagerId().toString(), ex.getMessage(), Level.DEBUG);
		        }
		    }
        } else {
        	ManhattanLogger.log(Util.getManagerId().toString(), "SubscriberBean() - EventBusFactory is null" , Level.ERROR);
        }
        
    	ManhattanLogger.log(Util.getManagerId().toString(), "SubscriberBean() - End thread for user " + this.userLogged.getLogin() + " used to get market whatch information", Level.DEBUG);
    }
        
    private PushMarketWatch GetMarketWhatchSymbolsValues() {

    	ManhattanLogger.log(Util.getManagerId().toString(), "GetMarketWhatchSymbolsValues() - Subscribe information in facade service", Level.DEBUG);
    	
    	PushMarketWatch pushObject = null;
    	
    	try {
        	if (this.marketBean != null && null != marketBean.getMarketWhatchTabs()) {        		
        		//if tabs is empty must load for first signal
        		if (marketBean.getMarketWhatchTabs().isEmpty()) {
        			try {
        				ManhattanLogger.log(Util.getManagerId().toString(), "GetMarketWhatchSymbolsValues() - Send first signal for user " +  userLogged.getLogin(), Level.DEBUG);

        				marketBean.setStrategyTypes(marketWatchFacade.getStrategyTypesDomain());
        				marketBean.setMarketWhatchTabs(marketWatchFacade.getWatchTabMarkets(userLogged.getLogin()));
        				
        		    	pushObject = new PushMarketWatch();
        		    	
        				pushObject.setRefreshTableIsNeeded("S");
        				        				
        				return pushObject;
        			} catch (DAOExceptionManhattan e) {
        				ManhattanLogger.log(Util.getManagerId().toString(), "GetMarketWhatchSymbolsValues() - First signal for user " +  userLogged.getLogin(), Level.ERROR);
        			}
        		}
        		
        		for (MarketWhatchTab marketWatchTab: marketBean.getMarketWhatchTabs()) {
		    		for (Market marketItem: marketWatchTab.getMarkets()) {
	    				for (String instrument: marketItem.getContractsList()) {
	    					List<SimulationItem> simulationItens = facadeService.getSimulationListBySymbol(instrument);
	    					
	    					if (simulationItens == null) {
	    						ManhattanLogger.log(Util.getManagerId().toString(), "FacadeServiceImpl getSimulationListBySymbol return null for instrument [" + instrument + "]", Level.ERROR);
	    					} else {
	    						pushObject = new PushMarketWatch();
	    						
	    						pushObject.setTabViewId(marketWatchTab.getId());
	    						
	    						for (SimulationItem simulationItem: simulationItens) {
	    							if (PushHelper.checkSimulationItemForUpdateData(marketItem, simulationItem)) {
		    							pushObject.addSimulationItem(marketItem.getId(), simulationItem);	    			
		    						} else {
		    							ManhattanLogger.log(Util.getManagerId().toString(), "Market object is equal a screen market objet, push is not necessary", Level.DEBUG);
		    						}
	    						}
	    					}
	    				}	    			
	    			}        			
        		}
        	} else {
        		ManhattanLogger.log(Util.getManagerId().toString(), "MarketBean object is null for subscriber", Level.ERROR);
        	}
    	} catch (Exception ex) {
    		ex.printStackTrace();
    		
    		ManhattanLogger.log(Util.getManagerId().toString(), ex.getMessage(), Level.ERROR);
    	}
    	
    	return pushObject;
    }    	

	@Override
	public void run() {
		this.start();
	}

	public void shutdown() {
		setDone(true);
	}

	public User getUserLogged() {
		return userLogged;
	}

	public void setUserLogged(User userLogged) {
		this.userLogged = userLogged;
	}

	public boolean isDone() {
		return done;
	}

	public void setDone(boolean done) {
		this.done = done;
	}

	public void setMarketWatchFacade(MarketWatchFacade marketWatchFacade) {
		this.marketWatchFacade = marketWatchFacade;
	}
}