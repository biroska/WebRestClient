package com.ubs.manhatthan.beans;

import java.io.Serializable;
import java.util.List;
import java.util.UUID;

import javax.annotation.PostConstruct;

import org.apache.log4j.Level;
import org.primefaces.json.JSONObject;
import org.primefaces.push.EventBus;
import org.primefaces.push.EventBusFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.exception.DAOExceptionManhattan;
import com.ubs.manhatthan.helper.PushHelper;
import com.ubs.manhatthan.manager.facade.FacadeService;
import com.ubs.manhatthan.manager.logger.ManhattanLogger;
import com.ubs.manhatthan.manager.persistence.entities.Strategy;
import com.ubs.manhatthan.manager.persistence.entities.StrategyOrders;
import com.ubs.manhatthan.manager.persistence.entities.StrategyReport;
import com.ubs.manhatthan.manager.utils.Util;
import com.ubs.manhatthan.model.LegStrategyReport;
import com.ubs.manhatthan.model.PushManager;
import com.ubs.manhatthan.model.Unlegging;

@Component("subscriberManagerBean")
@Scope("session")
public class SubscriberManagerBean implements Serializable, Runnable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -686269472821533540L;
   
    private static Integer sleepTimeout = 1000;

    private String channel;
    
    @Autowired
    private ResourceChannelBean resourceChannelBean;
    
    @Autowired
    private ManagerBean managerBean;
    
    private User userLogged;
    
    private volatile boolean done;
    
	@Autowired
	protected FacadeService facadeService;
		
	@PostConstruct
    public void init() {
    	channel = "/" + UUID.randomUUID().toString();
    }
    
    public void setManagerBean(ManagerBean managerBean)
    {
    	this.managerBean = managerBean;
    }

    public void setResourceChannelBean(ResourceChannelBean resourceChannelBean)
    {
    	this.resourceChannelBean = resourceChannelBean;
    }

	public void setFacadeService(FacadeService facadeService) {
		this.facadeService = facadeService;
	}

	public String getChannel() {
		return this.channel;
	}
	
    public void start() {
    	
    	ManhattanLogger.log(Util.getManagerId().toString(), "SubscriberBean() - Start thread for user " + this.userLogged.getLogin() + " get market whatch and manager information", Level.DEBUG);
    	
        EventBus eventBus = null;
        
        if (eventBus == null)
        	eventBus = EventBusFactory.getDefault().eventBus();

        PushManager pushManagerObject = null;
    	
        resourceChannelBean.addChannel(userLogged.getLogin(), channel);
    	
        if (EventBusFactory.getDefault() != null) {
        	while (!done) {
	            try {
		        	//Get strategies from facade
		        	List<Strategy> strategies = this.GetStrategiesForFacade();
		        	
		        	//Get manager (strategy reports and strategy orders)
		        	pushManagerObject = this.GetManagerSymbolsValues(strategies);

		        	if (pushManagerObject != null) {
	        			JSONObject jsonObjectManager = new JSONObject(pushManagerObject);	
						    		        			
			        	eventBus.publish(resourceChannelBean.getChannel(userLogged.getLogin()), String.valueOf(jsonObjectManager));
	        		} else {
	        			ManhattanLogger.log(Util.getManagerId().toString(), "SubscriberBean() - 0 strategies to send for manager screen", Level.DEBUG);	        			
	        		}
		        	
		            Thread.sleep(sleepTimeout);	        
		        } catch (Exception ex) {
		        	ex.printStackTrace();
		        	
		        	ManhattanLogger.log(Util.getManagerId().toString(), ex.getMessage(), Level.DEBUG);
		        }
		    }
        } else {
        	ManhattanLogger.log(Util.getManagerId().toString(), "SubscriberBean() - EventBusFactory is null" , Level.ERROR);
        }
        
    	ManhattanLogger.log(Util.getManagerId().toString(), "SubscriberBean() - End thread for user " + this.userLogged.getLogin() + " used to get manager information", Level.DEBUG);
    }
        
    private List<Strategy> GetStrategiesForFacade() {
    	
		List<Strategy> strategies = null;

		if (this.userLogged.getProfile() != null) {
    		if (this.userLogged.getProfile().equals("admin")) {
    	    	if (managerBean.getStrategyReports().size() == 0) { //First signal (Get all snapshot)
    	    		ManhattanLogger.log(Util.getManagerId().toString(), "GetManagerSymbolsValues(Supervisor) - Subscribe information in manager in facade service", Level.DEBUG);
    			
    	    		strategies = facadeService.getAllMessages();
    	    	} else {
    	    		ManhattanLogger.log(Util.getManagerId().toString(), "GetManagerSymbolsValues(Supervisor) - Subscribe incremental information in manager in facade service", Level.DEBUG);
        			
    	    		strategies = facadeService.getMessagesBySupervisor();
    	    	}
    		} else {
    	    	if (managerBean.getStrategyReports().size() == 0) { //First signal (Get all snapshot)
	    	    	ManhattanLogger.log(Util.getManagerId().toString(), "GetManagerSymbolsValues(User) - Subscribe all information in manager in facade service", Level.DEBUG);

    	    		strategies = facadeService.getMessagesSnapshotByUser(this.userLogged.getLogin());
    	    	} else {
	    	    	ManhattanLogger.log(Util.getManagerId().toString(), "GetManagerSymbolsValues(User) - Subscribe incremental information in manager in facade service", Level.DEBUG);

	    	    	strategies = facadeService.getMessagesByUser(this.userLogged.getLogin());
    	    	}
    		}    		
		}    	
		
		return strategies;
    }
    	
    private PushManager GetManagerSymbolsValues(List<Strategy> strategies) {   	
    	
    	PushManager pushObject = null;

		if (strategies != null) {
	    	ManhattanLogger.log(Util.getManagerId().toString(), "GetManagerSymbolsValues - Will process " + strategies.size() + " strategies." , Level.DEBUG);

	    	if (managerBean.getStrategyReports().isEmpty()) {
	    		pushObject = this.GetManagerSymbolsValuesToFirstPush(strategies);
	    	} else {
	    		pushObject = this.GetManagerSymbolsValuesToIncrementalPush(strategies);
	    	}
		}    
    		
    	return pushObject;
    }
    
    private PushManager GetManagerSymbolsValuesToFirstPush(List<Strategy> strategies) {
    	
    	PushManager pushObject = new PushManager();
    	
    	StrategyReport strategyReportEntity = null;
    	StrategyOrders strategyOrderEntity = null;

		pushObject.setRefreshTableIsNeeded("S");

		try {
			if (strategies != null) {
								
				for (int i=0; i < strategies.size(); i++) {	
		    		
		    		if (strategies.get(i) instanceof StrategyReport) { //Strategy Report
		    			ManhattanLogger.log(Util.getManagerId().toString(), "ready strategy report", Level.DEBUG);
		    			
			    		strategyReportEntity = (StrategyReport) strategies.get(i);
						com.ubs.manhatthan.model.StrategyReport strategyReportModel = PushHelper.convertStrategyReportToModel(strategyReportEntity);						
						
						managerBean.getStrategyReports().add(strategyReportModel);
					} else { //Strategy Order
						ManhattanLogger.log(Util.getManagerId().toString(), "ready strategy order", Level.DEBUG);
						
						strategyOrderEntity = (StrategyOrders) strategies.get(i);
						
						addStrategyOrderToStrategyReportModelInSession(strategyOrderEntity);
					}
		    	}
			}
		} catch (Exception ex) {
    		ex.printStackTrace();
    		
    		ManhattanLogger.log(Util.getManagerId().toString(), ex.getMessage(), Level.ERROR);
		}
		
    	return pushObject;
    }

    private PushManager GetManagerSymbolsValuesToIncrementalPush(List<Strategy> strategies) {
    	
    	PushManager pushObject = new PushManager();

    	try {    		
    		com.ubs.manhatthan.model.StrategyReport strategyRportModelToPush = null;
    		
    		LegStrategyReport legStrategyReportToPush = null;
    		
    		if (strategies != null) {
    	    	ManhattanLogger.log(Util.getManagerId().toString(), "GetManagerSymbolsValues - Will process " + strategies.size() + " strategies." , Level.DEBUG);
    	    	        	    	
    	    	for (int i=0; i < strategies.size(); i++) {

    	    		if (strategies.get(i) instanceof StrategyReport) {

    	    			ManhattanLogger.log(Util.getManagerId().toString(), "ready strategy report", Level.DEBUG);

    	    			//Check and add strategy report body to push object, if needed
    					StrategyReport strategyReportEntity = (StrategyReport) strategies.get(i);    					
    					strategyRportModelToPush = getStrategyReportModelInSession(strategyReportEntity);    					
    					
    					if (strategyRportModelToPush != null) {
    						pushObject.addLegStrategyReport(strategyRportModelToPush);
    					} else {	    					
	    					pushObject.setRefreshTableIsNeeded("S");
    					}

    					//Check and add strategy report legs to push object, if needed
	    				legStrategyReportToPush = null;	    				
	    				for (com.ubs.manhatthan.manager.persistence.entities.LegStrategyReport legStrategyReport: strategyReportEntity.getLegStrategyList()) {
	    					legStrategyReportToPush = getLegStrategyReportModelInSession(legStrategyReport);
	    					
	    					// if leg strategy is null must be add in session manager bean for refresh screen
	    					if (legStrategyReportToPush != null) {
    							pushObject.addLegStrategyReport(legStrategyReportToPush);
	    					} else {
	    						pushObject.setRefreshTableIsNeeded("S");
	    					}
	    				}
	    			} else {
		    			ManhattanLogger.log(Util.getManagerId().toString(), "ready strategy order", Level.DEBUG);

		    			StrategyOrders strategyOrderEntity = (StrategyOrders) strategies.get(i);
	    				
	    				addStrategyOrderToStrategyReportModelInSession(strategyOrderEntity);
	    				
	    				legStrategyReportToPush = PushHelper.convertStrategyOrderEntityToLegModel(strategyOrderEntity);
	    				
	    				pushObject.addLegStrategyReport(legStrategyReportToPush);
	    				
	    				pushObject.setMustBeUnlegging(true);
	    			}
	    		}	
    		}
    	} catch (Exception ex) {
    		ex.printStackTrace();
    		
    		ManhattanLogger.log(Util.getManagerId().toString(), ex.getMessage(), Level.ERROR);
    	}
    	
		return pushObject;
    }
    
    private com.ubs.manhatthan.model.StrategyReport getStrategyReportModelInSession(com.ubs.manhatthan.manager.persistence.entities.StrategyReport strategyReportEntity) throws BeansException, DAOExceptionManhattan {
    	
    	com.ubs.manhatthan.model.StrategyReport strategyReportModel = PushHelper.convertStrategyReportToModel(strategyReportEntity);    	    	    	
    	    	    	
    	if (managerBean.getStrategyReports().contains(strategyReportModel)) {
    		int index = managerBean.getStrategyReports().indexOf(strategyReportModel);
    		
    		managerBean.getStrategyReports().set(index, strategyReportModel);    		
    	} else {
    		managerBean.getStrategyReports().add(strategyReportModel);
    		
    		return null;
    	}
    	
    	return strategyReportModel;
    }

    private LegStrategyReport getLegStrategyReportModelInSession(com.ubs.manhatthan.manager.persistence.entities.LegStrategyReport legStrategyReportEntity)  throws BeansException, DAOExceptionManhattan {
    	LegStrategyReport legStrategyReportModel = null;
    	    	    	    	
		boolean strategyReportFinded = false;
		boolean legStrategyIsAlreadyInSession = false;			

		int indexStrategyReport = 0;
		int indexLegStrategyReport = 0;
		
		
		if (legStrategyReportEntity != null)
    	{
			//ready session to check what strategies must be updated
			for (indexStrategyReport = 0; indexStrategyReport < managerBean.getStrategyReports().size(); indexStrategyReport++) {				
				strategyReportFinded = (managerBean.getStrategyReports().get(indexStrategyReport).getEngineId().equals(legStrategyReportEntity.getId().getEngineId()) && 
						(managerBean.getStrategyReports().get(indexStrategyReport).getStrategyId().equals(legStrategyReportEntity.getId().getStrategyId())));
				
				if (strategyReportFinded) {
					for (indexLegStrategyReport = 0; indexLegStrategyReport < managerBean.getStrategyReports().get(indexStrategyReport).getLegStrategyList().size(); indexLegStrategyReport++) {
						legStrategyIsAlreadyInSession = (managerBean.getStrategyReports().get(indexStrategyReport).getLegStrategyList().get(indexLegStrategyReport).getEngineId().equals(legStrategyReportEntity.getId().getEngineId()) && 
								(managerBean.getStrategyReports().get(indexStrategyReport).getLegStrategyList().get(indexLegStrategyReport).getStrategyId().equals(legStrategyReportEntity.getId().getStrategyId())) &&
								(managerBean.getStrategyReports().get(indexStrategyReport).getLegStrategyList().get(indexLegStrategyReport).getLegSeq().equals(legStrategyReportEntity.getId().getLegSeq())));
	
						if (legStrategyIsAlreadyInSession) {
							legStrategyReportModel = managerBean.getStrategyReports().get(indexStrategyReport).getLegStrategyList().get(indexLegStrategyReport);
													
							break;
						}
					}
					
					break;
				}
			}
		}
    	
    	if (strategyReportFinded) {
    		legStrategyReportModel = PushHelper.convertLegStrategyReportEntityToReportModel(legStrategyReportEntity);
    		
    		if (legStrategyIsAlreadyInSession) {
    			managerBean.getStrategyReports().get(indexStrategyReport).getLegStrategyList().set(indexLegStrategyReport,legStrategyReportModel);    			
    		} else {
    			managerBean.getStrategyReports().get(indexStrategyReport).getLegStrategyList().add(legStrategyReportModel);
    		}
    		
    	} 
					    	
    	return legStrategyReportModel;
    }
    
    private void addStrategyOrderToStrategyReportModelInSession(com.ubs.manhatthan.manager.persistence.entities.StrategyOrders strategyOrderEntity) throws BeansException, DAOExceptionManhattan {
    
    	boolean unleggingExists = false;
    	
    	int iRep = 0;
    	int iLeg = 0;
    	int iUnleg = 0;
    	
    	Unlegging unleggingModel = PushHelper.convertStrategyOrderToUnleggingModel(strategyOrderEntity);
    	
    	if (strategyOrderEntity != null) {
    		for (iRep = 0; iRep < managerBean.getStrategyReports().size(); iRep++) {
        		for (iLeg = 0; iLeg < managerBean.getStrategyReports().get(iRep).getLegStrategyList().size(); iLeg++) {
            		for (iUnleg = 0; iUnleg < managerBean.getStrategyReports().get(iRep).getLegStrategyList().get(iLeg).getUnleggingList().size(); iUnleg++) {
            			unleggingExists = managerBean.getStrategyReports().get(iRep).getLegStrategyList().get(iLeg).getUnleggingList().get(iUnleg).getLegSeq().equals(strategyOrderEntity.getLegSeq()) && 
            						managerBean.getStrategyReports().get(iRep).getLegStrategyList().get(iLeg).getUnleggingList().get(iUnleg).getOrderId().equals(strategyOrderEntity.getId().getOrderId());
            			
            			if (unleggingExists) break;
            		}
            		
            		if (unleggingExists) break;
        		}
        		
        		if (unleggingExists) break;
    		}
    	}
    	
    	if (unleggingExists) {    		
    		if (strategyOrderEntity.getQuantity() > 0) { //For leg quantity must be grather than 0   			
        		managerBean.getStrategyReports().get(iRep).getLegStrategyList().get(iLeg).getUnleggingList().set(iUnleg, unleggingModel);
    		} else {
    			managerBean.getStrategyReports().get(iRep).getLegStrategyList().get(iLeg).getUnleggingList().remove(iUnleg);
    		}
    	} else {
    		managerBean.getStrategyReports().get(iRep).getLegStrategyList().get(iLeg).getUnleggingList().add(unleggingModel);
    	}
    }

	@Override
	public void run() {
		this.start();
	}

	public void shutdown() {
		setDone(true);
	}

	public User getUserLogged() {
		return userLogged;
	}

	public void setUserLogged(User userLogged) {
		this.userLogged = userLogged;
	}

	public boolean isDone() {
		return done;
	}

	public void setDone(boolean done) {
		this.done = done;
	}
}