$(function() {
	//startSubscriber();
});

$(document).keyup(function(e) {
	  if (e.keyCode == 27){
		  PF('dlgStrategyParameters').hide();
	  }
});

function onClickBtnDownFontSize(tab) {
	var fontSizeDown = parseInt($("div.fontSize tbody").css("font-size"));
	fontSizeDown = fontSizeDown - 1 + "px";
	$("div.fontSize tbody").css({
		"font-size" : fontSizeDown
	});
}
function onClickBtnUpFontSize(tab) {
	var fontSizeUp = parseInt($("div.fontSize tbody").css("font-size"));
	fontSizeUp = fontSizeUp + 1 + "px";
	$("div.fontSize tbody").css({
		"font-size" : fontSizeUp
	});
}

function onClickOTC(index) {
	document.getElementById('componentTab:componentTabMain:tabManagerGrid:formGridManager:manager:'+index+':otc').click();
}

function onClickUnl(index) {
	document.getElementById('componentTab:componentTabMain:tabManagerGrid:formGridManager:manager:'+index+':unl').click();
}

function onClickStr(index) {
	document.getElementById('componentTab:componentTabMain:tabManagerGrid:formGridManager:manager:'+index+':str').click();
}

function handleDialogSubmit(dialog, xhr, status, args) {
    if (args.validationFailed) {
    	PF(dialog).show();
    } else {
    	PF(dialog).hide();
    }
}

function dialogConfirm(dialog, xhr, status, args) {
    if (args.validationFailed) {
    	PF(dialog).show();
    } else {
    	PF(dialog).hide();
    }
}

function alertValue(labelId) {
	alert(labelId);
	
	alert(PF(labelId).jq.val());
}

function buySell(index){
	if(PF('qty'+index) != undefined) {
		var val1 = parseInt(PF('qty'+index).jq.val());
		var val2 = parseInt(0);
		if(val1 >= val2){
			PF('buy'+index).jq.val(1);
		}else
		{
			PF('buy'+index).jq.val(2);
		}
	}
}

function focusContracts(){
	if(PF('contracts0') != undefined) {
		PF('contracts0').jq.focus();
	}
}

function focusContract(index){
	var pos = index + 1;
	if(PF('contracts'+pos) != undefined) {
		PF('contracts'+pos).jq.focus();
	}else{
		PF('qty0').jq.focus();
	}
}

function focusQtd(index){
	var pos = index + 1;
	if(PF('qty'+pos) != undefined) {
		PF('qty'+pos).jq.focus();
	}else{
		PF('clip0').jq.focus();
	}
}

function focusClip(index){
	var pos = index + 1;
	if(PF('clip'+pos) != undefined) {
		PF('clip'+pos).jq.focus();
	}else{
		PF('target').jq.focus();
	}
}

function focusDV1(index){
	var pos = index + 1;
	if(PF('dv'+pos) != undefined) {
		PF('dv'+pos).jq.focus();
	}else{
		PF('clip0').jq.focus();
	}
}

function focusDV1Teste(index){
	var count = index + 1;
	if(PF('dv'+count) != undefined) {
		PF('contracts'+count).jq.focus();
	}else{
		PF('clip0').jq.focus();
	}
}

function funcFocusSide(index){
	var pos = index + 1;
	if(PF('contract'+pos) != undefined) {
		PF('contract'+pos).jq.focus();
	}else{
		PF('btnAdd').jq.focus();
	}
}

function funcTabEnter(){
	if (window.event && window.event.keyCode == 13){
		window.event.keyCode = 9;
	}
}

function focusSideManager(index){
	if(PF('clip'+index) != undefined) {
		PF('clip'+index).jq.focus();
	}else{
		PF('target').jq.focus();
	}
}