var countReceivedPackage = 0;
var countReceivedManagerPackage = 0;
var countReceivedMarketWatchPackage = 0;

var logEnabled = true;

function handleMessage(objJson) {
	countReceivedPackage++;
	
	log("handleMessage - total package [" + countReceivedPackage + "]");

	if (objJson.messageId == "1") { //Market Whatch data
		handleMessageMarketWhatch(objJson);
	} else { //Manager data
		handleMessageManager(objJson);
	}
}

function handleMessageMarketWhatch(objJson) {
	countReceivedMarketWatchPackage++;
	
	log("handleMessageMarketWhatch - total package [" + countReceivedMarketWatchPackage + "]");
	
	if (objJson.refreshTableIsNeeded == "S") {
		log("Refresh Screen Status for Market Whatch" + objJson.refreshTableIsNeeded);
		
		updateMarketWhatchTab();
	} else {
		handleMarketWatchObject(objJson);
	}
}

function handleMessageManager(objJson) {
	countReceivedManagerPackage++;
	
	log("handleMessageManager - total package [" + countReceivedManagerPackage + "]");
	
	if (objJson.refreshTableIsNeeded == "S") {
		log("Refresh Screen Status for Manager" + objJson.refreshTableIsNeeded);
		
		updateManagerTable();
	} else {
		handleManagerObject(objJson);
	}
}

function handleMarketWatchObject(objJson) {
	
	log("handleMarketWatch()");

	log("Process " + objJson.fields.length + " records for market whatch");
	
	for (var i = 0; i < objJson.fields.length; i++) {	
		//Update values 
		processMarketWatchObject(objJson.fields[i]);
	}
}

function handleManagerObject(objJson) {

	log("handleManager()");
	
	if (objJson.fields == null)
		return;
	
	log("Process " + objJson.fields.length + " records for manager");
		
	for (var i = 0; i < objJson.fields.length; i++) {
		processManagerObject(objJson.fields[i]);
	}	
}

function processMarketWatchObject(objJson) {
	
	log("processMarketWatchObject()");
	
	setNewFieldValue(objJson.lastQuantityHtmlId, objJson.lastQuantity);	
	setNewFieldValue(objJson.lastPriceHtmlId, objJson.lastPrice);	
	setNewFieldValue(objJson.buyQuantityHtmlId, objJson.buyQuantity);	
	setNewFieldValue(objJson.buyPriceHtmlId, objJson.buyPrice);	
	setNewFieldValue(objJson.sellQuantityHtmlId, objJson.sellQuantity);	
	setNewFieldValue(objJson.sellPriceHtmlId, objJson.sellPrice);	

	setNewStyleForLastPrice(objJson.lastPriceHtmlId, objJson.lastPrice);
}

function processManagerObject(objJson) {
	
	log("processManagerObject()");
	
	if (!objJson.isALeg) { //Is strategy report, not is a leg
		setNewFieldValue(objJson.statusHtmlId, objJson.statusDisplayText);

		setNewStyleForCancel(objJson.cancelHtmlId, objJson.status);			

		setNewStyleForStatus(objJson.cancelColumnHtmlId, objJson.status);
		
		if (objJson.mustBeUnlegging) {
			setRowStyleForUnlegging(objJson);
		}
	} else {
		if (typeof $(objJson.statusHtmlId).html() == "undefined") {
			log("Received a leg information but the same is colsed in webbrowser");
			
			return;
		}
	}
	
	setNewFieldValue(objJson.executedPercentHtmlId, objJson.executedPercent);	
	setNewFieldValue(objJson.leggedQuantityHtmlId, objJson.leggedQuantity);
	setNewFieldValue(objJson.leggedPriceHtmlId, objJson.leggedPrice);
	setNewFieldValue(objJson.totalQuantityHtmlId, objJson.totalQuantity);
	setNewFieldValue(objJson.quantityRemainHtmlId, objJson.quantityRemain);
	setNewFieldValue(objJson.quantityExecutedHtmlId, objJson.quantityExecuted);
	setNewFieldValue(objJson.averagePriceHtmlId, objJson.averagePrice);
	setNewFieldValue(objJson.otcQuantityHtmlId, objJson.otcQuantity);
	setNewFieldValue(objJson.otcPriceHtmlId, objJson.otcPrice);
	setNewFieldValue(objJson.poQuantityHtmlId, objJson.poQuantity);
	setNewFieldValue(objJson.poPriceHtmlId, objJson.poPrice);
	setNewFieldValue(objJson.executedTargetHtmlId, objJson.executedTarget);
	setNewFieldValue(objJson.textHtmlId, objJson.text);
}

function setNewStyleForLastPrice(fieldHtmlId, fieldNewValue) {
	if ($(fieldHtmlId).html() > fieldNewValue) {
		$(fieldHtmlId).attr("style", "color: red;");
	} else if ($(fieldHtmlId).html() < fieldNewValue) {
		$(fieldHtmlId).attr("style", "color: green;");
	} else {
		$(fieldHtmlId).attr("style", "color: black;");
	}
}

function setNewFieldValue(fieldHtmlId, fieldNewValue) {
	if (fieldNewValue == null) 
		$(fieldHtmlId).html(" - ");
	else
		$(fieldHtmlId).html(fieldNewValue);

	logNewFieldValue(fieldHtmlId, fieldNewValue);
}

function setNewStyleForCancel(fieldHtmlId, fieldNewValue) {
	if (fieldNewValue != 4 && fieldNewValue != 9 && fieldNewValue != 10) {
		$(fieldHtmlId).attr("style", "display: block; border: 0");
	} else {
		$(fieldHtmlId).attr("style", "display: none;");
	}
}

function setNewStyleForStatus(fieldHtmlId, fieldNewValue) {
	if (fieldNewValue == 5 || fieldNewValue == 8 || fieldNewValue == 9) {
		$(fieldHtmlId).attr("style", "background-color: transparent; text-align: center; text-transform: lowercase;");
	} else if (fieldNewValue == 2 || fieldNewValue == 6) {
		$(fieldHtmlId).attr("style", "background-color: yellow; text-align: center; text-transform: lowercase;");
	} else if (fieldNewValue == 10) {
		$(fieldHtmlId).attr("style", "background-color: orange; text-align: center; text-transform: lowercase;");
	} else if (fieldNewValue == 3 || fieldNewValue == 7) {
		$(fieldHtmlId).attr("style", "background-color: green; text-align: center; text-transform: lowercase;");
	} else {
		$(fieldHtmlId).attr("style", "background-color: #555555; text-align: center; text-transform: lowercase;");
	}
}

function setRowStyleForUnlegging(objJson) {
	$(objJson.executedPercentHtmlId).attr("style", "color: red;");
	$(objJson.leggedQuantityHtmlId).attr("style", "color: red;");
	$(objJson.leggedPriceHtmlId).attr("style", "color: red;");
	$(objJson.totalQuantityHtmlId).attr("style", "color: red;");
	$(objJson.quantityRemainHtmlId).attr("style", "color: red;");
	$(objJson.quantityExecutedHtmlId).attr("style", "color: red;");
	$(objJson.averagePriceHtmlId).attr("style", "color: red;");
	$(objJson.otcQuantityHtmlId).attr("style", "color: red;");
	$(objJson.otcPriceHtmlId).attr("style", "color: red;");
	$(objJson.poQuantityHtmlId).attr("style", "color: red;");
	$(objJson.poPriceHtmlId).attr("style", "color: red;");
	$(objJson.executedTargetHtmlId).attr("style", "color: red;");
	$(objJson.textHtmlId).attr("style", "color: red;");
}

function logNewFieldValue(fieldHtmlId, fieldNewValue) {
	log("Field [" + fieldHtmlId + "] [" + $(fieldHtmlId).html() + "], [" + fieldNewValue + "]" );
}

function log(logText) {
	if (logEnabled == true) console.log(logText);
}