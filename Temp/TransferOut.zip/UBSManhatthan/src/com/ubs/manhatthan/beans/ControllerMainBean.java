package com.ubs.manhatthan.beans;

import java.io.Serializable;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import org.primefaces.component.tabview.TabView;
import org.primefaces.event.TabChangeEvent;

@SuppressWarnings("serial")
@SessionScoped
@ManagedBean(name = "controllerMainBean")
public class ControllerMainBean implements Serializable {

	private TabView tabView;
	
	private int indexTabActive = 0;

	public ControllerMainBean() {
	}

	public void onTabChange(TabChangeEvent event) {
		if (event.getTab().getId().trim().equals("market1")) {
			indexTabActive = 0;
		} else if ((event.getTab().getId().trim().equals("manager1"))) {
			indexTabActive = 1;
		}
	}

	public int getIndexTabActive() {
		return indexTabActive;
	}

	public void setIndexTabActive(int indexTabActive) {
		this.indexTabActive = indexTabActive;
	}
	

	public TabView getTabView() {
		return tabView;
	}

	public void setTabView(TabView tabview) {
		this.tabView = tabview;
	}

}