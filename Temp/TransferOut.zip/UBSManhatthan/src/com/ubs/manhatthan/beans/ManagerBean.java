package com.ubs.manhatthan.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import com.ubs.manhatthan.mock.Mock;
import com.ubs.manhatthan.model.Account;
import com.ubs.manhatthan.model.Legged;
import com.ubs.manhatthan.model.Manager;
import com.ubs.manhatthan.service.Facade;

@SuppressWarnings("serial")
@SessionScoped
@ManagedBean(name="managerBean")
public class ManagerBean implements Serializable {

	private List<Manager> managers;
	private Manager selectedManager;
	private Account selectedAccount;
	private String text;
	
	private List<Manager> filteredStrategies;
	
	private LinkedList<String> filteredContracts;
	
	
	private Facade facade = new Mock();
	
	public ManagerBean(){		
		managers = new ArrayList<Manager>( facade.getManagers()  );
	}
	
	public List<String> getFilteredContracts() {
		filteredContracts = new LinkedList<>();
		for (Manager manager : getManagers()) {
			for (Legged legged : manager.getLeggeds()) {
				if (null != legged.getContract()) {
					filteredContracts.add(legged.getContract());
				}
			}
		}
		return filteredContracts;
	}
		
	public List<Manager> getManagers() {
		return managers;
	}

	public void setManagers(List<Manager> managers) {
		this.managers = managers;
	}

	public Manager getSelectedManager() {
		return selectedManager;
	}

	public void setSelectedManager(Manager selectedManager) {
		this.selectedManager = selectedManager;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public Account getSelectedAccount() {
		return selectedAccount;
	}

	public void setSelectedAccount(Account selectedAccount) {
		this.selectedAccount = selectedAccount;
	}

	public List<Manager> getFilteredStrategies() {
		return filteredStrategies;
	}

	public void setFilteredStrategies(List<Manager> filteredStrategies) {
		this.filteredStrategies = filteredStrategies;
	}

	public Facade getFacade() {
		return facade;
	}

	public void setFacade(Facade facade) {
		this.facade = facade;
	}
}