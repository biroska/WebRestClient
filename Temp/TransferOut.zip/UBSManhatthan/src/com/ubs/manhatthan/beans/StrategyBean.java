package com.ubs.manhatthan.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.faces.application.Application;
import javax.faces.application.ViewHandler;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;

import org.primefaces.context.RequestContext;
import org.primefaces.event.TabCloseEvent;

import com.ubs.manhatthan.mock.Mock;
import com.ubs.manhatthan.model.Market;
import com.ubs.manhatthan.model.MarketWhatchTab;
import com.ubs.manhatthan.model.Strategy;
import com.ubs.manhatthan.service.Facade;

@SessionScoped
@ManagedBean(name="strategyBean")
public class StrategyBean implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3148807863083961072L;

	private MarketWhatchTab marketWhatchTab;

	private List<MarketWhatchTab> marketWhatchTabs;
	
	private Strategy selectedStrategy;
	
	private String text;
		
	private ArrayList<String> marketsToFilter = new ArrayList<String>();
	
	private Facade facade = new Mock();
	
	public StrategyBean(){
		
		marketWhatchTabs = new ArrayList<MarketWhatchTab>(facade.getMarketWhatchTabs());
		marketsToFilter = changeToArrayString(new ArrayList<Strategy>(facade.getStrategies()));
	}
	
	
	public void loadFormMarketNewTab() {
		marketWhatchTab = new MarketWhatchTab();
		refresh();
	}
	
	public String addTabMarketPerUser() {
			if(null != marketWhatchTab.getName() &&  !"".equals(marketWhatchTab.getName().trim()) ){
				if (null != marketWhatchTabs) {
					if (null != marketWhatchTabs) {
						List<MarketWhatchTab> listTemp = marketWhatchTabs;
						for (MarketWhatchTab tabs : listTemp) {
							if (marketWhatchTab.getName().trim().equals( tabs.getName().trim())) {
								return "";
							}
						}
					}
					int rowid = marketWhatchTabs.size() + 1;	
					marketWhatchTab.setId(rowid);
					List<Market> markets = new ArrayList<Market>();
					Random rn = new Random();
					int jocker = rn.nextInt(10) + 1;
					for (int i = 0; i < jocker; i++) {
						Market market = new Market(Long.valueOf(String.valueOf(i)), "Teste"+i, Long.valueOf(String.valueOf(i)));
						markets.add(market);
					}
					marketWhatchTab.setMarkets(markets);
					marketWhatchTabs.add(marketWhatchTab);
					return "main.xhtml?faces-redirect=true";
				}
			}else{
				RequestContext.getCurrentInstance().execute("PF('dlgStrategy').show()");
			}
			
			loadFormMarketNewTab();
			
			return "";
			
	}
	

	public void onTabCloseMarket(TabCloseEvent event) {
		
		String tit = event.getTab().getTitle();
		
		if (null != marketWhatchTabs) {
			List<MarketWhatchTab> listTemp = marketWhatchTabs;
			for (MarketWhatchTab tabs : listTemp) {
				if (tit.trim().equals(tabs.getName().trim())) {
					marketWhatchTabs.remove(tabs);
					break;
				}
			}
		}
    }
	
	public void refresh() {  
        FacesContext context = FacesContext.getCurrentInstance();  
        Application application = context.getApplication();  
        ViewHandler viewHandler = application.getViewHandler();  
        UIViewRoot viewRoot = viewHandler.createView(context, context.getViewRoot().getViewId());  
        context.setViewRoot(viewRoot);  
        context.renderResponse();  
    }

	public List<String> completeString(String query) {
		List<String> results = new ArrayList<String>();
		for (int i = 0; i < 10; i++)
			results.add(query + i);
		return results;
	}
	
		
	private ArrayList<String> changeToArrayString( List<Strategy> list ){
		ArrayList<String> stringList = new ArrayList<String>();
		
		for (Strategy item : list ) {
			stringList.add( item.getName() );
		}
		
		return stringList;
	}


	public MarketWhatchTab getMarketWhatchTab() {
		return marketWhatchTab;
	}


	public void setMarketWhatchTab(MarketWhatchTab marketWhatchTab) {
		this.marketWhatchTab = marketWhatchTab;
	}


	public List<MarketWhatchTab> getMarketWhatchTabs() {
		return marketWhatchTabs;
	}


	public void setMarketWhatchTabs(List<MarketWhatchTab> marketWhatchTabs) {
		this.marketWhatchTabs = marketWhatchTabs;
	}


	public Strategy getSelectedStrategy() {
		return selectedStrategy;
	}


	public void setSelectedStrategy(Strategy selectedStrategy) {
		this.selectedStrategy = selectedStrategy;
	}


	public String getText() {
		return text;
	}


	public void setText(String text) {
		this.text = text;
	}


	public ArrayList<String> getMarketsToFilter() {
		return marketsToFilter;
	}


	public void setMarketsToFilter(ArrayList<String> marketsToFilter) {
		this.marketsToFilter = marketsToFilter;
	}
}
	
	
