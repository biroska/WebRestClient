package com.ubs.manhatthan.beans;

import java.io.Serializable;

import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;

import org.primefaces.push.EventBus;
import org.primefaces.push.EventBusFactory;
 
@SuppressWarnings("serial")
@ApplicationScoped
@ManagedBean(name="engineBean")
public class EngineBean implements Serializable {
    private volatile int count;
    
    public int getCount() {
        return count;
    }
 
    public void setCount(int count) {
        this.count = count;
    }
     
    public void increment() {
        count++;
         
        EventBus eventBus = EventBusFactory.getDefault().eventBus();
        eventBus.publish("/engine", String.valueOf(count));
    }
}
