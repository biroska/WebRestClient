/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import com.ubs.manhatthan.manager.persistence.entities.audit.ExchangeAudit;


/**
 * @author galdinoa
 *
 */
public interface IExchangeAuditDAO extends IGenericDAO<ExchangeAudit, Long> {}
