/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.functions;

import java.util.Date;

/**
 * @author galdinoa
 *
 */
public interface IDataBaseFunctions{

	Integer businessDayTotal2(Date beginningDt, Date endingDt);

	Integer businessDayTotal(Date beginningDt, Date endingDt);
}
