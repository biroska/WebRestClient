package com.ubs.manhatthan.manager.persistence.entities.audit;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.enums.StrategyTypeEnum;
import com.ubs.manhatthan.manager.persistence.entities.StrategyReport;


@Entity
@Table(name="TB_AUDIT_STRATEGY_REPORT")
public class StrategyReportAudit {
	
	public StrategyReportAudit() {
		super();
	}
	
	public StrategyReportAudit( StrategyReport strategyReport, ActionTypeEnum action, String user,
			Date registryDate ) {
		super();
		
		this.action = action;
		this.user = user;
		this.registryDate = registryDate;
		
		this.origid = strategyReport.getId().getStrategyId();
		this.engineId = strategyReport.getId().getEngineId();
		this.strategyId = strategyReport.getId().getStrategyId();
		this.strategyDate = strategyReport.getId().getStrategyDate();
		this.strategyType = strategyReport.getStrategyType();
		this.strategyTimestamp = strategyReport.getStrategyTimestamp();
		this.login = strategyReport.getLogin();
		this.startTime = strategyReport.getStartTime();
		this.endTime = strategyReport.getEndTime();
		this.executedPercentage = strategyReport.getExecutedPercentage();
		this.executedTarget = strategyReport.getExecutedTarget();
		this.startPaused = strategyReport.getStartPaused();
		this.text = strategyReport.getText();
		this.priceLimit = strategyReport.getPriceLimit();
		this.target = strategyReport.getTarget();
		this.agressiviness = strategyReport.getAgressiviness();
		this.riskLevel = strategyReport.getRiskLevel();
		this.restingLevel = strategyReport.getRestingLevel();
	}

	@Id
	@Column ( name = "ID")
	@SequenceGenerator(name = "TB_AUDIT_STRATEGY_REPORT_ID_GENERATOR", sequenceName = "SEQ_AUDIT_STRATEGY_REPORT", allocationSize = 1)
	@GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "TB_AUDIT_STRATEGY_REPORT_ID_GENERATOR" )
	private Long id;
	
	@Enumerated(EnumType.STRING)
	@Column( name = "ACTION", nullable=false )
	private ActionTypeEnum action;
	
	@Column( name = "REGISTRY_USER", nullable=false )
	private String user;
	
	@Column( name = "REGISTRY_DATE", nullable=false )
	private Date registryDate;

	@Column(name = "ORIG_ID", nullable = false )
	private Long origid;
	
	@Column ( name = "ENGINE_ID", nullable=false)
	private Long engineId;
	
	@Column ( name = "STRATEGY_ID", nullable=false)
	private Long strategyId;
	
	@Temporal(TemporalType.DATE)
	@Column ( name = "STRATEGY_DATE", nullable=false)
	private Date strategyDate;
	
	@Column ( name = "STRATEGY_TYPE ", nullable=false)
	private StrategyTypeEnum strategyType;
	
	@Temporal ( TemporalType.TIMESTAMP )
	@Column ( name = "STRATEGY_TIMESTAMP", nullable=false )
	private Date strategyTimestamp;
	
	@Column ( name = "LOGIN", nullable=false)
	private String login;
	
	@Temporal ( TemporalType.TIMESTAMP )
	@Column ( name = "START_TIME", nullable=false)
	private Date startTime;
	
	@Temporal ( TemporalType.TIMESTAMP )
	@Column ( name = "END_TIME", nullable=false)
	private Date endTime;
	
	@Column ( name = "EXECUTED_PERCENTAGE", columnDefinition= "Decimal(10,3)", nullable = false)
	private Double executedPercentage;
	
	@Column ( name = "TARGET_EXECUTED", columnDefinition= "Decimal(10,7)")
	private Double executedTarget;
	
	@Column ( name = "START_PAUSED", nullable=false)
	private Boolean startPaused;
	
	@Column ( name = "TEXT", length = 256)
	private String text;
	
	@Column ( name = "PRICE_LIMIT", columnDefinition= "Decimal(10,7)")
	private Double priceLimit;
	
	@Column ( name = "TARGET", columnDefinition= "Decimal(10,7)")
	private Double target;
	
	@Column ( name = "AGRESSIVINESS", columnDefinition= "Decimal(10,7)")
	private Double agressiviness;
	
	@Column ( name = "RISK_LEVEL")
	private Integer riskLevel;
	
	@Column ( name = "RESTING_LEVEL")
	private Integer restingLevel;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public ActionTypeEnum getAction() {
		return action;
	}

	public void setAction(ActionTypeEnum action) {
		this.action = action;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public Date getRegistryDate() {
		return registryDate;
	}

	public void setRegistryDate(Date registryDate) {
		this.registryDate = registryDate;
	}

	public Long getOrigid() {
		return origid;
	}

	public void setOrigid(Long origid) {
		this.origid = origid;
	}

	public Long getEngineId() {
		return engineId;
	}

	public void setEngineId(Long engineId) {
		this.engineId = engineId;
	}

	public Long getStrategyId() {
		return strategyId;
	}

	public void setStrategyId(Long strategyId) {
		this.strategyId = strategyId;
	}

	public Date getStrategyDate() {
		return strategyDate;
	}

	public void setStrategyDate(Date strategyDate) {
		this.strategyDate = strategyDate;
	}

	public StrategyTypeEnum getStrategyType() {
		return strategyType;
	}

	public void setStrategyType(StrategyTypeEnum strategyType) {
		this.strategyType = strategyType;
	}

	public Date getStrategyTimestamp() {
		return strategyTimestamp;
	}

	public void setStrategyTimestamp(Date strategyTimestamp) {
		this.strategyTimestamp = strategyTimestamp;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public Double getExecutedPercentage() {
		return executedPercentage;
	}

	public void setExecutedPercentage(Double executedPercentage) {
		this.executedPercentage = executedPercentage;
	}

	public Double getExecutedTarget() {
		return executedTarget;
	}

	public void setExecutedTarget(Double executedTarget) {
		this.executedTarget = executedTarget;
	}

	public Boolean getStartPaused() {
		return startPaused;
	}

	public void setStartPaused(Boolean startPaused) {
		this.startPaused = startPaused;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public Double getPriceLimit() {
		return priceLimit;
	}

	public void setPriceLimit(Double priceLimit) {
		this.priceLimit = priceLimit;
	}

	public Double getTarget() {
		return target;
	}

	public void setTarget(Double target) {
		this.target = target;
	}

	public Double getAgressiviness() {
		return agressiviness;
	}

	public void setAgressiviness(Double agressiviness) {
		this.agressiviness = agressiviness;
	}

	public Integer getRiskLevel() {
		return riskLevel;
	}

	public void setRiskLevel(Integer riskLevel) {
		this.riskLevel = riskLevel;
	}
	
	public Integer getRestingLevel() {
		return restingLevel;
	}

	public void setRestingLevel(Integer restingLevel) {
		this.restingLevel = restingLevel;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((action == null) ? 0 : action.hashCode());
		result = prime * result + ((origid == null) ? 0 : origid.hashCode());
		result = prime * result
				+ ((registryDate == null) ? 0 : registryDate.hashCode());
		result = prime * result + ((user == null) ? 0 : user.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StrategyReportAudit other = (StrategyReportAudit) obj;
		if (action != other.action)
			return false;
		if (origid == null) {
			if (other.origid != null)
				return false;
		} else if (!origid.equals(other.origid))
			return false;
		if (registryDate == null) {
			if (other.registryDate != null)
				return false;
		} else if (!registryDate.equals(other.registryDate))
			return false;
		if (user == null) {
			if (other.user != null)
				return false;
		} else if (!user.equals(other.user))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "StrategyReportAudit [id=" + id + ", action=" + action
				+ ", user=" + user + ", registryDate=" + registryDate
				+ ", origid=" + origid + ", engineId=" + engineId
				+ ", strategyId=" + strategyId + ", strategyDate="
				+ strategyDate + ", strategyType=" + strategyType
				+ ", strategyTimestamp=" + strategyTimestamp + ", login="
				+ login + ", startTime=" + startTime + ", endTime=" + endTime
				+ ", executedPercentage=" + executedPercentage
				+ ", executedTarget=" + executedTarget + ", startPaused="
				+ startPaused + ", text=" + text + ", priceLimit=" + priceLimit
				+ ", target=" + target + ", agressiviness=" + agressiviness
				+ ", riskLevel=" + riskLevel + ", restingLevel=" + restingLevel
				+ "]";
	}
}