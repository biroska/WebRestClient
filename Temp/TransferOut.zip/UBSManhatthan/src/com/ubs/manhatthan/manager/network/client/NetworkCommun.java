/*
 * NetworkClientCommon.java
 *
 *  Created on: Set 25, 2015
 *      Author: vanputtg
 */

package com.ubs.manhatthan.manager.network.client;

import java.util.Random;

public interface NetworkCommun {
	
	//Parameters
	public class MESSAGES_CONFIGURATION {
		
		//Random values for tests
		final public static long MANAGER_INSTANCE = new Random().nextInt(999) + 1;
//		final public static long MANAGER_INSTANCE = Long.valueOf( Util.getManagerId() );
		final public static int HEARBEAT_DELAY_S = 2;
		final public static int HEARBEAT_FAILOUT_C = 3;
		final public static int DELAY_STATISTICS_S = 10;
		final public static int DELAY_RECONNECTION_S = 3;
		final public static double SOCKET_BUFFER_SIZE_MB = 1.;
		
	}


}
