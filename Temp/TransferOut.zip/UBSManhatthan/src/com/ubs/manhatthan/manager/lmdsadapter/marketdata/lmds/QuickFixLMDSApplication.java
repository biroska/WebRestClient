package com.ubs.manhatthan.manager.lmdsadapter.marketdata.lmds;

import java.util.Properties;

import quickfix.Application;
import quickfix.DoNotSend;
import quickfix.FieldNotFound;
import quickfix.IncorrectDataFormat;
import quickfix.IncorrectTagValue;
import quickfix.Message;
import quickfix.RejectLogon;
import quickfix.Session;
import quickfix.SessionID;
import quickfix.SessionNotFound;
import quickfix.UnsupportedMessageType;

public class QuickFixLMDSApplication implements Application
{
	private final QuickFixLMDSCracker cracker;
	private final LMDSController controller;
	private SessionID sessionID;
	private String password;
	

	public QuickFixLMDSApplication(LMDSController controller)
	{
		this.controller = controller;
		this.password = "";
		this.sessionID = null;
		
		this.cracker = new QuickFixLMDSCracker(controller);
	}
	
	public synchronized void configure(Properties config) {
		this.password = config.getProperty("marketdata.lmds.password", "");
	}

	@Override
	public void fromAdmin(Message message, SessionID sessionID) throws FieldNotFound,
			IncorrectDataFormat, IncorrectTagValue, RejectLogon
	{
		//System.out.println(message.getHeader().getInt(MsgSeqNum.FIELD));
		
	}

	@Override
	public void fromApp(Message message, SessionID sessionID) throws FieldNotFound,
			IncorrectDataFormat, IncorrectTagValue, UnsupportedMessageType
	{
		//System.out.println(message.getHeader().getInt(MsgSeqNum.FIELD));
		
		cracker.crack(message, sessionID);
	}

	@Override
	public void onCreate(SessionID sessionID)
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onLogon(SessionID sessionID)
	{
		this.sessionID = sessionID;
		this.controller.onFixConnect();
	}

	@Override
	public void onLogout(SessionID sessionID)
	{
		this.controller.onFixDisconnect();
		this.sessionID = null;
	}

	@Override
	public void toAdmin(Message message, SessionID sessionID)
	{
		//
		// Put login password
		//
		try
		{
			if (quickfix.field.MsgType.LOGON.equals(message.getHeader().getString(quickfix.field.MsgType.FIELD)) &&
					this.password.length() > 0				
					) {			
				message.setInt(quickfix.field.RawDataLength.FIELD, this.password.length());
				message.setString(quickfix.field.RawData.FIELD, this.password);
			}
		} catch (FieldNotFound e)
		{
		}
		
	}

	@Override
	public void toApp(Message message, SessionID sessionID) throws DoNotSend
	{
		// TODO Auto-generated method stub
		
	}
	
	public void sendToConnectedSession(Message message) throws SessionNotFound {
		
		if (this.sessionID == null) throw new SessionNotFound("Disconnected");
		
		Session.sendToTarget(message, this.sessionID);
		
	}
	
	

}
