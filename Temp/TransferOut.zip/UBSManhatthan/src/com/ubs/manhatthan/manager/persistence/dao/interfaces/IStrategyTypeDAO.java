/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import com.ubs.manhatthan.manager.persistence.entities.StrategyType;

/**
 * @author galdinoa
 *
 */
public interface IStrategyTypeDAO extends IGenericDAO<StrategyType, Long> {

	StrategyType saveStrategyType(StrategyType strategyType);
}
