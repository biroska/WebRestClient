/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import com.ubs.manhatthan.manager.persistence.entities.StrategyTypeLeg;

/**
 * @author galdinoa
 *
 */
public interface IStrategyTypeLegDAO extends IGenericDAO<StrategyTypeLeg, Long> {

	StrategyTypeLeg saveStrategyTypeLeg(StrategyTypeLeg strategyTypeLeg);

}
