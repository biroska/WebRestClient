package com.ubs.manhatthan.manager.persistence.dao;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IExchangeDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.ITcpRecoverySessionAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.ITcpRecoverySessionDAO;
import com.ubs.manhatthan.manager.persistence.entities.Exchange;
import com.ubs.manhatthan.manager.persistence.entities.TcpRecoverySession;
import com.ubs.manhatthan.manager.persistence.entities.audit.TcpRecoverySessionAudit;

@Repository
@Scope("singleton")
public class TcpRecoverySessionDAO extends GenericDAO<TcpRecoverySession, Long> implements ITcpRecoverySessionDAO {
	
	@Autowired
	private IExchangeDAO exchangeDAO;
	
	@Autowired
	private ITcpRecoverySessionAuditDAO tcpRecoverySessionAuditDAO;
	
	@Autowired
	private User user;
	
	@Override
	public TcpRecoverySession saveTcpRecoverySession( TcpRecoverySession tcpRecoverySession ){
		
		ActionTypeEnum action = tcpRecoverySession.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;

		tcpRecoverySession  = update( tcpRecoverySession );

		TcpRecoverySessionAudit trsa = new TcpRecoverySessionAudit( tcpRecoverySession, action, user.getLogin(), new Date() );
		
		tcpRecoverySessionAuditDAO.update( trsa );
		
		return tcpRecoverySession;
	}

	public Long generate( int qtd ){
		
		List<Exchange> exchangeList = exchangeDAO.findAll();
		
		Long qtRegs = 0L;
		
		for ( int i = 1; i<= qtd; i++ ){
			saveTcpRecoverySession( new TcpRecoverySession( exchangeList.get( i % 2), "255.255.255.0"+i, (long) 8079 +i,
															"targetCompId_"+i, "senderCompId_"+i ) );
			qtRegs++;
		}
		
		return qtRegs;
	}

	public void setExchangeDAO(IExchangeDAO exchangeDAO) {
		this.exchangeDAO = exchangeDAO;
	}

	public void setTcpRecoverySessionAuditDAO(ITcpRecoverySessionAuditDAO tcpRecoverySessionAuditDAO) {
		this.tcpRecoverySessionAuditDAO = tcpRecoverySessionAuditDAO;
	}

	public void setUser(User user) {
		this.user = user;
	}
}