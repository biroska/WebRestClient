package com.ubs.manhatthan.manager.persistence.entities.converters;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import com.ubs.manhatthan.manager.enums.SideEnum;

@Converter(autoApply = true)
public class SideEnumConverter implements AttributeConverter<SideEnum, Integer> {

	@Override
	public Integer convertToDatabaseColumn(SideEnum side ) {
		return side.getCode();
	}

	@Override
	public SideEnum convertToEntityAttribute(Integer dbData) {
		for ( SideEnum side : SideEnum.values() ) {
			if ( side.getCode().equals(dbData) ) {
				return side;
			}
		}

		throw new IllegalArgumentException("Unknown database value:" + dbData );
	}
}