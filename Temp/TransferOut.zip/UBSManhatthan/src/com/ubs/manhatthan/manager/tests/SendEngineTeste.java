/**
 * 
 */
package com.ubs.manhatthan.manager.tests;

import com.ubs.manhatthan.manager.cache.CacheHelper;
import com.ubs.manhatthan.manager.converters.ConvertToProtobuffer;
import com.ubs.manhatthan.manager.enricher.PrepareToEngine;
import com.ubs.manhatthan.manager.enums.CommandTypeEnum;
import com.ubs.manhatthan.manager.enums.MessageTypeEnum;
import com.ubs.manhatthan.manager.network.client.NetworkClientManager;
import com.ubs.manhatthan.manager.network.client.NetworkProtobuf.pb_to_engine_message;
import com.ubs.manhatthan.manager.persistence.entities.CommandMessage;
import com.ubs.manhatthan.manager.persistence.entities.Header;
import com.ubs.manhatthan.manager.persistence.entities.Message;
import com.ubs.manhatthan.manager.persistence.entities.StrategyOrders;
import com.ubs.manhatthan.manager.persistence.entities.StrategyReport;
import com.ubs.manhatthan.manager.service.ServiceManager;
import com.ubs.manhatthan.manager.utils.Constant;
import com.ubs.manhatthan.manager.utils.Util;

/**
 * @author galdinoa
 *
 */
public class SendEngineTeste {
	
	PrepareToEngine enricher = new PrepareToEngine();
	
	static ServiceManager serviceManager = new ServiceManager();
	static volatile boolean dummy_bool = true;
	
	public static void main(String[] args) {
		
		try {
 		
			SendEngineTeste teste = new SendEngineTeste();
			
			 teste.connect( );
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public pb_to_engine_message managerMessage( Message obj ) throws Exception{
		
		pb_to_engine_message engineMessage = null;
		
		if ( obj instanceof StrategyReport ){
			
			StrategyReport report = ( StrategyReport ) obj;
			
			switch ( report.getHeader().getMessageType() ) {
			
				case CREATE_STRATEGY:
					if ( report != null ){
						CacheHelper.StrategyReportMapByRequestId.put( report.getHeader().getManagerRequestId() , report );
					}
					
					engineMessage = sendCreateStrategy( report );
					
					break;
					
				case MODIFY_STRATEGY:
				case CANCEL_STRATEGY:
					if ( report != null ){
						CacheHelper.putStrategyReport( report );
						CacheHelper.StrategyReportMapByRequestId.put( report.getHeader().getManagerRequestId() , report );
					}
					
					engineMessage = sendModifyCancelStrategy( report );
					break;

			default:
				System.out.println("Tipo de mensagen desconhecido!!!!!");
				break;
			}
			
		} else
			
			if ( obj instanceof StrategyOrders ){
				
				StrategyOrders order = ( StrategyOrders ) obj;
				
				switch ( order.getHeader().getMessageType() ) {
				
					case LEGGED_ORDER:
						if ( order != null ){
							CacheHelper.strategyOrderMap.put( order.getId(), order );
							CacheHelper.StrategyOrderMapByRequestId.put( order.getHeader().getManagerRequestId(), order );
						}
						
						engineMessage = sendLeggedMessage( order );
						break;
						
					case REPORT_EXECUTION_ORDER:
						if ( order != null ){
							CacheHelper.strategyOrderMap.put( order.getId(), order );
							CacheHelper.StrategyOrderMapByRequestId.put( order.getHeader().getManagerRequestId(), order );
						}
						
						engineMessage = sendExecutionReportOrder( order );
						break;
						
					case NEW_ORDER:
						if ( order != null ){
							CacheHelper.strategyOrderMap.put( order.getId(), order );
							CacheHelper.StrategyOrderMapByRequestId.put( order.getHeader().getManagerRequestId(), order );
						}
						
						engineMessage = sendNewOrderSingle( order );
						break;

				default:
					System.out.println("Tipo de mensagen desconhecido!!!!!");
					break;
				}
				
			} else
				if ( obj instanceof CommandMessage ){
					CommandMessage commandMessage = (CommandMessage) obj;
					engineMessage = sendCommandMessage( commandMessage );
				}
		
		return engineMessage;
//		sendMessage( engineMessage );
	}
	
	public Header buildHeader( MessageTypeEnum type, Long engineInstance, Long managerRequestId ){
		return new Header( type, engineInstance, Util.getManagerId(), managerRequestId );
	}
	
//	public StrategyReport buildCreateModifyCancelStrategy( Header header, Long id ) throws Exception{
//		
//		StrategyReport report = new StrategyReport();
//		
//		report.setHeader( header );
//		report.getId().setStrategyId( id );
//		
//		return report;
//	}
	
	private pb_to_engine_message sendCreateStrategy( StrategyReport report ) throws Exception{
		
//		Enricher
		System.out.println("Enriching...");
		report = enricher.enrichCreateStrategy( report );
		
//		Converter to protobuffer
		System.out.println("Converting...");
		pb_to_engine_message engineMessage = ConvertToProtobuffer.convertToStrategy( report );
		
//		sendMessage( engineMessage );
		
		return engineMessage;
	}
	
	private pb_to_engine_message sendModifyCancelStrategy( StrategyReport report ) throws Exception{
		
//		Enricher
		System.out.println("Enriching...");
		report = enricher.enrichModifyCancelStrategy( report );
		
//		Converter to protobuffer
		System.out.println("Converting...");
		pb_to_engine_message engineMessage = ConvertToProtobuffer.convertToStrategy( report );
		
//		sendMessage( engineMessage );
		
		return engineMessage;
	}
	
	private pb_to_engine_message sendNewOrderSingle( StrategyOrders order ) throws Exception{
		
//		� uma new order n�o h� necessidade de enriquecer, apenas retransmitir a mensagem
//		Manager manager = new Manager();
//		
//		order = manager.generateNewOrder( order.getLegStrategyReport(), order);

//		Converter to protobuffer
		System.out.println("Converting...");
		pb_to_engine_message engineMessage = ConvertToProtobuffer.convertToNewOrderSingle( order );
		
		return engineMessage;
	}
	
	private pb_to_engine_message sendExecutionReportOrder( StrategyOrders order ) throws Exception{
		
//		Enricher
		System.out.println("Enriching...");
		order = enricher.enrichStrategyOrder( order );
		
//		Converter to protobuffer
		System.out.println("Converting...");
		pb_to_engine_message engineMessage = ConvertToProtobuffer.convertToReportOrder( order );
		
//		sendMessage( engineMessage );
		return engineMessage;
	}
	

	private pb_to_engine_message sendLeggedMessage( StrategyOrders order ) throws Exception{
		
//		Enricher
		System.out.println("Enriching...");
		order = enricher.enrichLeggedStrategyOrder( order );
		
//		Converter to protobuffer
		System.out.println("Converting...");
		pb_to_engine_message engineMessage = ConvertToProtobuffer.convertToLeggedOrder ( order );
		
//		sendMessage( engineMessage );
		return engineMessage;
	}
	
	public CommandMessage buildCommandMessage( Header header, CommandTypeEnum type ) throws Exception{
		
		CommandMessage commandMessage = new CommandMessage();
		
//		Header header = new Header( MessageTypeEnum.COMMANDE_MESSAGE, Util.getEngineId(), Util.getManagerId(), 123L );
		
		commandMessage.setHeader( header );
		commandMessage.setCommandType( type );

		return commandMessage;
	}

	private pb_to_engine_message sendCommandMessage( CommandMessage commandMessage ) throws Exception{
		
//		Enricher
		System.out.println("Enriching...");
//		CommandTypeEnum type = enricher.enrichCommandMessage( commandMessage.getCommandType() );
		
//		Converter to protobuffer
		System.out.println("Converting...");
		pb_to_engine_message engineMessage = ConvertToProtobuffer.convertToCommandMessage ( commandMessage );
		
//		sendMessage( engineMessage ); 
		return engineMessage;
	}
	
	private void connect( ) throws Exception{
		
		//Print start
		System.out.println("Starting engine...");
		
		//Start & Register Network Service
		NetworkClientManager client = new NetworkClientManager( Constant.COMUNICATION.ADDRESS, 
																Constant.COMUNICATION.PORT );
		serviceManager.registerService( client.getService() );		
	
		//Start all services
		serviceManager.start(); //Sending logon
		
		Thread.sleep( 1000 );
	}
}