/*
 * ServiceManager.java
 *
 *  Created on: Set 25, 2015
 *      Author: pretof
 */

package com.ubs.manhatthan.manager.service;

import java.util.HashSet;

public class ServiceManager {
	
	private HashSet<ServiceLifecycle> services = new HashSet<ServiceLifecycle>();
	
	public ServiceManager() {
	}
	
	public void registerService(ServiceLifecycle service) throws ServiceException {
		
		//Load Service
		try{
			
			service.onLoad();
		}
		
		//Error
		catch(ServiceException e){
			
			System.out.println("Error while registering service: " + e.toString());
			return;
		}
		
		//Success
		services.add(service);
		System.out.println("New service registered successfully");
	}
	
	public void start() throws ServiceException {
		
		for (ServiceLifecycle service : services) {
			
			service.onStart();
		}
		
	}
	
	public void stop() throws ServiceException {
		
		for (ServiceLifecycle service : services) {
			service.onStop();
		}
		
	}

	
	
}
