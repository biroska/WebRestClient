package com.ubs.manhatthan.manager.persistence.dao;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.manager.persistence.dao.interfaces.IAccountTypeDAO;
import com.ubs.manhatthan.manager.persistence.entities.AccountType;

@Repository
@Scope("singleton")
public class AccountTypeDAO extends GenericDAO<AccountType, Long> implements IAccountTypeDAO {
	
	@Override
	public AccountType saveAccountType( AccountType accountType ){
		
		AccountType update = update( accountType );
		
		return update;
	}
	
	public Long generateAccountType( int qtd ){
		
		Long qtRegs = 0L;
		
		for ( int i = 1; i<= qtd; i++ ){
			update( new AccountType( "AccountType_" + i  ) );
			qtRegs++;
		}
		return qtRegs;
	}
	
	public AccountType getAccountTypeByIndex( int index ) {
		return findAll().get( index );
	}

}
