package com.ubs.manhatthan.manager.persistence.dao;

import java.util.List;

import org.hibernate.criterion.Restrictions;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.manager.persistence.dao.interfaces.ILegStrategyReportDAO;
import com.ubs.manhatthan.manager.persistence.entities.LegStrategyReport;
import com.ubs.manhatthan.manager.persistence.entities.id.LegStrategyReportPK;

@Repository
@Scope("singleton")
public class LegStrategyReportDAO extends GenericDAO<LegStrategyReport, LegStrategyReportPK> implements ILegStrategyReportDAO {
	
	@Override
	public List<LegStrategyReport> findByStrategyId( Long reportId ){
		
		return findByCriteria( Restrictions.eq("id.strategyId", reportId ) );
	}
}