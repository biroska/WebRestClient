/**
 * 
 */
package com.ubs.manhatthan.manager.tests;

import java.util.Date;

import com.ubs.manhatthan.manager.facade.Facade;
import com.ubs.manhatthan.manager.facade.FacadeImpl;



/**
 * @author galdinoa
 *
 */
public class DiversosTestes {
	
	public static void main (String[] args){
		
		Facade base = new FacadeImpl();
		
		Date startDt = new Date(115, 9, 12);
		Date endDt = new Date(115, 9, 16);
		
		Integer businessDayTotal2 = base.businessDayTotal2( startDt, endDt );
		
		Integer businessDayTotal = base.businessDayTotal( startDt, endDt );
		
		System.out.println("\n\n businessDayTotal2: " + businessDayTotal2 + "\t businessDayTotal: " + businessDayTotal );
		
	}
	
}