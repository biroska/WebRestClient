/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import com.ubs.manhatthan.manager.persistence.entities.EngineInstance;


/**
 * @author galdinoa
 *
 */
public interface IEngineInstanceDAO extends IGenericDAO<EngineInstance, Integer> {

	EngineInstance saveEngineInstance(EngineInstance engine);

}
