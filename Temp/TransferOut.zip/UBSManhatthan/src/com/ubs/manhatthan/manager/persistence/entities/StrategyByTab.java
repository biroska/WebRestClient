package com.ubs.manhatthan.manager.persistence.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name="TB_REL_STRATEGY_PER_TAB",
uniqueConstraints={
		   @UniqueConstraint(columnNames={"TAB", "STRATEGY_TYPE", "INSTRUMENT"}, name = "CK_STRATEGY_PER_TAB")
		})
public class StrategyByTab {
	
	public StrategyByTab(){}
	
	public StrategyByTab(TraderWatchTab tab, StrategyType strategyType, Integer instrument) {
		super();
		this.tab = tab;
		this.strategyType = strategyType;
		this.instrument = instrument;
	}

	@Id
	@Column ( name = "ID")
	@SequenceGenerator(name = "TB_REL_STRATEGY_PER_TAB_ID_GENERATOR", sequenceName = "SEQ_REL_STRATEGY_PER_TAB", allocationSize = 1)
	@GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "TB_REL_STRATEGY_PER_TAB_ID_GENERATOR" )
	private Long id;
	
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name = "TAB", nullable = false )
	private TraderWatchTab tab;
	
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name = "STRATEGY_TYPE")
	private StrategyType strategyType;
	
	@Column ( name = "INSTRUMENT")
	private Integer instrument;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public TraderWatchTab getTab() {
		return tab;
	}

	public void setTab(TraderWatchTab tab) {
		this.tab = tab;
	}

	public StrategyType getStrategyType() {
		return strategyType;
	}

	public void setStrategyType(StrategyType strategyType) {
		this.strategyType = strategyType;
	}

	public Integer getInstrument() {
		return instrument;
	}

	public void setInstrument(Integer instrument) {
		this.instrument = instrument;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((instrument == null) ? 0 : instrument.hashCode());
		result = prime * result
				+ ((strategyType == null) ? 0 : strategyType.hashCode());
		result = prime * result + ((tab == null) ? 0 : tab.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StrategyByTab other = (StrategyByTab) obj;
		if (instrument == null) {
			if (other.instrument != null)
				return false;
		} else if (!instrument.equals(other.instrument))
			return false;
		if (strategyType == null) {
			if (other.strategyType != null)
				return false;
		} else if (!strategyType.equals(other.strategyType))
			return false;
		if (tab == null) {
			if (other.tab != null)
				return false;
		} else if (!tab.equals(other.tab))
			return false;
		return true;
	}

	@Override
	public String toString() {
		
		return "StrategyByTab [id=" + id + ", tab=" + tab + ", strategyType="
				+ strategyType + ", instrument=" + instrument + "]";
	}
}