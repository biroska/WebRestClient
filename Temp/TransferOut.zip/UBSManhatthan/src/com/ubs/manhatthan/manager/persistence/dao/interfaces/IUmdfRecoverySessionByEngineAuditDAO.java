/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import com.ubs.manhatthan.manager.persistence.entities.audit.UmdfRecoverySessionByEngineAudit;

/**
 * @author galdinoa
 *
 */
public interface IUmdfRecoverySessionByEngineAuditDAO extends IGenericDAO<UmdfRecoverySessionByEngineAudit, Long> {}
