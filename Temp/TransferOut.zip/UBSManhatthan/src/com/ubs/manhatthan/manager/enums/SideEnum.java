package com.ubs.manhatthan.manager.enums;


public enum SideEnum{
	
	NOT_DEFINED                 ( 0  ),
    BUY                         ( 49 ), // 0
    SELL                        ( 50 ),
    CROSS						( 56 ); // 4

    private final Integer code;
    
    private SideEnum( Integer code ) {
        this.code = code;
    }

    public Integer getCode() {
        return code;
    }
    
    public static SideEnum fromValue( Integer value ){
    	
		for (SideEnum item : SideEnum.values() ) {
			if ( item.getCode().equals( value ) ){
				return item;
			}
		}
		return null;
    }
}