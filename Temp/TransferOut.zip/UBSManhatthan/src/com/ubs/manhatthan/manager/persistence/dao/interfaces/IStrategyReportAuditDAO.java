/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import com.ubs.manhatthan.manager.persistence.entities.StrategyReport;
import com.ubs.manhatthan.manager.persistence.entities.audit.StrategyReportAudit;

/**
 * @author galdinoa
 *
 */
public interface IStrategyReportAuditDAO extends IGenericDAO<StrategyReportAudit, Long> {

	void saveReportAudit(StrategyReport report);
}
