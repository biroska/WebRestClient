package com.ubs.manhatthan.manager.persistence.dao;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.enums.OrderStatusEnum;
import com.ubs.manhatthan.manager.enums.SideEnum;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IClientAccountDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IOrderTradeAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IOrderTradeDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IStrategyOrdersDAO;
import com.ubs.manhatthan.manager.persistence.entities.ClientAccount;
import com.ubs.manhatthan.manager.persistence.entities.OrderTrade;
import com.ubs.manhatthan.manager.persistence.entities.StrategyOrders;
import com.ubs.manhatthan.manager.persistence.entities.audit.OrderTradeAudit;

@Repository
@Scope("singleton")
public class OrderTradeDAO extends GenericDAO<OrderTrade, Long> implements IOrderTradeDAO {
	
	@Autowired
	private IStrategyOrdersDAO strategyOrdersDAO;
	
	@Autowired
	private IClientAccountDAO clientAccountDAO;

	@Autowired
	private IOrderTradeAuditDAO orderTradeAuditDAO;
	
	@Autowired
	private User user;
	
	@Override
	public OrderTrade saveOrderTrade( OrderTrade orderTrade ){
		
		ActionTypeEnum action = orderTrade.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;

		orderTrade  = update( orderTrade );

		OrderTradeAudit teca = new OrderTradeAudit( orderTrade, action, user.getLogin(), new Date() );
		
		orderTradeAuditDAO.update( teca );
		
		return orderTrade;
	}
	
	public Long generate( int qtd ){
		
		StrategyOrders strategyOrder = strategyOrdersDAO.getByIndex( 0 );
		List<ClientAccount> clientAccountList = clientAccountDAO.findAll();
		
		Long qtRegs = 0L;
		
		for ( int i = 1; i<= qtd; i++ ){
			saveOrderTrade( new OrderTrade( strategyOrder, OrderStatusEnum.REPLACED , "SYMBOL",
					                        SideEnum.fromValue( (i % 2) +1 ) ,
					                        clientAccountList.get( i % 5), "TRADE_"+i,  i * 25L, (Math.random() * i * 100) ) );
			qtRegs++;
		}
		
		return qtRegs;
	}

	public void setStrategyOrdersDAO(IStrategyOrdersDAO strategyOrdersDAO) {
		this.strategyOrdersDAO = strategyOrdersDAO;
	}

	public void setClientAccountDAO(IClientAccountDAO clientAccountDAO) {
		this.clientAccountDAO = clientAccountDAO;
	}

	public void setOrderTradeAuditDAO(IOrderTradeAuditDAO orderTradeAuditDAO) {
		this.orderTradeAuditDAO = orderTradeAuditDAO;
	}

	public void setUser(User user) {
		this.user = user;
	}
}