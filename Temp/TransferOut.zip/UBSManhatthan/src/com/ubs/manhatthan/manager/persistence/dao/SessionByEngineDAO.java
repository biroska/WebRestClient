package com.ubs.manhatthan.manager.persistence.dao;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IEngineInstanceDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IOrderFixSessionDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.ISessionByEngineAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.ISessionByEngineDAO;
import com.ubs.manhatthan.manager.persistence.entities.EngineInstance;
import com.ubs.manhatthan.manager.persistence.entities.OrderFixSession;
import com.ubs.manhatthan.manager.persistence.entities.SessionByEngine;
import com.ubs.manhatthan.manager.persistence.entities.audit.SessionByEngineAudit;

@Repository
@Scope("singleton")
public class SessionByEngineDAO extends GenericDAO<SessionByEngine, Long> implements ISessionByEngineDAO {
	
	@Autowired
	private IEngineInstanceDAO engineInstanceDAO;
	
	@Autowired
	private IOrderFixSessionDAO orderFixSessionDAO;
	
	@Autowired
	private ISessionByEngineAuditDAO sessionByEngineAuditDAO;
	
	@Autowired
	private User user;
	
	@Override
	public SessionByEngine saveSessionByEngine( SessionByEngine sessionByEngine ){
		
		ActionTypeEnum action = sessionByEngine.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;

		sessionByEngine  = update( sessionByEngine );

		SessionByEngineAudit sbea = new SessionByEngineAudit( sessionByEngine, action, user.getLogin(), new Date() );
		
		sessionByEngineAuditDAO.save( sbea );
		
		return sessionByEngine;
	}

	public Long generate( int qtd ){
		
		List<EngineInstance> engineInstanceList = engineInstanceDAO.findAll();
		List<OrderFixSession> orderFixSessionList = orderFixSessionDAO.findAll();
		
		Long qtRegs = 0L;
		
		for ( int i = 1; i<= qtd; i++ ){
			saveSessionByEngine( new SessionByEngine( engineInstanceList.get( i -1), orderFixSessionList.get( qtd -i) ) );
			qtRegs++;
		}
		
		return qtRegs;
	}
	
	public SessionByEngine getByIndex( int index ) {
		return findAll().get( index );
	}

	public void setOrderFixSessionDAO(IOrderFixSessionDAO orderFixSessionDAO) {
		this.orderFixSessionDAO = orderFixSessionDAO;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public void setSessionByEngineAuditDAO(ISessionByEngineAuditDAO sessionByEngineAuditDAO) {
		this.sessionByEngineAuditDAO = sessionByEngineAuditDAO;
	}

	public IEngineInstanceDAO getEngineInstanceDAO() {
		return engineInstanceDAO;
	}
}