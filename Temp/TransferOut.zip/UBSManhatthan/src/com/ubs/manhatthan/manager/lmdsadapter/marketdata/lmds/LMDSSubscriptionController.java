package com.ubs.manhatthan.manager.lmdsadapter.marketdata.lmds;

import quickfix.Message;
import quickfix.SessionNotFound;

import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.SecurityDefinition;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.lmds.builders.MarketDataSubscribeBuilder;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.lmds.builders.SecurityListRequestBuilder;

class LMDSSubscriptionController
{
	private final QuickFixLMDSApplication application;
	private int reqCounter;

	public LMDSSubscriptionController(QuickFixLMDSApplication application)
	{
		this.application = application;
	}

	public synchronized void requestSecurityList() throws SessionNotFound
	{
		String reqId = generateUniqueRequestID();
		Message request = SecurityListRequestBuilder.build(reqId);
		this.application.sendToConnectedSession(request);
	}
 
	
	public synchronized void subscribeSymbol(SecurityDefinition instrument) {
		
		
		Message subscribeMessage = MarketDataSubscribeBuilder.buildSubscribe(
				instrument.getSecurity().getExchange(), instrument.getSecurity().getSymbol(), instrument.getSecurity().getSecurityID(), generateUniqueRequestID());
		
		try
		{
			this.application.sendToConnectedSession(subscribeMessage);
		} catch (SessionNotFound e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}


	private synchronized String generateUniqueRequestID()
	{
		this.reqCounter++;
		return "REQ." + this.reqCounter;
	}


}
