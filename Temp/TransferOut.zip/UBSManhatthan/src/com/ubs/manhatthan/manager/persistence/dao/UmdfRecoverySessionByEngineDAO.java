package com.ubs.manhatthan.manager.persistence.dao;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IEngineInstanceDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.ITcpRecoverySessionDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IUmdfRecoverySessionByEngineAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IUmdfRecoverySessionByEngineDAO;
import com.ubs.manhatthan.manager.persistence.entities.EngineInstance;
import com.ubs.manhatthan.manager.persistence.entities.TcpRecoverySession;
import com.ubs.manhatthan.manager.persistence.entities.UmdfRecoverySessionByEngine;
import com.ubs.manhatthan.manager.persistence.entities.audit.UmdfRecoverySessionByEngineAudit;

@Repository
@Scope("singleton")
public class UmdfRecoverySessionByEngineDAO extends GenericDAO<UmdfRecoverySessionByEngine, Long> implements IUmdfRecoverySessionByEngineDAO {
	
	@Autowired
	private IEngineInstanceDAO engineInstanceDAO;
	
	@Autowired
	private ITcpRecoverySessionDAO tcpRecoverySessionDAO;
	
	@Autowired
	private IUmdfRecoverySessionByEngineAuditDAO umdfRecoverySessionByEngineAuditDAO;
	
	@Autowired
	private User user;
	
	@Override
	public UmdfRecoverySessionByEngine saveUmdfRecoverySessionByEngine( UmdfRecoverySessionByEngine umdfRecoverySessionByEngine ){
		
		ActionTypeEnum action = umdfRecoverySessionByEngine.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;

		umdfRecoverySessionByEngine  = update( umdfRecoverySessionByEngine );

		UmdfRecoverySessionByEngineAudit ursbea = new UmdfRecoverySessionByEngineAudit( umdfRecoverySessionByEngine, action, user.getLogin(), new Date() );
		
		umdfRecoverySessionByEngineAuditDAO.update( ursbea );
		
		return umdfRecoverySessionByEngine;
	}

	public Long generate( int qtd ){
		
		List<EngineInstance> engineInstanceList = engineInstanceDAO.findAll();
		List<TcpRecoverySession> tcpRecoverySessionList = tcpRecoverySessionDAO.findAll();
		
		Long qtRegs = 0L;
		
		for ( int i = 1; i<= qtd; i++ ){
			saveUmdfRecoverySessionByEngine( new UmdfRecoverySessionByEngine( engineInstanceList.get( i -1 ), tcpRecoverySessionList.get( qtd -i ) ) );
			qtRegs++;
		}
		
		return qtRegs;
	}

	public void setEngineInstanceDAO(IEngineInstanceDAO engineInstanceDAO) {
		this.engineInstanceDAO = engineInstanceDAO;
	}

	public void setTcpRecoverySessionDAO(ITcpRecoverySessionDAO tcpRecoverySessionDAO) {
		this.tcpRecoverySessionDAO = tcpRecoverySessionDAO;
	}

	public void setUmdfRecoverySessionByEngineAuditDAO(
			IUmdfRecoverySessionByEngineAuditDAO umdfRecoverySessionByEngineAuditDAO) {
		this.umdfRecoverySessionByEngineAuditDAO = umdfRecoverySessionByEngineAuditDAO;
	}

	public void setUser(User user) {
		this.user = user;
	}
}