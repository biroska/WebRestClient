package com.ubs.manhatthan.manager.tests;

import java.math.BigDecimal;

import com.ubs.manhatthan.manager.enums.SideEnum;
import com.ubs.manhatthan.manager.enums.StrategyTypeEnum;
import com.ubs.manhatthan.manager.facade.FacadeService;
import com.ubs.manhatthan.manager.facade.FacadeServiceImpl;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.basicimplementation.BasicSecurity;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.basicimplementation.BasicSecurityDefinition;
import com.ubs.manhatthan.manager.mocks.MarketDataMock;
import com.ubs.manhatthan.manager.simulator.multileg.InputMultilegSimulation;
import com.ubs.manhatthan.manager.simulator.multileg.InputMultilegSimulationItem;
import com.ubs.manhatthan.manager.simulator.multileg.ReturnMultilegSimulation;

public class SimulationTeste {
	
		public static void main(String[] args) {
			
			FacadeService fService = new FacadeServiceImpl();
			
			InputMultilegSimulation input = new InputMultilegSimulation();
			
//			Only target teste - in�cio
//			Double random = Math.random();
//			random = ( random == 0 ? 0.5 : random );
//			
//			input.setUserDefinedTarget( random );
//			input.setOnlyTarget( true );
//			input.setSimulationMode( SimulationModeEnum.FRA_SIMULATION );
//			
//			ReturnMultilegSimulation calculate = fService.calculate( input );
//			
//			System.out.println("calculate-onlyTarget: " + calculate );
//			Only target teste - fim
			
//			full simulation Teste - in�cio
			Double random = Math.random();
			random = ( random == 0 ? 0.5 : random );
			
			input.setUserDefinedTarget( random );
			input.setOnlyTarget( false );
			input.setSimulationMode( StrategyTypeEnum.MULTILEG_FRA );
			
//			first leg
			InputMultilegSimulationItem item = new InputMultilegSimulationItem();
			item.setInstrument( Integer.valueOf( "" + MarketDataMock.getInstrumentByIndex( 0 ) ) );
			item.setLegSeq( 0 );
			item.setSide( SideEnum.BUY );
//			item.setQuote( new BasicBookSnapshot( new BasicSecurity("1", "BVMF", "DI1F18"), 5, new ArrayList<BookEntry>(), new ArrayList<BookEntry>(), 3 ) );
			item.setSecurityDefinition( new BasicSecurityDefinition( new BasicSecurity("1", "BVMF", "DI1F18"), 5, new BigDecimal( 0.75 ) ) );
			item.setBusinessDays( 5 );
			item.setSimulationLeg( false );
			
			input.getInputItens().add( item );
			
//			second leg
			item = new InputMultilegSimulationItem();
			item.setInstrument( Integer.valueOf( "" + MarketDataMock.getInstrumentByIndex( 1 ) ) );
			item.setLegSeq( 1 );
			item.setSide( SideEnum.SELL );
//			item.setQuote( new BasicBookSnapshot( new BasicSecurity("2", "BVMF", "DI1F21"), 5, new ArrayList<BookEntry>(), new ArrayList<BookEntry>(), 4 ) );
			item.setSecurityDefinition( new BasicSecurityDefinition( new BasicSecurity("3", "BVMF", "DI1F21"), 5, new BigDecimal( 0.35 ) ) );
			item.setBusinessDays( 2 );
			item.setSimulationLeg( true );
			
			input.getInputItens().add( item );
			
			ReturnMultilegSimulation calculate = fService.calculate( input );
			
			System.out.println("calculate-fullSimulation: " + calculate );
//			full simulation Teste - fim
			
		}
}