package com.ubs.manhatthan.manager.logger;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.FileAppender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;

import com.ubs.manhatthan.manager.utils.Constant;
import com.ubs.manhatthan.manager.utils.Util;

public class ManhattanLogger {

	private static PatternLayout layout;
	private static String conversionPattern;
	private static HashMap<String, FileAppender> appendersMap;
	private static HashMap<String, String> fileNameByPrefix;
	private static String fileLocation;

	static {
		layout = new PatternLayout();
		conversionPattern = "%d{HH:mm:ss.SSS} | %-5p | %c:  %m%n";
		appendersMap = new HashMap<String, FileAppender>();
		fileNameByPrefix = new HashMap<String, String>();
		fileLocation = Util.getPropertyFromFile( "manhattan.log.location" );
	}
	
	private static String generateFileName( String managerInstance ){
		
		String fileNamePrefix = Util.getDateFormated() +"_"+ managerInstance;
		String fileName = "";
		
		Integer fileQtd = null;
		
		fileName = fileNameByPrefix.get( fileNamePrefix );
		
		if ( fileName == null ){
			fileQtd = logVersion( fileNamePrefix );
			fileName = fileNamePrefix + "_" + fileQtd;
			fileNameByPrefix.put(fileNamePrefix, fileName);
		} 
		
		return fileName;
	}
	
	@SuppressWarnings("unused")
	private static int logVersion( String fileNamePrefix ){
		
		int fileQtd = 0;
		
//		String fileLocation = Util.getPropertyFromFile( "manhattan.log.location" );
		
		if ( StringUtils.isBlank( fileLocation) )
			fileLocation = System.getProperty("user.dir");
		
		Path directoryPath = Paths.get( fileLocation );

		if ( Files.isDirectory( directoryPath )  ) {
		    try ( DirectoryStream< Path > stream = Files.newDirectoryStream( directoryPath, fileNamePrefix+"*"  ) ) {
		        for (Path path : stream) {
		            fileQtd++;
		        }
		        
		        fileQtd++;
		        
		    } catch (IOException e) {
		        throw new RuntimeException(e);
		    }
		}
		
		return fileQtd;
		
	}
	
	private static Logger configureLogger( String managerInstance, Level logLevel ){
		
		String keyFileName = generateFileName( managerInstance );
		
		Logger logger = Logger.getLogger( keyFileName );
		logger.setLevel( logLevel  );
		logger.addAppender( getAppender( keyFileName ) );
		
		return logger;
		
	}
	
	public static void log( String managerInstance, String message, Level logLevel ){
		
		Logger logger = configureLogger( managerInstance, logLevel );
		
		writeByLogLevel( logger, logLevel, generateFileName( managerInstance ), message );
	}
	
	public static void log( String managerInstance, String message, Level logLevel, Exception e ){
		
		Logger logger = configureLogger( managerInstance, logLevel );
		
		writeByLogLevel( logger, generateFileName( managerInstance ), message, e );
	}
	
	private static FileAppender getAppender( String keyFileName ){
		
		FileAppender appender = appendersMap.get( keyFileName );
		
		if ( appender == null ){
			layout.setConversionPattern( conversionPattern );
			
			appender = new FileAppender();
			appender.setFile( fileLocation + keyFileName + "." + Constant.LOG_CONFIGURATION.FILE_EXTENSION );
			appender.setLayout( layout );
			appender.setName( keyFileName );
			appender.activateOptions();
			
			appendersMap.put( keyFileName, appender );
		}
		
		return appender;
	}
	
	@SuppressWarnings("static-access")
	private static void writeByLogLevel(Logger logger, Level logLevel, String keyFileName, String message ){
		
		if ( logLevel.equals( Level.DEBUG ) )
			logger.getLogger( keyFileName ).debug( message );
		else
			if ( logLevel.equals( Level.ERROR ) )
				logger.getLogger( keyFileName ).error( message );
			else
				if ( logLevel.equals( Level.INFO ) )
					logger.getLogger( keyFileName ).info( message );
				else
					if ( logLevel.equals( Level.WARN ) )
						logger.getLogger( keyFileName ).warn( message );
					else
						if ( logLevel.equals( Level.FATAL ) )
							logger.getLogger( keyFileName ).fatal( message );
		
	}
	
	@SuppressWarnings("static-access")
	private static void writeByLogLevel(Logger logger, String keyFileName, String message, Exception e ){
		
		logger.getLogger( keyFileName ).error( message, e );
		
	}
	
	public static void devLog( String fileName, String message ){
		
		if ( fileName == null || StringUtils.isBlank( fileName ) )
			fileName = "debugTeste";

		Logger log = Logger.getLogger( fileName );
		log.setLevel( Level.DEBUG  );
		
		layout.setConversionPattern( conversionPattern );
		
		FileAppender ap = new FileAppender();
		ap.setFile( fileLocation + fileName + "." + Constant.LOG_CONFIGURATION.FILE_EXTENSION );
		ap.setLayout( layout );
		ap.setName( fileName );
		ap.activateOptions();
			
		log.addAppender( ap );
		
		writeByLogLevel( log, Level.DEBUG, fileName, message );
	}
}