/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import com.ubs.manhatthan.manager.persistence.entities.OrderTrade;
import com.ubs.manhatthan.manager.persistence.entities.audit.OrderTradeAudit;

/**
 * @author galdinoa
 *
 */
public interface IOrderTradeAuditDAO extends IGenericDAO<OrderTradeAudit, Long> {

	public OrderTradeAudit saveOrderTradeAudit(OrderTrade orderTrade);
	
}
