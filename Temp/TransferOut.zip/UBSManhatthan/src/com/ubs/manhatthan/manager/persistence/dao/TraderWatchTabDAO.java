package com.ubs.manhatthan.manager.persistence.dao;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.ITraderWatchTabAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.ITraderWatchTabDAO;
import com.ubs.manhatthan.manager.persistence.entities.TraderWatchTab;
import com.ubs.manhatthan.manager.persistence.entities.audit.TraderWatchTabAudit;

@Repository
@Scope("singleton")
public class TraderWatchTabDAO extends GenericDAO<TraderWatchTab, Long> implements ITraderWatchTabDAO {
	
	@Autowired
	private ITraderWatchTabAuditDAO traderWatchTabAuditDAO;
	
	@Autowired
	private User user;
	
	@Override
	public TraderWatchTab saveTraderWatchTab( TraderWatchTab traderWatchTab ){
		
		ActionTypeEnum action = traderWatchTab.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;

		traderWatchTab = update( traderWatchTab );

		TraderWatchTabAudit sta = new TraderWatchTabAudit( traderWatchTab, action, user.getLogin(), new Date() );
		
		traderWatchTabAuditDAO.update( sta );
		
		return traderWatchTab;
	}

	public Long generate( int qtd ){

		Long qtRegs = 0L;
		
		for (int i = 1; i <= 10; i++) {
			saveTraderWatchTab( new TraderWatchTab( "AIM*", "Descrip_" + i ) );
			qtRegs++;
		}
		
		return qtRegs;
	}

	public void setTraderWatchTabAuditDAO(ITraderWatchTabAuditDAO traderWatchTabAuditDAO) {
		this.traderWatchTabAuditDAO = traderWatchTabAuditDAO;
	}

	public void setUser(User user) {
		this.user = user;
	}
}