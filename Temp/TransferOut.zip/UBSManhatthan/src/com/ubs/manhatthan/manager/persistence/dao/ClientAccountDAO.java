package com.ubs.manhatthan.manager.persistence.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.manager.persistence.dao.interfaces.IClientAccountDAO;
import com.ubs.manhatthan.manager.persistence.entities.ClientAccount;

@Repository
@Scope("singleton")
public class ClientAccountDAO extends GenericDAO<ClientAccount, Long> implements IClientAccountDAO {
	
	@Override
	public List<ClientAccount> findClientAccount( ClientAccount clientAccount ){
		
		List<ClientAccount> returnList = null;
		
		if ( clientAccount != null ){
			
			if ( clientAccount.getCode() != null ){
				clientAccount = findById( clientAccount.getCode() );

				if (clientAccount != null ){
					returnList = new ArrayList<ClientAccount>();
					returnList.add(clientAccount);
				}
			} else {
				returnList = findByExample( clientAccount );
			}
		} 
		return returnList;
	}
}