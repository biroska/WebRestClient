package com.ubs.manhatthan.manager.facade;

import java.util.Date;
import java.util.List;

import com.ubs.manhatthan.manager.persistence.entities.AccountType;
import com.ubs.manhatthan.manager.persistence.entities.ClientAccount;
import com.ubs.manhatthan.manager.persistence.entities.EngineInstance;
import com.ubs.manhatthan.manager.persistence.entities.EngineUmdfChannel;
import com.ubs.manhatthan.manager.persistence.entities.Exchange;
import com.ubs.manhatthan.manager.persistence.entities.LegStrategyReport;
import com.ubs.manhatthan.manager.persistence.entities.OrderFixSession;
import com.ubs.manhatthan.manager.persistence.entities.OrderTrade;
import com.ubs.manhatthan.manager.persistence.entities.PasswordParameter;
import com.ubs.manhatthan.manager.persistence.entities.Profile;
import com.ubs.manhatthan.manager.persistence.entities.Role;
import com.ubs.manhatthan.manager.persistence.entities.RoleByProfile;
import com.ubs.manhatthan.manager.persistence.entities.SessionByAccount;
import com.ubs.manhatthan.manager.persistence.entities.SessionByEngine;
import com.ubs.manhatthan.manager.persistence.entities.StrategyByTab;
import com.ubs.manhatthan.manager.persistence.entities.StrategyByTabLeg;
import com.ubs.manhatthan.manager.persistence.entities.StrategyOrders;
import com.ubs.manhatthan.manager.persistence.entities.StrategyReport;
import com.ubs.manhatthan.manager.persistence.entities.StrategyType;
import com.ubs.manhatthan.manager.persistence.entities.StrategyTypeLeg;
import com.ubs.manhatthan.manager.persistence.entities.TcpRecoverySession;
import com.ubs.manhatthan.manager.persistence.entities.Trader;
import com.ubs.manhatthan.manager.persistence.entities.TraderExchangeCode;
import com.ubs.manhatthan.manager.persistence.entities.TraderWatchTab;
import com.ubs.manhatthan.manager.persistence.entities.UmdfChannelByEngine;
import com.ubs.manhatthan.manager.persistence.entities.UmdfRecoverySessionByEngine;

public interface Facade {
	
	public StrategyReport saveReport( StrategyReport report ) throws Exception;
	
	public StrategyOrders saveOrder( StrategyOrders report ) throws Exception;
	
	public OrderTrade saveOrderTrade( OrderTrade orderTrade ) throws Exception;
	
	public LegStrategyReport getLegStrategyByID( Integer legSeq, Long strategyReportId ) throws Exception;
	
	public List<LegStrategyReport> getLegStrategyByReportId ( Long strategyReportId ) throws Exception;
	
	public StrategyOrders findStrategyOrderById( StrategyOrders order ) throws Exception;
	
	public StrategyReport findStrategyReportById( StrategyReport report ) throws Exception;
	
	public EngineInstance saveEngineInstance( EngineInstance engine ) throws Exception;
	
	public Integer businessDayTotal( Date beginningDt, Date endingDt );
	
	public Integer businessDayTotal2( Date beginningDt, Date endingDt );
	
	public Role saveRole( Role role );

	public AccountType saveAccountType(AccountType accountType);

	public EngineUmdfChannel saveEngineUmdfChannel(EngineUmdfChannel engineUmdfChannel);

	public Exchange saveExchange(Exchange exchange);

	public OrderFixSession saveOrderFixSession(OrderFixSession orderFixSession);

	public List<Exchange> findExchange(Exchange exchange);

	public PasswordParameter savePasswordParameter(PasswordParameter passwordParameter);

	public Profile saveProfile(Profile profile);

	public RoleByProfile saveRoleByProfile(RoleByProfile role);

	public List<Role> findRole(Role role);

	public List<Profile> findProfile(Profile profile);

	public SessionByAccount saveOrderFixSession(SessionByAccount sessionByAccount);

	public ClientAccount getClientAccountByIndex(int index);

	public OrderFixSession getOrderFixSessionByIndex(int index);

	public SessionByEngine saveSessionByEngine(SessionByEngine sessionByEngine);

	public EngineInstance getEngineInstanceByIndex(int index);

	public StrategyByTab saveStrategyByTab(StrategyByTab strategyByTab);

	public TraderWatchTab saveTraderWatchTab(TraderWatchTab traderWatchTab);

	public StrategyType saveStrategyType(StrategyType strategyType);

	public Exchange getExchangeByIndex(int index);

	public TraderWatchTab getTraderWatchTabByIndex(int index);

	public StrategyType getStrategyTypeByIndex(int index);

	public StrategyByTabLeg saveStrategyByTabLeg(StrategyByTabLeg strategyByTabLeg);

	public StrategyTypeLeg saveStrategyTypeLeg(StrategyTypeLeg strategyTypeLeg);

	public StrategyByTab getStrategyByTabByIndex(int index);

	public StrategyTypeLeg getStrategyTypeLegByIndex(int index);

	public TcpRecoverySession saveTcpRecoverySession(TcpRecoverySession tcpRecoverySession);

	public Trader saveTrader(Trader trader);

	public Profile getProfileByIndex(int index);

	public TraderExchangeCode saveTraderExchangeCode(TraderExchangeCode traderExchangeCode);

	public UmdfChannelByEngine saveUmdfChannelByEngine(UmdfChannelByEngine umdfChannelByEngine);

	public EngineUmdfChannel getEngineUmdfChannelByIndex(int index);

	public UmdfRecoverySessionByEngine saveUmdfRecoverySessionByEngine(UmdfRecoverySessionByEngine umdfRecoverySessionByEngine);

	public TcpRecoverySession getTcpRecoverySessionByIndex(int index);
}