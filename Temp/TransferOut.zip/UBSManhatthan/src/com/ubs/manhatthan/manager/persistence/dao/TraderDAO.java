package com.ubs.manhatthan.manager.persistence.dao;

import java.util.Date;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IProfileDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.ITraderAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.ITraderDAO;
import com.ubs.manhatthan.manager.persistence.entities.Profile;
import com.ubs.manhatthan.manager.persistence.entities.Trader;
import com.ubs.manhatthan.manager.persistence.entities.audit.TraderAudit;
import com.ubs.manhatthan.manager.persistence.factory.FactoryManager;

@Repository
@Scope("singleton")
public class TraderDAO extends GenericDAO<Trader, Long> implements ITraderDAO{
	
	@Autowired
	private IProfileDAO profileDAO;
	
	@Autowired
	private ITraderAuditDAO traderAuditDAO;
	
	@Autowired
	private User user;
	
	@Override
	public Trader saveTrader( Trader trader ){
		
		ActionTypeEnum action = trader.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;

		trader = update( trader );

		TraderAudit ta = new TraderAudit( trader, action, user.getLogin(), new Date() );
		
		traderAuditDAO.update( ta );
		
		return trader;
	}
	
	public List<Trader> findAllActive( boolean isActive ){
		
		CriteriaBuilder criteriaBuilder = FactoryManager.getEntityManager().getCriteriaBuilder();

		CriteriaQuery<Trader> criteriaQuery = criteriaBuilder.createQuery(Trader.class);
		Root<Trader> traderRoot = criteriaQuery.from(Trader.class);
		criteriaQuery.where( criteriaBuilder.equal( traderRoot.get( "enable" ), isActive ) );		
		
		criteriaQuery.select( traderRoot );

		List<Trader> clientsEngineQuery = FactoryManager.getEntityManager().createQuery(criteriaQuery).getResultList();

		return clientsEngineQuery;
	}
	
	public Long generateTraders( int qtd ){
		
		Profile profile = profileDAO.getByIndex( 1 );
		
		Long qtRegs = 0L;
		
		for ( int i = 1; i<= qtd; i++ ){
			saveTrader( new Trader( "Trader_" + i, "Login_" + i , "123456", new Date(), profile, i % 2 == 0 ) );
			qtRegs++;
		}
		
		return qtRegs;
	}

	public void setProfileDAO(IProfileDAO profileDAO) {
		this.profileDAO = profileDAO;
	}

	public void setTraderAuditDAO(ITraderAuditDAO traderAuditDAO) {
		this.traderAuditDAO = traderAuditDAO;
	}

	public void setUser(User user) {
		this.user = user;
	}
}