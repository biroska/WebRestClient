package com.ubs.manhatthan.manager.lmdsadapter.marketdata.manager;

import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.BookSnapshot;
import com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities.Trade;

public interface MDSubscriberHandler {

	void onBookUpdate(String symbol, BookSnapshot book);
	
	void onTrade(String symbol, Trade trade);
	
}
