/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import com.ubs.manhatthan.manager.persistence.entities.StrategyOrders;
import com.ubs.manhatthan.manager.persistence.entities.id.StrategyOrdersPK;

/**
 * @author galdinoa
 *
 */
public interface IStrategyOrdersDAO extends IGenericDAO<StrategyOrders, StrategyOrdersPK> {

	StrategyOrders saveStrategyOrder(StrategyOrders order);

}
