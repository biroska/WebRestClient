package com.ubs.manhatthan.manager.persistence.dao.audit;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.manager.persistence.dao.GenericDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.ITcpRecoverySessionAuditDAO;
import com.ubs.manhatthan.manager.persistence.entities.audit.TcpRecoverySessionAudit;

@Repository
@Scope("singleton")
public class TcpRecoverySessionAuditDAO extends GenericDAO<TcpRecoverySessionAudit, Long> implements ITcpRecoverySessionAuditDAO {}
