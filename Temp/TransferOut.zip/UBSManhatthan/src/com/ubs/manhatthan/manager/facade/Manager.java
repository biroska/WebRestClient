package com.ubs.manhatthan.manager.facade;

import java.util.ArrayList;
import java.util.Date;
import java.util.Random;

import com.ubs.manhatthan.manager.enums.ExecutionTypeEnum;
import com.ubs.manhatthan.manager.enums.OrderStatusEnum;
import com.ubs.manhatthan.manager.enums.OrderTypeEnum;
import com.ubs.manhatthan.manager.enums.SideEnum;
import com.ubs.manhatthan.manager.enums.StrategyTypeEnum;
import com.ubs.manhatthan.manager.enums.TimeInForceEnum;
import com.ubs.manhatthan.manager.logger.ManhattanLogger;
import com.ubs.manhatthan.manager.mocks.MarketDataMock;
import com.ubs.manhatthan.manager.persistence.dao.ClientAccountDAO;
import com.ubs.manhatthan.manager.persistence.dao.OrderFixSessionDAO;
import com.ubs.manhatthan.manager.persistence.entities.ClientAccount;
import com.ubs.manhatthan.manager.persistence.entities.LegStrategyReport;
import com.ubs.manhatthan.manager.persistence.entities.OrderFixSession;
import com.ubs.manhatthan.manager.persistence.entities.StrategyOrders;
import com.ubs.manhatthan.manager.persistence.entities.StrategyReport;
import com.ubs.manhatthan.manager.utils.Util;

public class Manager {
	
	private Random random = new Random();
	private long idGenerico = Long.valueOf( String.valueOf( System.currentTimeMillis() ).substring( 6 ) );
	
	private static ClientAccountDAO clientAccountDAO = new ClientAccountDAO();
	private static OrderFixSessionDAO orderFixSessionDAO = new OrderFixSessionDAO();
	
	private OrderFixSession fixSession;
	private ClientAccount clientAccount;
//	private Client client;
	
	public Manager() {
//		client = clientDAO.getByIndex( 3 );
//		fixSession = orderFixSessionDAO.getByIndex( 3 );
//		clientAccount = clientAccountDAO.getByIndex( 3 );
	}

	public synchronized StrategyReport generateStrategyReport(Long qtdLegs, Integer qtdOrders) {
		
		StrategyReport strategy = new StrategyReport();
		strategy.setLegStrategyList( new ArrayList<LegStrategyReport>() );

//			StrategyReport fields
		strategy.getId().setStrategyId( idGenerico++ );
		strategy.getId().setEngineId( Util.getEngineId() );
		strategy.getId().setStrategyDate( new Date() );

		
		strategy.setStrategyTimestamp( new Date() );
		strategy.setLogin( "AIM*" );
		strategy.setStartTime( new Date() );
		strategy.setEndTime( new Date() );
		strategy.setStartPaused( (long) random.nextInt( 1000 ) % 2 == 0 );
		strategy.setTarget( random.nextDouble() );
		strategy.setExecutedPercentage( random.nextDouble() );
		strategy.setExecutedTarget( random.nextDouble() );
		strategy.setText( "Random Text" + random.nextGaussian() );	
		strategy.setPriceLimit( random.nextDouble() );
		strategy.setAgressiviness( random.nextDouble() );
		strategy.setRiskLevel( random.nextInt( 1000 ) );
		strategy.setStrategyType( StrategyTypeEnum.MULTILEG_SPREAD );
		
		strategy.setRestingLevel( 5 );
		
		strategy = generateStrategyLegList( strategy, qtdLegs, qtdOrders );
		
		strategy = generateStrategyOrders( strategy, qtdOrders );
		
		if ( strategy.getLegStrategyList() != null && !strategy.getLegStrategyList().isEmpty() ){
			ManhattanLogger.devLog("", "====================================================================================================");
			ManhattanLogger.devLog("", "\t\t\t\t\t\t\t\t\t\t" + strategy.getId().getStrategyId() + " Size: " + strategy.getLegStrategyList().size() );
			ManhattanLogger.devLog("", "\t\t" + strategy.getLegStrategyList().get(0).getId().getLegSeq() + " ----------" +  strategy.getLegStrategyList().get(0).getInstrument());
			ManhattanLogger.devLog("", "\t\t" + strategy.getLegStrategyList().get(1).getId().getLegSeq() + " ----------" +  strategy.getLegStrategyList().get(1).getInstrument());
			ManhattanLogger.devLog("", "====================================================================================================");
		}
		
		return strategy;
	}
	
	public StrategyReport generateStrategyLegList(StrategyReport strategy, Long qtdLegs, Integer qtdOrders) {
		
		// LegStrategyReport fields
		for (int i = 1; i <= qtdLegs; i++) {
			strategy = generateStrategyLeg(strategy, i, qtdOrders);
		}
		return strategy;
	}

	public StrategyReport generateStrategyLeg( StrategyReport strategy, Integer legSeq, Integer qtdOrders) {
		
		fixSession = orderFixSessionDAO.getByIndex( 3 );
		clientAccount = clientAccountDAO.getByIndex( 3 );

		LegStrategyReport leg = new LegStrategyReport();
		
		leg.getId().setLegSeq( legSeq -1);
		leg.getId().setStrategyId( strategy.getId().getStrategyId() );
		leg.getId().setEngineId( strategy.getId().getEngineId() );
		leg.getId().setStrategyDate( strategy.getId().getStrategyDate() );
		
		leg.setInstrument( (long) MarketDataMock.getInstrumentByIndex( leg.getId().getLegSeq() % 4 ) );
		leg.setTotalQuantity( 10L );
		
		leg.setExecutedPercentage( random.nextDouble() );
		leg.setRemainingQuantity( 0L );
		leg.setExecutedQuantity( 0L );
		leg.setAveragePrice( random.nextDouble() );
		leg.setText( "Random Text" + random.nextGaussian() );
		leg.setSide( SideEnum.fromValue( ( leg.getId().getLegSeq() ) % 2 +1 ) );
		leg.setRouteId( fixSession );
		leg.setOrderType( OrderTypeEnum.LIMIT );
		leg.setTimeInForce( TimeInForceEnum.DAY );
		leg.setAccount( clientAccount );
		leg.setPassiveLeg( legSeq % 2 == 0 );
		leg.setMaxQuantityDisplay( Long.valueOf( 5 * ( random.nextInt( 1000 ) +1) ) );
		leg.setMinQuantityDisplay( 0L );
		leg.setRestingQuantity(  0L  );
		leg.setRestingPrice( random.nextDouble() );
		leg.setRestingRank( 0L );
		leg.setTimeOut( 0L );
		leg.setInvestorId( "Investor Id" );
		leg.setEnteringTrader( "eTrader" );
		
		leg.setDuration( (leg.getId().getLegSeq() +1) * 121 );
		
//			Seta o relacionamento entre as entidades
		strategy.addLegStrategyReport( leg );
		
		return strategy;
	}

	public StrategyReport generateStrategyOrders(StrategyReport strategy, Integer qtdOrders) {

		if (strategy != null && strategy.getLegStrategyList() != null) {
			
//			client = clientDAO.getByIndex( 3 );
			fixSession = orderFixSessionDAO.getByIndex( 3 );
			clientAccount = clientAccountDAO.getByIndex( 3 );

			for (LegStrategyReport leg : strategy.getLegStrategyList()) {

				for (int i = 1; i <= qtdOrders; i++) {
					StrategyOrders order = new StrategyOrders();
					
					order.getId().setEngineId( leg.getId().getEngineId() );
					order.getId().setOrderDate( leg.getId().getStrategyDate() );
					order.getId().setOrderId( idGenerico );
					
					order.setLegSeq( leg.getId().getLegSeq() );
					order.setStrategyId( leg.getId().getStrategyId() );
					order.setStrategyDate( leg.getId().getStrategyDate() );

					order.setOrderTimestamp( new Date() );
					order.setLegStrategyReport( leg );
					order.setExecutedQuantity(0L );
					order.setAveragePrice( random.nextDouble() );
					order.setSide( SideEnum.SELL ); // N�o pode ser Injetado pelo
													// m�todo add da Leg, tem
													// que gravar o que vier
					order.setRemainingQuantity( 0L );
					order.setRouteId( fixSession ); // N�o pode ser Injetado pelo
													// m�todo add da Leg, tem
													// que gravar o que vier
					order.setOrderType( OrderTypeEnum.LIMIT );
					order.setTimeInForce( TimeInForceEnum.DAY );
					order.setAccount( clientAccount ); // N�o pode ser Injetado
														// pelo m�todo add da
														// Leg, tem que gravar o
														// que vier
//					order.setClient( client );
					order.setOrderStatus(OrderStatusEnum.NEW);
					order.setExecutionType(ExecutionTypeEnum.NEW);
					order.setPrice(random.nextDouble());
					
					order.setQuantity( Long.valueOf( 5 * ( random.nextInt( 1000 ) +1 ) ) );
					order.setSymbol( MarketDataMock.getSymbolByIndex( i % 4 ) );

					// fixSessions.addStrategyOrder( order );
					leg.addStrategyOrder(order);

					idGenerico++;
				}
			}
		}
		
		return strategy;
	}
	
	public StrategyOrders generateNewOrder(LegStrategyReport leg, StrategyOrders order) {

		if (leg != null ) {
			
//			client = clientDAO.getByIndex( 3 );
			fixSession = orderFixSessionDAO.getByIndex( 3 );
			clientAccount = clientAccountDAO.getByIndex( 3 );

			order.setOrderTimestamp( new Date() );
			order.setLegStrategyReport( leg );
			order.setExecutedQuantity( 0L );
			order.setAveragePrice( random.nextDouble() );
			order.setSide( SideEnum.SELL ); // N�o pode ser Injetado pelo
											// m�todo add da Leg, tem
											// que gravar o que vier
			order.getId().setOrderId( idGenerico );
			order.setRemainingQuantity( 0L );
			order.setRouteId( fixSession ); // N�o pode ser Injetado pelo
											// m�todo add da Leg, tem
											// que gravar o que vier
			order.setOrderType( OrderTypeEnum.LIMIT );
			order.setTimeInForce( TimeInForceEnum.DAY );
			order.setAccount( clientAccount ); // N�o pode ser Injetado
												// pelo m�todo add da
												// Leg, tem que gravar o
												// que vier
//					order.setClient( client );
			order.setOrderStatus(OrderStatusEnum.NEW);
			order.setExecutionType(ExecutionTypeEnum.NEW);
			order.setPrice(random.nextDouble());
			
			order.setQuantity( Long.valueOf( 5 * ( random.nextInt(10) +1 ) ) );
			order.setSymbol( MarketDataMock.getSymbolByIndex( 0 ) );

			// fixSessions.addStrategyOrder( order );
			leg.addStrategyOrder(order);

			idGenerico++;
		}
		
		return order;
	}
	
	
}