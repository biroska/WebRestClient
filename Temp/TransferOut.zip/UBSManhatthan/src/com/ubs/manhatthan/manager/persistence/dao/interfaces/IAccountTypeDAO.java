/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import com.ubs.manhatthan.manager.persistence.entities.AccountType;

/**
 * @author galdinoa
 *
 */
public interface IAccountTypeDAO extends IGenericDAO<AccountType, Long> {
	
	public AccountType saveAccountType( AccountType accountType );

}
