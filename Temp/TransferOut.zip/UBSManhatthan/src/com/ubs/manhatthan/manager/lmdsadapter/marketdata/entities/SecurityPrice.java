package com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities;

import java.math.BigDecimal;

/**
 * Prices for a given instrument.
 * 
 * 
 * @author pretof
 *
 */
public interface SecurityPrice {
	
	/**
	 * 
	 * @return
	 */
	BigDecimal getClosingPrice();
	
	BigDecimal getOpeningPrice();

}
