package com.ubs.manhatthan.manager.persistence.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.admin.model.User;
import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IExchangeAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IExchangeDAO;
import com.ubs.manhatthan.manager.persistence.entities.Exchange;
import com.ubs.manhatthan.manager.persistence.entities.audit.ExchangeAudit;

@Repository
@Scope("singleton")
public class ExchangeDAO extends GenericDAO<Exchange, Long> implements IExchangeDAO {
	
	@Autowired
	private IExchangeAuditDAO exchangeAuditDAO;
	
	@Autowired
	private User user;
	
	@Override
	public Exchange saveExchange( Exchange exchange ){
		
		ActionTypeEnum action = exchange.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;
		
		exchange = update( exchange );
		
		ExchangeAudit pa = new ExchangeAudit( exchange, action, user.getLogin(), new Date() );
		
		exchangeAuditDAO.update( pa );
		
		return exchange;
	}
	
	@Override
	public List<Exchange> findExchange( Exchange exchange ){
		
		List<Exchange> returnList = null;
		
		if ( exchange != null ){
			
			if ( exchange.getId() != null ){
				exchange = findById( exchange.getId() );

				if (exchange != null ){
					returnList = new ArrayList<Exchange>();
					returnList.add(exchange);
				}
			} else {
				returnList = findByExample( exchange );
			}
		} 
		
		return returnList;
	}
	
	public Long generateExchange(){
		
		update( new Exchange( "BVSP", "IBOVESPA")  );
		update(new Exchange( "BMF", "Bolsa de Mercadorias e Futuros") );
		
		return 2L;
	}
	
	public void setExchangeAuditDAO(IExchangeAuditDAO exchangeAuditDAO) {
		this.exchangeAuditDAO = exchangeAuditDAO;
	}

	public void setUser(User user) {
		this.user = user;
	}
}