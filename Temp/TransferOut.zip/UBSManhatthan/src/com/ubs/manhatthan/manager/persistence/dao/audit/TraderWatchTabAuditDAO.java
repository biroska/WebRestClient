package com.ubs.manhatthan.manager.persistence.dao.audit;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.manager.persistence.dao.GenericDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.ITraderWatchTabAuditDAO;
import com.ubs.manhatthan.manager.persistence.entities.audit.TraderWatchTabAudit;

@Repository
@Scope("singleton")
public class TraderWatchTabAuditDAO extends GenericDAO<TraderWatchTabAudit, Long> implements ITraderWatchTabAuditDAO {}
