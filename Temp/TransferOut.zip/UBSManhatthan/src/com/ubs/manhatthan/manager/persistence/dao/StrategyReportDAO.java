package com.ubs.manhatthan.manager.persistence.dao;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.ubs.manhatthan.manager.persistence.dao.interfaces.IStrategyReportAuditDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IStrategyReportDAO;
import com.ubs.manhatthan.manager.persistence.entities.StrategyOrders;
import com.ubs.manhatthan.manager.persistence.entities.StrategyReport;
import com.ubs.manhatthan.manager.persistence.entities.id.StrategyReportPK;

@Repository
@Scope("singleton")
public class StrategyReportDAO extends GenericDAO<StrategyReport, StrategyReportPK> implements IStrategyReportDAO {
	
	public StrategyReportDAO() {}
	
	@Autowired
	private IStrategyReportAuditDAO strategyReportAuditDAO;
	
	@Override
	public StrategyReport saveReport( StrategyReport report ){
		
		report.setStrategyTimestamp( new Date() );
		
//		Salva o strategy report, legs e orders
		report = update( report );

//		Gera registro na tabela de auditoria - Strategyreport
		strategyReportAuditDAO.saveReportAudit( report );
		
		return report;
	}
	
	public StrategyOrders saveReport( StrategyOrders order ){
		
		return order;
	}
}