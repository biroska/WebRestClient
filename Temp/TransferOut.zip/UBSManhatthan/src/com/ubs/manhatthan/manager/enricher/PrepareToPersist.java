package com.ubs.manhatthan.manager.enricher;

import java.util.Date;

import javax.persistence.EntityTransaction;

import org.apache.log4j.Level;

import com.ubs.manhatthan.manager.cache.CacheHelper;
import com.ubs.manhatthan.manager.converters.ConverterToEntity;
import com.ubs.manhatthan.manager.enums.ExecutionTypeEnum;
import com.ubs.manhatthan.manager.facade.Facade;
import com.ubs.manhatthan.manager.facade.FacadeImpl;
import com.ubs.manhatthan.manager.logger.ManhattanLogger;
import com.ubs.manhatthan.manager.persistence.entities.LegStrategyReport;
import com.ubs.manhatthan.manager.persistence.entities.OrderFixSession;
import com.ubs.manhatthan.manager.persistence.entities.OrderTrade;
import com.ubs.manhatthan.manager.persistence.entities.StrategyOrders;
import com.ubs.manhatthan.manager.persistence.entities.StrategyReport;
import com.ubs.manhatthan.manager.persistence.factory.FactoryManager;
import com.ubs.manhatthan.manager.utils.Util;

public class PrepareToPersist {
	
	Facade facade = new FacadeImpl();
	
	public StrategyReport saveReport(StrategyReport report) {
		
		EntityTransaction transaction = FactoryManager.getEntityManager().getTransaction();
		
		try{
			transaction.begin();
	
			report = facade.saveReport( report );
			
			transaction.commit();
		
		} catch (Exception e){
			e.printStackTrace();
			
			ManhattanLogger.log( ""+Util.getManagerId(), e.toString(), Level.ERROR, e );
			e.printStackTrace();
			if ( transaction.isActive() ) {
				transaction.rollback();
			}
		} finally {
		
			System.out.println("finally " + new Date() );
			FactoryManager.closeEntityManagerFactory();
		}
		
		return report;
	}

	public StrategyOrders saveOrder(StrategyOrders order ) {
		
		EntityTransaction transaction = FactoryManager.getEntityManager().getTransaction();
		
		try {
			transaction.begin();
			StrategyReport strategyReport = CacheHelper.strategyReportMap.get( order.getLegStrategyReport().getId().getStrategyId() );
			
			Integer legSeq = order.getLegStrategyReport().getId().getLegSeq();
			LegStrategyReport legStrategyReport = strategyReport.getLegStrategyList().get( legSeq -1 );
			OrderFixSession route = legStrategyReport.getRouteId();
			
			order.setOrderTimestamp( new Date() );
			order.setRouteId( route );
			order.setOrderType( legStrategyReport.getOrderType() );
			order.setTimeInForce( legStrategyReport.getTimeInForce() );
			order.setAccount( legStrategyReport.getAccount() );
			
			System.out.println( "\n\n\n\n\n" + order );
			
			order = facade.saveOrder( order );
			
			FactoryManager.getEntityManager().flush();
			
	//		If Execution type == TRADE ( 70 or F ) build the OrderTrade entity
			if ( ExecutionTypeEnum.TRADE.getCode().equals( order.getExecutionType().getCode() ) ){
				OrderTrade orderTrade = ConverterToEntity.convertToOrderTrade( order );
				
				facade.saveOrderTrade( orderTrade );
			} 
			
			transaction.commit();
		} catch (Exception e){
			e.printStackTrace();
			
			ManhattanLogger.log( ""+Util.getManagerId(), e.toString(), Level.ERROR, e );
			e.printStackTrace();
			if ( transaction.isActive() ) {
				transaction.rollback();
			}
		} finally {
		
			System.out.println("finally " + new Date() );
			FactoryManager.closeEntityManagerFactory();
		}
		
		return order;
	}
}