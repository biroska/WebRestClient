/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import com.ubs.manhatthan.manager.persistence.entities.TraderWatchTab;

/**
 * @author galdinoa
 *
 */
public interface ITraderWatchTabDAO extends IGenericDAO<TraderWatchTab, Long> {

	TraderWatchTab saveTraderWatchTab(TraderWatchTab traderWatchTab);
}
