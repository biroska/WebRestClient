/**
 * 
 */
package com.ubs.manhatthan.manager.facade;

import com.ubs.manhatthan.manager.dto.ReceiveSynthetic;
import com.ubs.manhatthan.manager.persistence.entities.Message;
import com.ubs.manhatthan.manager.simulator.multileg.InputMultilegSimulation;
import com.ubs.manhatthan.manager.simulator.multileg.ReturnMultilegSimulation;

public interface FacadeService {
	
	public void initializeServices();
	
	public ReturnMultilegSimulation calculate( InputMultilegSimulation input );
	
	public boolean sendToEngine( Message obj );
	
	public boolean subscribe( ReceiveSynthetic synthetic );

}
