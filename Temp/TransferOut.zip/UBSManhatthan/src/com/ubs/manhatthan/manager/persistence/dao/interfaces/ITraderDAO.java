/**
 * 
 */
package com.ubs.manhatthan.manager.persistence.dao.interfaces;

import com.ubs.manhatthan.manager.persistence.entities.Trader;

/**
 * @author galdinoa
 *
 */
public interface ITraderDAO extends IGenericDAO<Trader, Long> {

	Trader saveTrader(Trader trader);}
