package com.ubs.manhatthan.manager.persistence.entities.audit;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.ubs.manhatthan.manager.enums.ActionTypeEnum;
import com.ubs.manhatthan.manager.persistence.entities.Trader;

@Entity
@Table(name="TB_AUDIT_TRADERS")
public class TraderAudit {
	
	public TraderAudit() {
		super();
	}

	public TraderAudit(Trader trader, ActionTypeEnum action, String user, Date registryDate) {
		this.action = action;
		this.user = user;
		this.registryDate = registryDate;
		
		this.origId = trader.getId();
		this.username = trader.getUsername();
		this.login = trader.getLogin();
		this.profile = trader.getProfile().getId();
		this.password = trader.getPassword();
		this.passwordLastModification = trader.getPasswordLastModification();
		this.enable = trader.isEnable();
	}
	
	@Id
	@Column ( name = "ID")
	@SequenceGenerator(name = "TB_AUDIT_TRADERS_ID_GENERATOR", sequenceName = "SEQ_AUDIT_TRADERS", allocationSize = 1)
	@GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "TB_AUDIT_TRADERS_ID_GENERATOR" )
	private Long id;
	
	@Enumerated(EnumType.STRING)
	@Column( name = "ACTION", nullable=false )
	private ActionTypeEnum action;
	
	@Column( name = "REGISTRY_USER", nullable=false )
	private String user;
	
	@Column( name = "REGISTRY_DATE", nullable=false )
	private Date registryDate;

	@Column ( name = "ORIG_ID", nullable=false )
	private Long origId;
	
	@Column ( name = "NAME", nullable=false, length = 64 )
	private String username;
	
	@Column ( name = "LOGIN", nullable=false, length = 64 )
	private String login;
	
	@Column ( name = "PASSWORD", nullable=false, length = 256 )
	private String password;
	
	@Temporal ( TemporalType.TIMESTAMP )
	@Column ( name = "PASSWORD_LAST_MODIFICATION" )
	private Date passwordLastModification;
	
	@Column ( name = "PROFILE", nullable=false )
	private Long profile;
	
	@Column ( name = "ENABLED", nullable=false )
	private boolean enable;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public ActionTypeEnum getAction() {
		return action;
	}

	public void setAction(ActionTypeEnum action) {
		this.action = action;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public Date getRegistryDate() {
		return registryDate;
	}

	public void setRegistryDate(Date registryDate) {
		this.registryDate = registryDate;
	}

	public Long getOrigId() {
		return origId;
	}

	public void setOrigId(Long origId) {
		this.origId = origId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public Date getPasswordLastModification() {
		return passwordLastModification;
	}

	public void setPasswordLastModification(Date passwordLastModification) {
		this.passwordLastModification = passwordLastModification;
	}

	public Long getProfile() {
		return profile;
	}

	public void setProfile(Long profile) {
		this.profile = profile;
	}

	public boolean isEnable() {
		return enable;
	}

	public void setEnable(boolean enable) {
		this.enable = enable;
	}
	
	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((action == null) ? 0 : action.hashCode());
		result = prime * result + ((origId == null) ? 0 : origId.hashCode());
		result = prime * result
				+ ((registryDate == null) ? 0 : registryDate.hashCode());
		result = prime * result + ((user == null) ? 0 : user.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TraderAudit other = (TraderAudit) obj;
		if (action != other.action)
			return false;
		if (origId == null) {
			if (other.origId != null)
				return false;
		} else if (!origId.equals(other.origId))
			return false;
		if (registryDate == null) {
			if (other.registryDate != null)
				return false;
		} else if (!registryDate.equals(other.registryDate))
			return false;
		if (user == null) {
			if (other.user != null)
				return false;
		} else if (!user.equals(other.user))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "TraderAudit [id=" + id + ", action=" + action + ", user="
				+ user + ", registryDate=" + registryDate + ", origId="
				+ origId + ", username=" + username + ", password=" + password
				+ ", passwordLastModification=" + passwordLastModification
				+ ", profile=" + profile + ", enable=" + enable + "]";
	}
}