package com.ubs.manhatthan.manager.facade;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ubs.manhatthan.manager.persistence.dao.interfaces.IAccountTypeDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IClientAccountDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IEngineInstanceDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IEngineUmdfChannelDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IExchangeDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.ILegStrategyReportDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IOrderFixSessionDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IOrderTradeDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IPasswordParameterDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IProfileDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IRoleByProfileDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IRoleDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.ISessionByAccountDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.ISessionByEngineDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IStrategyByTabDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IStrategyByTabLegDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IStrategyOrdersDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IStrategyReportDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IStrategyTypeDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IStrategyTypeLegDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.ITcpRecoverySessionDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.ITraderDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.ITraderExchangeCodeDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.ITraderWatchTabDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IUmdfChannelByEngineDAO;
import com.ubs.manhatthan.manager.persistence.dao.interfaces.IUmdfRecoverySessionByEngineDAO;
import com.ubs.manhatthan.manager.persistence.entities.AccountType;
import com.ubs.manhatthan.manager.persistence.entities.ClientAccount;
import com.ubs.manhatthan.manager.persistence.entities.EngineInstance;
import com.ubs.manhatthan.manager.persistence.entities.EngineUmdfChannel;
import com.ubs.manhatthan.manager.persistence.entities.Exchange;
import com.ubs.manhatthan.manager.persistence.entities.LegStrategyReport;
import com.ubs.manhatthan.manager.persistence.entities.OrderFixSession;
import com.ubs.manhatthan.manager.persistence.entities.OrderTrade;
import com.ubs.manhatthan.manager.persistence.entities.PasswordParameter;
import com.ubs.manhatthan.manager.persistence.entities.Profile;
import com.ubs.manhatthan.manager.persistence.entities.Role;
import com.ubs.manhatthan.manager.persistence.entities.RoleByProfile;
import com.ubs.manhatthan.manager.persistence.entities.SessionByAccount;
import com.ubs.manhatthan.manager.persistence.entities.SessionByEngine;
import com.ubs.manhatthan.manager.persistence.entities.StrategyByTab;
import com.ubs.manhatthan.manager.persistence.entities.StrategyByTabLeg;
import com.ubs.manhatthan.manager.persistence.entities.StrategyOrders;
import com.ubs.manhatthan.manager.persistence.entities.StrategyReport;
import com.ubs.manhatthan.manager.persistence.entities.StrategyType;
import com.ubs.manhatthan.manager.persistence.entities.StrategyTypeLeg;
import com.ubs.manhatthan.manager.persistence.entities.TcpRecoverySession;
import com.ubs.manhatthan.manager.persistence.entities.Trader;
import com.ubs.manhatthan.manager.persistence.entities.TraderExchangeCode;
import com.ubs.manhatthan.manager.persistence.entities.TraderWatchTab;
import com.ubs.manhatthan.manager.persistence.entities.UmdfChannelByEngine;
import com.ubs.manhatthan.manager.persistence.entities.UmdfRecoverySessionByEngine;
import com.ubs.manhatthan.manager.persistence.entities.id.LegStrategyReportPK;
import com.ubs.manhatthan.manager.persistence.functions.IDataBaseFunctions;
import com.ubs.manhatthan.manager.utils.Util;

@Service
@Scope("singleton")
@Transactional
public class FacadeImpl implements Facade {
	
	private Manager manager;
	
	@Autowired
	private IRoleDAO roleDAO;
	
	@Autowired
	private IAccountTypeDAO accountTypeDAO;
	
	@Autowired
	private IEngineInstanceDAO engineInstanceDAO;
	
	@Autowired
	private IEngineUmdfChannelDAO engineUmdfChannelDAO;
	
	@Autowired
	private IExchangeDAO exchangeDAO;
	
	@Autowired
	private IOrderFixSessionDAO orderFixSessionDAO;
	
	@Autowired
	private IPasswordParameterDAO passwordParameterDAO;
	
	@Autowired
	private IProfileDAO profileDAO;
	
	@Autowired
	private IRoleByProfileDAO roleByProfileDAO;
	
	@Autowired
	private ISessionByAccountDAO sessionByAccountDAO;
	
	@Autowired
	private IClientAccountDAO clientAccountDAO;
	
	@Autowired
	private ISessionByEngineDAO sessionByEngineDAO;
	
	@Autowired
	private IStrategyByTabDAO strategyByTabDAO;
	
	@Autowired
	private ITraderWatchTabDAO traderWatchTabDAO;
	
	@Autowired
	private IStrategyTypeDAO strategyTypeDAO;
	
	@Autowired
	private IStrategyByTabLegDAO strategyByTabLegDAO;
	
	@Autowired
	private IStrategyTypeLegDAO strategyTypeLegDAO;
	
	@Autowired
	private ITcpRecoverySessionDAO tcpRecoverySessionDAO;
	
	@Autowired
	private ITraderDAO traderDAO;
	
	@Autowired
	private IUmdfChannelByEngineDAO umdfChannelByEngineDAO;
	
	@Autowired
	private ITraderExchangeCodeDAO traderExchangeCodeDAO;
	
	@Autowired
	private IUmdfRecoverySessionByEngineDAO umdfRecoverySessionByEngineDAO;
	
	@Autowired
	private IStrategyReportDAO strategyReportDAO;
	
	@Autowired
	private ILegStrategyReportDAO legStrategyReportDAO;
	
	@Autowired
	private IStrategyOrdersDAO strategyOrderDAO;
	
	@Autowired
	private IOrderTradeDAO orderTradeDAO;

	@Autowired
	private IDataBaseFunctions dataBaseFunctions;
	
	public StrategyReport generateStrategyReport(Long qtdLegs, Integer qtdOrders) {

		manager = new Manager();
		
		StrategyReport strategy = manager.generateStrategyReport(qtdLegs, qtdOrders);
		strategy = strategyReportDAO.save( strategy );
		
		return strategy;
	}

	@Override
	public StrategyReport saveReport(StrategyReport report) throws Exception {

		report = strategyReportDAO.saveReport( report );
		
		return report;
	}

	@Override
	public StrategyOrders saveOrder(StrategyOrders order ) throws Exception {

		order = strategyOrderDAO.saveStrategyOrder( order );
		
		return order;
	}

	@Override
	public OrderTrade saveOrderTrade(OrderTrade orderTrade) throws Exception {
		
		orderTrade = orderTradeDAO.saveOrderTrade( orderTrade );

		return orderTrade;
	}

	@Override
	public LegStrategyReport getLegStrategyByID(Integer legSeq, Long strategyReportId) 
			throws Exception {
		
		LegStrategyReport leg = null;
		
		if ( legSeq != null && legSeq >= 0 &&
			 strategyReportId != null && strategyReportId > 0 ){

			LegStrategyReportPK legStrategyReportPK = new LegStrategyReportPK( Util.getEngineId(), strategyReportId, legSeq, new Date() );
			
			leg = legStrategyReportDAO.findById( legStrategyReportPK );
		}
		
		return leg;
	}

	/* (non-Javadoc)
	 * @see com.ubs.manhattan.facade.Facade#getLegStrategyByReport(java.lang.Long)
	 */
	@Override
	public List<LegStrategyReport> getLegStrategyByReportId(Long strategyReportId) throws Exception {

		return legStrategyReportDAO.findByStrategyId( strategyReportId );
	}
	
	public StrategyReport findStrategyReportById( StrategyReport report ){
		
		if ( report != null && report.getId() != null ){
			report = strategyReportDAO.findById( report.getId() );
		}
		
		return report;
	}
	
	public StrategyOrders findStrategyOrderById( StrategyOrders order ){
		
		if ( order != null && order.getId() != null && order.getId().getOrderId() != null )
			order = strategyOrderDAO.findById( order.getId() );
		
		return order;
	}

	@Override
	public Integer businessDayTotal(Date beginningDt, Date endingDt) {

		if ( beginningDt == null || endingDt == null )
			return null;
		
		return dataBaseFunctions.businessDayTotal(beginningDt, endingDt);
	}

	@Override
	public Integer businessDayTotal2(Date beginningDt, Date endingDt) {
		
		if ( beginningDt == null || endingDt == null )
			return null;
		
		return dataBaseFunctions.businessDayTotal2(beginningDt, endingDt);
	}
	
	@Override
	public Role saveRole( Role role ){
		Role saveRole = roleDAO.saveRole( role );
		return saveRole;
		
	}
	
	@Override
	public AccountType saveAccountType( AccountType accountType ){
		AccountType saveAccountType = accountTypeDAO.saveAccountType( accountType );
		return saveAccountType;
	}
	
	@Override
	public EngineInstance saveEngineInstance(EngineInstance engine) throws Exception {

		if ( engine != null )
			engine = engineInstanceDAO.saveEngineInstance( engine );
			
		return engine;
	}
	
	@Override
	public EngineUmdfChannel saveEngineUmdfChannel( EngineUmdfChannel engineUmdfChannel ){
		
		if ( engineUmdfChannel != null )
			engineUmdfChannel = engineUmdfChannelDAO.saveEngineUmdfChannel( engineUmdfChannel );
		
		return engineUmdfChannel;
	}
	
	@Override
	public Exchange saveExchange( Exchange exchange ){
		if ( exchange != null )
			exchange = exchangeDAO.saveExchange( exchange );
		
		return exchange;
	}
	
	@Override
	public List<Exchange> findExchange( Exchange exchange ){
		List<Exchange> findExchange = null;
		if ( exchange != null ){
			findExchange = exchangeDAO.findExchange(exchange);
		} 
		return findExchange;
	}
	
	@Override
	public OrderFixSession saveOrderFixSession( OrderFixSession orderFixSession ){
		if ( orderFixSession != null )
			orderFixSession = orderFixSessionDAO.saveOrderFixSession( orderFixSession );
		
		return orderFixSession;
	}
	
	@Override
	public PasswordParameter savePasswordParameter( PasswordParameter passwordParameter ){
		if ( passwordParameter != null )
			passwordParameter = passwordParameterDAO.savePasswordParameter( passwordParameter );
		
		return passwordParameter;
	}
	
	@Override
	public Profile saveProfile( Profile profile ){
		if ( profile != null )
			profile = profileDAO.saveProfile( profile );
		
		return profile;
	}
	
	@Override
	public RoleByProfile saveRoleByProfile( RoleByProfile role ){
		if ( role != null )
			role = roleByProfileDAO.saveRoleByProfile( role );
		
		return role;
	}
	
	@Override
	public List<Role> findRole( Role role ){
		
		List<Role> findRole = null;
		
		if ( role != null ){
			findRole = roleDAO.findRole( role );
		}
		
		return findRole;
	}
	
	@Override
	public List<Profile> findProfile( Profile profile ){
		
		List<Profile> findProfile = null;
		
		if ( profile != null ){
			findProfile = profileDAO.findProfile( profile );
		}
		
		return findProfile;
	}
	
	@Override
	public SessionByAccount saveOrderFixSession( SessionByAccount sessionByAccount ){
		if ( sessionByAccount != null )
			sessionByAccount = sessionByAccountDAO.saveOrderFixSession( sessionByAccount );
		
		return sessionByAccount;
	}
	
	@Override
	public SessionByEngine saveSessionByEngine( SessionByEngine sessionByEngine ){
		if ( sessionByEngine != null )
			sessionByEngine = sessionByEngineDAO.saveSessionByEngine( sessionByEngine );
		
		return sessionByEngine;
	}
	
	@Override
	public TraderWatchTab saveTraderWatchTab( TraderWatchTab traderWatchTab ){
		if ( traderWatchTab != null )
			traderWatchTab = traderWatchTabDAO.saveTraderWatchTab( traderWatchTab );
		
		return traderWatchTab;
	}
	
	@Override
	public StrategyType saveStrategyType( StrategyType strategyType ){
		if ( strategyType != null )
			strategyType = strategyTypeDAO.saveStrategyType( strategyType );
		
		return strategyType;
	}
	
	@Override
	public StrategyByTab saveStrategyByTab( StrategyByTab strategyByTab ){
		if ( strategyByTab != null )
			strategyByTab = strategyByTabDAO.saveStrategyByTab( strategyByTab );
		
		return strategyByTab;
	}
	
	@Override
	public StrategyByTabLeg saveStrategyByTabLeg( StrategyByTabLeg strategyByTabLeg ){
		if ( strategyByTabLeg != null )
			strategyByTabLeg = strategyByTabLegDAO.saveStrategyByTabLeg( strategyByTabLeg );
		
		return strategyByTabLeg;
	}
	
	@Override
	public StrategyTypeLeg saveStrategyTypeLeg( StrategyTypeLeg strategyTypeLeg ){
		if ( strategyTypeLeg != null )
			strategyTypeLeg = strategyTypeLegDAO.saveStrategyTypeLeg( strategyTypeLeg );
		
		return strategyTypeLeg;
	}
	
	@Override
	public TcpRecoverySession saveTcpRecoverySession( TcpRecoverySession tcpRecoverySession ){
		if ( tcpRecoverySession != null )
			tcpRecoverySession = tcpRecoverySessionDAO.saveTcpRecoverySession( tcpRecoverySession );
		
		return tcpRecoverySession;
	}
	
	@Override
	public Trader saveTrader( Trader trader ){
		if ( trader != null )
			trader = traderDAO.saveTrader( trader );
		
		return trader;
	}
	
	@Override
	public TraderExchangeCode saveTraderExchangeCode( TraderExchangeCode traderExchangeCode ){
		if ( traderExchangeCode != null )
			traderExchangeCode = traderExchangeCodeDAO.saveTraderExchangeCode( traderExchangeCode );
		
		return traderExchangeCode;
	}
	
	@Override
	public UmdfChannelByEngine saveUmdfChannelByEngine( UmdfChannelByEngine umdfChannelByEngine ){
		if ( umdfChannelByEngine != null )
			umdfChannelByEngine = umdfChannelByEngineDAO.saveUmdfChannelByEngine( umdfChannelByEngine );
		
		return umdfChannelByEngine;
	}
	
	@Override
	public UmdfRecoverySessionByEngine saveUmdfRecoverySessionByEngine( UmdfRecoverySessionByEngine umdfRecoverySessionByEngine ){
		if ( umdfRecoverySessionByEngine != null )
			umdfRecoverySessionByEngine = umdfRecoverySessionByEngineDAO.saveUmdfRecoverySessionByEngine( umdfRecoverySessionByEngine );
		
		return umdfRecoverySessionByEngine;
	}
	
	@Override
	public ClientAccount getClientAccountByIndex( int index ) {
		return clientAccountDAO.getByIndex( index );
	}

	@Override
	public Exchange getExchangeByIndex( int index ) {
		return exchangeDAO.getByIndex( index );
	}
	
	@Override
	public EngineInstance getEngineInstanceByIndex( int index ) {
		return engineInstanceDAO.getByIndex( index );
	}

	@Override
	public OrderFixSession getOrderFixSessionByIndex(int index) {
		return orderFixSessionDAO.getByIndex( index );
	}
	
	@Override
	public TraderWatchTab getTraderWatchTabByIndex(int index) {
		return traderWatchTabDAO.getByIndex( index );
	}
	
	@Override
	public StrategyType getStrategyTypeByIndex(int index) {
		return strategyTypeDAO.getByIndex( index );
	}
	
	@Override
	public StrategyByTab getStrategyByTabByIndex(int index) {
		return strategyByTabDAO.getByIndex( index );
	}
	
	@Override
	public StrategyTypeLeg getStrategyTypeLegByIndex(int index) {
		return strategyTypeLegDAO.getByIndex( index );
	}
	
	@Override
	public Profile getProfileByIndex(int index) {
		return profileDAO.getByIndex( index );
	}
	
	@Override
	public EngineUmdfChannel getEngineUmdfChannelByIndex(int index) {
		return engineUmdfChannelDAO.getByIndex( index );
	}
	
	@Override
	public TcpRecoverySession getTcpRecoverySessionByIndex(int index) {
		return tcpRecoverySessionDAO.getByIndex( index );
	}
	
	public void setRoleDAO(IRoleDAO roleDAO) {
		this.roleDAO = roleDAO;
	}

	public void setAccountTypeDAO(IAccountTypeDAO accountTypeDAO) {
		this.accountTypeDAO = accountTypeDAO;
	}

	public void setEngineInstanceDAO(IEngineInstanceDAO engineInstanceDAO) {
		this.engineInstanceDAO = engineInstanceDAO;
	}

	public void setExchangeDAO(IExchangeDAO exchangeDAO) {
		this.exchangeDAO = exchangeDAO;
	}

	public void setOrderFixSessionDAO(IOrderFixSessionDAO orderFixSessionDAO) {
		this.orderFixSessionDAO = orderFixSessionDAO;
	}

	public void setPasswordParameterDAO(IPasswordParameterDAO passwordParameterDAO) {
		this.passwordParameterDAO = passwordParameterDAO;
	}

	public IProfileDAO getProfileDAO() {
		return profileDAO;
	}

	public void setProfileDAO(IProfileDAO profileDAO) {
		this.profileDAO = profileDAO;
	}

	public void setRoleByProfile(IRoleByProfileDAO roleByProfileDAO) {
		this.roleByProfileDAO = roleByProfileDAO;
	}

	public void setSessionByAccountDAO(ISessionByAccountDAO sessionByAccountDAO) {
		this.sessionByAccountDAO = sessionByAccountDAO;
	}

	public IClientAccountDAO getClientAccountDAO() {
		return clientAccountDAO;
	}

	public void setClientAccountDAO(IClientAccountDAO clientAccountDAO) {
		this.clientAccountDAO = clientAccountDAO;
	}

	public void setSessionByEngineDAO(ISessionByEngineDAO sessionByEngineDAO) {
		this.sessionByEngineDAO = sessionByEngineDAO;
	}

	public void setStrategyByTabDAO(IStrategyByTabDAO strategyByTabDAO) {
		this.strategyByTabDAO = strategyByTabDAO;
	}

	public void setTraderWatchTabDAO(ITraderWatchTabDAO traderWatchTabDAO) {
		this.traderWatchTabDAO = traderWatchTabDAO;
	}

	public void setStrategyTypeDAO(IStrategyTypeDAO strategyTypeDAO) {
		this.strategyTypeDAO = strategyTypeDAO;
	}

	public void setStrategyByTabLegDAO(IStrategyByTabLegDAO strategyByTabLegDAO) {
		this.strategyByTabLegDAO = strategyByTabLegDAO;
	}

	public void setStrategyTypeLegDAO(IStrategyTypeLegDAO strategyTypeLegDAO) {
		this.strategyTypeLegDAO = strategyTypeLegDAO;
	}

	public void setTcpRecoverySessionDAO(ITcpRecoverySessionDAO tcpRecoverySessionDAO) {
		this.tcpRecoverySessionDAO = tcpRecoverySessionDAO;
	}

	public void setTraderDAO(ITraderDAO traderDAO) {
		this.traderDAO = traderDAO;
	}

	public void setTraderExchangeCodeDAO(ITraderExchangeCodeDAO traderExchangeCodeDAO) {
		this.traderExchangeCodeDAO = traderExchangeCodeDAO;
	}

	public void setUmdfChannelByEngineDAO(IUmdfChannelByEngineDAO umdfChannelByEngineDAO) {
		this.umdfChannelByEngineDAO = umdfChannelByEngineDAO;
	}

	public void setUmdfRecoverySessionByEngineDAO(IUmdfRecoverySessionByEngineDAO umdfRecoverySessionByEngineDAO) {
		this.umdfRecoverySessionByEngineDAO = umdfRecoverySessionByEngineDAO;
	}

	public void setStrategyReportDAO(IStrategyReportDAO strategyReportDAO) {
		this.strategyReportDAO = strategyReportDAO;
	}

	public void setLegStrategyReportDAO(ILegStrategyReportDAO legStrategyReportDAO) {
		this.legStrategyReportDAO = legStrategyReportDAO;
	}

	public void setStrategyOrderDAO(IStrategyOrdersDAO strategyOrderDAO) {
		this.strategyOrderDAO = strategyOrderDAO;
	}

	public void setOrderTradeDAO(IOrderTradeDAO orderTradeDAO) {
		this.orderTradeDAO = orderTradeDAO;
	}

	public void setDataBaseFunctions(IDataBaseFunctions dataBaseFunctions) {
		this.dataBaseFunctions = dataBaseFunctions;
	}
}