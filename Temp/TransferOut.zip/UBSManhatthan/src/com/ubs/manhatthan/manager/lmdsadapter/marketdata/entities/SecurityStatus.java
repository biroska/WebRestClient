package com.ubs.manhatthan.manager.lmdsadapter.marketdata.entities;

public interface SecurityStatus {

}
