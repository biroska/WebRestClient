package com.ubs.manhatthan.admin.model;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Recovery implements Serializable {

	private int engineId;
	private String exchange;
	private String host;
	private long port;
	private String senderCompld;
	
	
	public Recovery(int engineId, String exchange, String host, long port, String senderCompld) {
		super();

		this.engineId = engineId;
		this.exchange = exchange;
		this.host = host;
		this.port = port;
		this.senderCompld = senderCompld;
	}
	
	public int getEngineId() {
		return engineId;
	}


	public void setEngineId(int engineId) {
		this.engineId = engineId;
	}

	public String getExchange() {
		return exchange;
	}


	public void setExchange(String exchange) {
		this.exchange = exchange;
	}


	public String getHost() {
		return host;
	}


	public void setHost(String host) {
		this.host = host;
	}

	public long getPort() {
		return port;
	}

	public void setPort(long port) {
		this.port = port;
	}

	public String getSenderCompld() {
		return senderCompld;
	}

	public void setSenderCompld(String senderCompld) {
		this.senderCompld = senderCompld;
	}

	@Override
	public String toString() {
		return "Recovery [exchange=" + exchange + ", host=" + host + ", port=" + port + 
				", senderCompld=" + senderCompld + ", engine=" + engineId + "]";
	}

}
