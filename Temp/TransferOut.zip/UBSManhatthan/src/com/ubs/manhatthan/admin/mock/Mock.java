package com.ubs.manhatthan.admin.mock;

import java.util.ArrayList;

import com.ubs.manhatthan.admin.model.Account;
import com.ubs.manhatthan.admin.model.Engine;
import com.ubs.manhatthan.admin.model.OrderEntry;
import com.ubs.manhatthan.admin.model.Recovery;
import com.ubs.manhatthan.admin.model.UmdfChannel;
import com.ubs.manhatthan.admin.service.Facade;

public class Mock implements Facade {

	private static ArrayList<Account> accounts;
	private static ArrayList<Engine> enginers;
	private static ArrayList<Recovery> recovery;
	private static ArrayList<OrderEntry> orderEntry;
	private static ArrayList<UmdfChannel> umdfChannel;
	
	static {		
		accounts = new ArrayList<Account>();
		accounts.add( new Account("Caso1", 1284677L, 1, "ABC0001"));
		accounts.add( new Account("Caso2", 4567456L, 2, "Not Defined"));
		accounts.add( new Account("Caso3", 7864576L, 3, "ABC0001"));
		accounts.add( new Account("Caso4", 2456574L, 4, "Not Defined"));
		accounts.add( new Account("Caso5", 3253457L, 5, "Not Defined"));
		accounts.add( new Account("Caso6", 25334966L, 6, "ABC0002"));
							
		enginers = new ArrayList<Engine>();
		enginers.add(new Engine(1 , "123.123.123.123", 1234));
		enginers.add(new Engine(2 , "123.123.123.123", 1234));
		enginers.add(new Engine(3 , "123.123.123.123", 1234));
		
		recovery = new ArrayList<Recovery>();
		recovery.add(new Recovery(1, "Bovespa", "123.123.123.123", 10567, "OCTA001"));
		recovery.add(new Recovery(2, "BMF", "123.123.123.123", 10567, "OCT0001"));
		recovery.add(new Recovery(1, "BMF", "123.123.123.123", 10567, "OCT0002"));
										
		orderEntry = new ArrayList<OrderEntry>();
		orderEntry.add(new OrderEntry("BMF", "Desk" , 1, "123.123.123.123", 1234, "OTC0001", "OE104", 123456, true));
		orderEntry.add(new OrderEntry("BMF", "Desk" , 1, "123.123.123.123", 1234, "OTC0003", "OE104", 123456, false));
		orderEntry.add(new OrderEntry("BMF", "Desk" , 2, "123.123.123.123", 1234, "OTC0002", "OE104", 123456, true));
		orderEntry.add(new OrderEntry("BMF", "Desk" , 2, "123.123.123.123", 1234, "OTC0002", "OE104", 123456, true));

		umdfChannel = new ArrayList<UmdfChannel>();
		umdfChannel.add(new UmdfChannel(100, "Type", "Exchange", "111.111.111.111", new Long(1000), "222.222.222.222", new Long(200), "333.333.333.333", new Long(300)));		
	}
	
	public ArrayList<Account> getAccounts() {
		return accounts;
	}

	public static void setAccounts(ArrayList<Account> accounts) {
		Mock.accounts = accounts;
	}

	public ArrayList<Engine> getEnginers() {
		return enginers;
	}

	public static void setEnginers(ArrayList<Engine> enginers) {
		Mock.enginers = enginers;
	}		

	public ArrayList<Recovery> getRecovery() {
		return recovery;
	}

	public static void setRecovery(ArrayList<Recovery> recovery) {
		Mock.recovery = recovery;
	}

	public ArrayList<OrderEntry> getOrderEntry() {
		return orderEntry;
	}

	public static void setOrderEntry(ArrayList<OrderEntry> orderEntry) {
		Mock.orderEntry = orderEntry;
	}

	public ArrayList<UmdfChannel> getUmdfChannel() {
		return umdfChannel;
	}

	public static void setUmdfChannel(ArrayList<UmdfChannel> umdfChannel) {
		Mock.umdfChannel = umdfChannel;
	}
}
