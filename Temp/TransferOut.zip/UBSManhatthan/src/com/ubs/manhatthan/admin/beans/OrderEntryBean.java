package com.ubs.manhatthan.admin.beans;

import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import com.ubs.manhatthan.admin.mock.Mock;
import com.ubs.manhatthan.admin.model.OrderEntry;
import com.ubs.manhatthan.admin.service.Facade;

@SessionScoped
@ManagedBean(name="orderEntryBean")
public class OrderEntryBean {

	private List<OrderEntry> orderEntries;
	private OrderEntry selectedOrderEntry;
	private String text;
		
	private List<OrderEntry> filteredOrderEntries;

	private Facade facade = new Mock();
	
	public OrderEntryBean() {		
		orderEntries = new ArrayList<OrderEntry>( facade.getOrderEntry() );
	}
	
	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public List<OrderEntry> getOrderEntries() {
		return orderEntries;
	}

	public void setOrderEntries(List<OrderEntry> orderEntrys) {
		this.orderEntries = orderEntrys;
	}

	public OrderEntry getSelectedOrderEntry() {
		return selectedOrderEntry;
	}

	public void setSelectedOrderEntry(OrderEntry selectedOrderEntry) {
		this.selectedOrderEntry = selectedOrderEntry;
	}

	public List<OrderEntry> getFilteredOrderEntries() {
		return filteredOrderEntries;
	}

	public void setFilteredOrderEntries(List<OrderEntry> filteredOrderEntries) {
		this.filteredOrderEntries = filteredOrderEntries;
	}
	
	public Facade getFacade() {
		return facade;
	}

	public void setFacade(Facade facade) {
		this.facade = facade;
	}
}
	
	
