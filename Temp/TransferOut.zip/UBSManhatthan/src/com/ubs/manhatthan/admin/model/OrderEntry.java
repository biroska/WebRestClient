package com.ubs.manhatthan.admin.model;

import java.io.Serializable;

@SuppressWarnings("serial")
public class OrderEntry implements Serializable {

	private String exchange;
	private String description;
	private int engine;
	private String host;
	private long port;
	private String targetCompld;
	private String senderCompld;
	private long password;
	private boolean eneabled;
	
	
	public OrderEntry(String exchange, String description, int engine, String host, long port, String targetCompld, String senderCompld, long password, boolean eneabled) {
		super();
		this.exchange = exchange;
		this.description = description;
		this.engine = engine;
		this.host = host;
		this.port = port;
		this.targetCompld = targetCompld;
		this.senderCompld = senderCompld;
		this.password = password;
		this.eneabled = eneabled;
		
	}
	
	
	public String getExchange() {
		return exchange;
	}


	public void setExchange(String exchange) {
		this.exchange = exchange;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public int getEngine() {
		return engine;
	}


	public void setEngine(int engine) {
		this.engine = engine;
	}


	public String getHost() {
		return host;
	}


	public void setHost(String host) {
		this.host = host;
	}


	public long getPort() {
		return port;
	}


	public void setPort(long port) {
		this.port = port;
	}


	public String getTargetCompld() {
		return targetCompld;
	}


	public void setTargetCompld(String targetCompld) {
		this.targetCompld = targetCompld;
	}


	public String getSenderCompld() {
		return senderCompld;
	}


	public void setSenderCompld(String senderCompld) {
		this.senderCompld = senderCompld;
	}


	public long getPassword() {
		return password;
	}


	public void setPassword(long password) {
		this.password = password;
	}


	public boolean isEneabled() {
		return eneabled;
	}

	public void setEneabled(boolean eneabled) {
		this.eneabled = eneabled;
	}



	@Override
	public String toString() {
		return "OrderEntry [exchange=" + exchange + ", description=" + description + ", engine=" + engine + ", host=" + host + ", port=" + port + ", targetCompld=" + targetCompld + ", senderCompld=" + senderCompld + ", password=" + password + ", eneabled=" + eneabled + "]";
	}
	
}
