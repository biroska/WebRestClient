package com.ubs.manhatthan.admin.model;

import java.io.Serializable;

@SuppressWarnings("serial")
public class MarketData implements Serializable {

	private int id;
	private String type;
	private String exchange;
	private String incremental;
	private String recovery;
	private String instDefinition;
	
	
	public MarketData(int id, String type, String exchange, String incremental, String recovery, String instDefinition ) {
		super();
		this.id = id;
		this.type = type;
		this.exchange = exchange;
		this.incremental = incremental;
		this.recovery = recovery;
		this.instDefinition = instDefinition;
		
	}
	

	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getExchange() {
		return exchange;
	}


	public void setExchange(String exchange) {
		this.exchange = exchange;
	}


	public String getIncremental() {
		return incremental;
	}


	public void setIncremental(String incremental) {
		this.incremental = incremental;
	}


	public String getRecovery() {
		return recovery;
	}

	public void setRecovery(String recovery) {
		this.recovery = recovery;
	}

	public String getInstDefinition() {
		return instDefinition;
	}

	public void setInstDefinition(String instDefinition) {
		this.instDefinition = instDefinition;
	}


	@Override
	public String toString() {
		return "MarketData [id=" + id + ", type=" + type + ", exchange=" + exchange + ", incremental=" + incremental + ", recovery=" + recovery + ", instDefinition=" + instDefinition + "]";
	}

}
