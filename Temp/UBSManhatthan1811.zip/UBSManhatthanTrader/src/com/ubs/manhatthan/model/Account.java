package com.ubs.manhatthan.model;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Account implements Serializable {

	private String name;
	private Long number;
	
	
	public Account() {
		super();
	}
	
	public Account(String name, Long number) {
		super();
		this.name = name;
		this.number = number;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getNumber() {
		return number;
	}

	public void setNumber(Long number) {
		this.number = number;
	}

	@Override
	public String toString() {
		return name;
	}
	
}
