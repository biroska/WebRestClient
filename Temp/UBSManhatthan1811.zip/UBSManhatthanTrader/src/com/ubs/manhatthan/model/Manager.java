package com.ubs.manhatthan.model;

import java.io.Serializable;

public class Manager implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5537769916985591429L;
	private long id;
	private boolean cancelAtive;
	private String client;
	private int status;
	private int percent;
	private String user;
	private String start;
	private String end; 
	
	private Account account;
	private StrategyType strategyType;
	
	public Manager(){
		super();
	}
	

	public Manager(long id, boolean cancelAtive, int status, int percent, String user, String start,
			String end, Account account, StrategyType strategyType) {
		this.id = id;
		this.cancelAtive = cancelAtive;
		this.status = status;
		this.percent = percent;
		this.user = user;
		this.start = start;
		this.end = end;
		this.account = account;
		this.strategyType = strategyType;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public boolean isCancel() {
		return cancelAtive;
	}

	public void setCancel(boolean cancelAtive) {
		this.cancelAtive = cancelAtive;
	}

	public String getClient() {
		return client;
	}

	public void setClient(String client) {
		this.client = client;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public int getPercent() {
		return percent;
	}

	public void setPercent(int percent) {
		this.percent = percent;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getStart() {
		return start;
	}

	public void setStart(String start) {
		this.start = start;
	}

	public String getEnd() {
		return end;
	}

	public void setEnd(String end) {
		this.end = end;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public StrategyType getStrategyType() {
		return strategyType;
	}

	public void setStrategyType(StrategyType strategyType) {
		this.strategyType = strategyType;
	}
}
