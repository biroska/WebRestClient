package com.ubs.manhatthan.model;

import java.io.Serializable;

public class StrategyParameters  implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3322485785376389048L;
	private String contract;
	private int qty;
	private String side;
	private int clip;
	private int rank;
	private Long dv1;
	private String condorPrice;
	private String accountName;

	public StrategyParameters(Long long1, String string, long l){}

	public StrategyParameters(String contract, int qty, String side,  int clip, int rank, long dv1, String condorPrice, String accountName) {
		super();
		this.contract = contract;
		this.qty = qty;
		this.side = side;
		this.clip = clip;
		this.rank = rank;
		this.dv1 = dv1;
		this.condorPrice = condorPrice;
		this.accountName = accountName;

	}

	
	public String getContract() {
		return contract;
	}

	public void setContract(String contract) {
		this.contract = contract;
	}

	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	public String getSide() {
		return side;
	}

	public void setSide(String side) {
		this.side = side;
	}

	public int getClip() {
		return clip;
	}

	public void setClip(int clip) {
		this.clip = clip;
	}

	public int getRank() {
		return rank;
	}

	public void setRank(int rank) {
		this.rank = rank;
	}

	public Long getDv1() {
		return dv1;
	}

	public void setDv1(Long dv1) {
		this.dv1 = dv1;
	}
	
	public String getCondorPrice() {
		return condorPrice;
	}

	public void setCondorPrice(String condorPrice) {
		this.condorPrice = condorPrice;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	@Override
	public String toString() {
		return "StrategyParameters [contract=" + contract + ", qty=" + qty + ", side=" + side + ", clip=" + clip + ", rank=" + rank + ", condorPrice=" + condorPrice + ", accountName=" + accountName + ", dv1=" + dv1 + "]";
	}
	
}
