package com.ubs.manhatthan.model;

import java.io.Serializable;
import java.util.List;

public class StrategyType implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long id;
	
	private Integer strategyCode;
	
	private String description;
	
	private Integer numberOfLegs;
	
	private int defaultStrag;
	
	private int sumQtdLeggeds;
	
	private List<StrategyTypeLeg> strategyTypeLegList;
	
	public StrategyType() {
		super();
	}

	public StrategyType(Long id, Integer strategyCode, String description, Integer numberOfLegs, int defaultStrag, List<StrategyTypeLeg> strategyTypeLegList) {
		super();
		this.id = id;
		this.strategyCode = strategyCode;
		this.description = description;
		this.numberOfLegs = numberOfLegs;
		this.defaultStrag = defaultStrag;
		this.strategyTypeLegList = strategyTypeLegList;
	}
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Integer getStrategyCode() {
		return strategyCode;
	}

	public void setStrategyCode(Integer strategyCode) {
		this.strategyCode = strategyCode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getNumberOfLegs() {
		return numberOfLegs;
	}

	public void setNumberOfLegs(Integer numberOfLegs) {
		this.numberOfLegs = numberOfLegs;
	}

	public List<StrategyTypeLeg> getStrategyTypeLegList() {
		return strategyTypeLegList;
	}

	public void setStrategyTypeLegList(List<StrategyTypeLeg> strategyTypeLegList) {
		this.strategyTypeLegList = strategyTypeLegList;
	}

	public int getDefaultStrag() {
		return defaultStrag;
	}

	public void setDefaultStrag(int defaultStrag) {
		this.defaultStrag = defaultStrag;
	}

	public int getSumQtdLeggeds() {
		int sum = 0;
		sumQtdLeggeds = 0;
		for (StrategyTypeLeg strategyTypeLeg : strategyTypeLegList) {
			sum += strategyTypeLeg.getLegged().getLeggedQty();
		}
		sumQtdLeggeds = sum;
		return sumQtdLeggeds;
	}
}
