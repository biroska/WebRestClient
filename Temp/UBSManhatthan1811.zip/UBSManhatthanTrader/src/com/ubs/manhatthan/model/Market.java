package com.ubs.manhatthan.model;

import java.io.Serializable;
import java.util.Iterator;

@SuppressWarnings("serial")
public class Market implements Serializable {

	private long id;
	private int lq;
	private long lp;
	private int bq;
	private long bp;
	private long sp;
	private int sq;
	
	private Account account;
	private StrategyType strategyType;
	
	public Market() {
		super();
	}

	public Market(long id, int lq, long lp, int bq, long bp, long sp, int sq, StrategyType strategyType) {
		super();
		this.id = id;
		this.lq = lq;
		this.lp = lp;
		this.bq = bq;
		this.bp = bp;
		this.sp = sp;
		this.sq = sq;
		this.strategyType = strategyType;
	}

	public String getContracts() {
		StringBuffer listContractsByName = new StringBuffer();
 
		if (null != strategyType && null != strategyType.getStrategyTypeLegList()) {
	
			for (Iterator<StrategyTypeLeg> iterator = strategyType.getStrategyTypeLegList().iterator(); iterator.hasNext();) {
				StrategyTypeLeg strategyTypeLeg = (StrategyTypeLeg) iterator.next();
				if (iterator.hasNext()) {
					listContractsByName.append(strategyTypeLeg.getLegged().getContract() + " / ");
				}else{
					listContractsByName.append(strategyTypeLeg.getLegged().getContract());
				}
			}
		}
		return listContractsByName.toString();
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int getLq() {
		return lq;
	}

	public void setLq(int lq) {
		this.lq = lq;
	}

	public long getLp() {
		return lp;
	}

	public void setLp(long lp) {
		this.lp = lp;
	}

	public int getBq() {
		return bq;
	}

	public void setBq(int bq) {
		this.bq = bq;
	}

	public long getBp() {
		return bp;
	}

	public void setBp(long bp) {
		this.bp = bp;
	}

	public long getSp() {
		return sp;
	}

	public void setSp(long sp) {
		this.sp = sp;
	}

	public int getSq() {
		return sq;
	}

	public void setSq(int sq) {
		this.sq = sq;
	}

	public StrategyType getStrategyType() {
		return strategyType;
	}

	public void setStrategyType(StrategyType strategyType) {
		this.strategyType = strategyType;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}
}
