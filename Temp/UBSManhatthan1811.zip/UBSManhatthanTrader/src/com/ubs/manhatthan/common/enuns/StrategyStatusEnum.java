package com.ubs.manhatthan.common.enuns;

public enum StrategyStatusEnum {
	
	UNKNOWN (0, "UNKNOWN"),
	INITIALIZING (1,"INITIALIZING"),
	MODIFYING (2,"MODIFYING"),
	SCHEDULING (3,"SCHEDULING"),
	PAUSING (4,"PAUSING"),
	RESUMING (5,"RESUMING"),
	CANCELLING (6,"CANCELLING"),
	FINALIZING (7,"FINALIZING"),
	SCHEDULED (8,"SCHEDULED"),
	PAUSED (9,"PAUSED"),
	RESUMED (10,"RESUMED"),
	COMPLETED (11,"COMPLETED"),
	CANCELLED (12,"CANCELLED"),
	ERROR (13, "ERROR");
	
    StrategyStatusEnum(int code) {
        this.code = code;
    }

    StrategyStatusEnum(int code, String description) {
		this.code = code;
		this.description = description;
	}

	private int code;
    
    private String description;

    public int getCode( ) {
    	return code;
    }

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	
}