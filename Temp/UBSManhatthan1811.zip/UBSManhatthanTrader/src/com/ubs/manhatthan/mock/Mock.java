package com.ubs.manhatthan.mock;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.ubs.manhatthan.model.Account;
import com.ubs.manhatthan.model.Legged;
import com.ubs.manhatthan.model.Manager;
import com.ubs.manhatthan.model.Market;
import com.ubs.manhatthan.model.MarketWhatchTab;
import com.ubs.manhatthan.model.Otc;
import com.ubs.manhatthan.model.ReportAverageDetail;
import com.ubs.manhatthan.model.ReportPriceDetail;
import com.ubs.manhatthan.model.ReportUserDetail;
import com.ubs.manhatthan.model.Strategy;
import com.ubs.manhatthan.model.StrategyParameters;
import com.ubs.manhatthan.model.StrategyType;
import com.ubs.manhatthan.model.StrategyTypeLeg;
import com.ubs.manhatthan.model.Unlegging;
import com.ubs.manhatthan.service.Facade;

public class Mock implements Facade, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private ArrayList<StrategyType> strategyTypes;
	private List<Legged> listLeggeds2;
	private List<Legged> listLeggeds4;
	
	private ArrayList<Market> markets;
	private static ArrayList<Account> accounts;
	private static ArrayList<Manager> managers;
	private static ArrayList<Unlegging> unlegging;
	private static ArrayList<Otc> otc;
	private static ArrayList<StrategyParameters> strategyParameters;
	private static ArrayList<Strategy> strategies;
	private static ArrayList<MarketWhatchTab> marketWhatchTabs;
	private static ArrayList<ReportUserDetail> reportUserDetails;
	private static ArrayList<ReportPriceDetail> reportPriceDetails;
	private static ArrayList<ReportAverageDetail> reportAverageDetails;

	static {
		
		
		// =================
		// | Account |
		// =================
		
		accounts = new ArrayList<Account>();
		accounts.add( new Account("Bradesco Seguros S/A", 1234567L));
		accounts.add( new Account("ITAU BBA Seguros S/A", 4567456L));
		accounts.add( new Account("SANTANDER PREVIDENCIA MELHOR IDADE", 7864576L));
		

		// =================
		// | Unlegging |
		// =================

		unlegging = new ArrayList<Unlegging>();

		unlegging.add(new Unlegging("", "", 65, 0));
		unlegging.add(new Unlegging("DI1F23", "BUY", 40, 1301));
		unlegging.add(new Unlegging("DI1F23", "BUY", 10, 1302));
		unlegging.add(new Unlegging("DI1F23", "BUY", 15, 1301));
		unlegging.add(new Unlegging("", "", 0, 0));
		unlegging.add(new Unlegging("", "", 0, 0));
		unlegging.add(new Unlegging("", "", 0, 0));

		// =================
		// | OTC |
		// =================

		otc = new ArrayList<Otc>();

		otc.add(new Otc("DI1F23", "BUY", 1325, 20));


		reportUserDetails = new ArrayList<ReportUserDetail>();

		reportUserDetails.add(new ReportUserDetail("Form 12", 100.00, 100, "User Report Test", 1000.05, "S"));
		reportUserDetails.add(new ReportUserDetail("BVMF", 100.00, 100, "User Report Test 1", 1000.05, "B"));
		reportUserDetails.add(new ReportUserDetail("BVMF", 100.00, 100, "User Report Test 2", 1000.05, "B"));
		reportUserDetails.add(new ReportUserDetail("BVMF", 100.00, 100, "User Report Test 3", 1000.05, "B"));
		reportUserDetails.add(new ReportUserDetail("BVMF", 100.00, 100, "User Report Test 4", 1000.05, "S"));
		reportUserDetails.add(new ReportUserDetail("BVMF", 100.00, 100, "User Report Test 5", 1000.05, "S"));

		reportPriceDetails = new ArrayList<ReportPriceDetail>();

		reportPriceDetails.add(new ReportPriceDetail("Form 18", 100.00, 100, "Price Report Test", 1000.05, "B"));
		reportPriceDetails.add(new ReportPriceDetail("BVMF", 100.00, 100, "Price Report Test 1", 1000.05, "S"));
		reportPriceDetails.add(new ReportPriceDetail("BVMF", 100.00, 100, "Price Report Test 2", 1000.05, "S"));
		reportPriceDetails.add(new ReportPriceDetail("BVMF", 100.00, 100, "Price Report Test 3", 1000.05, "B"));
		reportPriceDetails.add(new ReportPriceDetail("BVMF", 100.00, 100, "Price Report Test 4", 1000.05, "B"));
		reportPriceDetails.add(new ReportPriceDetail("BVMF", 100.00, 100, "Price Report Test 5", 1000.05, "B"));

		reportAverageDetails = new ArrayList<ReportAverageDetail>();

		reportAverageDetails
				.add(new ReportAverageDetail("Form 18", 100.00, 100, "Price Average Test", 1000.05, "S", 50.05));
		reportAverageDetails
				.add(new ReportAverageDetail("BVMF", 100.00, 100, "Price Average Test 1", 1000.05, "B", 50.05));
		reportAverageDetails
				.add(new ReportAverageDetail("BVMF", 100.00, 100, "Price Average Test 2", 1000.05, "B", 50.05));
		reportAverageDetails
				.add(new ReportAverageDetail("BVMF", 100.00, 100, "Price Average Test 3", 1000.05, "S", 50.05));
		reportAverageDetails
				.add(new ReportAverageDetail("BVMF", 100.00, 100, "Price Average Test 4", 1000.05, "S", 50.05));
		reportAverageDetails
				.add(new ReportAverageDetail("BVMF", 100.00, 100, "Price Average Test 5", 1000.05, "B", 50.05));
	}

	@Override
	public List<Account> getAccountByNameOrNumber(String query) {

		ArrayList<Account> result = new ArrayList<Account>();

		if (query != null && !query.isEmpty()) {
			for (Account item : accounts) {

				if (item.getName().contains(query)) {
					result.add(item);
				} else if (String.valueOf(item.getNumber()).contains(query)) {
					result.add(item);
				}
			}
		} else {
			result.addAll(accounts);
		}

		return result;
	}
	
	@Override
	public Account getAccountById(String query) {

		Account result = new Account();

		if (query != null && !query.isEmpty()) {
			for (Account item : accounts) {
				if (String.valueOf(item.getNumber()).contains(query)) {
					result = item;
				}
			}
		} 
		return result;
	}

	@Override
	public List<MarketWhatchTab> getWatchTabMarkets() {
		// ========================
		// | Strategies Tabs |
		// ========================

		marketWhatchTabs = new ArrayList<MarketWhatchTab>();

		marketWhatchTabs.add(new MarketWhatchTab(1, "View Strategy 1", "Strategy 1", getMarkets()));
		
		return Mock.marketWhatchTabs;
	}

	@Override
	public List<Market> getMarkets() {
		markets = new ArrayList<Market>();
			for (int i = 1; i < getStrategyTypes2().size(); i++) {
				Market mk = new Market(i, 5, 13400, 25, 13400, 13410, 30,  getStrategyTypes2().get(i));
				markets.add(mk);
			}
		return markets;
	}

	@Override
	public List<Manager> getManagers() {
		// =================
		// | Managers |
		// =================
		managers = new ArrayList<Manager>();
		for (int i = 0; i <  getStrategyTypes2().size(); i++) {
			managers.add(new Manager(+1+i, false, i, 50, "ROSCK SHIELDS", "12:20",
					"14:00",accounts.get(0), getStrategyTypes2().get(i)));

			managers.add(new Manager(+10+i, true, i, 50, "PEREIRA SILVA", "12:20",
					"14:00", accounts.get(1), getStrategyTypes2().get(i)));
			
			managers.add(new Manager(+20+i, false, 13, 50, "GAMA SOPRANO", "12:20",
					"14:00",accounts.get(2), getStrategyTypes2().get(i)));
			
		}

		
		return managers;
	}

	@Override
	public List<Unlegging> getUnlegging() {
		return Mock.unlegging;
	}

	@Override
	public List<Otc> getOtc() {
		return Mock.otc;
	}

	@Override
	public List<StrategyParameters> getStrategyParameters() {
		return Mock.strategyParameters;
	}

	@Override
	public List<Strategy> getStrategies() {
		return Mock.strategies;
	}

	@Override
	public List<StrategyType> getStrategyTypes() {
		
		// =================
		// | strategyTypes |
		// =================
		strategyTypes = new ArrayList<StrategyType>();
		
		for (long i = 1; i < 2; i++) {
			long idp2 = i+1;
			long idp4 = i+2;
			StrategyType strategyType2;
			StrategyTypeLeg l1p2 = new StrategyTypeLeg(i+1,Integer.valueOf(1),Integer.valueOf(1),  new Legged());
			StrategyTypeLeg l2p2 = new StrategyTypeLeg(i+1,Integer.valueOf(2),Integer.valueOf(2),  new Legged());
			strategyType2 = new StrategyType(idp2, Integer.valueOf(String.valueOf(i+3l)), "Strategy " + idp2 +" - 2 Leggeds", 2, 1, new ArrayList<StrategyTypeLeg>());
			strategyType2.getStrategyTypeLegList().add(l1p2);
			strategyType2.getStrategyTypeLegList().add(l2p2);
			strategyTypes.add(strategyType2);
			
			StrategyType strategyType4 = new StrategyType();
			StrategyTypeLeg l1 = new StrategyTypeLeg(i+1,Integer.valueOf(1),Integer.valueOf(1), new Legged());
			StrategyTypeLeg l2 = new StrategyTypeLeg(i+1,Integer.valueOf(2),Integer.valueOf(2), new Legged());
			StrategyTypeLeg l3 = new StrategyTypeLeg(i+1,Integer.valueOf(1),Integer.valueOf(3), new Legged());
			StrategyTypeLeg l4 = new StrategyTypeLeg(i+1,Integer.valueOf(2),Integer.valueOf(4), new Legged());
			strategyType4.setId(idp4);
			strategyType4.setStrategyCode(Integer.valueOf(String.valueOf(i+3l)));
			strategyType4.setDescription("Strategy " + idp4 +" - 4 Leggeds");
			strategyType4.setNumberOfLegs(4);
			strategyType4.setStrategyTypeLegList(new ArrayList<StrategyTypeLeg>());
			strategyType4.getStrategyTypeLegList().add(l1);
			strategyType4.getStrategyTypeLegList().add(l2);
			strategyType4.getStrategyTypeLegList().add(l3);
			strategyType4.getStrategyTypeLegList().add(l4);
			
			strategyTypes.add(strategyType4);

			
		}
		return strategyTypes;

	}
	
	private List<StrategyType> getStrategyTypes2() {
		
		// =================
		// | strategyTypes |
		// =================
		strategyTypes = new ArrayList<StrategyType>();
		
		for (long i = 1; i < 6; i++) {
			long idp2 = i+1;
			long idp4 = i+2;
			StrategyType strategyType2;
			StrategyTypeLeg l1p2 = new StrategyTypeLeg(i+1,Integer.valueOf(1),Integer.valueOf(1), new Legged(i%2==0?"S":"N", "DI1F1"+i, 0, 11000+i+1L, 500+i, i, 0, 0, 0, 0, 0, 0, 0, 800, 00511));
			StrategyTypeLeg l2p2 = new StrategyTypeLeg(i+2,Integer.valueOf(2),Integer.valueOf(2), new Legged(i%2==0?"S":"N", "DI1F2"+i, 0, 1000+i+1L, 500+i, i, 0, 0, 0, 0, 0, 0, 0, 800, 00511));
			strategyType2 = new StrategyType(idp2, Integer.valueOf(String.valueOf(i+3l)), "Condor " + idp2 +" - 2 Leggeds", 2, 1, new ArrayList<StrategyTypeLeg>());
			strategyType2.getStrategyTypeLegList().add(l1p2);
			strategyType2.getStrategyTypeLegList().add(l2p2);
			
			strategyTypes.add(strategyType2);
			
			StrategyType strategyType4 = new StrategyType();
			StrategyTypeLeg l1 = new StrategyTypeLeg(i+3,Integer.valueOf(1),Integer.valueOf(1), new Legged(i%2==0?"S":"N", "DI1F1"+i, 0, 91+i+1L, 500+i, i, 0, 0, 0, 0, 0, 0, 0, 800, 00511));
			StrategyTypeLeg l2 = new StrategyTypeLeg(i+4,Integer.valueOf(2),Integer.valueOf(2), new Legged(i%2==0?"S":"N", "DI1F1"+i, 0, 81+i+1L, 500+i, i, 0, 0, 0, 0, 0, 0, 0, 800, 00511));
			StrategyTypeLeg l3 = new StrategyTypeLeg(i+5,Integer.valueOf(1),Integer.valueOf(3), new Legged(i%2==0?"S":"N", "DI1F1"+i, 0, 21+i+1L, 500+i, i, 0, 0, 0, 0, 0, 0, 0, 800, 00511));
			StrategyTypeLeg l4 = new StrategyTypeLeg(i+6,Integer.valueOf(2),Integer.valueOf(4), new Legged(i%2==0?"S":"N", "DI1F1"+i, 0, 281+i+1L, 500+i, i, 0, 0, 0, 0, 0, 0, 0, 800, 00511));
			
			strategyType4.setId(idp4);
			strategyType4.setStrategyCode(Integer.valueOf(String.valueOf(i+3l)));
			strategyType4.setDescription("Duration " + idp4 +" - 4 Leggeds");
			strategyType4.setNumberOfLegs(4);
			strategyType4.setStrategyTypeLegList(new ArrayList<StrategyTypeLeg>());
			strategyType4.getStrategyTypeLegList().add(l1);
			strategyType4.getStrategyTypeLegList().add(l2);
			strategyType4.getStrategyTypeLegList().add(l3);
			strategyType4.getStrategyTypeLegList().add(l4);
			
			strategyTypes.add(strategyType4);

			
		}
		return strategyTypes;

	}

	@Override
	public List<ReportUserDetail> getReportUserDetails() {
		return Mock.reportUserDetails;

	}

	@Override
	public List<ReportPriceDetail> getReportPriceDetails() {
		return Mock.reportPriceDetails;

	}

	@Override
	public List<Account> getListAllAcconts() {
		return accounts;
	}
	
	@Override
	public List<Legged> getListLeggeds2() {
		// =================
		// | Legged2 |
		// =================
		listLeggeds2 = new ArrayList<Legged>();
		Legged p2legged1 = new Legged("S", "DI1F02", 0, 881+1L, 500, 0, 0, 0, 0, 0, 0, 0, 0, 800, 00511);
		Legged p2legged2 = new Legged("B", "DI1F04", 0, 5+1L, 500, 0, 0, 0, 0, 0, 0, 0, 0, 800, 00511);
		listLeggeds2.add(p2legged1);
		listLeggeds2.add(p2legged2);
		return listLeggeds2;
	}
	
	
	@Override
	public List<Legged> getListLeggeds4() {
		// =================
		// | Legged4 |
		// =================
		listLeggeds4 = new  ArrayList<Legged>();
		Legged p4legged1 = new Legged("S", "DI1F16", 2, 12+1L, 500, 0, 0, 0, 0, 0, 0, 0, 0, 800, 00511);
		Legged p4legged2 = new Legged("B", "DI1F15", 1, 3L, 500, 0, 0, 0, 0, 0, 0, 0, 0, 800, 00511);
		Legged p4legged3 = new Legged("S", "DI1F12", 0, 900L, 500, 0, 0, 0, 0, 0, 0, 0, 0, 800, 00511);
		Legged p4legged4 = new Legged("B", "DI1F11", 2, 1000L, 500, 0, 0, 0, 0, 0, 0, 0, 0, 800, 00511);
		
		listLeggeds4.add(p4legged1);
		listLeggeds4.add(p4legged2);
		listLeggeds4.add(p4legged3);
		listLeggeds4.add(p4legged4);
		
		return listLeggeds4;
	}

}
