package com.ubs.manhatthan.beans;

import java.io.Serializable;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import com.ubs.manhatthan.model.User;

@SuppressWarnings("serial")
@SessionScoped
@ManagedBean(name = "userLoginBean")
public class UserLoginBean extends UBSCommonBean implements Serializable {

	public UserLoginBean() {
		this.userTrader = new User();
	}
	

	private User userTrader;
	
	

	public String login() {
		boolean loggedIn = false;

		if (null != userTrader && null != userTrader.getLogin() && userTrader.getLogin().equals("admin") && userTrader.getPassword() != null && userTrader.getLogin().equals("admin") || userTrader.getLogin().equals("bmfbovespa") && userTrader.getPassword() != null && userTrader.getLogin().equals("bmfbovespa")) {
			loggedIn = true;
		} else {
			addMsgValidationWarn("Loggin Error", "Invalid credentials");
		}

		if (loggedIn) {
			refresh();
			return "main.xhtml" + UBSCommonBean.forceRedirect();
		} else {
			return "login.xhtml" + UBSCommonBean.forceRedirect();
		}
	}

	public String logout() {
		logoutSession();
		return "login.xhtml" + UBSCommonBean.forceRedirect();
	}

	public User getUserTrader() {
		return userTrader;
	}

	public void setUserTrader(User userTrader) {
		this.userTrader = userTrader;
	}
}