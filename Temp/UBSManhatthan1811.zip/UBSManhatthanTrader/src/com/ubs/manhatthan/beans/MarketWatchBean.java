package com.ubs.manhatthan.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.event.ValueChangeEvent;

import org.primefaces.component.tabview.TabView;
import org.primefaces.event.TabCloseEvent;

import com.ubs.manhatthan.common.enuns.SideEnum;
import com.ubs.manhatthan.mock.Mock;
import com.ubs.manhatthan.model.Account;
import com.ubs.manhatthan.model.Legged;
import com.ubs.manhatthan.model.Market;
import com.ubs.manhatthan.model.MarketWhatchTab;
import com.ubs.manhatthan.model.StrategyType;
import com.ubs.manhatthan.model.StrategyTypeLeg;

@SuppressWarnings("serial")
@SessionScoped
@ManagedBean(name = "marketBean")
public class MarketWatchBean extends UBSCommonBean implements Serializable {

	private String idSelectMarket;

	private MarketWhatchTab marketWhatchTab;

	private List<MarketWhatchTab> marketWhatchTabs;

	private StrategyType selectStrategyType;
	
	private Legged instrumentLegged;

	private Account selectedAccount;

	private List<MarketWhatchTab> filteredStrategies;

	private List<StrategyType> strategyTypes;

	private Boolean renderLegged1 = false;

	private Boolean renderLegged2 = false;

	private Boolean renderLegged3 = false;

	private Boolean renderLegged4 = false;

	private Boolean renderBtnSynt = false;

	private TabView tabView;

	private int indexTabActive = 0;

	private Mock facade = new Mock();

	public MarketWatchBean() {
		instrumentLegged = new Legged();
		resetLeggedRender();
		strategyTypes = new ArrayList<StrategyType>(facade.getStrategyTypes());
		marketWhatchTabs = new ArrayList<MarketWhatchTab>(facade.getWatchTabMarkets());
	}

	private void resetLeggedRender() {
		renderLegged1 = false;
		renderLegged2 = false;
		renderLegged3 = false;
		renderLegged4 = false;
	}
	
    private Account selectAccount;
    

    public Account getSelectAccount() {
        return selectAccount;
    }

    public void setSelectAccount(Account selectAccount) {
        this.selectAccount = selectAccount;
    }

    // Actions
    public List<Account> completeAccount(){
        return facade.getListAllAcconts();
    }
    
    public String clear(){
        this.selectAccount = null;
        return "";
    }

	public void loadFormMarketNewTab() {
		marketWhatchTab = new MarketWhatchTab();
		setMarketWhatchTab(new MarketWhatchTab());
		refresh();
	}

	public void loadFormAddSyntetic() {
		resetLeggedRender();
		renderLegged2 = true;
		for (StrategyType strategyType : strategyTypes) {
			if (strategyType.getDefaultStrag()==1) {
				selectStrategyType = strategyType;
				idSelectMarket = strategyType.getId().toString();
			}
		}
		refresh();
	}

	public void changeComboValueSyntetic(ValueChangeEvent event) {
		
		resetLeggedRender();
		
		String tw = (String) event.getNewValue();
		
		idSelectMarket = tw;

		for (StrategyType strategyType : strategyTypes) {
			if (Long.valueOf(tw).equals(strategyType.getId())) {
				if (2 == strategyType.getNumberOfLegs()) {
					renderLegged2 = true;
				}
				if (4 == strategyType.getNumberOfLegs()) {
					renderLegged4 = true;
				}
				selectStrategyType = strategyType;
				break;
			}
		}
		refresh();
	}
	

	public void changeOrderBS() {
		for (int i = 0; i < selectStrategyType.getStrategyTypeLegList().size(); i++) {
			if (SideEnum.BUY.getCode().equals(selectStrategyType.getStrategyTypeLegList().get(i).getDefaultSide())) {
				selectStrategyType.getStrategyTypeLegList().get(i).setDefaultSide(2);
			} else {
				selectStrategyType.getStrategyTypeLegList().get(i).setDefaultSide(1);
			}
		}

	}
	
	public String addInstrument() {
			StrategyType instrumentStrategyType = new StrategyType();
			instrumentStrategyType.setNumberOfLegs(1);
			instrumentStrategyType.setId(this.marketWhatchTabs.get(indexTabActive).getMarkets() != null || !this.marketWhatchTabs.get(indexTabActive).getMarkets().isEmpty() ? this.marketWhatchTabs.get(indexTabActive).getMarkets().size()+1L : 1L);
			instrumentStrategyType.setDescription("");
			instrumentStrategyType.setStrategyTypeLegList(new ArrayList<StrategyTypeLeg>());
			StrategyTypeLeg strategyTypeLeg = new StrategyTypeLeg();
			strategyTypeLeg.setDefaultSide(1);
			strategyTypeLeg.setId(99L);
			strategyTypeLeg.setLegSeq(1);
			strategyTypeLeg.setLegged(instrumentLegged);
			instrumentStrategyType.getStrategyTypeLegList().add(strategyTypeLeg);
			Market market = new Market(this.marketWhatchTabs.get(indexTabActive).getMarkets().size()+0,0,0,0,0,0,0, instrumentStrategyType);
			this.marketWhatchTabs.get(indexTabActive).getMarkets().add(market);
			refresh();
			instrumentLegged = new Legged();
			return "main.xhtml?faces-redirect=true";
	}

	public String addSyntetic() {
		if(null != idSelectMarket && !"0".equals(idSelectMarket.trim())){
			Market market = new Market(this.marketWhatchTabs.get(indexTabActive).getMarkets().size()+1,1,2,2,3,3,3, selectStrategyType);
			this.marketWhatchTabs.get(indexTabActive).getMarkets().add(market);
			refresh();
			return "main.xhtml?faces-redirect=true";
		}else{
			resetLeggedRender();
			addMsgValidationWarn("", "Select Strategy required - N�o foi possivel realizar opera��o");
			return "";
		}
	}

	public String addTabMarketPerUser() {
		if (null != marketWhatchTab.getName() && !"".equals(marketWhatchTab.getName().trim())) {
			if (null != marketWhatchTabs) {
				if (null != marketWhatchTabs) {
					List<MarketWhatchTab> listTemp = marketWhatchTabs;
					for (MarketWhatchTab tabs : listTemp) {
						if (marketWhatchTab.getName().trim().equals(tabs.getName().trim())) {
							addMsgValidationWarn("", "Duplicate name tab - N�o foi possivel realizar opera��o");
							return "";
						}
					}
				}
				int rowid = marketWhatchTabs.size();
				marketWhatchTab.setId(rowid);
				marketWhatchTab.setDisplayName(marketWhatchTab.getName());
				marketWhatchTab.setMarkets(new ArrayList<Market>());
				marketWhatchTabs.add(marketWhatchTab);

				if (!marketWhatchTabs.isEmpty()) {
					renderBtnSynt = false;
				}
				return "main.xhtml?faces-redirect=true";
			}
		}
		loadFormMarketNewTab();
		return "";
	}

	public String onTabCloseMarket(TabCloseEvent event) {
		renderBtnSynt = false;
		resetLeggedRender();
		String id = event.getTab().getTitle();
		if (null != marketWhatchTabs) {
			List<MarketWhatchTab> listTemp = marketWhatchTabs;
			for (MarketWhatchTab tabs : listTemp) {
				if (id.trim().equals(tabs.getName().trim())) {
					marketWhatchTabs.remove(tabs);
					break;
				}
			}
			if (marketWhatchTabs.isEmpty()) {
				renderBtnSynt = true;
			}
		}
		return "main.xhtml?faces-redirect=true";
	}

	public void saveSession() {
		addMsgValidationSucess("Opera��o realizada com sucesso", "Opera��o realizada com sucesso");
	}

	public Account getSelectedAccount() {
		return selectedAccount;
	}

	public void setSelectedAccount(Account selectedAccount) {
		this.selectedAccount = selectedAccount;
	}

	public List<MarketWhatchTab> getFilteredStrategies() {
		return filteredStrategies;
	}

	public void setFilteredStrategies(List<MarketWhatchTab> filteredStrategies) {
		this.filteredStrategies = filteredStrategies;
	}

	public Mock getFacade() {
		return facade;
	}

	public void setFacade(Mock facade) {
		this.facade = facade;
	}

	public MarketWhatchTab getMarketWhatchTab() {
		return marketWhatchTab;
	}

	public void setMarketWhatchTab(MarketWhatchTab marketWhatchTab) {
		this.marketWhatchTab = marketWhatchTab;
	}

	public List<MarketWhatchTab> getMarketWhatchTabs() {
		return marketWhatchTabs;
	}

	public void setMarketWhatchTabs(List<MarketWhatchTab> marketWhatchTabs) {
		this.marketWhatchTabs = marketWhatchTabs;
	}

	public String getIdSelectMarket() {
		return idSelectMarket;
	}

	public void setIdSelectMarket(String idSelectMarket) {
		this.idSelectMarket = idSelectMarket;
	}

	public Boolean getRenderLegged1() {
		return renderLegged1;
	}

	public void setRenderLegged1(Boolean renderLegged1) {
		this.renderLegged1 = renderLegged1;
	}

	public Boolean getRenderLegged2() {
		return renderLegged2;
	}

	public void setRenderLegged2(Boolean renderLegged2) {
		this.renderLegged2 = renderLegged2;
	}

	public Boolean getRenderLegged3() {
		return renderLegged3;
	}

	public void setRenderLegged3(Boolean renderLegged3) {
		this.renderLegged3 = renderLegged3;
	}

	public Boolean getRenderLegged4() {
		return renderLegged4;
	}

	public void setRenderLegged4(Boolean renderLegged4) {
		this.renderLegged4 = renderLegged4;
	}

	public TabView getTabView() {
		return tabView;
	}

	public void setTabView(TabView tabView) {
		this.tabView = tabView;
	}

	public int getIndexTabActive() {
		return indexTabActive;
	}

	public void setIndexTabActive(int indexTabActive) {
		this.indexTabActive = indexTabActive;
	}

	public Boolean getRenderBtnSynt() {
		return renderBtnSynt;
	}

	public void setRenderBtnSynt(Boolean renderBtnSynt) {
		this.renderBtnSynt = renderBtnSynt;
	}
	

	public List<StrategyType> getStrategyTypes() {
		return strategyTypes;
	}

	public void setStrategyTypes(List<StrategyType> strategyTypes) {
		this.strategyTypes = strategyTypes;
	}

	public StrategyType getSelectStrategyType() {
		return selectStrategyType;
	}

	public void setSelectStrategyType(StrategyType selectStrategyType) {
		this.selectStrategyType = selectStrategyType;
	}

	public Legged getInstrumentLegged() {
		return instrumentLegged;
	}

	public void setInstrumentLegged(Legged instrumentLegged) {
		this.instrumentLegged = instrumentLegged;
	}
}