package com.ubs.manhatthan.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import com.ubs.manhatthan.mock.Mock;
import com.ubs.manhatthan.model.ReportUserDetail;
import com.ubs.manhatthan.service.Facade;

@SuppressWarnings("serial")
@SessionScoped
@ManagedBean(name="reportUserBean")
public class ReportUserBean implements Serializable {

	private List<ReportUserDetail> reportUserDetails;
	private ReportUserDetail selectedReportUserDetail;
	private String text;
		
	private Facade facade = new Mock();
	
	public ReportUserBean(){
		
		reportUserDetails = new ArrayList<ReportUserDetail>(facade.getReportUserDetails());
	}
	
	public List<ReportUserDetail> getRecords() {
		return reportUserDetails;
	}

	public void setRecords(List<ReportUserDetail> reportUserDetails) {
		this.reportUserDetails = reportUserDetails;
	}

	public ReportUserDetail getSelectedReportUserDetail() {
		return selectedReportUserDetail;
	}

	public void setSelectedReportUserDetail(ReportUserDetail selectedReportUserDetail) {
		this.selectedReportUserDetail = selectedReportUserDetail;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public Facade getFacade() {
		return facade;
	}

	public void setFacade(Facade facade) {
		this.facade = facade;
	}
}
