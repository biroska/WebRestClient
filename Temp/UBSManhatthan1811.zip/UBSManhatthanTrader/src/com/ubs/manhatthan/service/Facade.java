package com.ubs.manhatthan.service;

import java.util.List;

import com.ubs.manhatthan.model.Account;
import com.ubs.manhatthan.model.Legged;
import com.ubs.manhatthan.model.Manager;
import com.ubs.manhatthan.model.Market;
import com.ubs.manhatthan.model.MarketWhatchTab;
import com.ubs.manhatthan.model.Otc;
import com.ubs.manhatthan.model.ReportPriceDetail;
import com.ubs.manhatthan.model.ReportUserDetail;
import com.ubs.manhatthan.model.Strategy;
import com.ubs.manhatthan.model.StrategyParameters;
import com.ubs.manhatthan.model.StrategyType;
import com.ubs.manhatthan.model.Unlegging;

public interface Facade {
	
	public List<Account> getAccountByNameOrNumber(String query );
	
	public List<Account> getListAllAcconts();
	
	public List<MarketWhatchTab> getWatchTabMarkets();
	
	public List<Market> getMarkets();
		
	public List<Manager> getManagers();
	
	public List<Unlegging> getUnlegging();
	
	public List<Otc> getOtc();
	
	public List<StrategyParameters> getStrategyParameters();
	
	public List<Strategy> getStrategies();
		
	public List<StrategyType> getStrategyTypes();
	
	public List<ReportUserDetail> getReportUserDetails();

	public List<ReportPriceDetail> getReportPriceDetails();

	Account getAccountById(String query);

	List<Legged> getListLeggeds2();

	List<Legged> getListLeggeds4();

}
