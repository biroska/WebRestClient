package com.ubs.manhatthan.admin.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import com.ubs.manhatthan.admin.mock.Mock;
import com.ubs.manhatthan.admin.model.ChannelType;
import com.ubs.manhatthan.admin.service.Facade;

@FacesConverter(value="channelTypeConverter")
public class ChannelTypeConverter implements Converter {

	Facade facade = new Mock();

    public Object getAsObject(FacesContext context, UIComponent component, String value) {
    	ChannelType c = facade.getChannelTypeById(value);
        return c;
    }

    public String getAsString(FacesContext context, UIComponent component, Object object) {
    	if (object != null) {
    		return String.valueOf(((ChannelType) object).getId());
    	} else {
    		return null;    	
    	}
    }
}
