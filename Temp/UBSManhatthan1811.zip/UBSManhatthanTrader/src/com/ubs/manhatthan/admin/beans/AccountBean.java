package com.ubs.manhatthan.admin.beans;

import java.util.ArrayList;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import com.ubs.manhatthan.admin.mock.Mock;
import com.ubs.manhatthan.admin.model.Account;
import com.ubs.manhatthan.admin.model.AccountSession;
import com.ubs.manhatthan.admin.service.Facade;

@SessionScoped
@ManagedBean(name="accountBean")
public class AccountBean {

	private List<Account> accounts;
	private Account selectedAccount;
		
	private List<Account> filteredAccounts;

	private List<AccountSession> availableSessions;
	private List<AccountSession> sessions;
	
	private AccountSession selectedAvailableAccountSession;
	private AccountSession selectedAccountSession;
	
	private Facade facade = new Mock();
	
	public AccountBean() {		
		accounts = new ArrayList<Account>(facade.getAccounts());
		
		availableSessions = new ArrayList<AccountSession>(facade.getAvailableSessions());
		
		sessions = new ArrayList<AccountSession>(facade.getSessions());
	}
		
	public List<Account> getAccounts() {
		return accounts;
	}

	public void setAccounts(List<Account> accounts) {
		this.accounts = accounts;
	}

	public Account getSelectedAccount() {
		return selectedAccount;
	}

	public void setSelectedAccount(Account selectedAccount) {
		this.selectedAccount = selectedAccount;
	}

	public List<Account> getFilteredAccounts() {
		return filteredAccounts;
	}

	public void setFilteredAccounts(List<Account> filteredAccounts) {
		this.filteredAccounts = filteredAccounts;
	}

	public List<Account> completeAccount(String account) {
		return new ArrayList<Account>(facade.getAccounts());
	}
	
	public List<AccountSession> getAvailableAccountSessions() {
		return this.availableSessions;
	}
	
	public List<AccountSession> getAccountSessions() {
		return this.sessions;
	}

	public AccountSession getSelectedAvailableAccountSession() {
		return selectedAvailableAccountSession;
	}

	public void setSelectedAvailableAccountSession(AccountSession selectedAvailableAccountSession) {
		this.selectedAvailableAccountSession = selectedAvailableAccountSession;
	}

	public AccountSession getSelectedAccountSession() {
		return selectedAccountSession;
	}

	public void setSelectedAccountSession(AccountSession selectedAccountSession) {
		this.selectedAccountSession = selectedAccountSession;
	}

	public void newAccount(ActionEvent actionEvent) {		
		this.selectedAccount = new Account();
	}
	
	public void deleteAccount(ActionEvent actionEvent) {		
		this.accounts.remove(this.selectedAccount);
	}
	
	public void addAccount(ActionEvent actionEvent) {
		boolean recordExists = false;
		
		if (this.selectedAccount != null) {
			for (Account item: this.accounts) {
				recordExists = (selectedAccount.getNumber() == item.getNumber());
				
				if (recordExists) break;
			}
			
			if (recordExists) {
				this.addMessage("Item already registered!");
			} else {
				this.accounts.add(this.selectedAccount);				
			}
		}
	}

	public void saveAccount(ActionEvent actionEvent) {

	}

	public Facade getFacade() {
		return facade;
	}

	public void setFacade(Facade facade) {
		this.facade = facade;
	}

	public void addMessage(String messageText) {
		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, messageText, null);
		FacesContext.getCurrentInstance().addMessage(null, message);
	}
}