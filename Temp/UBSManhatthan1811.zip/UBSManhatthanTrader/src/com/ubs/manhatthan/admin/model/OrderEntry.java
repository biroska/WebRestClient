package com.ubs.manhatthan.admin.model;

import java.io.Serializable;

@SuppressWarnings("serial")
public class OrderEntry implements Serializable {

	private int id;
	private Engine engine;
	private ExchangeType exchangeType;
	private String description;
	private String host;
	private long port;
	private String targetCompld;
	private String senderCompld;
	private String password;
	private boolean eneabled;
	
	
	public OrderEntry() {
		this.initialize();
	}
	
	public OrderEntry(int id, String description, String host, long port, String targetCompld, String senderCompld, String password, boolean eneabled) {
		super();
		
		this.initialize();
		
		this.id = id;
		this.description = description;
		this.host = host;
		this.port = port;
		this.targetCompld = targetCompld;
		this.senderCompld = senderCompld;
		this.password = password;
		this.eneabled = eneabled;
		
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Engine getEngine() {
		return engine;
	}

	public void setEngine(Engine engine) {
		this.engine = engine;
	}

	public ExchangeType getExchangeType() {
		return exchangeType;
	}

	public void setExchangeType(ExchangeType exchangeType) {
		this.exchangeType = exchangeType;
	}


	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}


	public long getPort() {
		return port;
	}


	public void setPort(long port) {
		this.port = port;
	}


	public String getTargetCompld() {
		return targetCompld;
	}


	public void setTargetCompld(String targetCompld) {
		this.targetCompld = targetCompld;
	}


	public String getSenderCompld() {
		return senderCompld;
	}


	public void setSenderCompld(String senderCompld) {
		this.senderCompld = senderCompld;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public boolean isEneabled() {
		return eneabled;
	}

	public void setEneabled(boolean eneabled) {
		this.eneabled = eneabled;
	}

	@Override
	public String toString() {
		return "OrderEntry [id=" + id + ", engine=" + engine.getId() + ", exchangeType=" + exchangeType.getName() + ", description=" + description + ", host=" + host + ", port=" + port + ", targetCompld=" + targetCompld + ", senderCompld=" + senderCompld + ", password=" + password + ", eneabled=" + eneabled + "]";
	}
	
	private void initialize() {
		engine = new Engine();
		
		exchangeType = new ExchangeType();
	}
}
