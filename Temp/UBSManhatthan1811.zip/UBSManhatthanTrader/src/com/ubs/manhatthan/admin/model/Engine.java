package com.ubs.manhatthan.admin.model;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Engine implements Serializable {

	private int id;
	private String host;
	private long port;
	private String logPath;
	
	public Engine() {
	
	}
	
	public Engine(int id, String host, long port, String logPath) {
		super();
		this.id = id;
		this.host = host;
		this.port = port;
		this.logPath = logPath;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public long getPort() {
		return port;
	}

	public void setPort(long port) {
		this.port = port;
	}

	public String getLogPath() {
		return logPath;
	}

	public void setLogPath(String logPath) {
		this.logPath = logPath;
	}

	@Override
	public String toString() {
		return "Engine [id=" + id + ", host=" + host + ", port=" + port + ", logPath=" + logPath + "]";
	}

}
