package com.ubs.manhatthan.admin.model;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Account implements Serializable {

	private Long number;
	private String name;
	private int sessionsEneabled;
	private String sessionId;
	
	public Account() {
		
	}
	
	public Account(Long number, String name, int sessionsEneabled, String sessionId) {
		super();
		this.number = number;
		this.name = name;
		this.sessionsEneabled = sessionsEneabled;
		this.sessionId = sessionId;
	}

	public Long getNumber() {
		return number;
	}

	public void setNumber(Long number) {
		this.number = number;
	}
	

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getSessionsEneabled() {
		return sessionsEneabled;
	}

	public void setSessionsEneabled(int sessionsEneabled) {
		this.sessionsEneabled = sessionsEneabled;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	@Override
	public String toString() {
		return "Account [number=" + number + ", name=" + name + ", sessionsEneabled=" + sessionsEneabled + ", sessionId=" + sessionId + "]";
	}
	
}
