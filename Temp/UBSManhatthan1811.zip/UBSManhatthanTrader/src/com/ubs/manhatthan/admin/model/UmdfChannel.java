package com.ubs.manhatthan.admin.model;

import java.io.Serializable;

@SuppressWarnings("serial")
public class UmdfChannel implements Serializable {

	private int id;
	private ChannelType channelType;
	private ExchangeType exchangeType;
	private String incrementalHost;
	private Long incrementalPort;
	private String recoveryHost;
	private Long recoveryPort;
	private String instDefinitionHost;
	private Long instDefinitionPort;
		
	public UmdfChannel() {
		this.initialize();
	}
	
	public UmdfChannel(int id, String incrementalHost,
				Long incrementalPort, String recoveryHost, Long recoveryPort, String instDefinitionHost,
				Long instDefinitionPort) {
		
		super();
		
		this.initialize();
		
		this.id = id;
		this.incrementalHost = incrementalHost;
		this.incrementalPort = incrementalPort;
		this.recoveryHost = recoveryHost;
		this.recoveryPort = recoveryPort;
		this.instDefinitionHost = instDefinitionHost;
		this.instDefinitionPort = instDefinitionPort;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public ChannelType getChannelType() {
		return channelType;
	}

	public void setChannelType(ChannelType channelType) {
		this.channelType = channelType;
	}

	public ExchangeType getExchangeType() {
		return exchangeType;
	}

	public void setExchangeType(ExchangeType exchangeType) {
		this.exchangeType = exchangeType;
	}

	public String getIncrementalHost() {
		return incrementalHost;
	}

	public void setIncrementalHost(String incrementalHost) {
		this.incrementalHost = incrementalHost;
	}

	public Long getIncrementalPort() {
		return incrementalPort;
	}

	public void setIncrementalPort(Long incrementalPort) {
		this.incrementalPort = incrementalPort;
	}

	public String getRecoveryHost() {
		return recoveryHost;
	}

	public void setRecoveryHost(String recoveryHost) {
		this.recoveryHost = recoveryHost;
	}

	public Long getRecoveryPort() {
		return recoveryPort;
	}

	public void setRecoveryPort(Long recoveryPort) {
		this.recoveryPort = recoveryPort;
	}

	public String getInstDefinitionHost() {
		return instDefinitionHost;
	}

	public void setInstDefinitionHost(String instDefinitionHost) {
		this.instDefinitionHost = instDefinitionHost;
	}

	public Long getInstDefinitionPort() {
		return instDefinitionPort;
	}

	public void setInstDefinitionPort(Long instDefinitionPort) {
		this.instDefinitionPort = instDefinitionPort;
	}

	@Override
	public String toString() {
		return "UmdfChannel [id=" + this.id + ", channelType=" + this.channelType.getName() + ", exchangeType=" + this.exchangeType.getName() + 
				", incrementalHost=" + this.incrementalHost + ", incrementalPort=" + this.incrementalPort.toString() + 
				", recoveryHost=" + this.recoveryHost + ", recoveryPort=" + this.recoveryPort.toString() +
				", instDefinitionHost=" + this.instDefinitionHost + ", instDefinitionPort=" + this.instDefinitionPort.toString() + 
				"]";
	}
	
	private void initialize() {
		channelType = new ChannelType();
		
		exchangeType = new ExchangeType();		
	}
}