package com.ubs.manhatthan.admin.mock;

import java.util.ArrayList;

import com.ubs.manhatthan.admin.model.*;
import com.ubs.manhatthan.admin.service.Facade;

public class Mock implements Facade {

	private static ArrayList<Account> accounts;
	private static ArrayList<AccountSession> availableSessions;
	private static ArrayList<AccountSession> sessions;
	private static ArrayList<Engine> enginers;
	private static ArrayList<Recovery> recovery;
	private static ArrayList<OrderEntry> orderEntry;
	private static ArrayList<UmdfChannel> umdfChannel;
	private static ArrayList<ChannelType> channelTypes;
	private static ArrayList<ExchangeType> exchangeTypes;
	
	static {		
		accounts = new ArrayList<Account>();
		accounts.add( new Account(1284677L, "Conta 1", 1, "ABC0001"));
		accounts.add( new Account(4567456L, "Conta 2", 2, "Not Defined"));
		accounts.add( new Account(7864576L, "Conta 3", 3, "ABC0001"));
		accounts.add( new Account(2456574L, "Conta 4", 4, "Not Defined"));
		accounts.add( new Account(3253457L, "Conta 5", 5, "Not Defined"));
		accounts.add( new Account(25334966L, "Conta 6", 6, "ABC0002"));

		availableSessions = new ArrayList<AccountSession>();
		availableSessions.add( new AccountSession(1, "Sessao 1"));
		availableSessions.add( new AccountSession(2, "Sessao 3"));
		availableSessions.add( new AccountSession(3, "Sessao 2"));

		sessions = new ArrayList<AccountSession>();
		sessions.add( new AccountSession(1, "Sessao 1"));

		enginers = new ArrayList<Engine>();
		enginers.add(new Engine(1 , "123.123.123.123", 1234, ""));
		enginers.add(new Engine(2 , "123.123.123.123", 1234, ""));
		enginers.add(new Engine(3 , "123.123.123.123", 1234, ""));
		
		recovery = new ArrayList<Recovery>();
		recovery.add(new Recovery(1, "123.123.123.123", 10567, "OCTA001"));
		recovery.add(new Recovery(2, "123.123.123.123", 10567, "OCT0001"));
		recovery.add(new Recovery(3, "123.123.123.123", 10567, "OCT0002"));
										
		orderEntry = new ArrayList<OrderEntry>();
		orderEntry.add(new OrderEntry(1, "Desk" , "123.123.123.123", 1234, "OTC0001", "OE104", "123456", true));
		orderEntry.add(new OrderEntry(2, "Desk" , "123.123.123.123", 1234, "OTC0003", "OE104", "123456", false));
		orderEntry.add(new OrderEntry(3, "Desk" , "123.123.123.123", 1234, "OTC0002", "OE104", "123456", true));
		orderEntry.add(new OrderEntry(4, "Desk" , "123.123.123.123", 1234, "OTC0002", "OE104", "123456", true));

		umdfChannel = new ArrayList<UmdfChannel>();
		umdfChannel.add(new UmdfChannel(100, "111.111.111.111", new Long(1000), "222.222.222.222", new Long(200), "333.333.333.333", new Long(300)));
		
		channelTypes = new ArrayList<ChannelType>();
		channelTypes.add(new ChannelType(1, "BMF"));
		channelTypes.add(new ChannelType(2, "MBP"));

		exchangeTypes = new ArrayList<ExchangeType>();
		exchangeTypes.add(new ExchangeType(1, "BMF"));
		exchangeTypes.add(new ExchangeType(2, "MBP"));
}
	
	public ArrayList<Account> getAccounts() {
		return accounts;
	}

	public static void setAccounts(ArrayList<Account> accounts) {
		Mock.accounts = accounts;
	}

	public ArrayList<AccountSession> getAvailableSessions() {
		return availableSessions;
	}

	public static void setAvailableSessions(ArrayList<AccountSession> availableSessions) {
		Mock.availableSessions = availableSessions;
	}

	public ArrayList<AccountSession> getSessions() {
		return sessions;
	}

	public static void setSessions(ArrayList<AccountSession> sessions) {
		Mock.sessions = sessions;
	}

	public ArrayList<Engine> getEnginers() {
		return enginers;
	}

	public static void setEnginers(ArrayList<Engine> enginers) {
		Mock.enginers = enginers;
	}		

	public ArrayList<Recovery> getRecovery() {
		return recovery;
	}

	public static void setRecovery(ArrayList<Recovery> recovery) {
		Mock.recovery = recovery;
	}

	public ArrayList<OrderEntry> getOrderEntry() {
		return orderEntry;
	}

	public static void setOrderEntry(ArrayList<OrderEntry> orderEntry) {
		Mock.orderEntry = orderEntry;
	}

	public ArrayList<UmdfChannel> getUmdfChannel() {
		return umdfChannel;
	}

	public static void setUmdfChannel(ArrayList<UmdfChannel> umdfChannel) {
		Mock.umdfChannel = umdfChannel;
	}

	public ArrayList<ChannelType> getChannelTypes() {
		return channelTypes;
	}

	public static void setChannelTypes(ArrayList<ChannelType> channelTypes) {
		Mock.channelTypes = channelTypes;
	}

	public ArrayList<ExchangeType> getExchangeTypes() {
		return exchangeTypes;
	}

	public static void setExchangeTypes(ArrayList<ExchangeType> exchangeTypes) {
		Mock.exchangeTypes = exchangeTypes;
	}
	
	public Engine getEngineById(String query) {
		Engine result = new Engine();

		if (query != null && !query.isEmpty()) {
			for (Engine item : enginers) {
				if (String.valueOf(item.getId()).contains(query)) {
					result = item;
				}
			}
		} 
		
		return result;
	}

	public ChannelType getChannelTypeById(String query) {
		ChannelType result = new ChannelType();

		if (query != null && !query.isEmpty()) {
			for (ChannelType item : channelTypes) {
				if (String.valueOf(item.getId()).contains(query)) {
					result = item;
				}
			}
		} 
		
		return result;
	}

	public ExchangeType getExchangeTypeById(String query) {
		ExchangeType result = new ExchangeType();

		if (query != null && !query.isEmpty()) {
			for (ExchangeType item : exchangeTypes) {
				if (String.valueOf(item.getId()).contains(query)) {
					result = item;
				}
			}
		} 
		
		return result;
	}

	public Account getAccountById(String query) {
		Account result = new Account();

		if (query != null && !query.isEmpty()) {
			for (Account item : accounts) {
				if (String.valueOf(item.getNumber()).contains(query)) {
					result = item;
				}
			}
		} 
		
		return result;
	}

	public AccountSession getAccountSessionById(String query) {
		AccountSession result = new AccountSession();

		if (query != null && !query.isEmpty()) {
			for (AccountSession item : availableSessions) {
				if (String.valueOf(item.getId()).contains(query)) {
					result = item;
				}
			}
		} 
		
		return result;
	}
}