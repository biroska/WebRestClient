package com.ubs.manhatthan.admin.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import com.ubs.manhatthan.admin.mock.Mock;
import com.ubs.manhatthan.admin.model.ExchangeType;
import com.ubs.manhatthan.admin.service.Facade;

@FacesConverter(value="exchangeTypeConverter")
public class ExchangeTypeConverter implements Converter {

	Facade facade = new Mock();

    public Object getAsObject(FacesContext context, UIComponent component, String value) {
    	ExchangeType c = facade.getExchangeTypeById(value);
        return c;
    }

    public String getAsString(FacesContext context, UIComponent component, Object object) {
    	if (object != null) {
    		return String.valueOf(((ExchangeType) object).getId());
    	} else {
    		return null;    	
    	}
    }
}
