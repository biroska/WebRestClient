package com.ubs.manhatthan.admin.model;

import java.io.Serializable;

@SuppressWarnings("serial")
public class ChannelType implements Serializable {

	private int id;
	private String name;
	
	public ChannelType() {
		
	}
	
	public ChannelType(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String host) {
		this.name = host;
	}

	@Override
	public String toString() {
		return "Engine [id=" + id + ", name=" + name + "]";
	}

}
