package com.ubs.manhatthan.admin.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import com.ubs.manhatthan.admin.mock.Mock;
import com.ubs.manhatthan.admin.model.AccountSession;
import com.ubs.manhatthan.admin.service.Facade;

@FacesConverter(value="accountSessionConverter")
public class AccountSessionConverter implements Converter {

	Facade facade = new Mock();

    public Object getAsObject(FacesContext context, UIComponent component, String value) {
    	AccountSession c = facade.getAccountSessionById(value);
        return c;
    }

    public String getAsString(FacesContext context, UIComponent component, Object object) {
    	if (object != null) {
    		return String.valueOf(((AccountSession) object).getId());
    	} else {
    		return null;    	
    	}
    }
}
