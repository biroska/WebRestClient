package com.ubs.manhatthan.admin.service;

import java.util.ArrayList;

import com.ubs.manhatthan.admin.model.*;

public interface Facade {		
	public ArrayList<Account> getAccounts();

	public ArrayList<AccountSession> getAvailableSessions();

	public ArrayList<AccountSession> getSessions();

	public ArrayList<Engine> getEnginers();
	
	public ArrayList<Recovery> getRecovery();
	
	public ArrayList<OrderEntry> getOrderEntry();
	
	public ArrayList<UmdfChannel> getUmdfChannel();

	public ArrayList<ChannelType> getChannelTypes();
	
	public ArrayList<ExchangeType> getExchangeTypes();
	
	public Engine getEngineById(String query);

	public ChannelType getChannelTypeById(String query);

	public ExchangeType getExchangeTypeById(String query);

	public Account getAccountById(String query);

	public AccountSession getAccountSessionById(String query);
}