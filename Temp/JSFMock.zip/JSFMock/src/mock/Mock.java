package mock;

import java.util.ArrayList;
import java.util.List;

import model.Account;
import model.Player;
import service.Facade;

public class Mock implements Facade {

	private static ArrayList<Player> players;
	private static ArrayList<Account> accounts;
	
	static {
		
// =================
// |	Players    |
// =================
		players = new ArrayList<Player>();
//		for (int i = 0; i < 10; i++) {
//			
//			String valueOfRandom = String.valueOf( Math.random() * 100 );
//			
//			System.out.println("TesteMB.OrderListBean(): " + valueOfRandom );
//			System.out.println("TesteMB.OrderListBean(): " + valueOfRandom.indexOf(".") );
//			System.out.println("TesteMB.OrderListBean(): " + valueOfRandom.substring(0, valueOfRandom.indexOf(".")  ) );
//			
//			players.add(new Player( Long.valueOf( i+1 ), "Messi", Long.valueOf( valueOfRandom.substring(0, valueOfRandom.indexOf(".")  ) ) ));
//		}
			String valueOfRandom = String.valueOf( Math.random() * 100 );
			players.add(new Player( Long.valueOf( valueOfRandom.substring(0, valueOfRandom.indexOf(".")  ) ), "Sepp Maier", 1L  ));
			
			valueOfRandom = String.valueOf( Math.random() * 100 );
			players.add(new Player( Long.valueOf( valueOfRandom.substring(0, valueOfRandom.indexOf(".")  ) ), "Djalma Santos", 2L  ));
			
			valueOfRandom = String.valueOf( Math.random() * 100 );
			players.add(new Player( Long.valueOf( valueOfRandom.substring(0, valueOfRandom.indexOf(".")  ) ), "Bobby Moore", 3L  ));
			
			valueOfRandom = String.valueOf( Math.random() * 100 );
			players.add(new Player( Long.valueOf( valueOfRandom.substring(0, valueOfRandom.indexOf(".")  ) ), "Franz Beckenbauer", 4L  ));
			
			valueOfRandom = String.valueOf( Math.random() * 100 );
			players.add(new Player( Long.valueOf( valueOfRandom.substring(0, valueOfRandom.indexOf(".")  ) ), "Nilton Santos", 6L  ));
			
			valueOfRandom = String.valueOf( Math.random() * 100 );
			players.add(new Player( Long.valueOf( valueOfRandom.substring(0, valueOfRandom.indexOf(".")  ) ), "Didi", 5L  ));
			
			valueOfRandom = String.valueOf( Math.random() * 100 );
			players.add(new Player( Long.valueOf( valueOfRandom.substring(0, valueOfRandom.indexOf(".")  ) ), "Puskas", 10L  ));
			
			valueOfRandom = String.valueOf( Math.random() * 100 );
			players.add(new Player( Long.valueOf( valueOfRandom.substring(0, valueOfRandom.indexOf(".")  ) ), "Garrincha", 7L  ));
			
			valueOfRandom = String.valueOf( Math.random() * 100 );
			players.add(new Player( Long.valueOf( valueOfRandom.substring(0, valueOfRandom.indexOf(".")  ) ), "Cruyff", 8L  ));
			
			valueOfRandom = String.valueOf( Math.random() * 100 );
			players.add(new Player( Long.valueOf( valueOfRandom.substring(0, valueOfRandom.indexOf(".")  ) ), "Pele", 9L  ));
			
			valueOfRandom = String.valueOf( Math.random() * 100 );
			players.add(new Player( Long.valueOf( valueOfRandom.substring(0, valueOfRandom.indexOf(".")  ) ), "Maradona", 11L  ));
		
// =================
// |	Account    |
// =================	
		accounts = new ArrayList<Account>();
		
		accounts.add( new Account("Caso1", 1111L) );
		accounts.add( new Account("Caso2", 1112L) );
		accounts.add( new Account("Caso3", 1113L) );
		accounts.add( new Account("Teste1", 2224L) );
		accounts.add( new Account("Teste2", 2225L) );
		accounts.add( new Account("Teste3", 2226L) );
		accounts.add( new Account("Mock1", 3337L) );
		accounts.add( new Account("Mock2", 3338L) );
		accounts.add( new Account("Mock3", 3339L) );
		accounts.add( new Account("Finito", 6666L) );
		
	}
	
	@Override
	public List<Account> getAccountByNameOrNumber(String query) {
		
		ArrayList<Account> result = new ArrayList<Account>();
		
		if ( query != null && !query.isEmpty() ){
			for (Account item : accounts) {
				
				if ( item.getName().contains( query ) ){
					result.add( item );
				}
				else
					if ( String.valueOf( item.getNumber() ).contains( query ) ){
						result.add( item );
					}
			}
		} else {
			result.addAll( accounts );
		}
		
		return result;
	}


	public ArrayList<Player> getPlayers() {
		return players;
	}


	public void setPlayers(ArrayList<Player> players) {
		Mock.players = players;
	}


	public static ArrayList<Account> getAccounts() {
		return accounts;
	}


	public static void setAccounts(ArrayList<Account> accounts) {
		Mock.accounts = accounts;
	}

}
