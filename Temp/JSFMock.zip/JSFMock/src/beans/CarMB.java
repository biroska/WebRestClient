package beans;

import java.util.ArrayList;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import model.Car;

@SessionScoped
@ManagedBean(name="carMB")
public class CarMB {
	
	private ArrayList<Car> cars = new ArrayList<Car>();
	
	public CarMB(){
		cars.add( new Car( String.valueOf( Math.random() ), "Yellow", 2007L ) );
		cars.add( new Car( String.valueOf( Math.random() ), "Yellow", 2007L ) );
		cars.add( new Car( String.valueOf( Math.random() ), "Orange", 2005L ) );
		cars.add( new Car( String.valueOf( Math.random() ), "Orange", 2005L ) );
		cars.add( new Car( String.valueOf( Math.random() ), "Brown",  2009L ) );
		cars.add( new Car( String.valueOf( Math.random() ), "Brown",  2009L ) );
		cars.add( new Car( String.valueOf( Math.random() ), "Gray",   2010L ) );
		cars.add( new Car( String.valueOf( Math.random() ), "Gray",   2010L ) );
		cars.add( new Car( String.valueOf( Math.random() ), "Blue",   2014L ) );
		cars.add( new Car( String.valueOf( Math.random() ), "Blue",   2014L ) );
	}

	public ArrayList<Car> getCars() {
		return cars;
	}

	public void setCars(ArrayList<Car> cars) {
		this.cars = cars;
	}
}