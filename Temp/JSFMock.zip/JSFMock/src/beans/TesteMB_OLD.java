package beans;

import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import mock.Mock;
import model.Account;
import model.Player;
import service.Facade;

@ManagedBean
@SessionScoped
public class TesteMB_OLD {

	private List<Player> players;
	private Player selectedPlayer;
	private Account selectedAccount;
	private String text;
	
	private Facade facade = new Mock();
	
	public TesteMB_OLD(){
		OrderListBean();
	}

	public void OrderListBean() {
		players = new ArrayList<Player>();
		for (int i = 0; i < 10; i++) {
			
			String valueOfRandom = String.valueOf( Math.random() * 100 );
			
			System.out.println("TesteMB.OrderListBean(): " + valueOfRandom );
			System.out.println("TesteMB.OrderListBean(): " + valueOfRandom.indexOf(".") );
			System.out.println("TesteMB.OrderListBean(): " + valueOfRandom.substring(0, valueOfRandom.indexOf(".")  ) );
			
			
			players.add(new Player("Messi", Long.valueOf( valueOfRandom.substring(0, valueOfRandom.indexOf(".")  ) ) ));
		}
	}
	
	public List<String> completeString(String query) {
		List<String> results = new ArrayList<String>();
		for (int i = 0; i < 10; i++)
			results.add(query + i);
		return results;
	}
	
	public List<Account> complete(String query) {

		List<Account> accountList = facade.getAccountByNameOrNumber( query );

		return accountList;
	}

	public List<Player> getPlayers() {
		return players;
	}

	public void setPlayers(List<Player> players) {
		this.players = players;
	}

	public Player getSelectedPlayer() {
		return selectedPlayer;
	}

	public void setSelectedPlayer(Player selectedPlayer) {
		this.selectedPlayer = selectedPlayer;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public Account getSelectedAccount() {
		return selectedAccount;
	}

	public void setSelectedAccount(Account selectedAccount) {
		this.selectedAccount = selectedAccount;
	}

}