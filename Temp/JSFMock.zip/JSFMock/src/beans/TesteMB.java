package beans;

import java.util.ArrayList;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

import mock.Mock;
import model.Account;
import model.Player;

import org.primefaces.event.CellEditEvent;

import service.Facade;

@SessionScoped
@ManagedBean(name="testeMB")
public class TesteMB {

	private List<Player> players;
	private Player selectedPlayer;
	private Account selectedAccount;
	private String text;
	
	private ArrayList<String> playersToFilter = new ArrayList<String>();
	
	private Facade facade = new Mock();
	
	public TesteMB(){
		
		players = new ArrayList<Player>( facade.getPlayers()  );
		playersToFilter = changeToArrayString( players );
	}

	public List<String> completeString(String query) {
		List<String> results = new ArrayList<String>();
		for (int i = 0; i < 10; i++)
			results.add(query + i);
		return results;
	}
	
	public List<Account> complete(String query) {

		List<Account> accountList = facade.getAccountByNameOrNumber( query );

		return accountList;
	}
	
	public void onCellEdit( CellEditEvent event ) {
		
        Object oldValue = event.getOldValue();
        Object newValue = event.getNewValue();
        
        int rowIndex = event.getRowIndex();
        
        Player player = players.get( rowIndex );
        
        players.get( rowIndex ).setName( players.get( rowIndex ).getName() + " Editado" );
         
        if( newValue != null && !newValue.equals(oldValue) ) {
            FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "player: " + player.getName() +  " Cell Changed", "Old: " + oldValue + ", New:" + newValue);
            FacesContext.getCurrentInstance().addMessage(null, msg);
        }
    }
	
	private ArrayList<String> changeToArrayString( List<Player> list ){
		ArrayList<String> stringList = new ArrayList<String>();
		
		for (Player item : list ) {
			stringList.add( item.getName() );
		}
		
		return stringList;
	}

	public List<Player> getPlayers() {
		return players;
	}

	public void setPlayers(List<Player> players) {
		this.players = players;
	}

	public Player getSelectedPlayer() {
		return selectedPlayer;
	}

	public void setSelectedPlayer(Player selectedPlayer) {
		this.selectedPlayer = selectedPlayer;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public Account getSelectedAccount() {
		return selectedAccount;
	}

	public void setSelectedAccount(Account selectedAccount) {
		this.selectedAccount = selectedAccount;
	}

	public ArrayList<String> getPlayersToFilter() {
		return playersToFilter;
	}

	public void setPlayersToFilter(ArrayList<String> playersToFilter) {
		this.playersToFilter = playersToFilter;
	}

}