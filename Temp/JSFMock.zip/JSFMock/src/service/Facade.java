package service;

import java.util.ArrayList;
import java.util.List;

import model.Account;
import model.Player;

public interface Facade {
	
	public List<Account> getAccountByNameOrNumber( String query );
	
	public ArrayList<Player> getPlayers();
	
}
