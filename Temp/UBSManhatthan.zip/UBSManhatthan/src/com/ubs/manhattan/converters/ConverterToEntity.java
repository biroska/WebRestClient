/**
 * 
 */
package com.ubs.manhattan.converters;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Level;

import com.ubs.manhattan.enums.ExecutionTypeEnum;
import com.ubs.manhattan.enums.OrderStatusEnum;
import com.ubs.manhattan.enums.OrderTypeEnum;
import com.ubs.manhattan.enums.SideEnum;
import com.ubs.manhattan.enums.StrategyTypeEnum;
import com.ubs.manhattan.enums.TimeInForceEnum;
import com.ubs.manhattan.logger.ManhattanLogger;
import com.ubs.manhattan.mocks.MarketDataMock;
import com.ubs.manhattan.network.client.NetworkProtobuf.pb_legged_order;
import com.ubs.manhattan.network.client.NetworkProtobuf.pb_report_order_message;
import com.ubs.manhattan.network.client.NetworkProtobuf.pb_report_strategy_message;
import com.ubs.manhattan.network.client.NetworkProtobuf.pb_strategy_body_report_message;
import com.ubs.manhattan.network.client.NetworkProtobuf.pb_strategy_leg_report_message;
import com.ubs.manhattan.network.client.NetworkProtobuf.pb_to_manager_message;
import com.ubs.manhattan.persistence.entities.ClientAccount;
import com.ubs.manhattan.persistence.entities.LegStrategyReport;
import com.ubs.manhattan.persistence.entities.OrderFixSession;
import com.ubs.manhattan.persistence.entities.OrderTrade;
import com.ubs.manhattan.persistence.entities.Strategy;
import com.ubs.manhattan.persistence.entities.StrategyOrders;
import com.ubs.manhattan.persistence.entities.StrategyReport;
import com.ubs.manhattan.utils.Util;

/**
 * @author galdinoa
 *
 */
public class ConverterToEntity {
	
	/**
	 * <p>
	 * The convertToManager is responsible for Conversion between 
	 * {@link pb_report_strategy_message} to {@link StrategyReport}.
	 * </p>
	 * 
	 * @author <a href="mailto:aimbere.galdino@ubs.com">Aimbere Galdino</a>
	 * @param <M>
	 *            contains the {@link pb_report_strategy_message}.
	 * @param <M>
	 *            contains the {@link engineId}.
	 * @param <E>
	 *            contains the {@link StrategyReport}.
	 * @since 1.7
	 */
	public static StrategyReport convertToStrategy ( long engineId, pb_report_strategy_message message ){
		
		if ( !message.isInitialized() ){
			ManhattanLogger.log( ""+Util.getManagerId(), "Protobuffer message 'pb_report_strategy_message' is not initialized", Level.ERROR );
			return null;
		}
		
		StrategyReport report = null;
		
//			Build the Strategy Report and Legs
			if ( message.isInitialized() ){
				
//				Translate the pb_strategy_body_report_message message to StrategyReport
				report = buildStrategyReport( message.getBody() );
				
//				Define the id of Strategy
				report.getId().setStrategyId( message.getStrategyId() );
				report.getId().setEngineId( engineId );
				report.getId().setStrategyDate( new Date() );
				
//				Build legStrategyReport from pb_strategy_leg_report_message
				List<LegStrategyReport> legStrategyReportList = buildLegStrategyReport( engineId, message.getLegsList() );
				
				for (LegStrategyReport legStrategyReport : legStrategyReportList) {
//				For each leg build the mapping between StrategyReport and LegStrategyReport
					legStrategyReport.getId().setStrategyId( report.getId().getStrategyId() );
					report.addLegStrategyReport( legStrategyReport );
				}
				
				return report;
			} 
		
		return null;
	}
	
	/**
	 * <p>
	 * The convertToStrategy is responsible for Conversion between 
	 * {@link pb_report_order_message} to {@link StrategyOrders}.
	 * </p>
	 * 
	 * @author <a href="mailto:aimbere.galdino@ubs.com">Aimbere Galdino</a>
	 * @param <M>
	 *            contains the {@link pb_report_order_message}.
	 * @param <E>
	 *            contains the {@link StrategyOrders}.
	 * @since 1.7
	 */
	public static StrategyOrders convertToStrategy ( long engineId, pb_report_order_message message ){
		
		if ( !message.isInitialized() ){
			ManhattanLogger.log( ""+Util.getManagerId(), "Protobuffer message 'pb_report_strategy_message' is not initialized", Level.ERROR );
			return null;
		}
		
		StrategyOrders order = null;
		
//		Build the Strategy Order
		order = convertToStrategyOrder( engineId, message );
			
		return order;
	}
	
	/**
	 * <p>
	 * The convertToManager is responsible for Conversion between 
	 * {@link pb_to_manager_message} to {@link StrategyReport}.
	 * </p>
	 * 
	 * @author <a href="mailto:aimbere.galdino@ubs.com">Aimbere Galdino</a>
	 * @param <M>
	 *            contains the {@link pb_to_manager_message}.
	 * @param <E>
	 *            contains the {@link StrategyReport}.
	 * @since 1.7
	 */
	public static Strategy convertToStrategy ( long engineId, pb_to_manager_message message ){
		
		if ( !message.isInitialized() ){
			ManhattanLogger.log( ""+Util.getManagerId(), "Protobuffer message 'pb_report_strategy_message' is not initialized", Level.ERROR );
			return null;
		}
		
//		Work only with messages of ReportStrategy and ReportOrder types
		if ( ( message.getReportStrategy() == null || !message.getReportStrategy().isInitialized() ) &&
				( message.getReportOrder() == null || !message.getReportOrder().isInitialized() )	){
			return null;
		}
		
		StrategyReport report = null;
		StrategyOrders order = null;
		
		if ( message.getHeader().isInitialized() ){
			
			// Get the engineId to build the strategyID
//			long engineInstanceId = message.getHeader().getEngineInstanceId();
			
//			Build the Strategy Report and Legs
			if ( message.getReportStrategy().isInitialized() ){
				
//				Translate the pb_strategy_body_report_message message to StrategyReport
				report = buildStrategyReport( message.getReportStrategy().getBody() );
				
//				Define the id of Strategy
				report.getId().setStrategyId( message.getReportStrategy().getStrategyId() );
				
//				Build legStrategyReport from pb_strategy_leg_report_message
				List<LegStrategyReport> legStrategyReportList = buildLegStrategyReport( engineId, message.getReportStrategy().getLegsList() );
				
				for (LegStrategyReport legStrategyReport : legStrategyReportList) {
//				For each leg build the mapping between StrategyReport and LegStrategyReport
					legStrategyReport.getId().setStrategyId( report.getId().getStrategyId() );
					report.addLegStrategyReport( legStrategyReport );
				}
				
				return report;
				
			} else
//				Build the Strategy Order
				if ( message.getReportOrder().isInitialized() ){
					order = convertToStrategyOrder( engineId, message.getReportOrder() );
				}
			return order;
		}
		
		return null;
	}
	
	
	/**
	 * <p>
	 * The convertToManager is responsible for Conversion between 
	 * {@link pb_strategy_body_report_message} to {@link StrategyReport}.
	 * </p>
	 * 
	 * @author <a href="mailto:aimbere.galdino@ubs.com">Aimbere Galdino</a>
	 * @param <M>
	 *            contains the {@link pb_strategy_body_report_message}.
	 * @param <E>
	 *            contains the {@link StrategyReport}.
	 * @since 1.7
	 */
	public static StrategyReport buildStrategyReport ( pb_strategy_body_report_message message ){
		
		if ( !message.isInitialized() ){
			ManhattanLogger.log( ""+Util.getManagerId(), "Protobuffer message 'pb_strategy_body_parameters_message' is not initialized", Level.ERROR );
			return null;
		}
		
		StrategyReport report = new StrategyReport();
		
		report.setLogin( message.getLogin() );
		report.setStartTime( Util.microSegundosToDate( message.getStartTime() ) );
		report.setEndTime( Util.microSegundosToDate( message.getEndTime() ) );
		report.setExecutedPercentage( message.getExecutedPercentage() );
		report.setExecutedTarget( message.getTargetExecuted() );
		report.setStrategyType( StrategyTypeEnum.fromValue( message.getStrategyType().getNumber() ) );
		report.setStartPaused( message.getStartPaused() );
		report.setText( message.getText() ) ;
		report.setPriceLimit( message.getPriceLimit() );
		report.setTarget( message.getTarget() );
		report.setAgressiviness( message.getAgressiviness() );
		report.setRiskLevel( message.getRiskLevel() );
		report.setRestingLevel( message.getRestingLevel() );
		
		return report;
	}
	
	/**
	 * <p>
	 * The convertToManager is responsible for Conversion between 
	 * {@link List<pb_strategy_leg_report_message>} to {@link List<LegStrategyReport>}.
	 * </p>
	 * 
	 * @author <a href="mailto:aimbere.galdino@ubs.com">Aimbere Galdino</a>
	 * @param <M>
	 *            contains the {@link List<pb_strategy_leg_report_message>}.
	 * @param <E>
	 *            contains the {@link List<LegStrategyReport>}.
	 * @since 1.7
	 */
	public static List<LegStrategyReport> buildLegStrategyReport (long engineId, List<pb_strategy_leg_report_message> pbLegsMessage ){
		
		List<LegStrategyReport> legs = null;
		
		if ( pbLegsMessage == null || pbLegsMessage.isEmpty() ){
			return null;
		}
		
		legs = new ArrayList<LegStrategyReport>();
		
		for (pb_strategy_leg_report_message pbLeg : pbLegsMessage) {
			legs.add( convertToManager ( engineId, pbLeg ) );
		}
		
		return legs;
	}
	
	/**
	 * <p>
	 * The convertToManager is responsible for Conversion between 
	 * {@link pb_strategy_leg_report_message} to {@link LegStrategyReport}.
	 * </p>
	 * 
	 * @author <a href="mailto:aimbere.galdino@ubs.com">Aimbere Galdino</a>
	 * @param <M>
	 *            contains the {@link pb_strategy_leg_report_message}.
	 * @param <E>
	 *            contains the {@link LegStrategyReport}.
	 * @since 1.7
	 */
	public static LegStrategyReport convertToManager (long engineId, pb_strategy_leg_report_message pbLegMessage ){
		
		if ( !pbLegMessage.isInitialized() ){
			return null;
		}
		
		LegStrategyReport leg = new LegStrategyReport();
		
		leg.getId().setLegSeq( pbLegMessage.getLegSeq() );
		leg.getId().setEngineId( engineId );
		leg.getId().setStrategyDate( new Date() );
//		leg.getId().setStrategyId( pbLegMessage.get );
		
		
		leg.setInstrument( pbLegMessage.getInstrument() );
		leg.setTotalQuantity( pbLegMessage.getTotalQuantity() );
		leg.setExecutedPercentage( pbLegMessage.getExecutedPercentage() );
		leg.setRemainingQuantity( pbLegMessage.getRemainingQuantity() );
		leg.setExecutedQuantity( pbLegMessage.getExecutedQuantity() );
		leg.setAveragePrice( pbLegMessage.getAveragePrice() );
		leg.setText( pbLegMessage.getText() );
		leg.setSide( SideEnum.fromValue( pbLegMessage.getSide().getNumber() ) );
		leg.setRouteId( pbLegMessage.getRouteId() == 0 ? null : new OrderFixSession( pbLegMessage.getRouteId() ) );
		leg.setOrderType( OrderTypeEnum.fromValue( pbLegMessage.getOrderType().getNumber() ) );
		leg.setTimeInForce( TimeInForceEnum.fromValue( pbLegMessage.getTimeInForce().getNumber() ) );
		leg.setAccount( pbLegMessage.getAccount() == 0 ? null : new ClientAccount( pbLegMessage.getAccount() ) );
		leg.setPassiveLeg( pbLegMessage.getPassiveLeg() );
		leg.setMaxQuantityDisplay( pbLegMessage.getMaxQuantityDisplay() );
		leg.setMinQuantityDisplay( pbLegMessage.getMinQuantityDisplay() );
		leg.setRestingQuantity( pbLegMessage.getRestingQuantity() );
		leg.setRestingPrice( pbLegMessage.getRestingPrice() );
		leg.setRestingRank( (long) pbLegMessage.getRestingRank() );
		leg.setTimeOut( (long) pbLegMessage.getTimeOut() );
		leg.setInvestorId( pbLegMessage.getInvestorId() );
		leg.setEnteringTrader( pbLegMessage.getEnteringTrader() );
		leg.setDuration( pbLegMessage.getDuration() );
		
		return leg;
	}
	
	/**
	 * <p>
	 * The convertToManager is responsible for Conversion between 
	 * {@link pb_report_order_message} to {@link LegStrategyReport}.
	 * </p>
	 * 
	 * @author <a href="mailto:aimbere.galdino@ubs.com">Aimbere Galdino</a>
	 * @param <M>
	 *            contains the {@link pb_strategy_leg_report_message}.
	 * @param <E>
	 *            contains the {@link LegStrategyReport}.
	 * @since 1.7
	 */
	public static StrategyOrders convertToStrategyOrder ( long engineId, pb_report_order_message orderMessage ){
		
		if ( !orderMessage.isInitialized() ){
			return null;
		}
		
		StrategyOrders order = new StrategyOrders();
		
		LegStrategyReport legReport = new LegStrategyReport();
		legReport.getId().setLegSeq( orderMessage.getLegSeq() );
		legReport.getId().setStrategyId( orderMessage.getStrategyId() );
		
		
		order.getId().setOrderId( orderMessage.getOrderId() );
		order.getId().setEngineId( engineId );
		order.getId().setOrderDate( new Date() );
		
		order.setLegStrategyReport( legReport );
		order.setExecutedQuantity( orderMessage.getExecutedQuantity() );
		order.setAveragePrice( orderMessage.getAveragePrice() );
		order.setSymbol( MarketDataMock.getSymbol( orderMessage.getInstrument() ) );
		order.setSide( SideEnum.fromValue( orderMessage.getSide().getNumber() ) );
		order.setQuantity( orderMessage.getQuantity() );
		order.setRemainingQuantity( orderMessage.getRemainingQuantity() );
		order.setRouteId( orderMessage.getRouteId() == 0 ? null : new OrderFixSession( orderMessage.getRouteId() ) );
		order.setOrderType( OrderTypeEnum.fromValue( orderMessage.getOrderType().getNumber() ) );
		order.setTimeInForce( TimeInForceEnum.fromValue( orderMessage.getTimeInForce().getNumber() ) );
		order.setAccount( orderMessage.getAccount() == 0 ? null : new ClientAccount( (long) orderMessage.getAccount() ) );
//		order.setClient( orderMessage.getClientOrderId() != null && orderMessage.getClientOrderId().isEmpty() ? null : new Client( Long.valueOf( orderMessage.getClientOrderId() ) ) );
		order.setOrderStatus( OrderStatusEnum.fromValue( orderMessage.getOrderStatus().getNumber() ) );
		order.setExecutionType( ExecutionTypeEnum.fromValue( orderMessage.getExecutionType().getNumber() ) );
		order.setPrice( orderMessage.getPrice() );
		
		order.setTradeId( orderMessage.getUniqueTradeId() );

		return order;
	}
	
	/**
	 * <p>
	 * The convertToManager is responsible for Conversion between 
	 * {@link pb_report_order_message} to {@link LegStrategyReport}.
	 * </p>
	 * 
	 * @author <a href="mailto:aimbere.galdino@ubs.com">Aimbere Galdino</a>
	 * @param <M>
	 *            contains the {@link pb_strategy_leg_report_message}.
	 * @param <E>
	 *            contains the {@link LegStrategyReport}.
	 * @since 1.7
	 */
	public static StrategyOrders convertToStrategyOrder( pb_legged_order leggedOrder ){
		
		if ( !leggedOrder.isInitialized() ){
			return null;
		}
		
		StrategyOrders order = new StrategyOrders();
		
		LegStrategyReport legReport = new LegStrategyReport();
		
		legReport.getId().setLegSeq( leggedOrder.getLegSeq() );
		legReport.getId().setStrategyId( leggedOrder.getStrategyId() );
		order.setLegStrategyReport( legReport );
		
		order.getId().setOrderId( leggedOrder.getOrderId() );
		order.setPrice( leggedOrder.getPrice() );
		order.setMarket( leggedOrder.getMarket() );
		
		return order;
	}
	
	/**
	 * <p>
	 * The convertToOrderTrade is responsible for Conversion between 
	 * {@link StrategyOrders} to {@link OrderTrade}.
	 * </p>
	 * 
	 * @author <a href="mailto:aimbere.galdino@ubs.com">Aimbere Galdino</a>
	 * @param <M>
	 *            contains the {@link StrategyOrders}.
	 * @param <E>
	 *            contains the {@link OrderTrade}.
	 * @since 1.7
	 */
	public static OrderTrade convertToOrderTrade( StrategyOrders order ){
		
		if ( order == null ){
			return null;
		}
		
		OrderTrade orderTrade = new OrderTrade();
		
		orderTrade.setStrategyOrder( order );
		orderTrade.setOrderStatus( order.getOrderStatus() );
		orderTrade.setSymbol( order.getSymbol() );
		orderTrade.setSide( order.getSide() );
		orderTrade.setAccount( order.getAccount() );
		orderTrade.setTradeId( order.getTradeId() );
		orderTrade.setQuantity( order.getQuantity() );
		orderTrade.setPrice( order.getPrice() );
		orderTrade.setTradeId( order.getTradeId() );

		return orderTrade;
	}

}
