/**
 * 
 */
package com.ubs.manhattan.converters;

import org.apache.commons.lang.StringUtils;

import com.ubs.manhattan.enums.CommandTypeEnum;
import com.ubs.manhattan.mocks.MarketDataMock;
import com.ubs.manhattan.network.client.NetworkProtobuf.pb_command_message;
import com.ubs.manhattan.network.client.NetworkProtobuf.pb_command_type_enum;
import com.ubs.manhattan.network.client.NetworkProtobuf.pb_create_modify_cancel_strategy_message;
import com.ubs.manhattan.network.client.NetworkProtobuf.pb_execution_type_enum;
import com.ubs.manhattan.network.client.NetworkProtobuf.pb_header_message;
import com.ubs.manhattan.network.client.NetworkProtobuf.pb_legged_order;
import com.ubs.manhattan.network.client.NetworkProtobuf.pb_message_type_enum;
import com.ubs.manhattan.network.client.NetworkProtobuf.pb_new_order_single_message;
import com.ubs.manhattan.network.client.NetworkProtobuf.pb_order_status_enum;
import com.ubs.manhattan.network.client.NetworkProtobuf.pb_order_type_enum;
import com.ubs.manhattan.network.client.NetworkProtobuf.pb_report_order_message;
import com.ubs.manhattan.network.client.NetworkProtobuf.pb_side_enum;
import com.ubs.manhattan.network.client.NetworkProtobuf.pb_strategy_body_parameters_message;
import com.ubs.manhattan.network.client.NetworkProtobuf.pb_strategy_leg_parameters_message;
import com.ubs.manhattan.network.client.NetworkProtobuf.pb_strategy_type_enum;
import com.ubs.manhattan.network.client.NetworkProtobuf.pb_time_in_force_enum;
import com.ubs.manhattan.network.client.NetworkProtobuf.pb_to_engine_message;
import com.ubs.manhattan.persistence.entities.CommandMessage;
import com.ubs.manhattan.persistence.entities.Header;
import com.ubs.manhattan.persistence.entities.LegStrategyReport;
import com.ubs.manhattan.persistence.entities.StrategyOrders;
import com.ubs.manhattan.persistence.entities.StrategyReport;

/**
 * @author galdinoa
 *
 */
public class ConvertToProtobuffer {

	/**
	 * <p>
	 * The convertToStrategy is responsible for Conversion from 
	 * {@link StrategyReport} to {@link pb_create_modify_cancel_strategy_message}.
	 * </p>
	 * 
	 * @author <a href="mailto:aimbere.galdino@ubs.com">Aimbere Galdino</a>
	 * @param <M>
	 *            contains the {@link StrategyReport}.
	 * @param <E>
	 *            contains the {@link pb_create_modify_cancel_strategy_message}.
	 * @since 1.7
	 */
	public static pb_to_engine_message convertToStrategy ( StrategyReport message ){
		
		pb_to_engine_message pbEngineMessage = null;
		
		if ( message != null ){
			
			pb_header_message pbHeader = convertToHeader( message.getHeader() );
			
			pb_strategy_leg_parameters_message pbStrategyLeg = null;
		
			pb_strategy_body_parameters_message.Builder createBuilder = pb_strategy_body_parameters_message.newBuilder()
											                    .setLogin( message.getLogin() )
											                    .setStartTime( message.getStartTime().getTime() )
											                    .setEndTime( message.getEndTime().getTime() )
											                    .setStrategyType( pb_strategy_type_enum.valueOf( message.getStrategyType().getCode() ) )
											                    .setStartPaused( message.getStartPaused() );
			
			if ( message.getPriceLimit() != null )
				createBuilder.setPriceLimit( message.getPriceLimit() );
			
			if ( message.getTarget() != null )
				createBuilder.setTarget( message.getTarget() );
			
			if ( message.getAgressiviness() != null )
				createBuilder.setAgressiviness( message.getAgressiviness() );
			
			if ( message.getRiskLevel() != null )
				createBuilder.setRiskLevel( message.getRiskLevel() );
			
			if ( message.getRestingLevel() != null )
				createBuilder.setRestingLevel( message.getRestingLevel() );
			
			pb_strategy_body_parameters_message pbStrategyBody = createBuilder.build();
			
			pb_create_modify_cancel_strategy_message.Builder msgCreateBuilder = pb_create_modify_cancel_strategy_message.newBuilder().setBody( pbStrategyBody );
			
			if ( message.getLegStrategyList() != null && !message.getLegStrategyList().isEmpty() ){
				
				for (LegStrategyReport leg : message.getLegStrategyList()) {
					
					pb_strategy_leg_parameters_message.Builder legBuilder = pb_strategy_leg_parameters_message.newBuilder();
					
					legBuilder.setLegSeq( leg.getId().getLegSeq() )
	                          .setInstrument( leg.getInstrument() )
	                          .setTotalQuantity( leg.getTotalQuantity() )
	                          .setSide( pb_side_enum.valueOf( leg.getSide().getCode() ) ) 
	                          .setRouteId( leg.getRouteId().getId()  )
	                          .setOrderType( pb_order_type_enum.valueOf( leg.getOrderType().getCode() ) )
	                          .setTimeInForce( pb_time_in_force_enum.valueOf( leg.getTimeInForce().getCode() ) )
	                          .setAccount( leg.getAccount().getCode() )
	                          .setPassiveLeg( leg.getPassiveLeg() );
//	                          .setMinQuantityDisplay( leg.getMinQuantityDisplay() )
//	time_out
	                  
	                if ( leg.getMaxQuantityDisplay() != null )
	                	legBuilder.setMaxQuantityDisplay( leg.getMaxQuantityDisplay() );
	                          	                
                    if ( leg.getDuration() != null )
                    	legBuilder.setDuration( leg.getDuration() );
	                          
					if ( StringUtils.isNotBlank( leg.getInvestorId() ) )
						legBuilder.setInvestorId( leg.getInvestorId() );
					
					if ( StringUtils.isNotBlank( leg.getEnteringTrader() ) )
						legBuilder.setEnteringTrader( leg.getEnteringTrader() );
						
					pbStrategyLeg = legBuilder.build();

					msgCreateBuilder.addLegs( pbStrategyLeg );
				}
			}

			msgCreateBuilder.setStrategyId( message.getId().getStrategyId() );
			
			pb_create_modify_cancel_strategy_message pbStrategy = msgCreateBuilder.build();
			
			pbEngineMessage = pb_to_engine_message.newBuilder()
								.setHeader( pbHeader )
								.setStrategy( pbStrategy )
								.build();
		}
		
		return pbEngineMessage;
	}
	
	/**
	 * <p>
	 * The convertToNewOrderSingle is responsible for Conversion from 
	 * {@link StrategyOrders} to {@link pb_new_order_single_message}.
	 * </p>
	 * 
	 * @author <a href="mailto:aimbere.galdino@ubs.com">Aimbere Galdino</a>
	 * @param <M>
	 *            contains the {@link StrategyOrders}.
	 * @param <E>
	 *            contains the {@link pb_new_order_single_message}.
	 * @since 1.7
	 */
	public static pb_to_engine_message convertToNewOrderSingle ( StrategyOrders order ){
		
		pb_to_engine_message pbEngineMessage = null;
		
		if ( order != null ){
			
			pb_header_message pbHeader = convertToHeader( order.getHeader() );
			
			pb_new_order_single_message.Builder msgCreateBuilder = pb_new_order_single_message.newBuilder();
			
			msgCreateBuilder.setInstrument( MarketDataMock.getInstrument( order.getSymbol() ) )
							.setSide( pb_side_enum.valueOf( order.getSide().getCode() ) )
							.setRouteId( order.getRouteId().getId()  )
				            .setOrderType( pb_order_type_enum.valueOf( order.getOrderType().getCode() ))
				            .setTimeInForce( pb_time_in_force_enum.valueOf( order.getTimeInForce().getCode() ))
				            .setAccount( order.getAccount().getCode() );
			
			if ( order.getId() != null && order.getId().getOrderId() != null )
				msgCreateBuilder.setOrderId( order.getId().getOrderId() );
			
			if ( order.getPrice() != null )
				msgCreateBuilder.setPrice( order.getPrice() );
			
			if ( order.getLegStrategyReport() != null ){
			
				if ( StringUtils.isNotBlank( order.getLegStrategyReport().getInvestorId() ) )
					msgCreateBuilder.setInvestorId( order.getLegStrategyReport().getInvestorId() );
				
				if ( StringUtils.isNotBlank( order.getLegStrategyReport().getEnteringTrader() ) )
					msgCreateBuilder.setEnteringTrader( order.getLegStrategyReport().getEnteringTrader() );
					
				if ( order.getLegStrategyReport().getMinQuantityDisplay() != null )
					msgCreateBuilder.setMinQuantity( order.getLegStrategyReport().getMinQuantityDisplay() );				
				
				if ( StringUtils.isNotBlank( order.getLegStrategyReport().getText() ) )
					msgCreateBuilder.setMemo( order.getLegStrategyReport().getText() );
			}

//	Campos n�o necess�rios
//			                    .setMaxFloor( legStrategy.getMaxQuantityDisplay() )
//			                    .setStopPrice( legStrategy.get )
			pb_new_order_single_message pbNewOrderSingle = msgCreateBuilder.build();
			
			pbEngineMessage = pb_to_engine_message.newBuilder()
								.setHeader( pbHeader )
								.setNewOrder( pbNewOrderSingle )
								.build();
		}
		
		return pbEngineMessage;
	}
	
	/**
	 * <p>
	 * The convertToReportOrder is responsible for Conversion from 
	 * {@link StrategyOrders} to {@link pb_report_order_message}.
	 * </p>
	 * 
	 * @author <a href="mailto:aimbere.galdino@ubs.com">Aimbere Galdino</a>
	 * @param <M>
	 *            contains the {@link StrategyOrders}.
	 * @param <E>
	 *            contains the {@link pb_report_order_message}.
	 * @since 1.7
	 */
	public static pb_to_engine_message convertToReportOrder( StrategyOrders order ){
		
		pb_to_engine_message pbEngineMessage = null;
		
		if ( order != null ){
			
			pb_header_message pbHeader = convertToHeader( order.getHeader() );
			
			pb_report_order_message.Builder builder = pb_report_order_message.newBuilder();
			
			builder.setStrategyId( order.getStrategyId() )
				   .setLegSeq( order.getLegSeq() )
				   .setInstrument( MarketDataMock.getInstrument( order.getSymbol() ) )
				   .setExecutedQuantity( order.getExecutedQuantity() )
				   .setAveragePrice( order.getAveragePrice() )
				   .setSide( pb_side_enum.valueOf( order.getSide().getCode() ) );

			if ( order.getId().getOrderId() != null )
				builder.setOrderId( order.getId().getOrderId() );
			
			if ( order.getQuantity() != null )
				builder.setQuantity( order.getQuantity() );
			
			if ( order.getRemainingQuantity() != null )
				builder.setRemainingQuantity( order.getRemainingQuantity() );
			
			if ( order.getRouteId() != null && order.getRouteId().getId() != null )
				builder.setRouteId( order.getRouteId().getId() );
			
			if ( order.getOrderType() != null && pb_order_type_enum.valueOf( order.getOrderType().getCode() ) != null )
				builder.setOrderType( pb_order_type_enum.valueOf( order.getOrderType().getCode() ) );
			
			if ( order.getTimeInForce() != null && pb_time_in_force_enum.valueOf( order.getTimeInForce().getCode() ) != null )
				builder.setTimeInForce( pb_time_in_force_enum.valueOf( order.getTimeInForce().getCode() ) );
			
			if ( order.getAccount() != null && order.getAccount().getCode() != null )
				builder.setAccount( order.getAccount().getCode() );
			
			if ( order.getOrderStatus() != null && pb_order_status_enum.valueOf( order.getOrderStatus().getCode() ) != null )
				builder.setOrderStatus( pb_order_status_enum.valueOf( order.getOrderStatus().getCode() ) );
			
			if ( order.getExecutionType() != null && pb_execution_type_enum.valueOf( order.getExecutionType().getCode() ) != null )
				builder.setExecutionType( pb_execution_type_enum.valueOf( order.getExecutionType().getCode() ) );
			
			if ( order.getPrice() != null )
				builder.setPrice( order.getPrice() );
			
			if ( StringUtils.isNotBlank( order.getClientOrderId() ) )
				builder.setClientOrderId( order.getClientOrderId() );
			
//			Campos n�o necess�rios
//			builder.setLastQuantity(value)
//			builder.setLastPrice(value)
//			builder.setUniqueTradeId(value)
			
			pb_report_order_message pbReportOrder = builder.build();
			
			pbEngineMessage = pb_to_engine_message.newBuilder()
								.setHeader( pbHeader )
								.setReportOrder( pbReportOrder )
								.build();
		}
		
		return pbEngineMessage;
	}
	
	/**
	 * <p>
	 * The convertToCommandMessage is responsible for Conversion from 
	 * {@link CommandTypeEnum} to {@link pb_to_engine_message}.
	 * </p>
	 * 
	 * @author <a href="mailto:aimbere.galdino@ubs.com">Aimbere Galdino</a>
	 * @param <M>
	 *            contains the {@link CommandTypeEnum}.
	 * @param <E>
	 *            contains the {@link pb_command_message}.
	 * @since 1.7
	 */
	public static pb_to_engine_message convertToCommandMessage ( CommandMessage commandMessage ){
		
		pb_to_engine_message pbEngineMessage = null;
		
		if ( commandMessage.getCommandType() != null ){
			
			pb_command_message pbCommandMessage = null;
			
			pb_header_message pbHeader = convertToHeader( commandMessage.getHeader() );
			
			pbCommandMessage = pb_command_message.newBuilder()
								.setCommandType( pb_command_type_enum.valueOf( commandMessage.getCommandType().getCode() ) )
								.build();
			
			pbEngineMessage = pb_to_engine_message.newBuilder()
								.setHeader( pbHeader )
								.setCommandMessage( pbCommandMessage )
								.build();
		}
		
		return pbEngineMessage;
	}
	
	/**
	 * <p>
	 * The convertToLeggedOrder is responsible for Conversion from 
	 * {@link StrategyOrders} to {@link pb_to_engine_message}.
	 * </p>
	 * 
	 * @author <a href="mailto:aimbere.galdino@ubs.com">Aimbere Galdino</a>
	 * @param <M>
	 *            contains the {@link StrategyOrders}.
	 * @param <E>
	 *            contains the {@link pb_to_engine_message}.
	 * @since 1.7
	 */
	public static pb_to_engine_message convertToLeggedOrder ( StrategyOrders order ){
		
		pb_to_engine_message pbEngineMessage = null;
		
		if ( order != null ){
			
			pb_header_message pbHeader = convertToHeader( order.getHeader() );
			
			pb_legged_order pbLeggedOrder = pb_legged_order.newBuilder()
											.setStrategyId( order.getLegStrategyReport().getId().getStrategyId() )
											.setLegSeq( order.getLegStrategyReport().getId().getLegSeq() )
											.setOrderId( order.getId().getOrderId() )
											.setPrice( order.getPrice() == null ? 0 : order.getPrice() )
											.setMarket( order.isMarket() )
										    .build();
			
			pbEngineMessage = pb_to_engine_message.newBuilder()
								.setHeader( pbHeader )
								.setLeggedMessage( pbLeggedOrder )
								.build();
		}
		
		return pbEngineMessage;
	}
	
	private static pb_header_message convertToHeader ( Header header){
		
		pb_header_message pbHeader = pb_header_message.newBuilder()
										.setEngineInstanceId( header.getEngineInstanceId() )
										.setManagerInstanceId( header.getManagerInstanceId() )
										.setManagerRequestId( header.getManagerRequestId() )
										.setMessageType( pb_message_type_enum.valueOf( header.getMessageType().getCode() ) )
										.build();
		
		return pbHeader;
	}
}