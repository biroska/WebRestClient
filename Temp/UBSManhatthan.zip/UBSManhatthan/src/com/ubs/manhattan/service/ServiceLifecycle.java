/*
 * ServiceLifecycle.java
 *
 *  Created on: Set 25, 2015
 *      Author: pretof
 */

package com.ubs.manhattan.service;

public interface ServiceLifecycle {

	/**
	 * This method is called when the service is loaded for the first time
	 */
	boolean onLoad() throws ServiceException;
	
	/**
	 * This method is called when the service is unloaded 
	 */
	boolean onUnLoad() throws ServiceException;
	
	/**
	 * This method is called when the service is started
	 */
	boolean onStart() throws ServiceException;
	
	/**
	 * 	This methos is called when the service should stop
	 */
	boolean onStop() throws ServiceException;

}
