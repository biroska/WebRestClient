package com.ubs.manhattan.mocks;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import com.ubs.manhattan.persistence.entities.Exchange;
import com.ubs.manhattan.persistence.entities.OrderFixSession;
import com.ubs.manhattan.persistence.factory.FactoryManager;

public class OrderFixSessionsMock {
	
	long idGenerico;
	
	private ExchangeMock exchangeMock = new ExchangeMock();
	
	public OrderFixSessionsMock(){
		idGenerico = System.currentTimeMillis();
	}
	
	public List<OrderFixSession> insert( int qtd ){
		
		ArrayList<OrderFixSession> fixSessions = new ArrayList<OrderFixSession>();
		
		List<Exchange> allExchanges = exchangeMock.getAllExchanges();
		
		for ( int i = 0; i<= qtd; i++ )
			fixSessions.add( new OrderFixSession( allExchanges.get( i % 2 ), "255.255.255." + i, 8070L + i, "BVMF_" + i, "UBS_" + i, "123456", "description" ) );
		
		return fixSessions;
	}
	
	public OrderFixSession getFirstClient( int index ) {

		CriteriaBuilder criteriaBuilder = FactoryManager.getEntityManager().getCriteriaBuilder();
		
		CriteriaQuery<OrderFixSession> criteriaQuery = criteriaBuilder.createQuery(OrderFixSession.class);
		Root<OrderFixSession> fixSessionsRoot = criteriaQuery.from(OrderFixSession.class);

		criteriaQuery.select( fixSessionsRoot );

		List<OrderFixSession> fixSessions = FactoryManager.getEntityManager().createQuery(criteriaQuery).getResultList();

		return fixSessions.get( index );
	}
}