package com.ubs.manhattan.mocks;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import com.ubs.manhattan.enums.ExecutionTypeEnum;
import com.ubs.manhattan.enums.OrderStatusEnum;
import com.ubs.manhattan.enums.OrderTypeEnum;
import com.ubs.manhattan.enums.SideEnum;
import com.ubs.manhattan.enums.TimeInForceEnum;
import com.ubs.manhattan.persistence.dao.ClientAccountDAO;
import com.ubs.manhattan.persistence.dao.OrderFixSessionDAO;
import com.ubs.manhattan.persistence.entities.ClientAccount;
import com.ubs.manhattan.persistence.entities.LegStrategyReport;
import com.ubs.manhattan.persistence.entities.OrderFixSession;
import com.ubs.manhattan.persistence.entities.StrategyOrders;
import com.ubs.manhattan.persistence.entities.StrategyReport;
import com.ubs.manhattan.persistence.factory.FactoryManager;

public class StrategyWithLegsMock {
	
	private Random random;
	private long idGenerico;
	
	private CriteriaBuilder criteriaBuilder =  FactoryManager.getEntityManager().getCriteriaBuilder();
	
//	Instancia os MOCKs
	private OrderFixSessionDAO orderFixSessionDAO = new OrderFixSessionDAO();
	private ClientAccountDAO clientAccountDAO = new ClientAccountDAO();
	
//	Instancias os objetos default
	private OrderFixSession fixSession = orderFixSessionDAO.getByIndex( 3 );
	private ClientAccount clientAccount = clientAccountDAO.getByIndex( 5 );
//	private Client client = clienteDAO.getByIndex( 4 );
	
	public StrategyWithLegsMock(){
		random = new Random();
		idGenerico = System.currentTimeMillis();
	}
	
	public StrategyReport insert( int legQtd ){
		
		StrategyReport strategy = new StrategyReport();
		strategy.setLegStrategyList( new ArrayList<LegStrategyReport>() );

//		StrategyReport fields
		strategy.getId().setStrategyId( idGenerico++ );
		strategy.setStrategyTimestamp( new Date() );
		strategy.setLogin( "AIM*" );
		strategy.setStartTime( new Date() );
		strategy.setEndTime( new Date() );
		strategy.setStartPaused( (long) random.nextInt( 1000 ) % 2 == 0 );
		strategy.setTarget( random.nextDouble() );
		strategy.setExecutedPercentage( random.nextDouble() );
		strategy.setExecutedTarget( random.nextDouble() );
		strategy.setText( "Random Text" + random.nextGaussian() );	
		strategy.setPriceLimit( random.nextDouble() );
		strategy.setAgressiviness( random.nextDouble() );
		strategy.setRiskLevel( random.nextInt( 1000 ) );
		
//		LegStrategyReport fields
		for (int i = 1; i <= legQtd; i++) {
			LegStrategyReport leg = new LegStrategyReport();
			
			leg.getId().setLegSeq( i );
			leg.getId().setStrategyId( strategy.getId().getStrategyId() );
			
			leg.setInstrument( (long) random.nextInt( 1000 )  );
			leg.setTotalQuantity((long) random.nextInt( 1000 )  );
			
			leg.setExecutedPercentage( random.nextDouble() );
			leg.setRemainingQuantity( (long) random.nextInt( 1000 )  );
			leg.setExecutedQuantity( (long) random.nextInt( 1000 )  );
			leg.setAveragePrice( random.nextDouble() );
			leg.setText( "Random Text" + random.nextGaussian() );
			leg.setSide( SideEnum.SELL  );
			leg.setRouteId( fixSession );
			leg.setOrderType( OrderTypeEnum.LIMIT );
			leg.setTimeInForce( TimeInForceEnum.DAY );
			leg.setAccount( clientAccount );
			leg.setPassiveLeg( i % 2 == 0 );
			leg.setMaxQuantityDisplay( (long) random.nextInt( 1000 ) );
			leg.setMinQuantityDisplay( (long) random.nextInt( 1000 ) );
			leg.setRestingQuantity( (long) random.nextInt( 1000 ) );
			leg.setRestingPrice( random.nextDouble() );
			leg.setRestingRank( (long) random.nextInt( 1000 ) );
			leg.setTimeOut( (long) random.nextInt( 1000 ) );
			leg.setInvestorId( "Investor Id" );
			leg.setEnteringTrader( "eTrader" );
			
//			Seta o relacionamento entre as entidades
			strategy.addLegStrategyReport( leg );
		}
		
		return strategy;
	}
	
	public StrategyReport loadStrategyReportMock( Long strategyId ){
		
		CriteriaQuery<StrategyReport> criteriaQuery = criteriaBuilder.createQuery( StrategyReport.class );
		Root<StrategyReport> strategyRoot = criteriaQuery.from( StrategyReport.class );
		
		criteriaQuery.select( strategyRoot );
		criteriaQuery.where( criteriaBuilder.equal( strategyRoot.get("strategyId") , strategyId ) );
		
		List<StrategyReport> strategy = FactoryManager.getEntityManager().createQuery( criteriaQuery ).getResultList();
		
		return strategy.get( 0 );
	}
	
	public StrategyReport updateStrategyReportMock( Long strategyId ){
		
		ClientAccount clientsAccounts = clientAccountDAO.getByIndex( 7 );
		
		StrategyReport strategy = loadStrategyReportMock( strategyId );
		
//		StrategyReport fields
		strategy.setText( "Alterado " + random.nextGaussian() );
		
//		LegStrategyReport fields
		for (LegStrategyReport leg : strategy.getLegStrategyList() ) {
			leg.setText( "Alterado " + random.nextGaussian() );
			leg.setOrderType( OrderTypeEnum.STOP_LOSS );
			leg.setTimeInForce( TimeInForceEnum.GOOD_TILL_DATE );
			leg.setAccount( clientsAccounts );
			leg.setInvestorId( "Alterado Investor Id" );
			leg.setEnteringTrader( "Alterado" );
		}
		
		return strategy;
	}
	
	public StrategyReport generateOrders( StrategyReport strategy ){
		
		if( strategy != null && strategy.getLegStrategyList() != null ){
			
			for (LegStrategyReport leg : strategy.getLegStrategyList() ) {
				
				for (int i = 1; i <= 1000; i++) {
					StrategyOrders order = new StrategyOrders();
					
					order.setOrderTimestamp( new Date() );
					order.setLegStrategyReport( leg );
					order.setExecutedQuantity( (long) random.nextInt( 1000 ) );
					order.setAveragePrice( random.nextDouble() );
					order.setSide( SideEnum.SELL ); // N�o pode ser Injetado pelo m�todo add da Leg, tem que gravar o que vier
					order.getId().setOrderId( idGenerico );
					order.setRemainingQuantity( (long) random.nextInt( 1000 ) );
					order.setRouteId( fixSession );  // N�o pode ser Injetado pelo m�todo add da Leg, tem que gravar o que vier
					order.setOrderType( OrderTypeEnum.LIMIT );
					order.setTimeInForce( TimeInForceEnum.DAY );
					order.setAccount( clientAccount );  // N�o pode ser Injetado pelo m�todo add da Leg, tem que gravar o que vier
//					order.setClient( client );
					order.setOrderStatus( OrderStatusEnum.NEW );
					order.setExecutionType( ExecutionTypeEnum.NEW );
					order.setPrice( random.nextDouble() );
					
//					fixSessions.addStrategyOrder( order );
					leg.addStrategyOrder( order );
					
					idGenerico++;
				}
			}
		}
		return strategy;
	}
}