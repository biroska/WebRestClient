package com.ubs.manhattan.mocks;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import com.ubs.manhattan.persistence.entities.Exchange;
import com.ubs.manhattan.persistence.factory.FactoryManager;

public class ExchangeMock {
	
	public ExchangeMock(){}
	
	public List<Exchange> insert( ){
		
		ArrayList<Exchange> exchangeList = new ArrayList<Exchange>();
		
		exchangeList.add( new Exchange( "BVSP", "IBOVESPA") );
		exchangeList.add( new Exchange( "BMF", "Bolsa de Mercadorias e Futuros") );
		
		return exchangeList;
	}
	
	public List<Exchange> getAllExchanges() {
		
		CriteriaBuilder criteriaBuilder =  FactoryManager.getEntityManager().getCriteriaBuilder();

		CriteriaQuery<Exchange> criteriaQuery = criteriaBuilder.createQuery(Exchange.class);
		Root<Exchange> exchangeRoot = criteriaQuery.from(Exchange.class);

		criteriaQuery.select( exchangeRoot );

		return FactoryManager.getEntityManager().createQuery(criteriaQuery).getResultList();
	}
	
	public Exchange getExchangeByIndex( int index ) {
		
		List<Exchange> exchange = getAllExchanges();

		return exchange.get( index );
	}
	
}