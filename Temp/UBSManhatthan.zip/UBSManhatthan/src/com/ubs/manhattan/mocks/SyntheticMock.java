/**
 * 
 */
package com.ubs.manhattan.mocks;

import com.ubs.manhattan.dto.ReceiveSymbolSyntheticItem;
import com.ubs.manhattan.dto.ReceiveSynthetic;
import com.ubs.manhattan.enums.SideEnum;
import com.ubs.manhattan.enums.StrategyTypeEnum;


/**
 * @author galdinoa
 *
 */
public class SyntheticMock {
	
	public static ReceiveSynthetic mockReceiveSynthetic( StrategyTypeEnum type, String... symbolList  ){
		
		ReceiveSynthetic synthetic = new ReceiveSynthetic();
		synthetic.setStrategyType( type );
		
		for (int i = 0; i < symbolList.length; i++) {
			ReceiveSymbolSyntheticItem item = new ReceiveSymbolSyntheticItem();
			item.setLegSeq( i );
			item.setSide( i % 2 == 0 ? SideEnum.BUY : SideEnum.SELL );
			item.setSymbol( symbolList[ i ] );
			synthetic.getSyntheticList().add( item );
		}
		
		return synthetic;
	}
}