package com.ubs.manhattan.mocks;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import com.ubs.manhattan.persistence.entities.AccountType;
import com.ubs.manhattan.persistence.factory.FactoryManager;

public class AccountTypeMock {
	
	public AccountTypeMock(){}
	
	public List<AccountType> insert( int qtd ){
		
		ArrayList<AccountType> accountTypeList = new ArrayList<AccountType>();
		
		for ( int i = 0; i<= qtd; i++ )
			accountTypeList.add( new AccountType( "AccountType_" + i  ) );
		
		return accountTypeList;
	}
	
	public AccountType getAccountTypeByIndex( int index ) {
		
		CriteriaBuilder criteriaBuilder =  FactoryManager.getEntityManager().getCriteriaBuilder();

		CriteriaQuery<AccountType> criteriaQuery = criteriaBuilder.createQuery(AccountType.class);
		Root<AccountType> accountTypeRoot = criteriaQuery.from(AccountType.class);

		criteriaQuery.select( accountTypeRoot );

		List<AccountType> accountType = FactoryManager.getEntityManager().createQuery(criteriaQuery).getResultList();

		return accountType.get( index );
	}
	
}