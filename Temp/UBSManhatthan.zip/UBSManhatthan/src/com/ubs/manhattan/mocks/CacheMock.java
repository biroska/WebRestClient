/**
 * 
 */
package com.ubs.manhattan.mocks;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import com.ubs.manhattan.persistence.dao.LegStrategyReportDAO;
import com.ubs.manhattan.persistence.dao.StrategyOrdersDAO;
import com.ubs.manhattan.persistence.dao.StrategyReportDAO;
import com.ubs.manhattan.persistence.entities.LegStrategyReport;
import com.ubs.manhattan.persistence.entities.StrategyOrders;
import com.ubs.manhattan.persistence.entities.StrategyReport;
import com.ubs.manhattan.persistence.entities.id.LegStrategyReportPK;
import com.ubs.manhattan.persistence.entities.id.StrategyOrdersPK;
import com.ubs.manhattan.persistence.entities.id.StrategyReportPK;

/**
 * @author galdinoa
 *
 */
public class CacheMock {
	
	public void generateStrategyReport( ConcurrentHashMap< StrategyReportPK, StrategyReport > strategyReportMap ){
	
		StrategyReportDAO reportDAO = new StrategyReportDAO();
	
//		Busca os 5 primeiros registros
		List<StrategyReport> reportByCriteria = reportDAO.findByCriteria(null, false, -1, 5);
		
		if ( reportByCriteria != null ){
			for (StrategyReport strategyReport : reportByCriteria) {
				strategyReportMap.put( strategyReport.getId(), strategyReport );
			}
		}
	}
	
	public void generateStrategyOrder( ConcurrentHashMap< StrategyOrdersPK, StrategyOrders > strategyOrderMap ){
		
		StrategyOrdersDAO dao = new StrategyOrdersDAO();
		
//		Busca os 5 primeiros registros
		List<StrategyOrders> findByCriteria = dao.findByCriteria(null, false, -1, 5);
		
		if ( findByCriteria != null ){
			for (StrategyOrders item : findByCriteria) {
				strategyOrderMap.put( item.getId(), item );
			}
		}
	}
	
	public void generateLegStrategy( ConcurrentHashMap< LegStrategyReportPK, LegStrategyReport > legStrategyReportMap ){
		
		LegStrategyReportDAO dao = new LegStrategyReportDAO();
		
//		Busca os 5 primeiros registros
		List<LegStrategyReport> findByCriteria = dao.findByCriteria(null, false, -1, 5);
		
		if ( findByCriteria != null ){
			for (LegStrategyReport item : findByCriteria) {
				legStrategyReportMap.put( item.getId(), item );
			}
		}
	}
}
