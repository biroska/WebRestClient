package com.ubs.manhattan.mocks;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import com.ubs.manhattan.persistence.entities.EngineInstance;
import com.ubs.manhattan.persistence.factory.FactoryManager;

public class EngineMock {
	
	public EngineMock(){}
	
	public List<EngineInstance> insert(){
		
		int i = 1;
		
		ArrayList<EngineInstance> engineList = new ArrayList<EngineInstance>();
		
		engineList.add( new EngineInstance( (long) i, " 255.255.255." + i, (long) 8079 + i++ , "EngDesc") );
		engineList.add( new EngineInstance( (long) i, " 255.255.255." + i, (long) 8079 + i++ , "EngDesc") );
		engineList.add( new EngineInstance( (long) i, " 255.255.255." + i, (long) 8079 + i++ , "EngDesc") );
		engineList.add( new EngineInstance( (long) i, " 255.255.255." + i, (long) 8079 + i++ , "EngDesc") );
		engineList.add( new EngineInstance( (long) i, " 255.255.255." + i, (long) 8079 + i++ , "EngDesc") );
		engineList.add( new EngineInstance( (long) i, " 255.255.255." + i, (long) 8079 + i++ , "EngDesc") );
		engineList.add( new EngineInstance( (long) i, " 255.255.255." + i, (long) 8079 + i++ , "EngDesc") );
		engineList.add( new EngineInstance( (long) i, " 255.255.255." + i, (long) 8079 + i++ , "EngDesc") );
		engineList.add( new EngineInstance( (long) i, " 255.255.255." + i, (long) 8079 + i++ , "EngDesc") );
		engineList.add( new EngineInstance( (long) i, " 255.255.255." + i, (long) 8079 + i++ , "EngDesc") );
		
		return engineList;
	}
	
	public EngineInstance getEngineByIndex( int index ) {
		
		CriteriaBuilder criteriaBuilder = FactoryManager.getEntityManager().getCriteriaBuilder();

		CriteriaQuery<EngineInstance> criteriaQuery = criteriaBuilder.createQuery(EngineInstance.class);
		Root<EngineInstance> engineRoot = criteriaQuery.from(EngineInstance.class);

		criteriaQuery.select( engineRoot );

		List<EngineInstance> engine = FactoryManager.getEntityManager().createQuery(criteriaQuery).getResultList();

		return engine.get( index );
	}
	
}