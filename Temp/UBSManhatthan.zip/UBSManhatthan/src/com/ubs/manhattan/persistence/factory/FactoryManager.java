package com.ubs.manhattan.persistence.factory;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class FactoryManager {
	
	
	private static final String PERSISTENCE_UNIT = "PersistenceUnit";
	private static ThreadLocal<EntityManager> threadEntityManager = new ThreadLocal<EntityManager>();
	
	private static EntityManagerFactory factory;
	
	public FactoryManager(){}
	
	public static EntityManager getEntityManager() {
		
		if ( factory == null) {
			try {
				Class.forName("oracle.jdbc.OracleDriver");
				factory = Persistence.createEntityManagerFactory( PERSISTENCE_UNIT );
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		EntityManager entityManager = threadEntityManager.get();

		if ( entityManager == null || !entityManager.isOpen() ) {
			entityManager = factory.createEntityManager();
			FactoryManager.threadEntityManager.set( entityManager );
		}
		return entityManager;
	}
	
	public static void closeEntityManager() {
		
		EntityManager entityManager = threadEntityManager.get();
		
		if ( entityManager != null ) {
			EntityTransaction transaction = entityManager.getTransaction();
			
			if (transaction.isActive()) {
				transaction.commit();
			}
			
			entityManager.close();
			threadEntityManager.set( null );
		}
	}
	
	public static void closeEntityManagerFactory() {
		closeEntityManager();
		factory.close();
	}
}