package com.ubs.manhattan.persistence.dao;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ubs.manhattan.enums.ActionTypeEnum;
import com.ubs.manhattan.persistence.dao.audit.RoleAuditDAO;
import com.ubs.manhattan.persistence.entities.Role;
import com.ubs.manhattan.persistence.entities.audit.RoleAudit;
import com.ubs.manhatthan.admin.model.User;

//@Repository
public class RoleDAO extends AbstractDAO<Role, Long> implements RoleInterfaceDAO {
	
	private RoleAuditDAO roleAuditDAO = new RoleAuditDAO();
	
//	@Autowired
	private User user = new User();
	
	public Role saveRole( Role role ){
		
		user.setLogin("aim*");
		
		ActionTypeEnum action = role.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;

		role = save( role );

		RoleAudit pa = new RoleAudit( role, action, user.getLogin(), new Date() );
		
		roleAuditDAO.save( pa );
		
		return role;
	}

	public Long generate( int qtd ){
		
		Long qtRegs = 4L;
		
		saveRole( new Role("CONSULTAR") );
		saveRole( new Role("CANCEL_ALL") );
		saveRole( new Role("PAUSE_ALL") );
		saveRole( new Role("CREATE_STRATEGY") );
		
		return qtRegs;
	}
	
	public Role getByIndex( int index ) {
		return findAll().get( index );
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
}