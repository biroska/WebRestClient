package com.ubs.manhattan.persistence.dao;

import java.util.Date;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import com.ubs.manhattan.enums.ActionTypeEnum;
import com.ubs.manhattan.persistence.dao.audit.TraderAuditDAO;
import com.ubs.manhattan.persistence.entities.Profile;
import com.ubs.manhattan.persistence.entities.Trader;
import com.ubs.manhattan.persistence.entities.audit.TraderAudit;
import com.ubs.manhattan.persistence.factory.FactoryManager;
import com.ubs.manhatthan.admin.model.User;

public class TraderDAO extends AbstractDAO<Trader, Long> {
	
	private ProfileDAO profileDAO = new ProfileDAO();
	private TraderAuditDAO traderAuditDAO = new TraderAuditDAO();
	private User user = new User();
	
	public Trader saveTrader( Trader trader ){
		
		ActionTypeEnum action = trader.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;

		trader = save( trader );

		TraderAudit ta = new TraderAudit( trader, action, user.getLogin(), new Date() );
		
		traderAuditDAO.save( ta );
		
		return trader;
	}
	
	public List<Trader> findAllActive( boolean isActive ){
		
		CriteriaBuilder criteriaBuilder = FactoryManager.getEntityManager().getCriteriaBuilder();

		CriteriaQuery<Trader> criteriaQuery = criteriaBuilder.createQuery(Trader.class);
		Root<Trader> traderRoot = criteriaQuery.from(Trader.class);
		criteriaQuery.where( criteriaBuilder.equal( traderRoot.get( "enable" ), isActive ) );		
		
		criteriaQuery.select( traderRoot );

		List<Trader> clientsEngineQuery = FactoryManager.getEntityManager().createQuery(criteriaQuery).getResultList();

		return clientsEngineQuery;
	}
	
	public Long generateTraders( int qtd ){
		
		Profile profile = profileDAO.getByIndex( 1 );
		
		Long qtRegs = 0L;
		
		for ( int i = 1; i<= qtd; i++ ){
			saveTrader( new Trader( "Trader_" + i, "Login_" + i , "123456", new Date(), profile, i % 2 == 0 ) );
			qtRegs++;
		}
		
		return qtRegs;
	}
	
	public Trader getByIndex( Integer index ){
		return findAllActive( true ).get( index );
	}
}