package com.ubs.manhattan.persistence.dao.audit;

import com.ubs.manhattan.persistence.dao.AbstractDAO;
import com.ubs.manhattan.persistence.entities.audit.TraderWatchTabAudit;

public class TraderWatchTabAuditDAO extends AbstractDAO<TraderWatchTabAudit, Long> {}
