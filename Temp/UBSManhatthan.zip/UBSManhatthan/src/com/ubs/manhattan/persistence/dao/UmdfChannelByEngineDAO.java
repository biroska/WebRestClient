package com.ubs.manhattan.persistence.dao;

import java.util.Date;
import java.util.List;

import com.ubs.manhattan.enums.ActionTypeEnum;
import com.ubs.manhattan.persistence.dao.audit.UmdfChannelByEngineAuditDAO;
import com.ubs.manhattan.persistence.entities.EngineInstance;
import com.ubs.manhattan.persistence.entities.EngineUmdfChannel;
import com.ubs.manhattan.persistence.entities.UmdfChannelByEngine;
import com.ubs.manhattan.persistence.entities.audit.UmdfChannelByEngineAudit;
import com.ubs.manhatthan.admin.model.User;

public class UmdfChannelByEngineDAO extends AbstractDAO<UmdfChannelByEngine, Long> {
	
	private EngineInstanceDAO engineInstanceDAO = new EngineInstanceDAO();
	private EngineUmdfChannelDAO engineUmdfChannelDAO = new EngineUmdfChannelDAO();
	
	private UmdfChannelByEngineAuditDAO umdfChannelByEngineAuditDAO = new UmdfChannelByEngineAuditDAO();
	
	private User user = new User();
	
	public UmdfChannelByEngine saveUmdfChannelByEngine( UmdfChannelByEngine umdfChannelByEngine ){
		
		ActionTypeEnum action = umdfChannelByEngine.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;

		umdfChannelByEngine  = save( umdfChannelByEngine );

		UmdfChannelByEngineAudit ofsa = new UmdfChannelByEngineAudit( umdfChannelByEngine, action, user.getLogin(), new Date() );
		
		umdfChannelByEngineAuditDAO.save( ofsa );
		
		return umdfChannelByEngine;
	}

	public Long generate( int qtd ){
		
		List<EngineInstance> engineInstanceList = engineInstanceDAO.findAll();
		List<EngineUmdfChannel> engineUmdfChannelList = engineUmdfChannelDAO.findAll();
		
		Long qtRegs = 0L;
		
		for ( int i = 1; i<= qtd; i++ ){
			saveUmdfChannelByEngine( new UmdfChannelByEngine( engineInstanceList.get( i -1 ), engineUmdfChannelList.get( qtd -i ) ) );
			qtRegs++;
		}
		
		return qtRegs;
	}
	
	public UmdfChannelByEngine getByIndex( int index ) {
		return findAll().get( index );
	}
}