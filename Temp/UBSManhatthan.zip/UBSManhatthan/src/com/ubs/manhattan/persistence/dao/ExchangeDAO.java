package com.ubs.manhattan.persistence.dao;

import com.ubs.manhattan.persistence.entities.Exchange;

public class ExchangeDAO extends AbstractDAO<Exchange, Long> {
	
	public Long generateExchange(){
		
		save( new Exchange( "BVSP", "IBOVESPA")  );
		save(new Exchange( "BMF", "Bolsa de Mercadorias e Futuros") );
		
		return 2L;
	}
	
	
	public Exchange getExchangeByIndex( int index ) {
		
		return findAll().get( index );
	}

}
