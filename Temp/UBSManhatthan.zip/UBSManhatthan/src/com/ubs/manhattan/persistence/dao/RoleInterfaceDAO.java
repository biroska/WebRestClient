package com.ubs.manhattan.persistence.dao;

import org.springframework.stereotype.Repository;

import com.ubs.manhattan.persistence.entities.Role;

@Repository
public interface RoleInterfaceDAO {

	Role saveRole(Role role);

}
