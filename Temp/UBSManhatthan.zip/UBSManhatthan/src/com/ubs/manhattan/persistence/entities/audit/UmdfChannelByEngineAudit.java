package com.ubs.manhattan.persistence.entities.audit;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.ubs.manhattan.enums.ActionTypeEnum;
import com.ubs.manhattan.persistence.entities.UmdfChannelByEngine;

@Entity
@Table(name="TB_AUDIT_REL_UMDF_CHANEL_ENGIN")
public class UmdfChannelByEngineAudit {
	
	public UmdfChannelByEngineAudit() {
		super();
	}
	
	public UmdfChannelByEngineAudit( UmdfChannelByEngine umdfChannelByEngine, ActionTypeEnum action, String user,
			Date registryDate) {
		super();
		this.action = action;
		this.user = user;
		this.registryDate = registryDate;
		
		this.origid = umdfChannelByEngine.getId();
		this.engine = umdfChannelByEngine.getEngine().getId();
		this.engineUmdfChannel = umdfChannelByEngine.getEngineUmdfChannel().getId();
	}



	@Id
	@Column ( name = "ID")
	@SequenceGenerator(name = "TB_AUDIT_REL_UMDF_CHANEL_ENGIN_ID_GENERATOR", sequenceName = "SEQ_AUDIT_REL_UMDF_CHANL_ENGIN", allocationSize = 1)
	@GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "TB_AUDIT_REL_UMDF_CHANEL_ENGIN_ID_GENERATOR" )
	private Long id;
	
	@Enumerated(EnumType.STRING)
	@Column( name = "ACTION", nullable=false )
	private ActionTypeEnum action;
	
	@Column( name = "REGISTRY_USER", nullable=false )
	private String user;
	
	@Column( name = "REGISTRY_DATE", nullable=false )
	private Date registryDate;

	@Column(name = "ORIG_ID", nullable = false )
	private Long origid;
	
	@Column(name = "ENGINE_ID", nullable = false )
	private Integer engine;
	
	@Column(name = "CHANNEL_ID", nullable = false )
	private Long engineUmdfChannel;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public ActionTypeEnum getAction() {
		return action;
	}

	public void setAction(ActionTypeEnum action) {
		this.action = action;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public Date getRegistryDate() {
		return registryDate;
	}

	public void setRegistryDate(Date registryDate) {
		this.registryDate = registryDate;
	}

	public Long getOrigid() {
		return origid;
	}

	public void setOrigid(Long origid) {
		this.origid = origid;
	}

//	public EngineInstanceAudit getEngine() {
//		return engine;
//	}
//
//	public void setEngine(EngineInstanceAudit engine) {
//		this.engine = engine;
//	}
//
//	public EngineUmdfChannelAudit getEngineUmdfChannel() {
//		return engineUmdfChannel;
//	}
//
//	public void setEngineUmdfChannel(EngineUmdfChannelAudit engineUmdfChannel) {
//		this.engineUmdfChannel = engineUmdfChannel;
//	}
	
	public Integer getEngine() {
		return engine;
	}

	public void setEngine(Integer engine) {
		this.engine = engine;
	}

	public Long getEngineUmdfChannel() {
		return engineUmdfChannel;
	}

	public void setEngineUmdfChannel(Long engineUmdfChannel) {
		this.engineUmdfChannel = engineUmdfChannel;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((action == null) ? 0 : action.hashCode());
		result = prime * result + ((origid == null) ? 0 : origid.hashCode());
		result = prime * result
				+ ((registryDate == null) ? 0 : registryDate.hashCode());
		result = prime * result + ((user == null) ? 0 : user.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UmdfChannelByEngineAudit other = (UmdfChannelByEngineAudit) obj;
		if (action != other.action)
			return false;
		if (origid == null) {
			if (other.origid != null)
				return false;
		} else if (!origid.equals(other.origid))
			return false;
		if (registryDate == null) {
			if (other.registryDate != null)
				return false;
		} else if (!registryDate.equals(other.registryDate))
			return false;
		if (user == null) {
			if (other.user != null)
				return false;
		} else if (!user.equals(other.user))
			return false;
		return true;
	}
}