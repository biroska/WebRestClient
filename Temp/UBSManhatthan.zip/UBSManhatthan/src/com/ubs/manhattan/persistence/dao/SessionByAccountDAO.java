package com.ubs.manhattan.persistence.dao;

import java.util.Date;
import java.util.List;

import com.ubs.manhattan.enums.ActionTypeEnum;
import com.ubs.manhattan.persistence.dao.audit.SessionByAccountAuditDAO;
import com.ubs.manhattan.persistence.entities.ClientAccount;
import com.ubs.manhattan.persistence.entities.OrderFixSession;
import com.ubs.manhattan.persistence.entities.SessionByAccount;
import com.ubs.manhattan.persistence.entities.audit.SessionByAccountAudit;
import com.ubs.manhatthan.admin.model.User;

public class SessionByAccountDAO extends AbstractDAO<SessionByAccount, Long> {
	
	private ClientAccountDAO clientAccountDAO = new ClientAccountDAO();
	private OrderFixSessionDAO orderFixSessionDAO = new OrderFixSessionDAO();
	
	private SessionByAccountAuditDAO sessionByAccountAuditDAO = new SessionByAccountAuditDAO();
	
	private User user = new User();
	
	public SessionByAccount saveOrderFixSession( SessionByAccount sessionByAccount ){
		
		ActionTypeEnum action = sessionByAccount.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;

		sessionByAccount  = save( sessionByAccount );

		SessionByAccountAudit sbaa = new SessionByAccountAudit( sessionByAccount, action, user.getLogin(), new Date() );
		
		sessionByAccountAuditDAO.save( sbaa );
		
		return sessionByAccount;
	}

	public Long generate( int qtd ){
		
		List<ClientAccount> clientAccountList = clientAccountDAO.findAll();
		List<OrderFixSession> orderFixSessionList = orderFixSessionDAO.findAll();
		
		Long qtRegs = 0L;
		
		for ( int i = 1; i<= qtd; i++ ){
			saveOrderFixSession( new SessionByAccount( clientAccountList.get( i -1), orderFixSessionList.get( qtd -i) ) );
			qtRegs++;
		}
		
		return qtRegs;
	}
	
	public SessionByAccount getByIndex( int index ) {
		return findAll().get( index );
	}
}