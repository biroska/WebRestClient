package com.ubs.manhattan.persistence.dao;

import java.util.Date;

import com.ubs.manhattan.persistence.dao.audit.StrategyReportAuditDAO;
import com.ubs.manhattan.persistence.entities.StrategyOrders;
import com.ubs.manhattan.persistence.entities.StrategyReport;
import com.ubs.manhattan.persistence.entities.id.StrategyReportPK;

public class StrategyReportDAO extends AbstractDAO<StrategyReport, StrategyReportPK> {
	
	public StrategyReportDAO() {}
	
	private StrategyReportAuditDAO strategyReportAuditDAO = new StrategyReportAuditDAO();
	
	public StrategyReport saveReport( StrategyReport report ){
		
		report.setStrategyTimestamp( new Date() );
		
//		Salva o strategy report, legs e orders
		report = update( report );

//		Gera registro na tabela de auditoria - Strategyreport
		strategyReportAuditDAO.saveReportAudit( report );
		
		return report;
	}
	
	public StrategyOrders saveReport( StrategyOrders order ){
		
		
		return order;
	}
	
	public StrategyReport getByIndex( int index ) {
		
		return findAll().get( index );
	}
}