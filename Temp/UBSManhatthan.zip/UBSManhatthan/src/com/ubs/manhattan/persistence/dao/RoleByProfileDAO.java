package com.ubs.manhattan.persistence.dao;

import java.util.Date;
import java.util.List;

import com.ubs.manhattan.enums.ActionTypeEnum;
import com.ubs.manhattan.persistence.dao.audit.RoleByProfileAuditDAO;
import com.ubs.manhattan.persistence.entities.Profile;
import com.ubs.manhattan.persistence.entities.Role;
import com.ubs.manhattan.persistence.entities.RoleByProfile;
import com.ubs.manhattan.persistence.entities.audit.RoleByProfileAudit;
import com.ubs.manhatthan.admin.model.User;

public class RoleByProfileDAO extends AbstractDAO<RoleByProfile, Long> {
	
	private RoleByProfileAuditDAO roleByProfileAuditDAO = new RoleByProfileAuditDAO();
	
	private User user = new User();
	
	public RoleByProfile saveRoleByProfile( RoleByProfile role ){
		
		ActionTypeEnum action = role.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;

		role = save( role );

		RoleByProfileAudit pa = new RoleByProfileAudit( role, action, user.getLogin(), new Date() );
		
		roleByProfileAuditDAO.save( pa );
		
		return role;
	}

	public Long generate( int qtd ){
		
		Long qtRegs = 0L;
		
		RoleDAO roleDAO = new RoleDAO();
		ProfileDAO profileDAO = new ProfileDAO();
		
		List<Role> roleList = roleDAO.findAll();
		List<Profile> profileList = profileDAO.findAll();
		
		for (int i = 0; i < roleList.size(); i++) {
			saveRoleByProfile( new RoleByProfile( roleList.get( i % 4 ), profileList.get( i % 4) ) );
			qtRegs++;
		}
		
		return qtRegs;
	}
	
	public RoleByProfile getByIndex( int index ) {
		return findAll().get( index );
	}
}