package com.ubs.manhattan.persistence.dao.audit;

import java.util.List;

import com.ubs.manhattan.persistence.dao.AbstractDAO;
import com.ubs.manhattan.persistence.entities.audit.LegStrategyReportAudit;

public class LegStrategyReportAuditDAO extends AbstractDAO<LegStrategyReportAudit, Long> {
	
	public List<LegStrategyReportAudit> save(List<LegStrategyReportAudit> list) {

		for (LegStrategyReportAudit item : list) {
			item = save(item);
		}
		return list;
	}
}
