package com.ubs.manhattan.persistence.dao.audit;

import com.ubs.manhattan.persistence.dao.AbstractDAO;
import com.ubs.manhattan.persistence.entities.audit.TcpRecoverySessionAudit;

public class TcpRecoverySessionAuditDAO extends AbstractDAO<TcpRecoverySessionAudit, Long> {}
