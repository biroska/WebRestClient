package com.ubs.manhattan.persistence.dao;

import java.util.Date;

import com.ubs.manhattan.enums.ActionTypeEnum;
import com.ubs.manhattan.persistence.dao.audit.EngineInstanceAuditDAO;
import com.ubs.manhattan.persistence.entities.EngineInstance;
import com.ubs.manhattan.persistence.entities.audit.EngineInstanceAudit;
import com.ubs.manhatthan.admin.model.User;

public class EngineInstanceDAO extends AbstractDAO<EngineInstance, Long> {
	
	EngineInstanceAuditDAO engineInstanceAudit = new EngineInstanceAuditDAO();
	User user = new User();
	
	public EngineInstance saveEngineInstance( EngineInstance engine ){
		
		ActionTypeEnum action = engine.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;

		engine = save( engine );

		EngineInstanceAudit pa = new EngineInstanceAudit( engine, action, user.getLogin(), new Date() );
		
		engineInstanceAudit.save( pa );
		
		return engine;
	}
	
	public Long generateEngine( int qtd ){
		
		Long qtRegs = 0L;
		
		for ( int i = 1; i<= qtd; i++ ){
			saveEngineInstance(  new EngineInstance( (long) i, " 255.255.255." + i, (long) 8079 + i, "EngDesc") );
			qtRegs++;
		}
		return qtRegs;
	}
	
	public EngineInstance getByIndex( int index ) {
		return findAll().get( index );
	}
}