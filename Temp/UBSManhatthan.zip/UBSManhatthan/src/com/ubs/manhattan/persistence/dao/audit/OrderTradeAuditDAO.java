package com.ubs.manhattan.persistence.dao.audit;

import java.util.Date;

import com.ubs.manhattan.enums.ActionTypeEnum;
import com.ubs.manhattan.persistence.dao.AbstractDAO;
import com.ubs.manhattan.persistence.entities.OrderTrade;
import com.ubs.manhattan.persistence.entities.audit.OrderTradeAudit;
import com.ubs.manhatthan.admin.model.User;

public class OrderTradeAuditDAO extends AbstractDAO<OrderTradeAudit, Long> {
	
	private User user = new User();
	
	public OrderTradeAudit saveOrderTradeAudit( OrderTrade orderTrade ){
		return save( new OrderTradeAudit( orderTrade, ActionTypeEnum.INSERT, user.getLogin(), new Date() ) );
	}
	
}
