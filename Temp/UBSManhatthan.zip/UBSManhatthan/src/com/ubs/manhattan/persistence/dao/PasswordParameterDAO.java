package com.ubs.manhattan.persistence.dao;

import java.util.Date;

import com.ubs.manhattan.enums.ActionTypeEnum;
import com.ubs.manhattan.persistence.dao.audit.PasswordParameterAuditDAO;
import com.ubs.manhattan.persistence.entities.PasswordParameter;
import com.ubs.manhattan.persistence.entities.audit.PasswordParameterAudit;
import com.ubs.manhatthan.admin.model.User;

public class PasswordParameterDAO extends AbstractDAO<PasswordParameter, Long> {
	
	private PasswordParameterAuditDAO passwordParameterAuditDAO = new PasswordParameterAuditDAO();
	
	private User user = new User();
	
	public PasswordParameter savePasswordParameter( PasswordParameter passwordParameter ){
		
		ActionTypeEnum action = passwordParameter.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;

		passwordParameter = save( passwordParameter );

		PasswordParameterAudit pa = new PasswordParameterAudit( passwordParameter, action, user.getLogin(), new Date() );
		
		passwordParameterAuditDAO.save( pa );
		
		return passwordParameter;
	}

	public Long generate( int qtd ){
		
		Long qtRegs = 0L;
		
		savePasswordParameter( new PasswordParameter() );
		savePasswordParameter( new PasswordParameter( 1, 2, 3, 4, 120 ) );
		savePasswordParameter( new PasswordParameter( 5, 6, 7, 8, 100 ) );
		savePasswordParameter( new PasswordParameter( 9, 9, 9, 9, 30 ) );
		savePasswordParameter( new PasswordParameter( 5, 5, 5, 5, 60 ) );
		
		return qtRegs;
	}
	
	public PasswordParameter getByIndex( int index ) {
		return findAll().get( index );
	}
}