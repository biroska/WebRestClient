package com.ubs.manhattan.persistence.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name="TB_REL_SESSIONS_PER_ENGINE",
uniqueConstraints={
		   @UniqueConstraint(columnNames={"ENGINE_ID", "SESSION_ID"}, name = "CK_SESSIONS_PER_ENGINE")
		})
public class SessionByEngine {
	
	public SessionByEngine(){}
	
	public SessionByEngine(EngineInstance engineInstanceId, OrderFixSession orderFixSessionId) {
		super();
		this.engineInstanceId = engineInstanceId;
		this.orderFixSessionId = orderFixSessionId;
	}

	@Id
	@Column ( name = "ID")
	@SequenceGenerator(name = "TB_REL_SESSIONS_PER_ENGINE_ID_GENERATOR", sequenceName = "SEQ_REL_SESSIONS_PER_ENGINE", allocationSize = 1)
	@GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "TB_REL_SESSIONS_PER_ENGINE_ID_GENERATOR" )
	private Long id;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "ENGINE_ID", nullable = false )
	private EngineInstance engineInstanceId;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "SESSION_ID", nullable = false )
	private OrderFixSession orderFixSessionId;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public EngineInstance getEngineInstanceId() {
		return engineInstanceId;
	}

	public void setEngineInstanceId(EngineInstance engineInstanceId) {
		this.engineInstanceId = engineInstanceId;
	}

	public OrderFixSession getOrderFixSessionId() {
		return orderFixSessionId;
	}

	public void setOrderFixSessionId(OrderFixSession orderFixSessionId) {
		this.orderFixSessionId = orderFixSessionId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((engineInstanceId == null) ? 0 : engineInstanceId.hashCode());
		result = prime
				* result
				+ ((orderFixSessionId == null) ? 0 : orderFixSessionId
						.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SessionByEngine other = (SessionByEngine) obj;
		if (engineInstanceId == null) {
			if (other.engineInstanceId != null)
				return false;
		} else if (!engineInstanceId.equals(other.engineInstanceId))
			return false;
		if (orderFixSessionId == null) {
			if (other.orderFixSessionId != null)
				return false;
		} else if (!orderFixSessionId.equals(other.orderFixSessionId))
			return false;
		return true;
	}
}