package com.ubs.manhattan.persistence.entities.converters;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import com.ubs.manhattan.enums.OrderStatusEnum;

@Converter(autoApply = true)
public class OrderStatusEnumConverter implements AttributeConverter<OrderStatusEnum, Integer> {

	@Override
	public Integer convertToDatabaseColumn(OrderStatusEnum orderStatusEnum ) {
		return orderStatusEnum.getCode();
	}

	@Override
	public OrderStatusEnum convertToEntityAttribute(Integer dbData) {
		for ( OrderStatusEnum os : OrderStatusEnum.values() ) {
			if ( os.getCode().equals(dbData) ) {
				return os;
			}
		}

		throw new IllegalArgumentException("Unknown database value:" + dbData );
	}
}