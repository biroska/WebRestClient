package com.ubs.manhattan.persistence.dao;

import java.util.Date;
import java.util.List;

import com.ubs.manhattan.enums.ActionTypeEnum;
import com.ubs.manhattan.persistence.dao.audit.StrategyByTabLegAuditDAO;
import com.ubs.manhattan.persistence.entities.StrategyByTab;
import com.ubs.manhattan.persistence.entities.StrategyByTabLeg;
import com.ubs.manhattan.persistence.entities.StrategyTypeLeg;
import com.ubs.manhattan.persistence.entities.audit.StrategyByTabLegAudit;
import com.ubs.manhatthan.admin.model.User;

public class StrategyByTabLegDAO extends AbstractDAO<StrategyByTabLeg, Long> {
	
	private StrategyByTabLegAuditDAO strategyByTabLegAuditDAO = new StrategyByTabLegAuditDAO();
	
	private User user = new User();
	
	public StrategyByTabLeg saveStrategyByTabLeg( StrategyByTabLeg strategyByTabLeg ){
		
		ActionTypeEnum action = strategyByTabLeg.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;

		strategyByTabLeg = save( strategyByTabLeg );

		StrategyByTabLegAudit sta = new StrategyByTabLegAudit( strategyByTabLeg, action, user.getLogin(), new Date() );
		
		strategyByTabLegAuditDAO.save( sta );
		
		return strategyByTabLeg;
	}

	public Long generate( int qtd ){
		
		StrategyByTabDAO strategyByTabDAO = new StrategyByTabDAO();
		List<StrategyByTab> strategyByTabList = strategyByTabDAO.findAll();
		
		StrategyTypeLegDAO strategyTypeLegDAO = new StrategyTypeLegDAO();
		List<StrategyTypeLeg> strategyTypeLegList = strategyTypeLegDAO.findAll();
		
		Long qtRegs = 0L;
		
		for (int i = 1; i <= 10; i++) {
			saveStrategyByTabLeg( new StrategyByTabLeg( strategyByTabList.get( i % 5), strategyTypeLegList.get( i % 5 ) , ( i % 4 ) +1 ) );
			qtRegs++;
		}
		
		return qtRegs;
	}
	
	public StrategyByTabLeg getByIndex( int index ) {
		return findAll().get( index );
	}
}