package com.ubs.manhattan.persistence.dao;

import java.util.Date;
import java.util.List;

import com.ubs.manhattan.enums.ActionTypeEnum;
import com.ubs.manhattan.persistence.dao.audit.UmdfRecoverySessionByEngineAuditDAO;
import com.ubs.manhattan.persistence.entities.EngineInstance;
import com.ubs.manhattan.persistence.entities.TcpRecoverySession;
import com.ubs.manhattan.persistence.entities.UmdfRecoverySessionByEngine;
import com.ubs.manhattan.persistence.entities.audit.UmdfRecoverySessionByEngineAudit;
import com.ubs.manhatthan.admin.model.User;

public class UmdfRecoverySessionByEngineDAO extends AbstractDAO<UmdfRecoverySessionByEngine, Long> {
	
	private EngineInstanceDAO engineInstanceDAO = new EngineInstanceDAO();
	private TcpRecoverySessionDAO tcpRecoverySessionDAO = new TcpRecoverySessionDAO();
	
	private UmdfRecoverySessionByEngineAuditDAO umdfRecoverySessionByEngineAuditDAO = new UmdfRecoverySessionByEngineAuditDAO();
	
	private User user = new User();
	
	public UmdfRecoverySessionByEngine saveUmdfRecoverySessionByEngine( UmdfRecoverySessionByEngine umdfRecoverySessionByEngine ){
		
		ActionTypeEnum action = umdfRecoverySessionByEngine.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;

		umdfRecoverySessionByEngine  = save( umdfRecoverySessionByEngine );

		UmdfRecoverySessionByEngineAudit ursbea = new UmdfRecoverySessionByEngineAudit( umdfRecoverySessionByEngine, action, user.getLogin(), new Date() );
		
		umdfRecoverySessionByEngineAuditDAO.save( ursbea );
		
		return umdfRecoverySessionByEngine;
	}

	public Long generate( int qtd ){
		
		List<EngineInstance> engineInstanceList = engineInstanceDAO.findAll();
		List<TcpRecoverySession> tcpRecoverySessionList = tcpRecoverySessionDAO.findAll();
		
		Long qtRegs = 0L;
		
		for ( int i = 1; i<= qtd; i++ ){
			saveUmdfRecoverySessionByEngine( new UmdfRecoverySessionByEngine( engineInstanceList.get( i -1 ), tcpRecoverySessionList.get( qtd -i ) ) );
			qtRegs++;
		}
		
		return qtRegs;
	}
	
	public UmdfRecoverySessionByEngine getByIndex( int index ) {
		return findAll().get( index );
	}
}