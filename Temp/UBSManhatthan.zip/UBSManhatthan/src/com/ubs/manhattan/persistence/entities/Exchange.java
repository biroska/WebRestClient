package com.ubs.manhattan.persistence.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name="TB_DOMAIN_EXCHANGE",
	   uniqueConstraints={
		   @UniqueConstraint(columnNames={"CODE"}, name = "CK_DOMAIN_EXCHANGE_CODE")
		})
public class Exchange {
	
	public Exchange(){}
	
	public Exchange(String code, String description) {
		super();
		this.code = code;
		this.description = description;
	}

	@Id
	@Column ( name = "ID")
	@SequenceGenerator(name = "TB_DOMAIN_EXCHANGE_ID_GENERATOR", sequenceName = "SEQ_DOMAIN_EXCHANGE", allocationSize = 1)
	@GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "TB_DOMAIN_EXCHANGE_ID_GENERATOR" )
	private Long id;
	
	@Column ( name = "CODE", nullable=false, length = 8 )
	private String code;
	
	@Column ( name = "DESCRIPTION", nullable=false, length = 1024 )
	private String description;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((code == null) ? 0 : code.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Exchange other = (Exchange) obj;
		if (code == null) {
			if (other.code != null)
				return false;
		} else if (!code.equals(other.code))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Exchange [id=" + id + ", code=" + code + ", description="
				+ description + "]";
	}
}