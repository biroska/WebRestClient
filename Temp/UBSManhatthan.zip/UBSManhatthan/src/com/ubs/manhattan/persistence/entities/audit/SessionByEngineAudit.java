package com.ubs.manhattan.persistence.entities.audit;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.ubs.manhattan.enums.ActionTypeEnum;
import com.ubs.manhattan.persistence.entities.SessionByEngine;

@Entity
@Table(name="TB_AUDIT_REL_SESSION_PER_ENGIN")
public class SessionByEngineAudit {
	
	public SessionByEngineAudit() {
		super();
	}
	
	public SessionByEngineAudit( SessionByEngine sessionByEngine, ActionTypeEnum action, String user, Date registryDate) {
		super();
		this.action = action;
		this.user = user;
		this.registryDate = registryDate;
		
		this.origId = sessionByEngine.getId();
		this.engineInstanceId = sessionByEngine.getEngineInstanceId().getId();
		this.orderFixSessionId = sessionByEngine.getOrderFixSessionId().getId();
	}

	@Id
	@Column ( name = "ID")
	@SequenceGenerator(name = "TB_AUDIT_REL_SESSION_PER_ENGIN_ID_GENERATOR", sequenceName = "SEQ_AUDIT_SESSION_PER_ENGINE", allocationSize = 1)
	@GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "TB_AUDIT_REL_SESSION_PER_ENGIN_ID_GENERATOR" )
	private Long id;
	
	@Enumerated(EnumType.STRING)
	@Column( name = "ACTION", nullable=false )
	private ActionTypeEnum action;
	
	@Column( name = "REGISTRY_USER", nullable=false )
	private String user;
	
	@Column( name = "REGISTRY_DATE", nullable=false )
	private Date registryDate;
	
	@Column ( name = "ORIG_ID", nullable=false)
	private Long origId;
	
	@Column(name = "ENGINE_ID", nullable = false )
	private Integer engineInstanceId;
	
	@Column(name = "SESSION_ID", nullable = false )
	private Integer orderFixSessionId;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public ActionTypeEnum getAction() {
		return action;
	}

	public void setAction(ActionTypeEnum action) {
		this.action = action;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public Date getRegistryDate() {
		return registryDate;
	}

	public void setRegistryDate(Date registryDate) {
		this.registryDate = registryDate;
	}

	public Long getOrigId() {
		return origId;
	}

	public void setOrigId(Long origId) {
		this.origId = origId;
	}

//	public EngineInstanceAudit getEngineInstanceId() {
//		return engineInstanceId;
//	}
//
//	public void setEngineInstanceId(EngineInstanceAudit engineInstanceId) {
//		this.engineInstanceId = engineInstanceId;
//	}
//
//	public OrderFixSessionAudit getOrderFixSessionId() {
//		return orderFixSessionId;
//	}
//
//	public void setOrderFixSessionId(OrderFixSessionAudit orderFixSessionId) {
//		this.orderFixSessionId = orderFixSessionId;
//	}

	public Integer getEngineInstanceId() {
		return engineInstanceId;
	}

	public void setEngineInstanceId(Integer engineInstanceId) {
		this.engineInstanceId = engineInstanceId;
	}

	public Integer getOrderFixSessionId() {
		return orderFixSessionId;
	}

	public void setOrderFixSessionId(Integer orderFixSessionId) {
		this.orderFixSessionId = orderFixSessionId;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((action == null) ? 0 : action.hashCode());
		result = prime * result + ((origId == null) ? 0 : origId.hashCode());
		result = prime * result
				+ ((registryDate == null) ? 0 : registryDate.hashCode());
		result = prime * result + ((user == null) ? 0 : user.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SessionByEngineAudit other = (SessionByEngineAudit) obj;
		if (action != other.action)
			return false;
		if (origId == null) {
			if (other.origId != null)
				return false;
		} else if (!origId.equals(other.origId))
			return false;
		if (registryDate == null) {
			if (other.registryDate != null)
				return false;
		} else if (!registryDate.equals(other.registryDate))
			return false;
		if (user == null) {
			if (other.user != null)
				return false;
		} else if (!user.equals(other.user))
			return false;
		return true;
	}
}