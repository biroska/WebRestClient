package com.ubs.manhattan.persistence.dao.audit;

import com.ubs.manhattan.persistence.dao.AbstractDAO;
import com.ubs.manhattan.persistence.entities.audit.EngineInstanceAudit;

public class EngineInstanceAuditDAO extends AbstractDAO<EngineInstanceAudit, Long> {
	
}