package com.ubs.manhattan.persistence.dao;

import java.util.Date;

import com.ubs.manhattan.enums.ActionTypeEnum;
import com.ubs.manhattan.persistence.dao.audit.StrategyOrdersAuditDAO;
import com.ubs.manhattan.persistence.entities.StrategyOrders;
import com.ubs.manhattan.persistence.entities.audit.StrategyOrdersAudit;
import com.ubs.manhattan.persistence.entities.id.StrategyOrdersPK;
import com.ubs.manhatthan.admin.model.User;

public class StrategyOrdersDAO extends AbstractDAO<StrategyOrders, StrategyOrdersPK> {
	
	StrategyOrdersAuditDAO strategyOrdersAuditDAO = new StrategyOrdersAuditDAO();
	
	User user = new User();
	
	public StrategyOrders saveStrategyOrder( StrategyOrders order ){
		
		ActionTypeEnum action = order.getId().getOrderId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;
		
		findById( order.getId() );

		order = update( order );

		StrategyOrdersAudit soa = new StrategyOrdersAudit( order, action, user.getLogin(), new Date() );
		
		strategyOrdersAuditDAO.save( soa );
		
		return order;
	}
	
	public Long generateStrategyReport( int qtd ){
		
		Long qtRegs = 0L;
		
		return qtRegs;
	}
	
	
	public StrategyOrders getClientByIndex( int index ) {
		
		return findAll().get( index );
	}

}
