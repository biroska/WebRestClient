package com.ubs.manhattan.persistence.entities.converters;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import com.ubs.manhattan.enums.OrderTypeEnum;

@Converter(autoApply = true)
public class OrderTypeEnumConverter implements AttributeConverter<OrderTypeEnum, Integer> {

	@Override
	public Integer convertToDatabaseColumn(OrderTypeEnum orderTypeEnum ) {
		return orderTypeEnum.getCode();
	}

	@Override
	public OrderTypeEnum convertToEntityAttribute(Integer dbData) {
		for ( OrderTypeEnum order : OrderTypeEnum.values() ) {
			if ( order.getCode().equals(dbData) ) {
				return order;
			}
		}

		throw new IllegalArgumentException("Unknown database value:" + dbData );
	}
}