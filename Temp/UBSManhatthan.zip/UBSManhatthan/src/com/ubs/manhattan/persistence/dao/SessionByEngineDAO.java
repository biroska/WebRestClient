package com.ubs.manhattan.persistence.dao;

import java.util.Date;
import java.util.List;

import com.ubs.manhattan.enums.ActionTypeEnum;
import com.ubs.manhattan.persistence.dao.audit.SessionByEngineAuditDAO;
import com.ubs.manhattan.persistence.entities.EngineInstance;
import com.ubs.manhattan.persistence.entities.OrderFixSession;
import com.ubs.manhattan.persistence.entities.SessionByEngine;
import com.ubs.manhattan.persistence.entities.audit.SessionByEngineAudit;
import com.ubs.manhatthan.admin.model.User;

public class SessionByEngineDAO extends AbstractDAO<SessionByEngine, Long> {
	
	private EngineInstanceDAO engineInstanceDAO = new EngineInstanceDAO();
	private OrderFixSessionDAO orderFixSessionDAO = new OrderFixSessionDAO();
	
	private SessionByEngineAuditDAO sessionByEngineAuditDAO = new SessionByEngineAuditDAO();
	
	private User user = new User();
	
	public SessionByEngine saveSessionByEngine( SessionByEngine sessionByEngine ){
		
		ActionTypeEnum action = sessionByEngine.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;

		sessionByEngine  = save( sessionByEngine );

		SessionByEngineAudit sbea = new SessionByEngineAudit( sessionByEngine, action, user.getLogin(), new Date() );
		
		sessionByEngineAuditDAO.save( sbea );
		
		return sessionByEngine;
	}

	public Long generate( int qtd ){
		
		List<EngineInstance> engineInstanceList = engineInstanceDAO.findAll();
		List<OrderFixSession> orderFixSessionList = orderFixSessionDAO.findAll();
		
		Long qtRegs = 0L;
		
		for ( int i = 1; i<= qtd; i++ ){
			saveSessionByEngine( new SessionByEngine( engineInstanceList.get( i -1), orderFixSessionList.get( qtd -i) ) );
			qtRegs++;
		}
		
		return qtRegs;
	}
	
	public SessionByEngine getByIndex( int index ) {
		return findAll().get( index );
	}
}