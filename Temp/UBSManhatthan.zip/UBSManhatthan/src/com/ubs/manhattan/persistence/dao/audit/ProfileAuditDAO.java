package com.ubs.manhattan.persistence.dao.audit;

import com.ubs.manhattan.persistence.dao.AbstractDAO;
import com.ubs.manhattan.persistence.entities.audit.ProfileAudit;

public class ProfileAuditDAO extends AbstractDAO<ProfileAudit, Long> {}
