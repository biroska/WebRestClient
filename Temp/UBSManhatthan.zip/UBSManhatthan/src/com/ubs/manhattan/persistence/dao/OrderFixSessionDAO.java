package com.ubs.manhattan.persistence.dao;

import java.util.Date;
import java.util.List;

import com.ubs.manhattan.enums.ActionTypeEnum;
import com.ubs.manhattan.persistence.dao.audit.OrderFixSessionAuditDAO;
import com.ubs.manhattan.persistence.entities.Exchange;
import com.ubs.manhattan.persistence.entities.OrderFixSession;
import com.ubs.manhattan.persistence.entities.audit.OrderFixSessionAudit;
import com.ubs.manhatthan.admin.model.User;

public class OrderFixSessionDAO extends AbstractDAO<OrderFixSession, Long> {
	
	private ExchangeDAO exchangeDAO = new ExchangeDAO();
	private OrderFixSessionAuditDAO orderFixSessionAuditDAO = new OrderFixSessionAuditDAO();
	
	private User user = new User();
	
	public OrderFixSession saveOrderFixSession( OrderFixSession orderFixSession ){
		
		ActionTypeEnum action = orderFixSession.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;

		orderFixSession  = save( orderFixSession );

		OrderFixSessionAudit ofsa = new OrderFixSessionAudit( orderFixSession, action, user.getLogin(), new Date() );
		
		orderFixSessionAuditDAO.save( ofsa );
		
		return orderFixSession;
	}
	
	public Long generateOrderFixSession( int qtd ){
		
		Long qtRegs = 0L;
		
		List<Exchange> allExchanges = exchangeDAO.findAll();
		
		for ( int i = 1; i<= qtd; i++ ){
			saveOrderFixSession(  new OrderFixSession( allExchanges.get( i % 2 ), "255.255.255." + i, 8070L + i, "BVMF_" + i, "UBS_" + i, "123456" ,"description" ) );
			qtRegs++;
		}
		
		return qtRegs;
	}
	
	
	public OrderFixSession getByIndex( int index ) {
		return findAll().get( index );
	}

}
