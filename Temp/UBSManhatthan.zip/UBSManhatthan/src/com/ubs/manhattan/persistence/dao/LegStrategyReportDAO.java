package com.ubs.manhattan.persistence.dao;

import java.util.List;

import org.hibernate.criterion.Restrictions;

import com.ubs.manhattan.persistence.entities.LegStrategyReport;
import com.ubs.manhattan.persistence.entities.id.LegStrategyReportPK;

public class LegStrategyReportDAO extends AbstractDAO<LegStrategyReport, LegStrategyReportPK> {
	
	public List<LegStrategyReport> findByStrategyId( Long reportId ){
		
		return findByCriteria( Restrictions.eq("id.strategyId", reportId ) );
	}
	
	public Long generateStrategyReport( int qtd ){
		
		Long qtRegs = 0L;
		
		return qtRegs;
	}
	
	
	public LegStrategyReport getClientByIndex( int index ) {
		
		return findAll().get( index );
	}

}
