package com.ubs.manhattan.persistence.dao;

import java.util.Date;
import java.util.List;

import com.ubs.manhattan.enums.ActionTypeEnum;
import com.ubs.manhattan.enums.StrategyTypeEnum;
import com.ubs.manhattan.persistence.dao.audit.StrategyTypeAuditDAO;
import com.ubs.manhattan.persistence.entities.StrategyType;
import com.ubs.manhattan.persistence.entities.audit.StrategyTypeAudit;
import com.ubs.manhatthan.admin.model.User;

public class StrategyTypeDAO extends AbstractDAO<StrategyType, Long> {
	
	private StrategyType strategyTypeAux = new StrategyType(); 
	
	private StrategyTypeAuditDAO strategyTypeAuditDAO = new StrategyTypeAuditDAO();
	
	private User user = new User();
	
	public StrategyType saveStrategyType( StrategyType strategyType ){
		
		ActionTypeEnum action = strategyType.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;

		strategyType = save( strategyType );

		StrategyTypeAudit sta = new StrategyTypeAudit( strategyType, action, user.getLogin(), new Date() );
		
		strategyTypeAuditDAO.save( sta );
		
		return strategyType;
	}
	
	public Integer getNumberOfLegsFromStrategyType( StrategyTypeEnum strategyType ){
		
		if ( strategyType == null || strategyType.equals( StrategyTypeEnum.UNKNOWN ) )
			return null;
		
		strategyTypeAux.setDescription( strategyType.name() );
		
		List<StrategyType> strategyTypeList = findByExample( strategyTypeAux );
		
		if ( strategyTypeList != null && strategyTypeList.size() == 1 ){
			return strategyTypeList.get( 0 ).getNumberOfLegs();
		}
		return null;
	}

	public Long generate( int qtd ){
		
		Long qtRegs = 0L;
		
		for (int i = 1; i <= 10; i++) {
			saveStrategyType( new StrategyType( i, "Description_" + i , ( i % 4 ) +1 ) );
			qtRegs++;
		}
		
		return qtRegs;
	}
	
	public StrategyType getByIndex( int index ) {
		return findAll().get( index );
	}
}