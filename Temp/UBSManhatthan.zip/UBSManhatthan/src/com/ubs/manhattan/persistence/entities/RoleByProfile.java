package com.ubs.manhattan.persistence.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name="TB_REL_ROLES_PROFILES",
uniqueConstraints={
		   @UniqueConstraint(columnNames={"ROLE", "PROFILE"}, name = "CK_ROLES_PROFILES")
		})
public class RoleByProfile {
	
	public RoleByProfile(){}
	
	public RoleByProfile(Role role, Profile profile) {
		super();
		this.role = role;
		this.profile = profile;
	}

	@Id
	@Column ( name = "ID")
	@SequenceGenerator(name = "TB_REL_ROLES_PROFILES_ID_GENERATOR", sequenceName = "SEQ_REL_ROLES_PROFILES", allocationSize = 1)
	@GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "TB_REL_ROLES_PROFILES_ID_GENERATOR" )
	private Long id;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "ROLE", nullable = false )
	private Role role;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "PROFILE", nullable = false )
	private Profile profile;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public Profile getProfile() {
		return profile;
	}

	public void setProfile(Profile profile) {
		this.profile = profile;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((profile == null) ? 0 : profile.hashCode());
		result = prime * result + ((role == null) ? 0 : role.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RoleByProfile other = (RoleByProfile) obj;
		if (profile == null) {
			if (other.profile != null)
				return false;
		} else if (!profile.equals(other.profile))
			return false;
		if (role == null) {
			if (other.role != null)
				return false;
		} else if (!role.equals(other.role))
			return false;
		return true;
	}

	@Override
	public String toString() {
		
		String roleStr = "Role [id=" + role.getId() + ", description=" + role.getDescription() + "]";
		
		String profileStr = "Profile [id=" + profile.getId() + ", description=" + profile.getDescription() + "]";
		
		
		return "SessionByAccount [id=" + id +
			   ", role=" + roleStr +
			   ", profile=" + profileStr + "]";
	}
}