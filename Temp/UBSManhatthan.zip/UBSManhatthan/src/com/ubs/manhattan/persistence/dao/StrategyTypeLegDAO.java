package com.ubs.manhattan.persistence.dao;

import java.util.Date;
import java.util.List;

import com.ubs.manhattan.enums.ActionTypeEnum;
import com.ubs.manhattan.persistence.dao.audit.StrategyTypeLegAuditDAO;
import com.ubs.manhattan.persistence.entities.StrategyType;
import com.ubs.manhattan.persistence.entities.StrategyTypeLeg;
import com.ubs.manhattan.persistence.entities.audit.StrategyTypeLegAudit;
import com.ubs.manhatthan.admin.model.User;

public class StrategyTypeLegDAO extends AbstractDAO<StrategyTypeLeg, Long> {
	
	private StrategyTypeLegAuditDAO strategyTypeLegAuditDAO = new StrategyTypeLegAuditDAO();
	
	private User user = new User();
	
	public StrategyTypeLeg saveStrategyTypeLeg( StrategyTypeLeg strategyTypeLeg ){
		
		ActionTypeEnum action = strategyTypeLeg.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;

		strategyTypeLeg = save( strategyTypeLeg );

		StrategyTypeLegAudit sta = new StrategyTypeLegAudit( strategyTypeLeg, action, user.getLogin(), new Date() );
		
		strategyTypeLegAuditDAO.save( sta );
		
		return strategyTypeLeg;
	}

	public Long generate( int qtd ){
		
		StrategyTypeDAO strategyTypeDAO = new StrategyTypeDAO();
		List<StrategyType> StrategyTypeList = strategyTypeDAO.findAll();
		
		Long qtRegs = 0L;
		
		for (int i = 1; i <= 10; i++) {
			saveStrategyTypeLeg( new StrategyTypeLeg( StrategyTypeList.get( i % 5), ( i % 2 ) +1, ( i % 4 ) +1 ) );
			qtRegs++;
		}
		
		return qtRegs;
	}
	
	public StrategyTypeLeg getByIndex( int index ) {
		return findAll().get( index );
	}
}