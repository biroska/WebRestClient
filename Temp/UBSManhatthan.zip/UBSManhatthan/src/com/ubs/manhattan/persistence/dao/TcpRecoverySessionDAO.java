package com.ubs.manhattan.persistence.dao;

import java.util.Date;
import java.util.List;

import com.ubs.manhattan.enums.ActionTypeEnum;
import com.ubs.manhattan.persistence.dao.audit.TcpRecoverySessionAuditDAO;
import com.ubs.manhattan.persistence.entities.Exchange;
import com.ubs.manhattan.persistence.entities.TcpRecoverySession;
import com.ubs.manhattan.persistence.entities.audit.TcpRecoverySessionAudit;
import com.ubs.manhatthan.admin.model.User;

public class TcpRecoverySessionDAO extends AbstractDAO<TcpRecoverySession, Long> {
	
	private ExchangeDAO exchangeDAO = new ExchangeDAO();
	
	private TcpRecoverySessionAuditDAO tcpRecoverySessionAuditDAO = new TcpRecoverySessionAuditDAO();
	
	private User user = new User();
	
	public TcpRecoverySession saveTcpRecoverySession( TcpRecoverySession tcpRecoverySession ){
		
		ActionTypeEnum action = tcpRecoverySession.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;

		tcpRecoverySession  = save( tcpRecoverySession );

		TcpRecoverySessionAudit trsa = new TcpRecoverySessionAudit( tcpRecoverySession, action, user.getLogin(), new Date() );
		
		tcpRecoverySessionAuditDAO.save( trsa );
		
		return tcpRecoverySession;
	}

	public Long generate( int qtd ){
		
		List<Exchange> exchangeList = exchangeDAO.findAll();
		
		Long qtRegs = 0L;
		
		for ( int i = 1; i<= qtd; i++ ){
			saveTcpRecoverySession( new TcpRecoverySession( exchangeList.get( i % 2), "255.255.255.0"+i, (long) 8079 +i,
															"targetCompId_"+i, "senderCompId_"+i ) );
			qtRegs++;
		}
		
		return qtRegs;
	}
	
	public TcpRecoverySession getByIndex( int index ) {
		return findAll().get( index );
	}
}