package com.ubs.manhattan.persistence.dao;

import java.util.Date;

import com.ubs.manhattan.enums.ActionTypeEnum;
import com.ubs.manhattan.persistence.dao.audit.ProfileAuditDAO;
import com.ubs.manhattan.persistence.entities.Profile;
import com.ubs.manhattan.persistence.entities.audit.ProfileAudit;
import com.ubs.manhatthan.admin.model.User;

public class ProfileDAO extends AbstractDAO<Profile, Long> {
	
	private ProfileAuditDAO profileAuditDAO = new ProfileAuditDAO();
	
	private User user = new User();
	
	public Profile saveProfile( Profile profile ){
		
		ActionTypeEnum action = profile.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;

		profile = save( profile );

		ProfileAudit pa = new ProfileAudit( profile, action, user.getLogin(), new Date() );
		
		profileAuditDAO.save( pa );
		
		return profile;
	}

	public Long generate( int qtd ){
		
		Long qtRegs = 4L;
		
		saveProfile( new Profile("SUPPORT") );
		saveProfile( new Profile("TRADER") );
		saveProfile( new Profile("SUPERVISOR") );
		saveProfile( new Profile("ADMINISTRATIVE") );
		return qtRegs;
	}
	
	public Profile getByIndex( int index ) {
		return findAll().get( index );
	}
}