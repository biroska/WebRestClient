package com.ubs.manhattan.persistence.dao.audit;

import com.ubs.manhattan.persistence.dao.AbstractDAO;
import com.ubs.manhattan.persistence.entities.audit.PasswordParameterAudit;

public class PasswordParameterAuditDAO extends AbstractDAO<PasswordParameterAudit, Long> {}
