package com.ubs.manhattan.persistence.dao;

import java.util.Date;
import java.util.List;

import com.ubs.manhattan.enums.ActionTypeEnum;
import com.ubs.manhattan.persistence.dao.audit.EngineUmdfChannelAuditDAO;
import com.ubs.manhattan.persistence.entities.EngineUmdfChannel;
import com.ubs.manhattan.persistence.entities.Exchange;
import com.ubs.manhattan.persistence.entities.audit.EngineUmdfChannelAudit;
import com.ubs.manhatthan.admin.model.User;

public class EngineUmdfChannelDAO extends AbstractDAO<EngineUmdfChannel, Long> {
	
	private ExchangeDAO exchangeDAO = new ExchangeDAO();
	
	private EngineUmdfChannelAuditDAO engineUmdfChannelAuditDAO = new EngineUmdfChannelAuditDAO();
	
	private User user = new User();
	
	public EngineUmdfChannel saveEngineUmdfChannel( EngineUmdfChannel engineUmdfChannel ){
		
		ActionTypeEnum action = engineUmdfChannel.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;

		engineUmdfChannel  = save( engineUmdfChannel );

		EngineUmdfChannelAudit euca = new EngineUmdfChannelAudit( engineUmdfChannel, action, user.getLogin(), new Date() );
		
		engineUmdfChannelAuditDAO.save( euca );
		
		return engineUmdfChannel;
	}

	public Long generate( int qtd ){
		
		List<Exchange> exchangeList = exchangeDAO.findAll();
		
		long idGenerico = System.currentTimeMillis();
		
		Long qtRegs = 0L;
		
		for ( int i = 1; i<= qtd; i++ ){
			saveEngineUmdfChannel( new EngineUmdfChannel( idGenerico +i, exchangeList.get( i % 2),
																		"incrementalIp_"+i, (long) 8079 +i,
																		"marketRecIp_"+i, (long) 9089 +i,
																		"instrDefIp_"+i, (long) 7069 + i ) );
			qtRegs++;
		}
		
		return qtRegs;
	}
	
	public EngineUmdfChannel getByIndex( int index ) {
		return findAll().get( index );
	}
}