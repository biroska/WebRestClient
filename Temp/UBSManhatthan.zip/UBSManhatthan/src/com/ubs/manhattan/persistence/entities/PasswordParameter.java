package com.ubs.manhattan.persistence.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name="TB_PASSWORD_PARAMETERS",
	   uniqueConstraints={
		   @UniqueConstraint(columnNames={"QT_UPPER_CHARS",
										  "QT_LOWER_CHARS",
										  "QT_NUMBERS",
										  "QT_MIN_LENGTH",
										  "QT_VALID_DAYS"}, name = "CK_PASSWORD_PARAMETERS")
		})
public class PasswordParameter {
	
	public PasswordParameter(){}
	
	public PasswordParameter(Integer qtUpperChars, Integer qtLowerChars,
			Integer qtNumbers, Integer qtMinLength, Integer qtValidDays ) {
		super();
		this.qtUpperChars = qtUpperChars;
		this.qtLowerChars = qtLowerChars;
		this.qtNumbers = qtNumbers;
		this.qtMinLength = qtMinLength;
		this.qtValidDays = qtValidDays;
	}

	@Id
	@Column ( name = "ID")
	@SequenceGenerator(name = "TB_PASSWORD_PARAMETERS_ID_GENERATOR", sequenceName = "SEQ_PASSWORD_PARAMETERS", allocationSize = 1)
	@GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "TB_PASSWORD_PARAMETERS_ID_GENERATOR" )
	private Long id;
	
	@Column ( name = "QT_UPPER_CHARS", nullable = false )
	private Integer qtUpperChars = 1;
	
	@Column ( name = "QT_LOWER_CHARS", nullable = false)
	private Integer qtLowerChars = 1;
	
	@Column ( name = "QT_NUMBERS", nullable = false)
	private Integer qtNumbers = 1;
	
	@Column ( name = "QT_MIN_LENGTH", nullable = false)
	private Integer qtMinLength = 8;
	
	@Column ( name = "QT_VALID_DAYS", nullable = false)
	private Integer qtValidDays = 90;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Integer getQtUpperChars() {
		return qtUpperChars;
	}

	public void setQtUpperChars(Integer qtUpperChars) {
		this.qtUpperChars = qtUpperChars;
	}

	public Integer getQtLowerChars() {
		return qtLowerChars;
	}

	public void setQtLowerChars(Integer qtLowerChars) {
		this.qtLowerChars = qtLowerChars;
	}

	public Integer getQtNumbers() {
		return qtNumbers;
	}

	public void setQtNumbers(Integer qtNumbers) {
		this.qtNumbers = qtNumbers;
	}

	public Integer getQtMinLength() {
		return qtMinLength;
	}

	public void setQtMinLength(Integer qtMinLength) {
		this.qtMinLength = qtMinLength;
	}
	
	public Integer getQtValidDays() {
		return qtValidDays;
	}

	public void setQtValidDays(Integer qtValidDays) {
		this.qtValidDays = qtValidDays;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((qtLowerChars == null) ? 0 : qtLowerChars.hashCode());
		result = prime * result
				+ ((qtMinLength == null) ? 0 : qtMinLength.hashCode());
		result = prime * result
				+ ((qtNumbers == null) ? 0 : qtNumbers.hashCode());
		result = prime * result
				+ ((qtUpperChars == null) ? 0 : qtUpperChars.hashCode());
		result = prime * result
				+ ((qtValidDays == null) ? 0 : qtValidDays.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PasswordParameter other = (PasswordParameter) obj;
		if (qtLowerChars == null) {
			if (other.qtLowerChars != null)
				return false;
		} else if (!qtLowerChars.equals(other.qtLowerChars))
			return false;
		if (qtMinLength == null) {
			if (other.qtMinLength != null)
				return false;
		} else if (!qtMinLength.equals(other.qtMinLength))
			return false;
		if (qtNumbers == null) {
			if (other.qtNumbers != null)
				return false;
		} else if (!qtNumbers.equals(other.qtNumbers))
			return false;
		if (qtUpperChars == null) {
			if (other.qtUpperChars != null)
				return false;
		} else if (!qtUpperChars.equals(other.qtUpperChars))
			return false;
		if (qtValidDays == null) {
			if (other.qtValidDays != null)
				return false;
		} else if (!qtValidDays.equals(other.qtValidDays))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "PasswordParameters [id=" + id + ", qtUpperChars=" + qtUpperChars +
				", qtLowerChars=" + qtLowerChars + ", qtNumbers=" + qtNumbers +
				", qtMinLength=" + qtMinLength + ", qtValidDays= " + qtValidDays +"]";
	}
}