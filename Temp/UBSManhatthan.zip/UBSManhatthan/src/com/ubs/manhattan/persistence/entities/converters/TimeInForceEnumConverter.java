package com.ubs.manhattan.persistence.entities.converters;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import com.ubs.manhattan.enums.TimeInForceEnum;

@Converter(autoApply = true)
public class TimeInForceEnumConverter implements AttributeConverter<TimeInForceEnum, Integer> {

	@Override
	public Integer convertToDatabaseColumn(TimeInForceEnum timeInForceEnum ) {
		return timeInForceEnum.getCode();
	}

	@Override
	public TimeInForceEnum convertToEntityAttribute(Integer dbData) {
		for ( TimeInForceEnum tif : TimeInForceEnum.values() ) {
			if ( tif.getCode().equals(dbData) ) {
				return tif;
			}
		}

		throw new IllegalArgumentException("Unknown database value:" + dbData );
	}
}