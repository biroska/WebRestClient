package com.ubs.manhattan.persistence.dao;

import java.util.Date;

import com.ubs.manhattan.enums.ActionTypeEnum;
import com.ubs.manhattan.persistence.dao.audit.TraderWatchTabAuditDAO;
import com.ubs.manhattan.persistence.entities.TraderWatchTab;
import com.ubs.manhattan.persistence.entities.audit.TraderWatchTabAudit;
import com.ubs.manhatthan.admin.model.User;

public class TraderWatchTabDAO extends AbstractDAO<TraderWatchTab, Long> {
	
	private TraderWatchTabAuditDAO traderWatchTabAuditDAO = new TraderWatchTabAuditDAO();
	
	private User user = new User();
	
	public TraderWatchTab saveTraderWatchTab( TraderWatchTab traderWatchTab ){
		
		ActionTypeEnum action = traderWatchTab.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;

		traderWatchTab = save( traderWatchTab );

		TraderWatchTabAudit sta = new TraderWatchTabAudit( traderWatchTab, action, user.getLogin(), new Date() );
		
		traderWatchTabAuditDAO.save( sta );
		
		return traderWatchTab;
	}

	public Long generate( int qtd ){

		Long qtRegs = 0L;
		
		for (int i = 1; i <= 10; i++) {
			saveTraderWatchTab( new TraderWatchTab( "AIM*", "Descrip_" + i ) );
			qtRegs++;
		}
		
		return qtRegs;
	}
	
	public TraderWatchTab getByIndex( int index ) {
		return findAll().get( index );
	}
}