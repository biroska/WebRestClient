package com.ubs.manhattan.persistence.dao;

import java.util.List;

import com.ubs.manhattan.persistence.entities.ClientAccount;

public class ClientAccountDAO extends AbstractDAO<ClientAccount, Long> {
	
	public ClientAccount getByIndex( int index ) {
		
		List<ClientAccount> findByCriteria = findByCriteria(null, null, -1, index +1 );
		
		return findByCriteria.get( index );
	}
}