package com.ubs.manhattan.persistence.dao;

import java.util.Date;
import java.util.List;

import com.ubs.manhattan.enums.ActionTypeEnum;
import com.ubs.manhattan.enums.OrderStatusEnum;
import com.ubs.manhattan.enums.SideEnum;
import com.ubs.manhattan.persistence.dao.audit.OrderTradeAuditDAO;
import com.ubs.manhattan.persistence.entities.ClientAccount;
import com.ubs.manhattan.persistence.entities.OrderTrade;
import com.ubs.manhattan.persistence.entities.StrategyOrders;
import com.ubs.manhattan.persistence.entities.audit.OrderTradeAudit;
import com.ubs.manhatthan.admin.model.User;

public class OrderTradeDAO extends AbstractDAO<OrderTrade, Long> {
	
	private StrategyOrdersDAO strategyOrdersDAO = new StrategyOrdersDAO();
	private ClientAccountDAO clientAccountDAO = new ClientAccountDAO();

	private OrderTradeAuditDAO orderTradeAuditDAO = new OrderTradeAuditDAO();
	
	private User user = new User();
	
	public OrderTrade saveOrderTrade( OrderTrade orderTrade ){
		
		ActionTypeEnum action = orderTrade.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;

		orderTrade  = save( orderTrade );

		OrderTradeAudit teca = new OrderTradeAudit( orderTrade, action, user.getLogin(), new Date() );
		
		orderTradeAuditDAO.save( teca );
		
		return orderTrade;
	}
	
	public Long generate( int qtd ){
		
		StrategyOrders strategyOrder = strategyOrdersDAO.getClientByIndex( 0 );
		List<ClientAccount> clientAccountList = clientAccountDAO.findAll();
		
		Long qtRegs = 0L;
		
		for ( int i = 1; i<= qtd; i++ ){
			saveOrderTrade( new OrderTrade( strategyOrder, OrderStatusEnum.REPLACED , "SYMBOL",
					                        SideEnum.fromValue( (i % 2) +1 ) ,
					                        clientAccountList.get( i % 5), "TRADE_"+i,  i * 25L, (Math.random() * i * 100) ) );
			qtRegs++;
		}
		
		return qtRegs;
	}
	
	public OrderTrade getByIndex( int index ) {
		return findAll().get( index );
	}
}