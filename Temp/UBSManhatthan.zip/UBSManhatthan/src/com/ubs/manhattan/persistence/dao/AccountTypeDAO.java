package com.ubs.manhattan.persistence.dao;

import com.ubs.manhattan.persistence.entities.AccountType;

public class AccountTypeDAO extends AbstractDAO<AccountType, Long> {
	
	public Long generateAccountType( int qtd ){
		
		Long qtRegs = 0L;
		
		for ( int i = 1; i<= qtd; i++ ){
			save( new AccountType( "AccountType_" + i  ) );
			qtRegs++;
		}
		return qtRegs;
	}
	
	public AccountType getAccountTypeByIndex( int index ) {
		return findAll().get( index );
	}

}
