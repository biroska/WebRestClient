package com.ubs.manhattan.persistence.dao;

import java.util.Date;
import java.util.List;

import com.ubs.manhattan.enums.ActionTypeEnum;
import com.ubs.manhattan.persistence.dao.audit.TraderExchangeCodeAuditDAO;
import com.ubs.manhattan.persistence.entities.Exchange;
import com.ubs.manhattan.persistence.entities.TraderExchangeCode;
import com.ubs.manhattan.persistence.entities.audit.TraderExchangeCodeAudit;
import com.ubs.manhatthan.admin.model.User;

public class TraderExchangeCodeDAO extends AbstractDAO<TraderExchangeCode, Long> {
	
	private ExchangeDAO exchangeDAO = new ExchangeDAO();
//	private TraderDAO traderDAO = new TraderDAO();

	private TraderExchangeCodeAuditDAO traderExchangeCodeAuditDAO = new TraderExchangeCodeAuditDAO();
	
	private User user = new User();
	
	public TraderExchangeCode saveTraderExchangeCode( TraderExchangeCode traderExchangeCode ){
		
		ActionTypeEnum action = traderExchangeCode.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;

		traderExchangeCode  = save( traderExchangeCode );

		TraderExchangeCodeAudit teca = new TraderExchangeCodeAudit( traderExchangeCode, action, user.getLogin(), new Date() );
		
		traderExchangeCodeAuditDAO.save( teca );
		
		return traderExchangeCode;
	}
	
	public Long generate( int qtd ){
		
		List<Exchange> exchangeList = exchangeDAO.findAll();
//		List<Trader> traderList = traderDAO.findAll();
		
		Long qtRegs = 0L;
		
		for ( int i = 1; i<= qtd; i++ ){
			saveTraderExchangeCode( new TraderExchangeCode( "AIM*", exchangeList.get( i % 2 ), "Code_" + i) );
			qtRegs++;
		}
		
		return qtRegs;
	}
	
	public TraderExchangeCode getByIndex( int index ) {
		return findAll().get( index );
	}
}