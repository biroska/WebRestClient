package com.ubs.manhattan.persistence.entities;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.ubs.manhattan.enums.OrderStatusEnum;
import com.ubs.manhattan.enums.SideEnum;

@Entity
@Table(name="TB_ORDER_TRADES",
uniqueConstraints={
		   @UniqueConstraint(columnNames="UNIQUE_TRADE_ID", name = "CK_TRADER_WATCH_TABS")
		})
public class OrderTrade {
	
	public OrderTrade(){}
	
	public OrderTrade(StrategyOrders strategyOrder,
			OrderStatusEnum orderStatus, String symbol, SideEnum side,
			ClientAccount account, String tradeId, Long quantity, Double price) {
		super();
		this.strategyOrder = strategyOrder;
		this.orderStatus = orderStatus;
		this.symbol = symbol;
		this.side = side;
		this.account = account;
		this.tradeId = tradeId;
		this.quantity = quantity;
		this.price = price;
	}

	@Id
	@Column ( name = "ID")
	@SequenceGenerator(name = "TB_ORDER_TRADES_ID_GENERATOR", sequenceName = "SEQ_ORDER_TRADES", allocationSize = 1)
	@GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "TB_ORDER_TRADES_ID_GENERATOR" )
	private Long id;
	
//	@ManyToOne(fetch=FetchType.LAZY/*, cascade = CascadeType.ALL*/)
//	@JoinColumn(name = "ORDER_ID", nullable = false )
//	private StrategyOrders strategyOrder;
	
	@ManyToOne(fetch=FetchType.LAZY, cascade = CascadeType.REFRESH )
	@JoinColumns({
		  @JoinColumn( name = "ENGINE_ID", referencedColumnName = "ENGINE_ID", nullable = false ),
		  @JoinColumn( name = "ORDER_ID", referencedColumnName = "ORDER_ID" , nullable = false ),
		  @JoinColumn( name = "ORDER_DATE", referencedColumnName = "ORDER_DATE" , nullable = false )
		})
	private StrategyOrders strategyOrder;
	
	@Column ( name = "ORDER_STATUS", nullable=false )
	private OrderStatusEnum orderStatus;
	
	@Column ( name = "SYMBOL", nullable=false )
	private String symbol;
	
	@Column ( name = "SIDE", nullable=false )
	private SideEnum side;
	
	@ManyToOne(fetch=FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn( name = "ACCOUNT", nullable=false )
	private ClientAccount account;
	
	@Column ( name = "UNIQUE_TRADE_ID", nullable=false, length = 10 )
	private String tradeId;
	
	@Column ( name = "QUANTITY", nullable=false )
	private Long quantity;
	
	@Column ( name = "PRICE", columnDefinition= "Decimal(10,7)" )
	private Double price;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public StrategyOrders getStrategyOrder() {
		return strategyOrder;
	}

	public void setStrategyOrder(StrategyOrders strategyOrder) {
		this.strategyOrder = strategyOrder;
	}

	public OrderStatusEnum getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(OrderStatusEnum orderStatus) {
		this.orderStatus = orderStatus;
	}

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	public SideEnum getSide() {
		return side;
	}

	public void setSide(SideEnum side) {
		this.side = side;
	}

	public ClientAccount getAccount() {
		return account;
	}

	public void setAccount(ClientAccount account) {
		this.account = account;
	}

	public String getTradeId() {
		return tradeId;
	}

	public void setTradeId(String tradeId) {
		this.tradeId = tradeId;
	}

	public Long getQuantity() {
		return quantity;
	}

	public void setQuantity(Long quantity) {
		this.quantity = quantity;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((account == null) ? 0 : account.hashCode());
		result = prime * result
				+ ((orderStatus == null) ? 0 : orderStatus.hashCode());
		result = prime * result + ((price == null) ? 0 : price.hashCode());
		result = prime * result
				+ ((quantity == null) ? 0 : quantity.hashCode());
		result = prime * result + ((side == null) ? 0 : side.hashCode());
		result = prime * result
				+ ((strategyOrder == null) ? 0 : strategyOrder.hashCode());
		result = prime * result + ((symbol == null) ? 0 : symbol.hashCode());
		result = prime * result + ((tradeId == null) ? 0 : tradeId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OrderTrade other = (OrderTrade) obj;
		if (account == null) {
			if (other.account != null)
				return false;
		} else if (!account.equals(other.account))
			return false;
		if (orderStatus != other.orderStatus)
			return false;
		if (price == null) {
			if (other.price != null)
				return false;
		} else if (!price.equals(other.price))
			return false;
		if (quantity == null) {
			if (other.quantity != null)
				return false;
		} else if (!quantity.equals(other.quantity))
			return false;
		if (side != other.side)
			return false;
		if (strategyOrder == null) {
			if (other.strategyOrder != null)
				return false;
		} else if (!strategyOrder.equals(other.strategyOrder))
			return false;
		if (symbol == null) {
			if (other.symbol != null)
				return false;
		} else if (!symbol.equals(other.symbol))
			return false;
		if (tradeId == null) {
			if (other.tradeId != null)
				return false;
		} else if (!tradeId.equals(other.tradeId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "OrderTrade [id=" + id + ", strategyOrder=" + strategyOrder
				+ ", orderStatus=" + orderStatus + ", symbol=" + symbol
				+ ", side=" + side + ", account=" + account + ", tradeId="
				+ tradeId + ", quantity=" + quantity + ", price=" + price + "]";
	}
}