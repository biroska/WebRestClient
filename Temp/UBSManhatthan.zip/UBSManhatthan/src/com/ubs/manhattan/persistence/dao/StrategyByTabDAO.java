package com.ubs.manhattan.persistence.dao;

import java.util.Date;
import java.util.List;

import com.ubs.manhattan.enums.ActionTypeEnum;
import com.ubs.manhattan.persistence.dao.audit.StrategyByTabAuditDAO;
import com.ubs.manhattan.persistence.entities.StrategyByTab;
import com.ubs.manhattan.persistence.entities.StrategyType;
import com.ubs.manhattan.persistence.entities.TraderWatchTab;
import com.ubs.manhattan.persistence.entities.audit.StrategyByTabAudit;
import com.ubs.manhatthan.admin.model.User;

public class StrategyByTabDAO extends AbstractDAO<StrategyByTab, Long> {
	
	private StrategyByTabAuditDAO strategyByTabAuditDAO = new StrategyByTabAuditDAO();
	
	private User user = new User();
	
	public StrategyByTab saveStrategyByTab( StrategyByTab strategyByTab ){
		
		ActionTypeEnum action = strategyByTab.getId() == null ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;

		strategyByTab = save( strategyByTab );

		StrategyByTabAudit sta = new StrategyByTabAudit( strategyByTab, action, user.getLogin(), new Date() );
		
		strategyByTabAuditDAO.save( sta );
		
		return strategyByTab;
	}

	public Long generate( int qtd ){
		
		StrategyTypeDAO strategyTypeDAO = new StrategyTypeDAO();
		TraderWatchTabDAO traderWatchTabDAO = new TraderWatchTabDAO();
		
		List<StrategyType> strategyTypeList = strategyTypeDAO.findAll();
		List<TraderWatchTab> traderWatchTabList = traderWatchTabDAO.findAll();
		
		Long qtRegs = 0L;
		
		for (int i = 1; i <= 10; i++) {
			saveStrategyByTab( new StrategyByTab( traderWatchTabList.get( i % 5 ), strategyTypeList.get( i % 5), i ) );
			qtRegs++;
		}
		
		return qtRegs;
	}
	
	public StrategyByTab getByIndex( int index ) {
		return findAll().get( index );
	}
}