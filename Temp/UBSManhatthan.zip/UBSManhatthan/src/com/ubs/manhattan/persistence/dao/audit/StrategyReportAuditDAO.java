package com.ubs.manhattan.persistence.dao.audit;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.criterion.Restrictions;

import com.ubs.manhattan.enums.ActionTypeEnum;
import com.ubs.manhattan.persistence.dao.AbstractDAO;
import com.ubs.manhattan.persistence.entities.LegStrategyReport;
import com.ubs.manhattan.persistence.entities.StrategyOrders;
import com.ubs.manhattan.persistence.entities.StrategyReport;
import com.ubs.manhattan.persistence.entities.audit.LegStrategyReportAudit;
import com.ubs.manhattan.persistence.entities.audit.StrategyOrdersAudit;
import com.ubs.manhattan.persistence.entities.audit.StrategyReportAudit;
import com.ubs.manhatthan.admin.model.User;

public class StrategyReportAuditDAO extends AbstractDAO<StrategyReportAudit, Long> {
	
	private User user = new User();
	private StrategyOrdersAuditDAO strategyOrdersAuditDAO = new StrategyOrdersAuditDAO();
	private LegStrategyReportAuditDAO legStrategyReportAuditDAO = new LegStrategyReportAuditDAO();
	
	public void saveReportAudit( StrategyReport report ){
		
		Long legId = 0L;
		Long orderId = 0L;
		ActionTypeEnum legAction = null;
		ActionTypeEnum orderAction = null;
		List<StrategyOrdersAudit> lsoa = new ArrayList<StrategyOrdersAudit>();
		List<LegStrategyReportAudit> lsra = new ArrayList<LegStrategyReportAudit>();
		
//		Define StrategyReportAudit para persistencia
		Long idCount = countByCriteria( Restrictions.eq("origid", report.getId().getStrategyId() ) );
		
		ActionTypeEnum action = idCount == 0 ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;
		
		StrategyReportAudit strategyReportAudit = new StrategyReportAudit( report, action, user.getLogin(), new Date() );
		
//		Define LegStrategyReportAudit para persistencia
		if ( report.getLegStrategyList() != null ){
			for (LegStrategyReport leg : report.getLegStrategyList() ) {
				
				legId = legStrategyReportAuditDAO.countByCriteria( Restrictions.eq("legSeq", leg.getId().getLegSeq() ) ,
																   Restrictions.eq("strategyReportId", leg.getId().getStrategyId() ) );
				
				legAction = legId == 0 ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;
				
				LegStrategyReportAudit legAudit = new LegStrategyReportAudit( leg, legAction, user.getLogin(), new Date() );
				
				
				lsra.add( legAudit );
				
//				Define strategyOrdersAudit para persistencia
				if ( leg.getStrategyOrdersList() != null ){
					
					for (StrategyOrders order : leg.getStrategyOrdersList() ) {
						
						orderId = strategyOrdersAuditDAO.countByCriteria( Restrictions.eq("origid", order.getId().getOrderId() ) );
						
						orderAction = orderId == 0 ? ActionTypeEnum.INSERT : ActionTypeEnum.UPDATE;
						
						lsoa.add( new StrategyOrdersAudit( order , orderAction, user.getLogin(), new Date() ) );
					}
				}
			}
		}

//		Gera registro na tabela de auditoria - Strategyreport
		save( strategyReportAudit );
		legStrategyReportAuditDAO.save( lsra );
		strategyOrdersAuditDAO.save( lsoa );
	}
}