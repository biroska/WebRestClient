package com.ubs.manhattan.persistence.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name="TB_REL_SESSIONS_PER_ACCOUNT",
uniqueConstraints={
		   @UniqueConstraint(columnNames={"ACCOUNT_ID", "SESSION_ID"}, name = "CK_SESSIONS_PER_ACCOUNT")
		})
public class SessionByAccount {
	
	public SessionByAccount(){}
	
	public SessionByAccount(ClientAccount clientAccountId, OrderFixSession orderFixSessionId) {
		super();
		this.clientAccountId = clientAccountId;
		this.orderFixSessionId = orderFixSessionId;
	}

	@Id
	@Column ( name = "ID")
	@SequenceGenerator(name = "TB_REL_SESSIONS_PER_ACCOUNT_ID_GENERATOR", sequenceName = "SEQ_REL_SESSIONS_PER_ACCOUNT", allocationSize = 1)
	@GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "TB_REL_SESSIONS_PER_ACCOUNT_ID_GENERATOR" )
	private Long id;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "ACCOUNT_ID", nullable = false )
	private ClientAccount clientAccountId;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "SESSION_ID", nullable = false )
	private OrderFixSession orderFixSessionId;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public ClientAccount getClientAccountId() {
		return clientAccountId;
	}

	public void setClientAccountId(ClientAccount clientAccountId) {
		this.clientAccountId = clientAccountId;
	}

	public OrderFixSession getOrderFixSessionId() {
		return orderFixSessionId;
	}

	public void setOrderFixSessionId(OrderFixSession orderFixSessionId) {
		this.orderFixSessionId = orderFixSessionId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((clientAccountId == null) ? 0 : clientAccountId.hashCode());
		result = prime
				* result
				+ ((orderFixSessionId == null) ? 0 : orderFixSessionId
						.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SessionByAccount other = (SessionByAccount) obj;
		if (clientAccountId == null) {
			if (other.clientAccountId != null)
				return false;
		} else if (!clientAccountId.equals(other.clientAccountId))
			return false;
		if (orderFixSessionId == null) {
			if (other.orderFixSessionId != null)
				return false;
		} else if (!orderFixSessionId.equals(other.orderFixSessionId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "SessionByAccount [id=" + id + ", clientAccountId="
				+ clientAccountId + ", orderFixSessionId=" + orderFixSessionId
				+ "]";
	}
}