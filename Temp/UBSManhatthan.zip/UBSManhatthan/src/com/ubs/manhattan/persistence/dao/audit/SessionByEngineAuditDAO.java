package com.ubs.manhattan.persistence.dao.audit;

import com.ubs.manhattan.persistence.dao.AbstractDAO;
import com.ubs.manhattan.persistence.entities.audit.SessionByEngineAudit;

public class SessionByEngineAuditDAO extends AbstractDAO<SessionByEngineAudit, Long> {}
