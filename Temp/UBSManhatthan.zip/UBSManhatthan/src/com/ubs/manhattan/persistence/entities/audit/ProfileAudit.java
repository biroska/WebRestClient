package com.ubs.manhattan.persistence.entities.audit;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.ubs.manhattan.enums.ActionTypeEnum;
import com.ubs.manhattan.persistence.entities.Profile;

@Entity
@Table(name="TB_AUDIT_DOMAIN_PROFILES")
public class ProfileAudit {
	
	public ProfileAudit(){}
	
	public ProfileAudit(String description) {
		super();
		this.description = description;
	}
	
	public ProfileAudit( Profile profile, ActionTypeEnum action, String user, Date registryDate) {
		this.action = action;
		this.user = user;
		this.registryDate = registryDate;
		
		this.origId = profile.getId();
		this.description = profile.getDescription();
	}

	@Id
	@Column ( name = "PROFILE")
	@SequenceGenerator(name = "TB_DOMAIN_PROFILES_AUDIT_ID_GENERATOR", sequenceName = "SEQ_AUDIT_DOMAIN_PROFILES", allocationSize = 1)
	@GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "TB_DOMAIN_PROFILES_AUDIT_ID_GENERATOR" )
	private Long id;
	
	@Enumerated(EnumType.STRING)
	@Column( name = "ACTION", nullable=false )
	private ActionTypeEnum action;
	
	@Column( name = "REGISTRY_USER", nullable=false )
	private String user;
	
	@Column( name = "REGISTRY_DATE", nullable=false )
	private Date registryDate;

	@Column ( name = "ORIG_ID", nullable=false )
	private Long origId;
	
	@Column ( name = "DESCRIPTION", nullable=false, length = 16 )
	private String description;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public ActionTypeEnum getAction() {
		return action;
	}

	public void setAction(ActionTypeEnum action) {
		this.action = action;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public Date getRegistryDate() {
		return registryDate;
	}

	public void setRegistryDate(Date registryDate) {
		this.registryDate = registryDate;
	}

	public Long getOrigId() {
		return origId;
	}

	public void setOrigId(Long origId) {
		this.origId = origId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((action == null) ? 0 : action.hashCode());
		result = prime * result + ((origId == null) ? 0 : origId.hashCode());
		result = prime * result
				+ ((registryDate == null) ? 0 : registryDate.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProfileAudit other = (ProfileAudit) obj;
		if (action != other.action)
			return false;
		if (origId == null) {
			if (other.origId != null)
				return false;
		} else if (!origId.equals(other.origId))
			return false;
		if (registryDate == null) {
			if (other.registryDate != null)
				return false;
		} else if (!registryDate.equals(other.registryDate))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Profile [id=" + id + ", description=" + description + "]";
	}
}