/*
 * NetworkClient_Test.java
 *
 *  Created on: Set 25, 2015
 *      Author: vanputtg
 */

//Package
package com.ubs.manhattan.network.client;

//Import
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Level;

import com.ubs.manhattan.cache.CacheHelper;
import com.ubs.manhattan.converters.ConverterToEntity;
import com.ubs.manhattan.dispatcher.manager.Manager;
import com.ubs.manhattan.enricher.Builders;
import com.ubs.manhattan.enricher.PrepareToPersist;
import com.ubs.manhattan.enums.CommandTypeEnum;
import com.ubs.manhattan.enums.MessageTypeEnum;
import com.ubs.manhattan.logger.ManhattanLogger;
import com.ubs.manhattan.network.client.NetworkProtobuf.pb_legged_order;
import com.ubs.manhattan.network.client.NetworkProtobuf.pb_message_type_enum;
import com.ubs.manhattan.network.client.NetworkProtobuf.pb_reject_create_modify_cancel_strategy_message;
import com.ubs.manhattan.network.client.NetworkProtobuf.pb_report_order_message;
import com.ubs.manhattan.network.client.NetworkProtobuf.pb_report_strategy_message;
import com.ubs.manhattan.network.client.NetworkProtobuf.pb_statistics_message;
import com.ubs.manhattan.network.client.NetworkProtobuf.pb_to_engine_message;
import com.ubs.manhattan.network.client.NetworkProtobuf.pb_warning_message;
import com.ubs.manhattan.persistence.entities.Header;
import com.ubs.manhattan.persistence.entities.LegStrategyReport;
import com.ubs.manhattan.persistence.entities.Message;
import com.ubs.manhattan.persistence.entities.StrategyOrders;
import com.ubs.manhattan.persistence.entities.StrategyReport;
import com.ubs.manhattan.persistence.entities.id.StrategyReportPK;
import com.ubs.manhattan.utils.Constant;

//Test network client
public class NetworkClientManager implements NetworkClient.NetworkClientCallback{

	//Private members
	final private NetworkClient m_client;
	private Thread m_thread_user = null;
	
	private String messageToLog;

	//Constructor
	public NetworkClientManager(String address, int port){
		
		m_client = new NetworkClient(this, address, port);
	}
	
	public void send(pb_to_engine_message msg) throws Exception{
		
		try {
			m_client.send(msg);
		}catch (Exception e){
			throw e;
		}
		
	}
	
	//Function
	public NetworkClient getService(){
		
		return m_client;
	}
	
	@Override
	public void onStart(){
		onPrint("Client Process - [onStart]");		
	}
	
	@Override
	public void onStop(){
		onPrint("Client Process - [onStop]");
	}
	
	@Override
	public void onPrint(String msg){
		ManhattanLogger.log( ""+m_client.engineId(), msg, Level.INFO );
	}
	
	@Override
	public void onLoad(){
		onPrint("Client Process - [onLoad]");
	}
	
	@Override
	public void onUnLoad(){
		onPrint("Client Process - [onUnLoad]");
	}
	
	@Override
	public void onConnect() {
		onPrint("Client Process - [onConnect]");
	}
	
	@Override
	public void onLogon() {
		onPrint("Client Process - [onLogon]");
		
		//Launch Thread
		if( m_thread_user == null ){
			m_thread_user = new Thread( new Runnable() {
												public void run() {
													sendingMessages();
												}
											}
										);
			m_thread_user.start();
		}
	}
	
	@Override
	public void onLogoff(String str){
		onPrint("Client Process - [onLogoff] message: " + str );
	}

	@Override
	public void onDisconnect() {
		onPrint("Client Process - [onDisconnect]" );
	}
	
	@Override
	public void onMessage_ReportStrategy(long manager_id, long request_id, pb_report_strategy_message msg){

		if ( msg.isInitialized() ){
			messageToLog = buildLog("onMessage_ReportStrategy", manager_id, request_id, msg);
			onPrint( messageToLog );
		
			StrategyReport strategyReport = ConverterToEntity.convertToStrategy( m_client.engineId(), msg );
			
			if ( strategyReport != null ){
				strategyReport.setText( StringUtils.isBlank( strategyReport.getText() ) ? Constant.MESSAGES_CONFIGURATION.REPORT_MODIFIED : strategyReport.getText() );
				
//				generates cache of all received messages
//				CacheHelper.strategyReportMap.put( strategyReport.getId(), strategyReport );
				CacheHelper.putStrategyReport( strategyReport );
			
//				if ( m_client.managerId() == manager_id ){
					
					PrepareToPersist persist = new PrepareToPersist();
					strategyReport = persist.saveReport( strategyReport );
//				}
				
			} else {
				onPrint("Strategy is null: " + messageToLog );
			}
		}
	}
	
	@Override
	public void onMessage_RejectStrategy(long manager_id, long request_id, pb_reject_create_modify_cancel_strategy_message msg){

		
			
		if ( msg.isInitialized() ){
		
			messageToLog = buildLog("onMessage_RejectExecutionOrder", manager_id, request_id, msg);
			
			StrategyReport report = CacheHelper.StrategyReportMapByRequestId.get( request_id );
			
			ManhattanLogger.devLog( "", msg.getText() + " --- " + report.toString() );
			
			if ( report != null ){
				report.setText( msg.getText() );
				CacheHelper.putStrategyReport( report );
					
//				if ( m_client.managerId() == manager_id ){
					
					PrepareToPersist persist = new PrepareToPersist();
					report = persist.saveReport( report );
					
//					if ( report.getLegStrategyList() != null && !report.getLegStrategyList().isEmpty() ){
//						CacheHelper.putLegStrategyList( report.getLegStrategyList() );	
//					}
					
					onPrint( messageToLog + "\n"  + report  );
//				}
			}
		}
	}
	
	/* (non-Javadoc)
	 * @see com.ubs.manhattan.network.client.NetworkClient.NetworkClientCallback#onMessage_ReportOrder(long, long, com.ubs.manhattan.network.client.NetworkProtobuf.pb_report_order_message)
	 */
	@Override
	public void onMessage_ReportOrder(long manager_id, long request_id, pb_report_order_message msg) {
		
		if (msg.isInitialized()) {
			messageToLog = buildLog("onMessage_ReportOrder", manager_id,request_id, msg);
			onPrint(messageToLog);

			StrategyOrders strategyOrders = ConverterToEntity.convertToStrategy(m_client.engineId(), msg);

			if (strategyOrders != null) {
				
//				generates cache of all received messages				
				CacheHelper.strategyOrderMap.put(strategyOrders.getId(), strategyOrders);

//				if (m_client.managerId() == manager_id) {
					PrepareToPersist persist = new PrepareToPersist();
					persist.saveOrder(strategyOrders);
//				}
			}else{
				onPrint("Order is null: " + messageToLog);
			}
		}
	}

	/* (non-Javadoc)
	 * @see com.ubs.manhattan.network.client.NetworkClient.NetworkClientCallback#onMessage_RejectExecutionOrder(long, long, com.ubs.manhattan.network.client.NetworkProtobuf.pb_message_type_enum, java.lang.String)
	 */
	@Override
	public void onMessage_RejectExecutionOrder(long manager_id, long request_id, pb_reject_create_modify_cancel_strategy_message msg) {

//		if (m_client.managerId() == manager_id) {
			
			if ( msg.isInitialized() ) {
				
				messageToLog = buildLog("onMessage_RejectExecutionOrder", manager_id, request_id, msg);
				onPrint(messageToLog);
				
				StrategyOrders order = CacheHelper.StrategyOrderMapByRequestId.get(request_id);
				
				if (order != null) {

					order.setText( msg.getText() );
					PrepareToPersist persist = new PrepareToPersist();
					order = persist.saveOrder( order );

					CacheHelper.strategyOrderMap.put(order.getId(), order);

					onPrint(messageToLog + "\n" + order);
				}
			}
//		}
	}
	
	@Override
	public void onMessage_Statistics(long manager_id, long request_id, pb_statistics_message msg){
		if ( m_client.managerId() == manager_id ){
			messageToLog = buildLog("onMessage_Statistics", manager_id, request_id, msg);
			onPrint( messageToLog );
		}
	}
	
	@Override
	public void onMessage_Warning(long manager_id, long request_id, pb_warning_message msg){
		if ( m_client.managerId() == manager_id ){
			messageToLog = buildLog("onMessage_Warning", manager_id, request_id, msg);
			onPrint( messageToLog );
		}
	}
	
	@Override
	public void onMessage_LeggedOrder(long manager_id, long request_id, pb_legged_order msg){
		
		if ( msg.isInitialized() ){
			messageToLog = buildLog("onMessage_LeggedOrder", manager_id, request_id, msg);
			onPrint( messageToLog );
		
			StrategyOrders order = ConverterToEntity.convertToStrategyOrder( msg );
			
			if ( order != null ){
			
				CacheHelper.leggedOrderMap.put( order.getId(), order );

//				gerar cache normal?
//				algumtratamento para qdo os managerIds baterem ou n�o?
				
				if ( m_client.managerId() == manager_id ){
					CacheHelper.strategyOrderMap.put( order.getId(), order);
				}
			}
		}
	}
	
	private synchronized void sendingMessages(){
		
		Builders builder = new Builders();
		Manager manager = new Manager();
		
		//Print
		System.out.println("Start threads...");

		boolean goahead = true;
//		SendEngineTeste teste = new SendEngineTeste();
		Message message = null;
		
		try {
		//Loop
			boolean first = true;
			while (goahead && !Thread.interrupted()) {
				
				//Sleep
				if(!sleep(2 * 1000)){
					
					System.out.println("Stop processing user");
					break;
				}
				
				//Check Logged on
				if( !m_client.isLoggedOn() ) continue;
				
				int random_value = Math.abs( (int) new Date().getTime() % 7 );
				
				Long orderId = null; // 2_083_832L;
				Header header = null;
				
				System.out.println("============================== buildCreateModifyCancelStrategy: " + first + " ==============================");
				
				switch( Math.abs( random_value ) ){
					case 0:
						
//						s� entra se for a primeira vez
						if ( first ){
						
							header = builder.buildHeader( MessageTypeEnum.CREATE_STRATEGY, m_client.engineId(), Long.valueOf( random_value) );
							
							message = builder.buildCreateModifyCancelStrategy( header, null );
							
							com.ubs.manhattan.facade.Manager m = new com.ubs.manhattan.facade.Manager();
							
							StrategyReport generateStrategyReport = m.generateStrategyReport( 2L, 10 );
							generateStrategyReport.setHeader( ( (StrategyReport) message ).getHeader() );
							message = generateStrategyReport;
						
							first = false;
						}
							break;
						
					case 1:
					case 2:
						// 	sen�o for a primeira vez, n�o entra
						if ( !first ){
														
							StrategyReportPK strategyReportPK = CacheHelper.getStrategyReportByIndex( 0 );
							
							if ( strategyReportPK != null ){
							             
								header = builder.buildHeader( MessageTypeEnum.MODIFY_STRATEGY, m_client.engineId(), Long.valueOf( random_value) );
								
								System.out.println("\n\n============================== MODIFY_STRATEGY or CANCEL_STRATEGY  ==============================");		
								
								message = builder.buildCreateModifyCancelStrategy( header, strategyReportPK.getStrategyId() );
								StrategyReport report = ( StrategyReport ) message;
								
								GregorianCalendar cal = (GregorianCalendar) GregorianCalendar.getInstance();
								cal.add( Calendar.SECOND  , 30);
								
								report.setEndTime( cal.getTime() );
								
								if ( MessageTypeEnum.MODIFY_STRATEGY.equals( report.getHeader().getMessageType() ) ||
									 MessageTypeEnum.CANCEL_STRATEGY.equals( report.getHeader().getMessageType() ) ){
									
									StrategyReport reportFromCache = CacheHelper.strategyReportMap.get( strategyReportPK );
									
									if ( reportFromCache == null ){
										System.out.println("\n\n============================== Report n�o encontrado  ==============================");		
										System.out.println("\t\t" + strategyReportPK );		
										System.out.println("========================================================================================\n\n");
										continue;
									}
									
									reportFromCache.setHeader( header );
									
									message = reportFromCache;
								}
							}
						}
						
						break;
					
					case 3:
// Teste para New Order Single
						System.out.println("============================== buildNewOrderSingle ==============================");
						if ( !first ){
							
							LegStrategyReport leg = CacheHelper.getLegStrategyReportByIndex( 0 );
							
							header = builder.buildHeader( MessageTypeEnum.NEW_ORDER, m_client.engineId(), Long.valueOf( random_value) );
							
							message = builder.buildNewOrderSingle( header, leg );
							
							StrategyOrders order = (StrategyOrders) message;
							
							message = order;
						}
						break;
						
					case 4:
// Teste para Report Order
						System.out.println("============================== buildReportExecutionOrder ==============================");
						if ( !first ){
						
							header = builder.buildHeader( MessageTypeEnum.REPORT_EXECUTION_ORDER, m_client.engineId(), Long.valueOf( random_value) );
							
							StrategyReportPK reportPK = CacheHelper.getStrategyReportByIndex( 0 );
							
							if ( reportPK != null ){
							
								StrategyReport report = CacheHelper.strategyReportMap.get( reportPK );
								
								if ( report == null || report.getLegStrategyList() == null || report.getLegStrategyList().isEmpty() )
									break;
								
								LegStrategyReport leg = report.getLegStrategyList().get( 0 );
								
								message = builder.buildReportOrder( header, leg );
							}
						}
						break;
					case 5:
// Teste para Legged Message
						System.out.println("============================== buildLeggedMessage ==============================");
						if ( !first ){
							header = builder.buildHeader( MessageTypeEnum.LEGGED_ORDER, m_client.engineId(), Long.valueOf( random_value) );
							
							message = builder.buildLeggedMessage( header, orderId );
						}
						
						break;
						
					case 6:
// Teste para command Message
						System.out.println("============================== buildCommandMessage ==============================");
						
						if ( !first ){
						
							header = builder.buildHeader( MessageTypeEnum.COMMAND_MESSAGE, m_client.engineId(), Long.valueOf( random_value) );
							
							message = builder.buildCommandMessage( header, CommandTypeEnum.CANCEL_ALL_STRATEGIES );
							
						}
						
						break;
	
				default:
					continue;
				}
				
				if ( message != null ){
				
					pb_to_engine_message engineMessage = manager.managerMessage( message );
					
					onPrint("\n============================================== Sending message ============================================== \n" );
					onPrint( ""+ engineMessage.getHeader().getManagerInstanceId() );
					onPrint( ""+ engineMessage );
					onPrint("\n ===============================================================================================================");
					
					send( engineMessage );
				}
				
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	private boolean sleep(long milli){
		
		//Sleep
		try {

			Thread.sleep(milli);
			
		} catch (InterruptedException e) {
		
			//Failure - Interruption
			return false;
		}
		
		//Success
		return true;
	}
	
	private String buildLog( String method, long manager_id, long request_id, Object msg ){
		return "[" + method + "] EngineId: " + m_client.engineId() + " ManagerId: "+ manager_id +" RequestId: " + request_id + "\n message: " + msg.toString();
	}
	
	@SuppressWarnings("unused")
	private String buildLog( String method, long manager_id, long request_id, pb_message_type_enum messageType, Object msg ){
		return "[" + method + "] EngineId: " + m_client.engineId() + " ManagerId: "+ manager_id +" RequestId: " + request_id + " messageType: " + messageType + "\n message: " + msg.toString();
	}
}