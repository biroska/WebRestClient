/*
 * NetworkClient_Test.java
 *
 *  Created on: Set 25, 2015
 *      Author: vanputtg
 */


//Package
package com.ubs.manhattan.network.client;

//Import
import com.ubs.manhattan.network.client.NetworkProtobuf.pb_legged_order;
import com.ubs.manhattan.network.client.NetworkProtobuf.pb_reject_create_modify_cancel_strategy_message;
import com.ubs.manhattan.network.client.NetworkProtobuf.pb_report_order_message;
import com.ubs.manhattan.network.client.NetworkProtobuf.pb_report_strategy_message;
import com.ubs.manhattan.network.client.NetworkProtobuf.pb_statistics_message;
import com.ubs.manhattan.network.client.NetworkProtobuf.pb_warning_message;

//Test network client
public class NetworkClient_BasicImp implements NetworkClient.NetworkClientCallback{

	//Private members
	final private NetworkClient m_client;

	//Constructor
	public NetworkClient_BasicImp(String address, int port){
		
		m_client = new NetworkClient(this, address, port);
	}
	
	//Function
	public NetworkClient getService(){
		
		return m_client;
	}
	
	@Override
	public void onStart(){
		
		System.out.println("On Start");
	}
	
	@Override
	public void onStop(){
		
		System.out.println("On Stop");
	}
	
	@Override
	public void onLoad(){
		
		System.out.println("On Load");
	}
	
	@Override
	public void onUnLoad(){
		
		System.out.println("On UnLoad");
	}
	
	@Override
	public void onConnect() {
		
		System.out.println("On Connect");
	}
	
	@Override
	public void onLogon() {
		
		//Print
		System.out.println("On Logon");
	}
	
	@Override
	public void onLogoff(String str){
		
		System.out.println("On Logoff: " + str);
	}

	@Override
	public void onDisconnect() {
		
		System.out.println("On Disconnect");
	}
	
	
	@Override
	public void onPrint(String msg){
		
		System.out.println(msg);
	}
	
	@Override
	public void onMessage_ReportStrategy(long manager_id, long request_id, pb_report_strategy_message msg){
		
		System.out.println("On ReportStrategy for: " + manager_id);
	}
	
	@Override
	public void onMessage_RejectStrategy(long manager_id, long request_id, pb_reject_create_modify_cancel_strategy_message msg){
		
		System.out.println("On RejectStrategy: " + msg.getText() + " --> " + manager_id + "/" + msg.getStrategyId());
	}
	
	@Override
	public void onMessage_RejectExecutionOrder(long manager_id, long request_id, pb_reject_create_modify_cancel_strategy_message msg){
				
		System.out.println("On RejectOrder: " + msg.getText() + " --> " + manager_id + "/" + msg.getStrategyId());
	}
	
	@Override
	public void onMessage_ReportOrder(long manager_id, long request_id, pb_report_order_message msg){
		
		System.out.println("On ReportOrder for: " + manager_id);
	}
	@Override
	public void onMessage_Statistics(long manager_id, long request_id, pb_statistics_message msg){
		
		System.out.println("On Statistics for: " + manager_id);
	}
	
	@Override
	public void onMessage_Warning(long manager_id, long request_id, pb_warning_message msg){
		
		System.out.println("On Warning for: " + manager_id);
	}
	
	@Override
	public void onMessage_LeggedOrder(long manager_id, long request_id, pb_legged_order msg){
		
		System.out.println("On LeggedOrder for: " + manager_id);
	}		
	
}
