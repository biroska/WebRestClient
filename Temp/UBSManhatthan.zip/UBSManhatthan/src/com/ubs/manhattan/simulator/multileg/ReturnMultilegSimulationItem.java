package com.ubs.manhattan.simulator.multileg;

import com.ubs.manhattan.utils.Constant;

public class ReturnMultilegSimulationItem {
	

	public ReturnMultilegSimulationItem() {
		this.quantity = Constant.SIMULATION.INITIAL_QUANTITY;
		this.rank = Constant.SIMULATION.INITIAL_RANK;
		this.div1 = Constant.SIMULATION.INITIAL_DIV1;
		this.legSeq = Constant.SIMULATION.INITIAL_LEG_SEQ;
	}

	public Integer getQuantity() {
		return quantity;
	}
	
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	
	public Integer getRank() {
		return rank;
	}
	
	public void setRank(Integer rank) {
		this.rank = rank;
	}
	
	public Double getDiv1() {
		return div1;
	}
	
	public void setDiv1(Double div1) {
		this.div1 = div1;
	}
	
	public Integer getLegSeq() {
		return legSeq;
	}

	public void setLegSeq(Integer legSeq) {
		this.legSeq = legSeq;
	}

	private Integer quantity;
	private Integer rank;
	private Double div1;
	private Integer legSeq;
	
}
