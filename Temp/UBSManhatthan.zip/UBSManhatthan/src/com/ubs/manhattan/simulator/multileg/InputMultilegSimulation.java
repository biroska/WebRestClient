package com.ubs.manhattan.simulator.multileg;

import java.util.ArrayList;
import java.util.List;

import com.ubs.manhattan.enums.StrategyTypeEnum;
import com.ubs.manhattan.utils.Constant;

public class InputMultilegSimulation {
	
	public InputMultilegSimulation() {
		this.UserDefinedTarget = Constant.SIMULATION.INITIAL_TARGET;
		this.setOnlyTarget(false);
		this.inputItens = new ArrayList<InputMultilegSimulationItem>();
		this.simulationMode = StrategyTypeEnum.UNKNOWN;
	}

	public List<InputMultilegSimulationItem> getInputItens() {
		return inputItens;
	}

	public void setInputItens(List<InputMultilegSimulationItem> itens) {
		this.inputItens = itens;
	}
	
	public boolean isOnlyTarget() {
		return onlyTarget;
	}

	public void setOnlyTarget(boolean onlyTarget) {
		this.onlyTarget = onlyTarget;
	}
	
	public Double getUserDefinedTarget() {
		return UserDefinedTarget;
	}

	public void setUserDefinedTarget(Double userDefinedTarget) {
		UserDefinedTarget = userDefinedTarget;
	}

	public StrategyTypeEnum getSimulationMode() {
		return simulationMode;
	}

	public void setSimulationMode(StrategyTypeEnum simulationMode) {
		this.simulationMode = simulationMode;
	}

//	field informed by user
	private Double UserDefinedTarget;
	
//	flag to make the calculations only by the target attribute
	private boolean onlyTarget;

//	Type of simulation (Strategy type)
	private StrategyTypeEnum simulationMode;
	
//	List of rows in Strategy Parameters
	private List<InputMultilegSimulationItem> inputItens;

	@Override
	public String toString() {
		return "InputMultilegSimulation [UserDefinedTarget="
				+ UserDefinedTarget + ", onlyTarget=" + onlyTarget
				+ ", simulationMode=" + simulationMode + ", inputItens="
				+ inputItens + "]";
	}
}