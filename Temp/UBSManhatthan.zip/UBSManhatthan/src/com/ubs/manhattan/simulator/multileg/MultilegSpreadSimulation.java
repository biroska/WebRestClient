package com.ubs.manhattan.simulator.multileg;

public class MultilegSpreadSimulation {

	public ReturnMultilegSimulation simulate(InputMultilegSimulation input) {

		ReturnMultilegSimulation returnMultilegSimulation = new ReturnMultilegSimulation();
		returnMultilegSimulation.setValid(true);
		
		return returnMultilegSimulation;
	}

}
