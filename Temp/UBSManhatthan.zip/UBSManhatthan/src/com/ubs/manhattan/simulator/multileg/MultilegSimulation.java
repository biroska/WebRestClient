package com.ubs.manhattan.simulator.multileg;

import com.ubs.manhattan.enums.StrategyTypeEnum;

public class MultilegSimulation {
	
	public MultilegSimulation() {
		
		multilegFraSimulation = new MultilegFraSimulation();
		multilegSpreadSimulation = new MultilegSpreadSimulation();
	}
	
	public ReturnMultilegSimulation simulate(InputMultilegSimulation input) {
		
		if( StrategyTypeEnum.MULTILEG_FRA == input.getSimulationMode() )
		{
			return this.multilegFraSimulation.simulate( input );
		}
		else if( StrategyTypeEnum.MULTILEG_SPREAD == input.getSimulationMode() )
		{
			return this.multilegSpreadSimulation.simulate( input );
		}
		else
		{
			return new ReturnMultilegSimulation();
		}
		
	}
	
	private MultilegFraSimulation multilegFraSimulation;
	private MultilegSpreadSimulation multilegSpreadSimulation;

}
