package com.ubs.manhattan.simulator.multileg;

import java.util.ArrayList;
import java.util.List;

import com.ubs.manhattan.enums.SideEnum;
import com.ubs.manhattan.lmdsadapter.marketdata.entities.SecurityDefinition;
import com.ubs.manhattan.utils.Constant;

public class InputMultilegSimulationItem {

	public InputMultilegSimulationItem()
	{
		this.setInstrument(Constant.SIMULATION.INITIAL_INSTRUMENT);
		this.setSide(SideEnum.NOT_DEFINED);
		this.setSimulationLeg(false);
		this.byQuantity = false;
		this.quantity = Constant.SIMULATION.INITIAL_QUANTITY;
		this.div1 = Constant.SIMULATION.INITIAL_DIV1;
		this.businessDays = Constant.SIMULATION.INITIAL_BUSINESS_DAYS;
		this.legSeq = Constant.SIMULATION.INITIAL_LEG_SEQ;
		
		this.minBid = Constant.SIMULATION.INITIAL_MIN_BOOK_SIZE;
		this.minAsk = Constant.SIMULATION.INITIAL_MIN_BOOK_SIZE;
		this.bidPrices = new ArrayList<Double>(5);
		this.bidQuantities = new ArrayList<Long>(5);
		this.askPrices = new ArrayList<Double>(5);
		this.askQuantities = new ArrayList<Long>(5);
	}
	
	public boolean isInitialized() {
		
		if( this.instrument != Constant.SIMULATION.INITIAL_INSTRUMENT &&
			this.side != SideEnum.NOT_DEFINED &&
			this.businessDays != -1000 &&
			this.legSeq != Constant.SIMULATION.INITIAL_LEG_SEQ &&
			(this.quantity != Constant.SIMULATION.INITIAL_QUANTITY || this.div1 != Constant.SIMULATION.INITIAL_DIV1) )
		{
			return true;
		}
		
		return false;
	}
	
	public Integer getInstrument() {
		return instrument;
	}
	public void setInstrument(Integer instrument) {
		this.instrument = instrument;
	}

	public SideEnum getSide() {
		return side;
	}

	public void setSide(SideEnum side) {
		this.side = side;
	}

	public boolean isSimulationLeg() {
		return simulationLeg;
	}

	public void setSimulationLeg(boolean simulationLeg) {
		this.simulationLeg = simulationLeg;
	}

	public boolean isByQuantity() {
		return byQuantity;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
		this.div1 = Constant.SIMULATION.INITIAL_DIV1;
		this.byQuantity = true;
	}

	public Double getDiv1() {
		return div1;
	}

	public void setDiv1(Double div1) {
		this.div1 = div1;
		this.quantity = Constant.SIMULATION.INITIAL_QUANTITY;
		this.byQuantity = false;
	}

	public Integer getBusinessDays() {
		return businessDays;
	}

	public void setBusinessDays(Integer businessDays) {
		this.businessDays = businessDays;
	}

	public SecurityDefinition getSecurityDefinition() {
		return securityDefinition;
	}

	public void setSecurityDefinition(SecurityDefinition securityDefinition) {
		this.securityDefinition = securityDefinition;
	}

	public Integer getLegSeq() {
		return legSeq;
	}

	public void setLegSeq(Integer legSeq) {
		this.legSeq = legSeq;
	}
	
	public int getMinBid() {
		return minBid;
	}

	public void setMinBid(int minBid) {
		this.minBid = minBid;
	}

	public int getMinAsk() {
		return minAsk;
	}

	public void setMinAsk(int minAsk) {
		this.minAsk = minAsk;
	}

	public List<Double> getBidPrices() {
		return bidPrices;
	}

	public void setBidPrices(List<Double> bidPrices) {
		this.bidPrices = bidPrices;
	}

	public List<Long> getBidQuantities() {
		return bidQuantities;
	}

	public void setBidQuantities(List<Long> bidQuantities) {
		this.bidQuantities = bidQuantities;
	}

	public List<Double> getAskPrices() {
		return askPrices;
	}

	public void setAskPrices(List<Double> askPrices) {
		this.askPrices = askPrices;
	}

	public List<Long> getAskQuantities() {
		return askQuantities;
	}

	public void setAskQuantities(List<Long> askQuantities) {
		this.askQuantities = askQuantities;
	}

	public void setByQuantity(boolean byQuantity) {
		this.byQuantity = byQuantity;
	}

	@Override
	public String toString() {
		return "InputMultilegSimulationItem [instrument=" + instrument
				+ ", legSeq=" + legSeq + ", side=" + side + ", minBid="
				+ minBid + ", minAsk=" + minAsk + ", bidPrices=" + bidPrices
				+ ", bidQuantities=" + bidQuantities + ", askPrices="
				+ askPrices + ", askQuantities=" + askQuantities
				+ ", securityDefinition=" + securityDefinition
				+ ", businessDays=" + businessDays + ", simulationLeg="
				+ simulationLeg + ", byQuantity=" + byQuantity + ", quantity="
				+ quantity + ", div1=" + div1 + "]";
	}

	private Integer instrument;
	private Integer legSeq;
	private SideEnum side;
//	private BookSnapshot quote;

	private int minBid;
	private int minAsk;
	private List<Double> bidPrices;
	private List<Long> bidQuantities;
	private List<Double> askPrices;
	private List<Long> askQuantities;
		
	private SecurityDefinition securityDefinition;
	private Integer businessDays;
	private boolean simulationLeg;
	
	private boolean byQuantity;
	private Integer quantity;
	private Double div1;
}