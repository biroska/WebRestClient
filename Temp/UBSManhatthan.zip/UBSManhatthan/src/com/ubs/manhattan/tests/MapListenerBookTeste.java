/**
 * 
 */
package com.ubs.manhattan.tests;

import java.util.List;

import com.ubs.manhattan.cache.CacheHelper;
import com.ubs.manhattan.dto.ReceiveSynthetic;
import com.ubs.manhattan.enums.StrategyTypeEnum;
import com.ubs.manhattan.lmdsadapter.LmdsManager;
import com.ubs.manhattan.lmdsadapter.SimulationItem;
import com.ubs.manhattan.mocks.SyntheticMock;

/**
 * @author galdinoa
 *
 */
public class MapListenerBookTeste {

	private static LmdsManager lmds = new LmdsManager();

	public static void main(String[] args) {
		
		ReceiveSynthetic synthetic = SyntheticMock.mockReceiveSynthetic( StrategyTypeEnum.MULTILEG_FRA, "DI1F17", "DI1F18" );
		lmds.subscribeManager( synthetic );
		
		synthetic = SyntheticMock.mockReceiveSynthetic( StrategyTypeEnum.MULTILEG_FRA, "DI1F18", "DI1F19" );
		lmds.subscribeManager( synthetic );
		
		synthetic = SyntheticMock.mockReceiveSynthetic( StrategyTypeEnum.UNKNOWN, "DI1F19" );
		lmds.subscribeManager( synthetic );
		
		synthetic = SyntheticMock.mockReceiveSynthetic( StrategyTypeEnum.UNKNOWN, "DI1F21" );
		lmds.subscribeManager( synthetic );
		
		List<SimulationItem> simulationListBySymbol = CacheHelper.getSimulationListBySymbol( "DI1F19" );
		
		System.out.println( "\n\n\n simulationListBySymbol: " + simulationListBySymbol );
	}
	
}
