package com.ubs.manhattan.tests;

public class POC {
	
		public static void main(String[] args) {
			
			long idGenerico = System.currentTimeMillis();
		
			String aux = String.valueOf( idGenerico );
			
			String newId = aux.substring( 6 );
			
			long shortTimeStamp = Long.valueOf( String.valueOf( System.currentTimeMillis() ).substring( 6 ) );
			
			System.out.println("idGenerico: " + idGenerico + " shortTimeStamp: " + shortTimeStamp );
			
			System.out.println( 0 % 4 + "   " + 1 % 4 );
			
//			System.out.println("\n\n\n============================== buildCreateModifyCancelStrategy ==============================");
//			
//			SendEngineTeste teste = new SendEngineTeste();
//			
//			Message message;
//			try {
//				message = teste.buildCreateModifyCancelStrategy(MessageTypeEnum.MODIFY_STRATEGY,  2_083_831L );
//				
//				StrategyReport report = ( StrategyReport ) message;
//				
//				if ( MessageTypeEnum.MODIFY_STRATEGY.equals( report.getHeader().getMessageType() ) ||
//					 MessageTypeEnum.CANCEL_STRATEGY.equals( report.getHeader().getMessageType() ) ){
//					
//					if ( !CacheHelper.strategyReportMap.containsKey( report.getStrategyId() ) )
//						System.out.println("N�o existe no cache");
//					
//					pb_to_engine_message engineMessage = teste.managerMessage( message );
//					
//					System.out.println(" Message - " + engineMessage );
//				}
//
//			} catch (Exception e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
			

			
			
		}
}