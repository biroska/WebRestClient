/**
 * 
 */
package com.ubs.manhattan.tests;

import java.io.FileNotFoundException;
import java.io.IOException;

import com.ubs.manhattan.dto.ReceiveSynthetic;
import com.ubs.manhattan.enums.StrategyTypeEnum;
import com.ubs.manhattan.lmdsadapter.LmdsManager;
import com.ubs.manhattan.lmdsadapter.adapter.AdapterConfigurationException;
import com.ubs.manhattan.lmdsadapter.adapter.AdapterRuntimeException;
import com.ubs.manhattan.mocks.SyntheticMock;

/**
 * @author galdinoa
 *
 */
public class LmdsTestes {
	
	static LmdsManager lmds = new LmdsManager();
	
	public static void main ( String[] args ) throws FileNotFoundException, IOException, AdapterConfigurationException, AdapterRuntimeException, InterruptedException{
		
		//Print start
		System.out.println("Starting engine...");
		
		//Initializing the LMDS Adapter
		lmds.startLmdsAdapter("lmds-client-api.cfg");
		
		//Subscribing instruments
//		MDSubscribeResponse subscribeSymbol = lmdsManager.subscribeSymbol("WINZ15");
//		lmdsManager.subscribeSymbol("DI1Z15");
		
		ReceiveSynthetic synthetic = SyntheticMock.mockReceiveSynthetic( StrategyTypeEnum.MULTILEG_FRA, "DI1F21", "DI1F18" );
		lmds.subscribeManager( synthetic );
		
		synthetic = SyntheticMock.mockReceiveSynthetic( StrategyTypeEnum.MULTILEG_FRA, "DI1F18", "DI1F19" );
		lmds.subscribeManager( synthetic );
		
		synthetic = SyntheticMock.mockReceiveSynthetic( StrategyTypeEnum.UNKNOWN, "DI1F19" );
		lmds.subscribeManager( synthetic );
		
		synthetic = SyntheticMock.mockReceiveSynthetic( StrategyTypeEnum.UNKNOWN, "DI1F17" );
		lmds.subscribeManager( synthetic );
		
		//ShutdownHook
		Runtime.getRuntime().addShutdownHook(new Thread() {public void run(){ } });
		
		while(true) Thread.sleep(600000);
		
	}

}
