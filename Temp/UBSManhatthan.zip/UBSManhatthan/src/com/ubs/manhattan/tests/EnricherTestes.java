package com.ubs.manhattan.tests;

import java.util.Date;

import javax.persistence.EntityTransaction;

import com.ubs.manhattan.enricher.PrepareToEngine;
import com.ubs.manhattan.persistence.entities.StrategyOrders;
import com.ubs.manhattan.persistence.entities.StrategyReport;
import com.ubs.manhattan.persistence.factory.FactoryManager;


public class EnricherTestes {
	
	StrategyOrders order = new StrategyOrders();
	StrategyReport report = new StrategyReport();
	
	PrepareToEngine enricher = new PrepareToEngine();

	public static void main(String[] args) {
		
		EntityTransaction transaction = FactoryManager.getEntityManager().getTransaction();
		
//		EnricherTestes t = new EnricherTestes();
		
		try {
			System.out.println("\n\n\n");
			
//			enrichCreateModifyCancelStrategy();
//			t.enrichNewOrderReportOrder();
			
			System.out.println("\n\n\n");
//			transaction.begin();
//
//			order.setOrderId( 1_445_885_993_441L );
//			FacadeImpl facade = new FacadeImpl();
//			order = facade.findStrategyOrderById( order );
//			
//			transaction.commit();
			
		} catch (Exception e) {
			System.out.println("Rollback " + new Date() );
			e.printStackTrace();
			if ( transaction.isActive() ) {
				transaction.rollback();
			}
		} finally {
		
			System.out.println("finally " + new Date() );
			FactoryManager.closeEntityManagerFactory();
		}
	}
	
	@SuppressWarnings("unused")
	private void enrichModifyCancelStrategy(){
		
		try {
			report.getId().setStrategyId( 1_445_885_993_376L );
			report.setText( "Enricher Tests");
			
			StrategyReport enrichCreateModifyCancelStrategy;
			
			enrichCreateModifyCancelStrategy = enricher.enrichModifyCancelStrategy( report );
			
			System.out.println("\n\n\n     Enricher");
			System.out.println("Text: " + enrichCreateModifyCancelStrategy.getText() + " " + enrichCreateModifyCancelStrategy.getAgressiviness() );
			
			System.out.println("\n     After enricher Report Orig");
			System.out.println("Text: " + report.getText() + " " + report.getAgressiviness() );
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@SuppressWarnings("unused")
	private void enrichNewOrderReportOrder(){
		
		try {
			order.getId().setOrderId( 1_445_885_993_442L );
			order.setClientOrderId("Enricher Teste");
			order.setPrice( 5.5 );
			
			StrategyOrders enrichNewOrderReportOrder;
			
			System.out.println("\n     enricher Report Orig");
			System.out.println("getClientOrderId: " + order.getClientOrderId() + " getPrice: " + order.getPrice() + " getAveragePrice: " + order.getAveragePrice() );
			
			enrichNewOrderReportOrder = enricher.enrichNewOrderReportOrder( order );
			
			System.out.println("\n\n\n     Enricher");
			System.out.println("getClientOrderId: " + enrichNewOrderReportOrder.getClientOrderId() + " getPrice: " + enrichNewOrderReportOrder.getPrice() + " getAveragePrice: " + enrichNewOrderReportOrder.getAveragePrice() );
			
			System.out.println("\n     After enricher Report Orig");
			System.out.println("getClientOrderId: " + order.getClientOrderId() + " getPrice: " + order.getPrice() + " getAveragePrice: " + order.getAveragePrice() );
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}