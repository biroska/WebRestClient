package com.ubs.manhattan;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import com.ubs.manhattan.lmdsadapter.adapter.AdapterConfigurationException;
import com.ubs.manhattan.lmdsadapter.adapter.AdapterRuntimeException;
import com.ubs.manhattan.lmdsadapter.marketdata.entities.BookSnapshot;
import com.ubs.manhattan.lmdsadapter.marketdata.entities.SecurityDefinition;
import com.ubs.manhattan.lmdsadapter.marketdata.entities.Trade;
import com.ubs.manhattan.lmdsadapter.marketdata.lmds.LMDSAdapter;
import com.ubs.manhattan.lmdsadapter.marketdata.manager.MDManager;
import com.ubs.manhattan.lmdsadapter.marketdata.manager.MDManagerFactory;
import com.ubs.manhattan.lmdsadapter.marketdata.manager.MDSubscribeResponse;
import com.ubs.manhattan.lmdsadapter.marketdata.manager.MDSubscriberHandler;

public class LmdsExample implements MDSubscriberHandler {
	
	final MDManager manager = MDManagerFactory.getManager("BVMF");
	LMDSAdapter adapter = new LMDSAdapter();
	
	public void startLmdsAdapter(String configFile) throws FileNotFoundException,
									      				   IOException,
									    				   AdapterConfigurationException,
									    				   AdapterRuntimeException {
		
		Properties properties = new Properties();
		properties.load(new FileInputStream(configFile));
		
		this.adapter.configure(properties);
		this.adapter.start();
	}
	
	public void stopLmdsAdapter() throws AdapterRuntimeException {
		
		this.adapter.stop();
	}
	
	public MDSubscribeResponse subscribeSymbol(String symbol) {
		
		return this.manager.subscribe(symbol, this);
	}
	
	public void unsubscribeSymbol(String symbol) {
		
		this.manager.unsubscribe(symbol, this);
	}
	
	public SecurityDefinition getIntrumentDefinitionBySymbol(String symbol) {
		
		return this.manager.getInstrumentDefinitionBySymbol(symbol);
	}
	
	public SecurityDefinition getIntrumentDefinitionBySecurityId(String securityId) {
		
		return this.manager.getInstrumentDefinitionBySecurityID(securityId);
	}

	@Override
	public void onBookUpdate(String symbol, BookSnapshot book) {

		System.out.println("Received on BOOK listener: " + symbol);
	}

	@Override
	public void onTrade(String symbol, Trade trade) {

		System.out.println("Received TRADE." + 
						   " Symbol: " + symbol +
						   ", Price: " + trade.getPrice() +
						   ", Qty: " + trade.getQuantity() +
						   ", Date: " + trade.getTradeDate());
	}

}
