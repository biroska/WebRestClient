/**
 * 
 */
package com.ubs.manhattan.facade;

import com.ubs.manhattan.dto.ReceiveSynthetic;
import com.ubs.manhattan.persistence.entities.Message;
import com.ubs.manhattan.simulator.multileg.InputMultilegSimulation;
import com.ubs.manhattan.simulator.multileg.ReturnMultilegSimulation;

public interface FacadeService {
	
	public void initializeServices();
	
	public ReturnMultilegSimulation calculate( InputMultilegSimulation input );
	
	public boolean sendToEngine( Message obj );
	
	public boolean subscribe( ReceiveSynthetic synthetic );

}
