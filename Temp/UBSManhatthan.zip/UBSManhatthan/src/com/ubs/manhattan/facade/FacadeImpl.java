package com.ubs.manhattan.facade;

import java.util.Date;
import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.ubs.manhattan.persistence.dao.EngineInstanceDAO;
import com.ubs.manhattan.persistence.dao.LegStrategyReportDAO;
import com.ubs.manhattan.persistence.dao.OrderTradeDAO;
import com.ubs.manhattan.persistence.dao.RoleDAO;
import com.ubs.manhattan.persistence.dao.RoleInterfaceDAO;
import com.ubs.manhattan.persistence.dao.StrategyOrdersDAO;
import com.ubs.manhattan.persistence.dao.StrategyReportDAO;
import com.ubs.manhattan.persistence.entities.EngineInstance;
import com.ubs.manhattan.persistence.entities.LegStrategyReport;
import com.ubs.manhattan.persistence.entities.OrderTrade;
import com.ubs.manhattan.persistence.entities.Role;
import com.ubs.manhattan.persistence.entities.StrategyOrders;
import com.ubs.manhattan.persistence.entities.StrategyReport;
import com.ubs.manhattan.persistence.entities.id.LegStrategyReportPK;
import com.ubs.manhattan.persistence.functions.DataBaseFunctions;
import com.ubs.manhattan.utils.Util;

//@Service
public class FacadeImpl implements Facade {
	
	private Manager manager;
	private StrategyReportDAO strategyReportDAO = new StrategyReportDAO();
	private LegStrategyReportDAO legStrategyReportDAO = new LegStrategyReportDAO();
	private StrategyOrdersDAO strategyOrderDAO = new StrategyOrdersDAO();
	private OrderTradeDAO orderTradeDAO = new OrderTradeDAO();
	private EngineInstanceDAO engineInstanceDAO = new EngineInstanceDAO();
	private DataBaseFunctions dataBaseFunctions = new DataBaseFunctions();
	
//	@Autowired
	private RoleDAO roleDAO = new RoleDAO();

	public StrategyReport generateStrategyReport(Long qtdLegs, Integer qtdOrders) {

		manager = new Manager();
		
		StrategyReport strategy = manager.generateStrategyReport(qtdLegs, qtdOrders);
		strategy = strategyReportDAO.save( strategy );
		
		return strategy;
	}

	@Override
	public StrategyReport saveReport(StrategyReport report) throws Exception {

		report = strategyReportDAO.saveReport( report );
		
		return report;
	}

	@Override
	public StrategyOrders saveOrder(StrategyOrders order ) throws Exception {

		order = strategyOrderDAO.saveStrategyOrder( order );
		
		return order;
	}

	@Override
	public OrderTrade saveOrderTrade(OrderTrade orderTrade) throws Exception {
		
		orderTrade = orderTradeDAO.saveOrderTrade( orderTrade );

		return orderTrade;
	}

	@Override
	public LegStrategyReport getLegStrategyByID(Integer legSeq, Long strategyReportId) 
			throws Exception {
		
		LegStrategyReport leg = null;
		
		if ( legSeq != null && legSeq >= 0 &&
			 strategyReportId != null && strategyReportId > 0 ){

			LegStrategyReportPK legStrategyReportPK = new LegStrategyReportPK( Util.getEngineId(), strategyReportId, legSeq, new Date() );
			
			leg = legStrategyReportDAO.findById( legStrategyReportPK );
		}
		
		return leg;
	}

	/* (non-Javadoc)
	 * @see com.ubs.manhattan.facade.Facade#getLegStrategyByReport(java.lang.Long)
	 */
	@Override
	public List<LegStrategyReport> getLegStrategyByReportId(Long strategyReportId) throws Exception {

		return legStrategyReportDAO.findByStrategyId( strategyReportId );
	}
	
	public StrategyReport findStrategyReportById( StrategyReport report ){
		
		if ( report != null && report.getId() != null ){
			report = strategyReportDAO.findById( report.getId() );
		}
		
		return report;
	}
	
	public StrategyOrders findStrategyOrderById( StrategyOrders order ){
		
		if ( order != null && order.getId() != null && order.getId().getOrderId() != null )
			order = strategyOrderDAO.findById( order.getId() );
		
		return order;
	}

	@Override
	public EngineInstance saveEngineInstance(EngineInstance engine) throws Exception {

		if ( engine != null )
			engine = engineInstanceDAO.save( engine );
			
			
		return engine;
	}

	@Override
	public Integer businessDayTotal(Date beginningDt, Date endingDt) {

		if ( beginningDt == null || endingDt == null )
			return null;
		
		return dataBaseFunctions.businessDayTotal(beginningDt, endingDt);
	}

	@Override
	public Integer businessDayTotal2(Date beginningDt, Date endingDt) {
		
		if ( beginningDt == null || endingDt == null )
			return null;
		
		return dataBaseFunctions.businessDayTotal2(beginningDt, endingDt);
	}
	
	@Override
	@Transactional
	public Role saveRole( Role role ){
		Role saveRole = roleDAO.saveRole( role );
		return saveRole;
		
	}
}