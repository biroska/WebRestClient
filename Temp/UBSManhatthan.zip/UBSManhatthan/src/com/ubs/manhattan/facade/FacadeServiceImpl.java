/**
 * 
 */
package com.ubs.manhattan.facade;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Service;

import com.ubs.manhattan.cache.CacheHelper;
import com.ubs.manhattan.dispatcher.manager.Manager;
import com.ubs.manhattan.dto.ReceiveSynthetic;
import com.ubs.manhattan.enums.EnviromentEnum;
import com.ubs.manhattan.lmdsadapter.LmdsManager;
import com.ubs.manhattan.network.client.NetworkProtobuf.pb_to_engine_message;
import com.ubs.manhattan.persistence.entities.Message;
import com.ubs.manhattan.simulator.multileg.InputMultilegSimulation;
import com.ubs.manhattan.simulator.multileg.MultilegSimulation;
import com.ubs.manhattan.simulator.multileg.ReturnMultilegSimulation;
import com.ubs.manhattan.utils.Util;

@Service
public class FacadeServiceImpl implements FacadeService {
	
	private Manager manager = new Manager();

	private MultilegSimulation simulation = new MultilegSimulation();
	
	
	/**
	 * <p>
	 * The initializeServices is responsible for star the connection 
	 * process with the engine and the LMDS
	 * </p>
	 * 
	 * @author <a href="mailto:aimbere.galdino@ubs.com">Aimbere Galdino</a>
	 * @since 1.7
	 */
	@PostConstruct
	public void initializeServices(){
		
//		Se a aplica��o estiver rodando em ambiente local, n�o estartar as conex�es
		if ( EnviromentEnum.LOCAL.name().equals( Util.getPropertyFromFile( "manhattan.enviroment" ) ) ){
			System.out.println("======================================================================================");
			System.out.println("Enviroment is local! \t Engine and LMDS are not started");
			System.out.println("======================================================================================");
			return;
		}
		
//		TODO
//		aim*
//		Implementtar c�digo para conectar no engine e no LMDS
	}
	
	/**
	 * <p>
	 * The calculate is responsible for the calculus of the values of the market and strategy
	 * </p>
	 * 
	 * @author <a href="mailto:aimbere.galdino@ubs.com">Aimbere Galdino</a>
	 * @param <M>
	 *            contains the {@link InputMultilegSimulation}.
	 * @param <E>
	 *            contains the {@link ReturnMultilegSimulation}.
	 * @since 1.7
	 */
	@Override
	public ReturnMultilegSimulation calculate( InputMultilegSimulation input ) {

		return simulation.simulate( input );
	}
	
	/**
	 * <p>
	 * The subscribe is responsible to subscribe a symbol to lmds and put
	 * the symbol subscribed in the cache map
	 * </p>
	 * 
	 * @author <a href="mailto:aimbere.galdino@ubs.com">Aimbere Galdino</a>
	 * @param <M>
	 *            contains the {@link ReceiveSynthetic}.
	 * @param <E>
	 *            contains the {@link boolean}.
	 * @since 1.7
	 */
	@Override
	public boolean subscribe( ReceiveSynthetic synthetic ){
		
		if ( synthetic == null || synthetic.getStrategyType() == null ||
			 synthetic.getSyntheticList() == null || synthetic.getSyntheticList().isEmpty() )
				return false;
		
		LmdsManager lmdsManager = CacheHelper.lmdsCommunicatorInstance.get( Util.getManagerId() );
		
		boolean subscribeManager = lmdsManager.subscribeManager( synthetic );
		
		return subscribeManager;
	}

	/**
	 * <p>
	 * The sendToEngine is responsible to send CommandMessages, orders, Strategies, etc...
	 * to the Engine
	 * </p>
	 * 
	 * @author <a href="mailto:aimbere.galdino@ubs.com">Aimbere Galdino</a>
	 * @param <M>
	 *            contains the {@link Message}.
	 * @param <E>
	 *            contains the {@link boolean}.
	 * @since 1.7
	 */
	@Override
	public boolean sendToEngine(Message message) {

		try {
			pb_to_engine_message engineMessage = manager.managerMessage( message );
			
			CacheHelper.engineCommunicatorInstance.get( Util.getEngineId() ).send( engineMessage );
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
		return false;
	}
}