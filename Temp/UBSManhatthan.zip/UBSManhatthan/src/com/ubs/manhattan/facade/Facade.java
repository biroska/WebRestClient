package com.ubs.manhattan.facade;

import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Service;

import com.ubs.manhattan.persistence.entities.EngineInstance;
import com.ubs.manhattan.persistence.entities.LegStrategyReport;
import com.ubs.manhattan.persistence.entities.OrderTrade;
import com.ubs.manhattan.persistence.entities.Role;
import com.ubs.manhattan.persistence.entities.StrategyOrders;
import com.ubs.manhattan.persistence.entities.StrategyReport;

//@Service
public interface Facade {
	
	public StrategyReport saveReport( StrategyReport report ) throws Exception;
	
	public StrategyOrders saveOrder( StrategyOrders report ) throws Exception;
	
	public OrderTrade saveOrderTrade( OrderTrade orderTrade ) throws Exception;
	
	public LegStrategyReport getLegStrategyByID( Integer legSeq, Long strategyReportId ) throws Exception;
	
	public List<LegStrategyReport> getLegStrategyByReportId ( Long strategyReportId ) throws Exception;
	
	public StrategyOrders findStrategyOrderById( StrategyOrders order ) throws Exception;
	
	public StrategyReport findStrategyReportById( StrategyReport report ) throws Exception;
	
	public EngineInstance saveEngineInstance( EngineInstance engine ) throws Exception;
	
	public Integer businessDayTotal( Date beginningDt, Date endingDt );
	
	public Integer businessDayTotal2( Date beginningDt, Date endingDt );
	
	public Role saveRole( Role role );
	
}