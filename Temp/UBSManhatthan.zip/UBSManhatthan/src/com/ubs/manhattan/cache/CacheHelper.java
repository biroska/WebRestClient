package com.ubs.manhattan.cache;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import com.ubs.manhattan.lmdsadapter.LmdsManager;
import com.ubs.manhattan.lmdsadapter.SimulationItem;
import com.ubs.manhattan.network.client.NetworkClient;
import com.ubs.manhattan.persistence.entities.LegStrategyReport;
import com.ubs.manhattan.persistence.entities.StrategyOrders;
import com.ubs.manhattan.persistence.entities.StrategyReport;
import com.ubs.manhattan.persistence.entities.id.LegStrategyReportPK;
import com.ubs.manhattan.persistence.entities.id.StrategyOrdersPK;
import com.ubs.manhattan.persistence.entities.id.StrategyReportPK;
import com.ubs.manhattan.utils.Util;

public class CacheHelper {
									  /*symbol or synthetic*/  
	private static ConcurrentHashMap< String,   SimulationItem> simulationItensMap;
									/*symbol*/  /*Lista de keys do simulationItensMap*/
	private static ConcurrentHashMap< String,   List<String> > listeningSimulationItens;
	
	
	public static ConcurrentHashMap< StrategyReportPK, StrategyReport > strategyReportMap;
	public static ConcurrentHashMap< LegStrategyReportPK, LegStrategyReport > legStrategyReportMap;
	public static ConcurrentHashMap< StrategyOrdersPK, StrategyOrders > strategyOrderMap;
	public static ConcurrentHashMap< StrategyOrdersPK, StrategyOrders > leggedOrderMap;
	
	public static ConcurrentHashMap< Long, StrategyReport > StrategyReportMapByRequestId;
	public static ConcurrentHashMap< Long, StrategyOrders > StrategyOrderMapByRequestId;
	
//	The manager can connect with several Engines  <EngineId, NetworkClient>
	public static HashMap< Integer, NetworkClient > engineCommunicatorInstance;

//	The manager can connect with a unique LMDS Channel < ManagerId, LMDSManager >
	public static HashMap< Integer, LmdsManager > lmdsCommunicatorInstance;
	
	private static ArrayList<StrategyReportPK> auxListStrategyReport;
	private static ArrayList<LegStrategyReportPK> auxListLegStrategyReport;
	
	static {
		
//		This map associates the synthetic ( F16 / F18 ) with SimulationItem which represents
//		the values in market Watch panelSimulationItem
		simulationItensMap = new ConcurrentHashMap<String, SimulationItem>();
		
//		this map associates the symbol (DIF16) with a List< key from simulationItensMap >.
//		One entry of this map references a list with all synthetic/symbols which have this symbol( DIF16)
		listeningSimulationItens = new ConcurrentHashMap< String, List<String> >();
		
		// Map used to keep StrategyReport after persist
		strategyReportMap = new ConcurrentHashMap< StrategyReportPK, StrategyReport >();

		// Map used to keep LegStrategyReport after persist and avoid search the leg in all itens of strategyReportMap
		legStrategyReportMap = new ConcurrentHashMap< LegStrategyReportPK, LegStrategyReport >();
		
		// Map used to keep StrategyOrders after persist and avoid search the Order in all legs o each item of strategyReportMap
		strategyOrderMap = new ConcurrentHashMap< StrategyOrdersPK, StrategyOrders >();
		
		// Map used to keep Legged orders. This map is filled by the engine and consumed by view 
		leggedOrderMap = new ConcurrentHashMap< StrategyOrdersPK, StrategyOrders >();
		
//		Map used to keep the information before sending the message to Engine, these maps are used 
//		to retrieve the original information in case of a rejection message
		StrategyReportMapByRequestId = new ConcurrentHashMap< Long, StrategyReport >();
		StrategyOrderMapByRequestId = new ConcurrentHashMap< Long, StrategyOrders >();
		
		engineCommunicatorInstance = new HashMap< Integer, NetworkClient>();
		lmdsCommunicatorInstance = new HashMap< Integer, LmdsManager>();
		
		auxListStrategyReport = new ArrayList<StrategyReportPK>( strategyReportMap.keySet() );
		auxListLegStrategyReport = new ArrayList<LegStrategyReportPK>( legStrategyReportMap.keySet() );
	}
	
	
	public static void putLegStrategyList( List<LegStrategyReport> list ) {
		
		if ( list != null ){
			for (LegStrategyReport leg : list) {
				if ( !legStrategyReportMap.containsKey( leg.getId() ) ){
					legStrategyReportMap.put( leg.getId(), leg );
				}
			}
		}
	}
	
	public static List<LegStrategyReport> getLegStrategyReportByStrategyId( Long strategyId ){
		List<LegStrategyReport> list = new ArrayList<LegStrategyReport>();
		
		for ( LegStrategyReportPK pk : legStrategyReportMap.keySet() ) {
			if ( pk.getStrategyId().equals( strategyId ) )
				list.add( legStrategyReportMap.get( pk )  );
		}
		
		return list.isEmpty() ? null : list;
	}
	
	public static List<LegStrategyReport> getLegStrategyReportList( StrategyReport report ){
	
		if ( report == null || report.getId() == null )
			return null;
		
		List<LegStrategyReport> list = new ArrayList<LegStrategyReport>();
		
		for ( LegStrategyReportPK key : CacheHelper.legStrategyReportMap.keySet() ) {
			if ( key.getStrategyId().equals( report.getId() ) ){
				list.add( legStrategyReportMap.get( key ) );
			}
		}
		return list;
	}
	
	public static StrategyReport putStrategyReport( StrategyReport report ){
		
		if ( report != null ){
			
			strategyReportMap.put( report.getId(), report );
			
			if ( report.getLegStrategyList() != null && !report.getLegStrategyList().isEmpty() ){
				
				for (LegStrategyReport leg : report.getLegStrategyList() ) {
					legStrategyReportMap.put( leg.getId(), leg );
				}
			}
			
		}
		return report;
	}
	
		
	public static SimulationItem putSimulationItem( String key, SimulationItem item ){
		
		System.out.println( "\n===================== Begining ======================" );
		System.out.println( "\t key: " + key );
		System.out.println( "\t listeningSimulationItens: " + listeningSimulationItens );
		System.out.println( "\t simulationItensMap: " + simulationItensMap );
		System.out.println( "\t item: " + item );
		
		item = simulationItensMap.put( key, item );
		
		List<String> keyList = Util.extractKeyList( key );
		
		if ( keyList != null ){
		
			for (String element : keyList) {
				
				List<String> referencelist = listeningSimulationItens.get( element );
				
				if ( referencelist != null ){
					referencelist.add( key );
					
				} else {
					referencelist = new ArrayList<String>();
					referencelist.add( key );
					
					listeningSimulationItens.put( element, referencelist );
				}
			}
		}
		
		System.out.println( "===================== Endining ======================" );
		System.out.println( "\t listeningSimulationItens: " + listeningSimulationItens );
		System.out.println( "\t simulationItensMap: " + simulationItensMap );
		System.out.println( "===================================================== \n\n\n" );
		
//		listeningSimulationItens
		
		//Colocar entrada no HashMap simulationItensMap
		//Duas entradas no HashMap listeningSimulationItens
			//kye=DI1F17 e value=DI1F17|DI1F18
			//kye=DI1F18 e value=DI1F17|DI1F18
		
		return item;
	}
	
	public static List<SimulationItem> getSimulationListBySymbol( String symbol ){
		
		List<SimulationItem> simulationList = new ArrayList<SimulationItem>();
		
		List<String> syntheticKeyList = listeningSimulationItens.get( symbol );
		
		if ( syntheticKeyList == null || syntheticKeyList.isEmpty() )
			return null;
		
		for (String syntheticKey : syntheticKeyList) {
			
			SimulationItem auxSimulation = simulationItensMap.get( syntheticKey );
			
			if ( auxSimulation != null )
				simulationList.add( auxSimulation );
		}
		
		return simulationList.isEmpty() ? null : simulationList;
	}
	
	public static boolean listeningSimulationContainsKey( String symbol ){
		
		return listeningSimulationItens.containsKey( symbol );
	}
	
	public static boolean simulationItensMapContainsKey( String symbol ){
		
		return simulationItensMap.containsKey( symbol );
	}
	
	public static String printSimulationItensMap(){
		return simulationItensMap.toString();
	}
	
	public static String printlisteningSimulationItens(){
		return listeningSimulationItens.toString();
	}
	

//	m�todos para mock, remover.... aim*

	public static StrategyReportPK getStrategyReportByIndex( Integer index ){
		
		if ( strategyReportMap == null || strategyReportMap.isEmpty() ||
			 index == null || index < 0 )
			return null;
		
		auxListStrategyReport = new ArrayList<StrategyReportPK>( strategyReportMap.keySet() );
		
		if ( auxListStrategyReport.size() > index ){
			StrategyReportPK strategyReportPK = auxListStrategyReport.get( index );
			return strategyReportPK;
		}

		return null;
	}
	
	public static LegStrategyReport getLegStrategyReportByIndex( Integer index ){
		
		if ( index == null || index < 0 )
			return null;
		
		auxListLegStrategyReport = new ArrayList<LegStrategyReportPK>( legStrategyReportMap.keySet() );
			
		if ( auxListLegStrategyReport.size() > index ){
			return legStrategyReportMap.get( auxListLegStrategyReport.get( index ) );
		}
		
		return null;
	}
	
}