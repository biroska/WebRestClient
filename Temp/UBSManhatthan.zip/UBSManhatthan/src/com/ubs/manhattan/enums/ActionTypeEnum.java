package com.ubs.manhattan.enums;

public enum ActionTypeEnum{
	
    INSERT,
    UPDATE,
    DELETE;
    
    private ActionTypeEnum() {
    }
}
