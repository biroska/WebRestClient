package com.ubs.manhattan.enums;

public enum OrderTypeEnum {
	
	
    MARKET                          ( 49 ), // 1
    LIMIT                           ( 50 ), // 2
    STOP_LOSS                       ( 51 ), // 3
    STOP_LIMIT                      ( 52 ), // 4
    MARKET_WITH_LEFTOVER_AS_LIMIT   ( 75 ); // K
    
    private final Integer code;
    
    private OrderTypeEnum( Integer code ) {
        this.code = code;
    }

    public Integer getCode() {
        return code;
    }
    
    public static OrderTypeEnum fromValue( Integer value ){
    	
		for (OrderTypeEnum item : OrderTypeEnum.values() ) {
			if ( item.getCode().equals( value ) ){
				return item;
			}
		}
		return null;
    }
}
