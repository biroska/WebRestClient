package com.ubs.manhattan.enums;

public enum SideEnum{
	
	NOT_DEFINED                 ( 0 ),
    BUY                         ( 1 ), // 0
    SELL                        ( 2 ); // 4

    private final Integer code;
    
    private SideEnum( Integer code ) {
        this.code = code;
    }

    public Integer getCode() {
        return code;
    }
    
    public static SideEnum fromValue( Integer value ){
    	
		for (SideEnum item : SideEnum.values() ) {
			if ( item.getCode().equals( value ) ){
				return item;
			}
		}
		return null;
    }
}
