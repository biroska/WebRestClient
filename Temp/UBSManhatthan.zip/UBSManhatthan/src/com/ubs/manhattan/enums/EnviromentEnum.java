package com.ubs.manhattan.enums;

public enum EnviromentEnum {
	
	LOCAL,
	DEV,
	UAT,
	PROD;
}
