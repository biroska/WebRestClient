package com.ubs.manhattan.lmdsadapter.marketdata.entities;

/**
 * Security identification data
 * 
 * @author pretof
 *
 */
public interface Security {
	
	/**
	 * Security ID is an exchange specific number that identify a security
	 * 
	 * @return Security ID
	 */
	String getSecurityID();
	
	/**
	 * Exchange name
	 * 
	 * @return Exchange name like "BMF" or "BOVESPA"
	 */
	String getExchange();
	
	/**
	 * Symbol name on the current exchange
	 * 
	 * @return Exchange symbol. i.e: PETR4
	 */
	String getSymbol();
	

}
