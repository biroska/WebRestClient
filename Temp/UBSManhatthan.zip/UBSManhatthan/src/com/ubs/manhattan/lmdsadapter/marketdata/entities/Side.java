package com.ubs.manhattan.lmdsadapter.marketdata.entities;

/**
 * Side of an order
 * 
 * @author pretof
 *
 */
public enum Side {
	BUY,
	SELL,
	UNKNOWN
}
