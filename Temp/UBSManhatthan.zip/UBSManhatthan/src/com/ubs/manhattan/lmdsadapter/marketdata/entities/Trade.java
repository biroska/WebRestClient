package com.ubs.manhattan.lmdsadapter.marketdata.entities;

import java.math.BigDecimal;
import java.util.Date;


/**
 * A Trade 
 * 
 * @author pretof
 *
 */
public interface Trade {
	
	/**
	 * Price of the trade
	 * 	
	 * @return Price of the trade
	 */
	BigDecimal getPrice();	
	
	/**
	 * Get trade size in quantity of shares/contracts
	 * 
	 * @return trade size
	 */
	long getQuantity();
	
	/**
	 * Trade date timestamp
	 * 
	 * @return when the trade ocurred
	 */
	Date getTradeDate();

}
