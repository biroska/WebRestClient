package com.ubs.manhattan.lmdsadapter.marketdata.entities;

public interface SecurityStatus {

}
