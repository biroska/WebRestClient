package com.ubs.manhattan.lmdsadapter;

import com.ubs.manhattan.simulator.multileg.InputMultilegSimulation;
import com.ubs.manhattan.utils.Constant;

public class SimulationItem {
	
	public SimulationItem(){
		buyInputMultilegSimulationList = new InputMultilegSimulation();
		sellInputMultilegSimulationList = new InputMultilegSimulation();
		this.LastQty = (long) Constant.SIMULATION.INITIAL_QUANTITY;
		this.LastPx = Constant.SIMULATION.INITIAL_PRICE;
		this.BuyQty = (long) Constant.SIMULATION.INITIAL_QUANTITY;
		this.BuyPx = Constant.SIMULATION.INITIAL_PRICE;
		this.SellQty = (long ) Constant.SIMULATION.INITIAL_QUANTITY;
		this.SellPx = Constant.SIMULATION.INITIAL_PRICE;
	}
	
	private boolean onlySymbol;
	private InputMultilegSimulation buyInputMultilegSimulationList;
	private InputMultilegSimulation sellInputMultilegSimulationList;
	
	private Long   LastQty;
	private Double LastPx;
	private Long   BuyQty;
	private Double BuyPx;
	private Long   SellQty;
	private Double SellPx;
	
	public boolean isOnlySymbol() {
		return onlySymbol;
	}
	public void setOnlySymbol(boolean onlySymbol) {
		this.onlySymbol = onlySymbol;
	}
	public InputMultilegSimulation getBuyInputMultilegSimulationList() {
		return buyInputMultilegSimulationList;
	}
	public void setBuyInputMultilegSimulationList(
			InputMultilegSimulation buyInputMultilegSimulationList) {
		this.buyInputMultilegSimulationList = buyInputMultilegSimulationList;
	}
	public InputMultilegSimulation getSellInputMultilegSimulationList() {
		return sellInputMultilegSimulationList;
	}
	public void setSellInputMultilegSimulationList(
			InputMultilegSimulation sellInputMultilegSimulationList) {
		this.sellInputMultilegSimulationList = sellInputMultilegSimulationList;
	}
	public Long getLastQty() {
		return LastQty;
	}
	public void setLastQty(Long lastQty) {
		LastQty = lastQty;
	}
	public Double getLastPx() {
		return LastPx;
	}
	public void setLastPx(Double lastPx) {
		LastPx = lastPx;
	}
	public Long getBuyQty() {
		return BuyQty;
	}
	public void setBuyQty(Long buyQty) {
		BuyQty = buyQty;
	}
	public Double getBuyPx() {
		return BuyPx;
	}
	public void setBuyPx(Double buyPx) {
		BuyPx = buyPx;
	}
	public Long getSellQty() {
		return SellQty;
	}
	public void setSellQty(Long sellQty) {
		SellQty = sellQty;
	}
	public Double getSellPx() {
		return SellPx;
	}
	public void setSellPx(Double sellPx) {
		SellPx = sellPx;
	}
	@Override
	public String toString() {
		return "SimulationItem [onlySymbol=" + onlySymbol
				+ ", buyInputMultilegSimulationList="
				+ buyInputMultilegSimulationList
				+ ", sellInputMultilegSimulationList="
				+ sellInputMultilegSimulationList + ", LastQty=" + LastQty
				+ ", LastPx=" + LastPx + ", BuyQty=" + BuyQty + ", BuyPx="
				+ BuyPx + ", SellQty=" + SellQty + ", SellPx=" + SellPx + "] \n";
	}
}