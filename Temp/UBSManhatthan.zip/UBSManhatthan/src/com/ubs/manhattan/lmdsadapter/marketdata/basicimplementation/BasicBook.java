package com.ubs.manhattan.lmdsadapter.marketdata.basicimplementation;

import java.util.Vector;

import com.ubs.manhattan.lmdsadapter.marketdata.entities.Book;
import com.ubs.manhattan.lmdsadapter.marketdata.entities.BookEntry;
import com.ubs.manhattan.lmdsadapter.marketdata.entities.BookSnapshot;
import com.ubs.manhattan.lmdsadapter.marketdata.entities.IncrementalBookUpdate;
import com.ubs.manhattan.lmdsadapter.marketdata.entities.Security;
import com.ubs.manhattan.lmdsadapter.marketdata.entities.Side;

/**
 * Basic working book
 * 
 * @author pretof
 *
 */
public class BasicBook implements Book {
	
	private final Vector<BookEntry> buyEntries = new Vector<>();
	private final Vector<BookEntry> sellEntries = new Vector<>();
	private final Security security;
	private long lastIncrementalID;
	
	public BasicBook(Security security) {
		this.security = security;
	}

	@Override
	public Security getSecurity() {
		return this.security;
	}

	@Override
	public synchronized boolean isEmpty() {
		return this.buyEntries.isEmpty() && this.sellEntries.isEmpty();
	}

	@Override
	public synchronized boolean applyIncrementalUpdate(IncrementalBookUpdate update) {
		
		if (update == null) return false;
		
		if (update.getEntry() == null) return false;
		
		BookEntry bookEntry = update.getEntry();
		if (bookEntry.getSide() == Side.UNKNOWN) return false;
		
		
		Vector<BookEntry> entries = (bookEntry.getSide() == Side.BUY) ? this.buyEntries : this.sellEntries;
		
		switch (update.getUpdateType()) {
		
		case ADD:
			if (update.getPosition() > entries.capacity()) return false;			
			entries.add(update.getPosition(), bookEntry);
			break;
		case DELETE:
			if (update.getPosition() >= entries.capacity()) return false;			
			entries.remove(update.getPosition());
			break;
		case UPDATE:
			if (update.getPosition() >= entries.capacity()) return false;			
			entries.set(update.getPosition(), bookEntry);			
			break;		
		}
		
		this.lastIncrementalID = update.getIncrementalID();
		
		return true;
	}

	@Override
	public synchronized BookSnapshot getSnapshot(int depth) {
		
		BookSnapshot snapshot = new BasicBookSnapshot(this.getSecurity(), depth, this.buyEntries, this.sellEntries, this.lastIncrementalID);
		
		return snapshot;
	}

	@Override
	public synchronized int getBidSize() {
		return this.buyEntries.size();
	}

	@Override
	public synchronized int getAskSize() {
		return this.sellEntries.size();
	}

	@Override
	public synchronized BookEntry getBidAt(int position) {
		if (this.buyEntries.size() <= position) return null;
		
		return this.buyEntries.get(position);
	}

	@Override
	public synchronized BookEntry getAskAt(int position) {
		if (this.sellEntries.size() <= position) return null;
		
		return this.sellEntries.get(position);
	}

	@Override
	public long getLastIncrementalID() {
		return this.lastIncrementalID;
	}

	@Override
	public synchronized void reset() {
		this.buyEntries.clear();
		this.sellEntries.clear();
		this.lastIncrementalID = 0;
		
	}

}
