package com.ubs.manhattan.lmdsadapter.marketdata.lmds;

import java.util.List;
import java.util.Properties;

import com.ubs.manhattan.lmdsadapter.marketdata.basicimplementation.BasicBook;
import com.ubs.manhattan.lmdsadapter.marketdata.entities.SecurityDefinition;
import com.ubs.manhattan.lmdsadapter.marketdata.manager.MDManagedInstrument;
import com.ubs.manhattan.lmdsadapter.marketdata.manager.MDManager;
import com.ubs.manhattan.lmdsadapter.marketdata.manager.MDManagerFactory;

import quickfix.ConfigError;
import quickfix.DefaultMessageFactory;
import quickfix.FileLogFactory;
import quickfix.LogFactory;
import quickfix.MemoryStoreFactory;
import quickfix.MessageFactory;
import quickfix.MessageStoreFactory;
import quickfix.RuntimeError;
import quickfix.SessionID;
import quickfix.SessionNotFound;
import quickfix.SessionSettings;
import quickfix.ThreadedSocketInitiator;

public class LMDSController
{
	private State internalState;
	private ThreadedSocketInitiator fixSocket;
	private final QuickFixLMDSApplication fixApplication;
	private final LMDSSubscriptionController subController;

	public LMDSController()
	{
		this.fixApplication = new QuickFixLMDSApplication(this);
		this.subController = new LMDSSubscriptionController(this.fixApplication);
		this.internalState = State.UNCONFIGURED;
	}
	
	public void onConfigure(Properties config) throws ConfigError {

		if (this.fixSocket != null)
		{
			this.fixSocket.stop(true);
		}
		
		this.fixApplication.configure(config);
		SessionSettings settings = generateQFSessionSettings(config);
		MessageStoreFactory storeFactory = new MemoryStoreFactory();
		
		LogFactory logFactory = new FileLogFactory(settings);
		//LogFactory logFactory = new ScreenLogFactory(settings);
	    MessageFactory messageFactory = new DefaultMessageFactory();
	    
	    
	    this.fixSocket = new ThreadedSocketInitiator(fixApplication, storeFactory, settings, logFactory, messageFactory);
		
	    this.internalState = State.IDLE;

	}
	
	public void onStart() throws RuntimeError, ConfigError {
		//
		// Start quickfix
		//
		if (this.internalState != State.IDLE) {
			throw new ConfigError("Fix engine not configured yet");
		}
		
		this.internalState = State.CONNECTING;
		this.fixSocket.start();
		
		
	}
	
	public void onStop() throws ConfigError {
		//
		// Stop quickfix
		//

		if (this.fixSocket == null) {
			throw new ConfigError("Fix engine not configured yet");
		}

		this.fixSocket.stop(true);	
		this.internalState = State.ENDED;
	}
	
	public synchronized void onFixConnect() {
		
		//
		// Change state
		//
		this.internalState = State.RECEIVING_SECURITY_LIST;
		
		//
		// Request security list
		//
		try
		{
			this.subController.requestSecurityList();
		} catch (SessionNotFound e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public synchronized void onFixDisconnect() {
		
		//
		// Change State
		//
		this.internalState = State.CONNECTING;
	}
	
	public void onSecurityListReceived(List<SecurityDefinition> instruments) {
		
		
		// Subscribe
		for (SecurityDefinition instrument : instruments) {
			
			String exchange = instrument.getSecurity().getExchange();
			MDManager manager = MDManagerFactory.getManager(exchange);
			
			manager.registerInstrument(new MDManagedInstrument(instrument, new BasicBook(instrument.getSecurity())));

			this.subController.subscribeSymbol(instrument);
		}
		
	}
	
	public synchronized void onLastInstrumentReceived() {
		
	}
	
	private SessionSettings generateQFSessionSettings(Properties config) throws ConfigError {
		
		String host = config.getProperty("marketdata.lmds.host", "unknown");
		int port = Integer.parseInt(config.getProperty("marketdata.lmds.port", "0"));
		String targetCompID = config.getProperty("marketdata.lmds.targetcompid", "unknown");
		String senderCompID = config.getProperty("marketdata.lmds.sendercompid", "unknown");
		String fix44DataDictionaryPath = config.getProperty("marketdata.lmds.dictionary", "unknown");
				
		//
		// Generate DEFAULT setting dictionary
		//
		quickfix.Dictionary dicDefault = new quickfix.Dictionary();
		dicDefault.setString("BeginString", "FIX.4.4");
		dicDefault.setString("DataDictionary", fix44DataDictionaryPath);
		dicDefault.setString("StartTime", "05:45:00");
		dicDefault.setString("EndTime", "23:30:00");
		dicDefault.setString("UseLocalTime", "Y");
        dicDefault.setString("PersistMessages", "N");
        dicDefault.setString("ResetOnLogon", "Y");
        dicDefault.setString("HeartBtInt", "30");
        dicDefault.setString("CheckLatency", "N");
        dicDefault.setString("RejectInvalidMessage", "N");
        dicDefault.setString("ValidateIncomingMessage", "N");
        dicDefault.setString("ValidateFieldsOutOfOrder", "N");
        dicDefault.setString("ValidateUnorderedGroupFields", "N");
        dicDefault.setString("RejectMessageOnUnhandledException", "N");
        dicDefault.setString("ScreenLogEvents", "Y");
        dicDefault.setString("ScreenLogShowIncoming", "N");
        dicDefault.setString("FileStorePath", "logs/fix");
        dicDefault.setString("FileLogPath", "logs/fix");
        
        //
        // Generate SESSION settings dictionary
        //
        quickfix.Dictionary dicSession = new quickfix.Dictionary();
        dicSession.setString("BeginString", "FIX.4.4");
        dicSession.setString("TargetCompID", targetCompID);
        dicSession.setString("SenderCompID", senderCompID);
        dicSession.setString("ConnectionType", "initiator");
        dicSession.setString("SocketConnectHost", host);
        dicSession.setString("SocketConnectPort", Integer.toString(port));

        //
        // Populate session settings (first DEFAULT, after SESSION specific)
        //
        SessionSettings sessionSettings = new SessionSettings();
        sessionSettings.set(dicDefault);
        sessionSettings.set(new SessionID("FIX.4.4", senderCompID, targetCompID), dicSession);		
		
	    return sessionSettings;	
	}

	
	private enum State {
		UNCONFIGURED,
		IDLE,
		CONNECTING,
		RECEIVING_SECURITY_LIST,
		RUNNING,
		RECONNECTING,
		ENDED
	}
}
