package com.ubs.manhattan.lmdsadapter.marketdata.manager;

import com.ubs.manhattan.lmdsadapter.marketdata.entities.BookSnapshot;
import com.ubs.manhattan.lmdsadapter.marketdata.entities.Trade;

public interface MDSubscriberHandler {

	void onBookUpdate(String symbol, BookSnapshot book);
	
	void onTrade(String symbol, Trade trade);
	
}
