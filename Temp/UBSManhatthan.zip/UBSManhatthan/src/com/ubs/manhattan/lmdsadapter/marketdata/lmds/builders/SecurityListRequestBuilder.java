package com.ubs.manhattan.lmdsadapter.marketdata.lmds.builders;

import quickfix.Message;
import quickfix.fix44.SecurityListRequest;

public class SecurityListRequestBuilder
{

	private SecurityListRequestBuilder()
	{
		// Do No Instantiate
	}

	public static Message build(String reqId)
	{

		SecurityListRequest message = new SecurityListRequest();
		
		// Request Id
		message.setString(quickfix.field.SecurityReqID.FIELD, reqId);

		// Subscription Type
		message.setChar(quickfix.field.SubscriptionRequestType.FIELD,
				quickfix.field.SubscriptionRequestType.SNAPSHOT_PLUS_UPDATES);

		// SecurityListRequestType
		message.setInt(quickfix.field.SecurityListRequestType.FIELD,
				quickfix.field.SecurityListRequestType.ALL_SECURITIES);

		return message;

	}

}
