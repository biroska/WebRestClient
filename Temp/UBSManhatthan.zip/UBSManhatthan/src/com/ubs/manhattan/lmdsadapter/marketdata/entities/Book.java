package com.ubs.manhattan.lmdsadapter.marketdata.entities;
/**
 * The book retains bids and offers for a given instrument.
 * 
 * The book can be update through Incremetal Updates. The snapshot
 * that it generates is immutable.
 * 
 * 
 * @author pretof
 *
 */
public interface Book extends BookSnapshot {

	/**
	 * Generate a snapshot of the current book.
	 * 
	 * @param depth Limit the depth of snapshot (value must be bigger than 1)
	 * @return a snapshot of the requested depth
	 */
	BookSnapshot getSnapshot(int depth);
	
	/**
	 * Apply an incremental update on the book
	 * 
	 * @param update
	 * @return
	 */
	boolean applyIncrementalUpdate(IncrementalBookUpdate update);
	
	/**
	 * Clear the entire book
	 */
	void reset();
	
}
