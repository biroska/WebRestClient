package com.ubs.manhattan.lmdsadapter.marketdata.entities;

import java.math.BigDecimal;

/**
 * Prices for a given instrument.
 * 
 * 
 * @author pretof
 *
 */
public interface SecurityPrice {
	
	/**
	 * 
	 * @return
	 */
	BigDecimal getClosingPrice();
	
	BigDecimal getOpeningPrice();

}
