package com.ubs.manhattan.lmdsadapter.dependency;

import java.util.concurrent.ConcurrentHashMap;



/**
 * This is a very simple dependency injector system.
 * 
 * Register a class/interface with object instance
 * 
 * @author pretof
 *
 */
public final class Injector {
	
	private final static ConcurrentHashMap<Class<?>, Object> map = new ConcurrentHashMap<>();
	
	public static void register(Class<?> clazz, Object o) {
		Injector.map.put(clazz, o);
	}
	
	public static <T> T inject(Class<?> clazz) {
		
		try {
			@SuppressWarnings("unchecked")
			T o = (T)Injector.map.get(clazz);
			return o;
		} catch (ClassCastException e) {
			return null;
		}
		
	}

}
