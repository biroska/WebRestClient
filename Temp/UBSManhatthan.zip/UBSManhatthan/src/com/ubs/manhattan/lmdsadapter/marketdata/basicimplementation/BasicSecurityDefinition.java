package com.ubs.manhattan.lmdsadapter.marketdata.basicimplementation;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;

import com.ubs.manhattan.lmdsadapter.marketdata.entities.Security;
import com.ubs.manhattan.lmdsadapter.marketdata.entities.SecurityDefinition;

public class BasicSecurityDefinition implements SecurityDefinition {
	
	private final Security security;
	private final long roundLot;
	private final BigDecimal minPriceIncrement;
	private final Date maturityDate;

//	remover aim*
	public BasicSecurityDefinition(Security security, long roundLot,
			BigDecimal minPriceIncrement) {
		this.security = security;
		this.roundLot = roundLot;
		this.minPriceIncrement = minPriceIncrement;
		
		/* Mock para o Maturity Date */
		Calendar cal = Calendar.getInstance();
		cal.add( Calendar.DATE  , 5 );
		this.maturityDate = cal.getTime();
	}
	
	public BasicSecurityDefinition(Security security, long roundLot,
			BigDecimal minPriceIncrement, Date maturityDate) {
		this.security = security;
		this.roundLot = roundLot;
		this.minPriceIncrement = minPriceIncrement;

		/* Mock para o Maturity Date */
		Calendar cal = Calendar.getInstance();
		cal.add( Calendar.DATE  , 5 );
		this.maturityDate = cal.getTime();
	}

	@Override
	public Security getSecurity() {
		return this.security;
	}

	@Override
	public long getRoundLot() {
		// TODO Auto-generated method stub
		return this.roundLot;
	}

	@Override
	public BigDecimal getMinPriceIncrement() {
		return this.minPriceIncrement;
	}

	/* (non-Javadoc)
	 * @see com.ubs.manhattan.lmdsadapter.marketdata.entities.SecurityDefinition#getMaturityDate()
	 */
	@Override
	public Date getMaturityDate() {
		return this.maturityDate;
	}

}
