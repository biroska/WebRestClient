package com.ubs.manhattan.lmdsadapter.marketdata.lmds.handlers;

public interface QuickFixHandler<T extends quickfix.Message> extends Handler<T>
{

}
