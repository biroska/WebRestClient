package com.ubs.manhattan.lmdsadapter.marketdata.lmds.handlers;

public interface Handler<T>
{
	
	void handle(T event);
	
}
