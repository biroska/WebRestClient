package com.ubs.manhattan.lmdsadapter.marketdata.lmds;

import com.ubs.manhattan.lmdsadapter.marketdata.lmds.handlers.MarketDataIncrementalHandler;
import com.ubs.manhattan.lmdsadapter.marketdata.lmds.handlers.MarketDataSnapshotHandler;
import com.ubs.manhattan.lmdsadapter.marketdata.lmds.handlers.SecurityListHandler;

import quickfix.FieldNotFound;
import quickfix.IncorrectTagValue;
import quickfix.SessionID;
import quickfix.UnsupportedMessageType;
import quickfix.fix44.MarketDataIncrementalRefresh;
import quickfix.fix44.MarketDataRequestReject;
import quickfix.fix44.MarketDataSnapshotFullRefresh;
import quickfix.fix44.MessageCracker;
import quickfix.fix44.News;
import quickfix.fix44.SecurityList;

public class QuickFixLMDSCracker extends MessageCracker
{
	protected SecurityListHandler securityListHandler;
	protected MarketDataSnapshotHandler snapshotHandler;
	protected MarketDataIncrementalHandler incrementalHandler;
	protected final LMDSController controller;

	public QuickFixLMDSCracker(LMDSController controller)
	{
		this.controller = controller;
		this.securityListHandler = new SecurityListHandler(controller);
		this.snapshotHandler = new MarketDataSnapshotHandler();
		this.incrementalHandler = new MarketDataIncrementalHandler();
	}

	@Override
	public void onMessage(MarketDataIncrementalRefresh message,
			SessionID sessionID) throws FieldNotFound, UnsupportedMessageType,
			IncorrectTagValue
	{
		this.incrementalHandler.handle(message);
	}

	@Override
	public void onMessage(MarketDataRequestReject message, SessionID sessionID)
			throws FieldNotFound, UnsupportedMessageType, IncorrectTagValue
	{
	}

	@Override
	public void onMessage(MarketDataSnapshotFullRefresh message,
			SessionID sessionID) throws FieldNotFound, UnsupportedMessageType,
			IncorrectTagValue
	{
		this.snapshotHandler.handle(message);
	}

	@Override
	public void onMessage(News message, SessionID sessionID)
			throws FieldNotFound, UnsupportedMessageType, IncorrectTagValue
	{
	}

	@Override
	public void onMessage(SecurityList message, SessionID sessionID)
			throws FieldNotFound, UnsupportedMessageType, IncorrectTagValue
	{
		securityListHandler.handle(message);
	}

}
