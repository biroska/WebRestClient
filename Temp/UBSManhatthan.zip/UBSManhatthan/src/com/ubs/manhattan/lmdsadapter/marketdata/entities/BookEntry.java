package com.ubs.manhattan.lmdsadapter.marketdata.entities;

import java.math.BigDecimal;

public interface BookEntry {
	
	Side getSide();
	
	long getQuantity();
	
	BigDecimal getPrice();
	
	boolean isAggregatedEntry();
	
	int numberOfAggregatedOrders();

}
