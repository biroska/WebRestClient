package com.ubs.manhattan.lmdsadapter.marketdata.manager;

import java.util.HashMap;

/**
 * This factory constructs market data managers (MDManager). There must be only one MDManager per
 * market.
 * 
 * @see MDManager
 * @author pretof
 *
 */
public final class MDManagerFactory {

	private static final HashMap<String, MDManager> managers = new HashMap<>();
	
	/**
	 * Construct a manager. If there is already a manager constructed for the market
	 * then it will return the same manager as before.
	 * 
	 * @param market The market name. i.e. "BOVESPA" or "BMF"
	 * @return The MDManager for the given market
	 */
	public static synchronized MDManager getManager(String market) {
		
		if (!managers.containsKey(market))
			managers.put(market, new MDManager(market));
		
		return managers.get(market);
		
	}
	
}
