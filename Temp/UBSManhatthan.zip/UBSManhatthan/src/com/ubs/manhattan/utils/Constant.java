package com.ubs.manhattan.utils;

import org.apache.log4j.Level;

public interface Constant {

	public class COMUNICATION {

		public static String ADDRESS = "xsap6552vdap.sap.swissbank.com";
//		public static String ADDRESS = "localhost";
		public static int PORT = 6000;

		public static String QUIT_COMMAND = "quit";
	}
	
	public class MESSAGES_CONFIGURATION {
		public static int HEARTBEAT_DELAY = 3;
		public static int HEARTBEAT_FAIL =  3;
		public static int STATISTICS_DEELAY = 3;
		
		public static String REPORT_MODIFIED = "modified";
	}
	
	public class LOG_CONFIGURATION {
		public static String FILE_EXTENSION  = "log";
		public static Level LOG_LEVEL  = Level.INFO;
	}
	
	public class MOCK {
		public static Long STRATEGY_ID = 231415L;
	}
	
	public class SIMULATION {
		public static Integer INITIAL_QUANTITY      	 = -1000;
		public static Double  INITIAL_PRICE      	     = -1000D;
		public static Double  INITIAL_DIV1          	 = -1000.0;
		public static Integer INITIAL_BUSINESS_DAYS 	 = -1000;
		public static Integer INITIAL_RANK          	 = -1000;
		public static Integer INITIAL_LEG_SEQ       	 = -1000;
		public static Double  INITIAL_TARGET        	 = -1000.0;
		public static Integer INITIAL_INSTRUMENT    	 = -1000;
		public static Integer INITIAL_AVAILABLE_QUANTITY = -1000;
		public static Integer INITIAL_MIN_BOOK_SIZE 	 = -1000;
		public static Integer DEFAULT_BOOK_LEVEL 		 = 5;
		public static Long    DEFAULT_BOOK_QUANTITY 	 = 0L;
		public static Double  DEFAULT_BOOK_PRICE 	     = 0D;
		public static String  SEPARATOR_SYNTHETIC_KEYMAP = "|";
	}
}