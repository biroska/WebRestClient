package com.ubs.manhattan.utils;


import com.ubs.manhattan.enums.FilePropertiesEnum_remover;

public class EnvironmentVariables {
	
    public static Properties getManhattanProperties() {
    	
        return new Properties( FilePropertiesEnum_remover.MANHATTAN_PROPERTIES.getPath() );
    }
}
