package com.ubs.manhatthan.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import com.ubs.manhatthan.mock.Mock;
import com.ubs.manhatthan.model.Account;
import com.ubs.manhatthan.model.Market;
import com.ubs.manhatthan.service.Facade;

@SuppressWarnings("serial")
@SessionScoped
@ManagedBean(name="marketBean")
public class MarketBean implements Serializable {

	private List<Market> markets;
	private Market selectedMarket;
	private Account selectedAccount;
	private String text;
	
	private List<Market> filteredStrategies;
	
	private Facade facade = new Mock();
	
	public MarketBean() {		
		markets = new ArrayList<Market>(facade.getMarkets());
	}
		
	public List<Market> getMarkets() {
		return markets;
	}

	public void setMarkets(List<Market> markets) {
		this.markets = markets;
	}

	public Market getSelectedMarket() {
		return selectedMarket;
	}

	public void setSelectedMarket(Market selectedMarket) {
		this.selectedMarket = selectedMarket;
	}

	public Account getSelectedAccount() {
		return selectedAccount;
	}

	public void setSelectedAccount(Account selectedAccount) {
		this.selectedAccount = selectedAccount;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public List<Market> getFilteredStrategies() {
		return filteredStrategies;
	}

	public void setFilteredStrategies(List<Market> filteredStrategies) {
		this.filteredStrategies = filteredStrategies;
	}

	public Facade getFacade() {
		return facade;
	}

	public void setFacade(Facade facade) {
		this.facade = facade;
	}
}
	
	
