package com.ubs.manhatthan.beans;

import java.io.Serializable;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ubs.manhattan.facade.Facade;
import com.ubs.manhattan.facade.FacadeImpl;
import com.ubs.manhattan.persistence.entities.Role;
import com.ubs.manhatthan.admin.model.User;

@SuppressWarnings("serial")
@Component("userMergeBean")
@Scope("session")
public class UserMergeBean implements Serializable {  
	
	@Autowired
	private User user;
	
//	@Autowired
	private Facade facade = new FacadeImpl();
    
	@PersistenceContext
	private EntityManager em;
	
	public UserMergeBean(){}
	
	public String login() {
        FacesMessage message = null;
         
        if( "admin".equalsIgnoreCase( user.getLogin() ) && "admin".equalsIgnoreCase( user.getPassword() ) ) {
        	System.out.println("em: " + em);
        	
        	Role role = new Role( "Spring" );
        	
        	facade.saveRole(role);
        	
            return "teste.xhtml";
            
        } else {
            message = new FacesMessage(FacesMessage.SEVERITY_WARN, "Loggin Error", "Invalid credentials");

            FacesContext.getCurrentInstance().addMessage(null, message);
            
            return "merge.xhtml";
        }
   }
 
   
    public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public EntityManager getEm() {
		return em;
	}

	public void setEm(EntityManager em) {
		this.em = em;
	}

	public Facade getFacade() {
		return facade;
	}

	public void setFacade(Facade facade) {
		this.facade = facade;
	}
}