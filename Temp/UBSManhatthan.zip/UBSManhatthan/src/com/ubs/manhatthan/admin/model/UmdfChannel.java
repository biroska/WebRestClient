package com.ubs.manhatthan.admin.model;

import java.io.Serializable;

@SuppressWarnings("serial")
public class UmdfChannel implements Serializable {

	private int id;
	private String channelType;
	private String exchangeType;
	private String incrementalHost;
	private Long incrementalPort;
	private String recoveryHost;
	private Long recoveryPort;
	private String instDefinitionHost;
	private Long instDefinitionPort;
		
	public UmdfChannel(int id, String channelType, String exchangeType, String incrementalHost,
				Long incrementalPort, String recoveryHost, Long recoveryPort, String instDefinitionHost,
				Long instDefinitionPort) {
		
		super();
		
		this.id = id;
		this.channelType = channelType;
		this.exchangeType = exchangeType;
		this.incrementalHost = incrementalHost;
		this.incrementalPort = incrementalPort;
		this.recoveryHost = recoveryHost;
		this.recoveryPort = recoveryPort;
		this.instDefinitionHost = instDefinitionHost;
		this.instDefinitionPort = instDefinitionPort;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "UmdfChannel [id=" + this.id + ", channelType=" + this.channelType + ", exchangeType=" + this.exchangeType + 
				", incrementalHost=" + this.incrementalHost + ", incrementalPort=" + this.incrementalPort.toString() + 
				", recoveryHost=" + this.recoveryHost + ", recoveryPort=" + this.recoveryPort.toString() +
				", instDefinitionHost=" + this.instDefinitionHost + ", instDefinitionPort=" + this.instDefinitionPort.toString() + 
				"]";
	}

	public String getChannelType() {
		return channelType;
	}

	public void setChannelType(String channelType) {
		this.channelType = channelType;
	}

	public String getExchangeType() {
		return exchangeType;
	}

	public void setExchangeType(String exchangeType) {
		this.exchangeType = exchangeType;
	}

	public String getIncrementalHost() {
		return incrementalHost;
	}

	public void setIncrementalHost(String incrementalHost) {
		this.incrementalHost = incrementalHost;
	}

	public Long getIncrementalPort() {
		return incrementalPort;
	}

	public void setIncrementalPort(Long incrementalPort) {
		this.incrementalPort = incrementalPort;
	}

	public String getRecoveryHost() {
		return recoveryHost;
	}

	public void setRecoveryHost(String recoveryHost) {
		this.recoveryHost = recoveryHost;
	}

	public Long getRecoveryPort() {
		return recoveryPort;
	}

	public void setRecoveryPort(Long recoveryPort) {
		this.recoveryPort = recoveryPort;
	}

	public String getInstDefinitionHost() {
		return instDefinitionHost;
	}

	public void setInstDefinitionHost(String instDefinitionHost) {
		this.instDefinitionHost = instDefinitionHost;
	}

	public Long getInstDefinitionPort() {
		return instDefinitionPort;
	}

	public void setInstDefinitionPort(Long instDefinitionPort) {
		this.instDefinitionPort = instDefinitionPort;
	}

}
