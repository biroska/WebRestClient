package com.ubs.manhatthan.admin.beans;

import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import com.ubs.manhatthan.admin.mock.Mock;
import com.ubs.manhatthan.admin.model.Recovery;
import com.ubs.manhatthan.admin.service.Facade;

@SessionScoped
@ManagedBean(name="recoveryBean")
public class RecoveryBean {

	private List<Recovery> recoveries;
	private Recovery selectedRecovery;

	private List<Recovery> filteredRecoveries;

	private Facade facade = new Mock();
	
	public RecoveryBean() {
		recoveries = new ArrayList<Recovery>(facade.getRecovery());
	}

	public List<Recovery> getRecoveries() {
		return recoveries;
	}

	public void setRecoveries(List<Recovery> recovery) {
		this.recoveries = recovery;
	}

	public Recovery getSelectedRecovery() {
		return selectedRecovery;
	}

	public void setSelectedRecovery(Recovery selectedRecovery) {
		this.selectedRecovery = selectedRecovery;
	}

	public List<Recovery> getFilteredRecoveries() {
		return filteredRecoveries;
	}

	public void setFilteredRecoveries(List<Recovery> filteredRecoveries) {
		this.filteredRecoveries = filteredRecoveries;
	}

	public Facade getFacade() {
		return facade;
	}

	public void setFacade(Facade facade) {
		this.facade = facade;
	}
}
	
	
