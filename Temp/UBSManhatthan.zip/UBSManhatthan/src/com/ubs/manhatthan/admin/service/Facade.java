package com.ubs.manhatthan.admin.service;

import java.util.ArrayList;

import com.ubs.manhatthan.admin.model.Account;
import com.ubs.manhatthan.admin.model.Engine;
import com.ubs.manhatthan.admin.model.OrderEntry;
import com.ubs.manhatthan.admin.model.Recovery;
import com.ubs.manhatthan.admin.model.UmdfChannel;

public interface Facade {		
	public ArrayList<Account> getAccounts();
		
	public ArrayList<Engine> getEnginers();
	
	public ArrayList<Recovery> getRecovery();
	
	public ArrayList<OrderEntry> getOrderEntry();
	
	public ArrayList<UmdfChannel> getUmdfChannel();
}
