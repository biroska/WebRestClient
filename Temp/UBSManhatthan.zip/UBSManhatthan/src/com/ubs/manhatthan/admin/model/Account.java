package com.ubs.manhatthan.admin.model;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Account implements Serializable {

	private String name;
	private Long number;
	private int sessionsEneabled;
	private String sessionId;
	
	public Account(String name, Long number, int sessionsEneabled, String sessionId) {
		super();
		this.name = name;
		this.number = number;
		this.sessionsEneabled = sessionsEneabled;
		this.sessionId = sessionId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getNumber() {
		return number;
	}

	public void setNumber(Long number) {
		this.number = number;
	}
	

	public int getSessionsEneabled() {
		return sessionsEneabled;
	}

	public void setSessionsEneabled(int sessionsEneabled) {
		this.sessionsEneabled = sessionsEneabled;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	@Override
	public String toString() {
		return "Account [name=" + name + ", number=" + number + ", sessionsEneabled=" + sessionsEneabled + ", sessionId=" + sessionId + "]";
	}
	
}
