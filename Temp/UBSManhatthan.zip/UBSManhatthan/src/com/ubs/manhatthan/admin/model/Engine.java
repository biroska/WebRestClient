package com.ubs.manhatthan.admin.model;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Engine implements Serializable {

	private int id;
	private String host;
	private long port;
	
	public Engine(int id, String host, long port ) {
		super();
		this.id = id;
		this.host = host;
		this.port = port;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public long getPort() {
		return port;
	}

	public void setPort(long port) {
		this.port = port;
	}

	@Override
	public String toString() {
		return "Engine [id=" + id + ", host=" + host + ", port=" + port + "]";
	}

}
