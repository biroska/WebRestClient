package com.ubs.manhatthan.admin.beans;

import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.event.ActionEvent;

import com.ubs.manhatthan.admin.mock.Mock;
import com.ubs.manhatthan.admin.model.UmdfChannel;
import com.ubs.manhatthan.admin.service.Facade;

@SessionScoped
@ManagedBean(name="umdfChannelBean")
public class UmdfChannelBean {

	private List<UmdfChannel> umdfChannels;
	private UmdfChannel selectedUmdfChannel;

	private List<UmdfChannel> filteredUmdfChannels;

	private Facade facade = new Mock();
	
	public UmdfChannelBean() {
		umdfChannels = new ArrayList<UmdfChannel>(facade.getUmdfChannel());
	}

	public List<UmdfChannel> getUmdfChannels() {
		return umdfChannels;
	}

	public void setUmdfChannels(List<UmdfChannel> recovery) {
		this.umdfChannels = recovery;
	}

	public UmdfChannel getSelectedUmdfChannel() {
		return  selectedUmdfChannel;
	}

	public void setSelectedUmdfChannel(UmdfChannel selectedUmdfChannel) {
		this.selectedUmdfChannel = selectedUmdfChannel;
	}

	public List<UmdfChannel> getFilteredUmdfChannels() {
		return filteredUmdfChannels;
	}

	public void setFilteredUmdfChannels(List<UmdfChannel> filteredUmdfChannels) {
		this.filteredUmdfChannels = filteredUmdfChannels;
	}

	public void newUmdfChannel(ActionEvent actionEvent) {
		this.selectedUmdfChannel = null;
	}
	
	public Facade getFacade() {
		return facade;
	}

	public void setFacade(Facade facade) {
		this.facade = facade;
	}
}
	
	
