package com.ubs.manhatthan.admin.beans;

import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import com.ubs.manhatthan.admin.mock.Mock;
import com.ubs.manhatthan.admin.model.Account;
import com.ubs.manhatthan.admin.service.Facade;

@SessionScoped
@ManagedBean(name="accountBean")
public class AccountBean {

	private List<Account> accounts;
	private Account selectedAccounts;
	private Account selectedAccount;
	private String text;
		
	private List<Account> filteredAccounts;

	private Facade facade = new Mock();
	
	public AccountBean() {		
		accounts = new ArrayList<Account>( facade.getAccounts()  );
	}
	
	public Account getSelectedAccount() {
		return selectedAccount;
	}

	public void setSelectedAccount(Account selectedAccount) {
		this.selectedAccount = selectedAccount;
	}


	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public List<Account> getAccounts() {
		return accounts;
	}

	public void setAccounts(List<Account> accounts) {
		this.accounts = accounts;
	}

	public Account getSelectedAccounts() {
		return selectedAccounts;
	}

	public void setSelectedAccounts(Account selectedAccounts) {
		this.selectedAccounts = selectedAccounts;
	}

	public List<Account> getFilteredAccounts() {
		return filteredAccounts;
	}

	public void setFilteredAccounts(List<Account> filteredAccounts) {
		this.filteredAccounts = filteredAccounts;
	}

	public Facade getFacade() {
		return facade;
	}

	public void setFacade(Facade facade) {
		this.facade = facade;
	}
}
	
	
