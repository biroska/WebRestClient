package com.ubs.manhatthan.mock;

import java.util.ArrayList;
import java.util.List;

import com.ubs.manhatthan.model.Account;
import com.ubs.manhatthan.model.Legged;
import com.ubs.manhatthan.model.Manager;
import com.ubs.manhatthan.model.Market;
import com.ubs.manhatthan.model.MarketWhatchTab;
import com.ubs.manhatthan.model.Otc;
import com.ubs.manhatthan.model.ReportAverageDetail;
import com.ubs.manhatthan.model.ReportPriceDetail;
import com.ubs.manhatthan.model.ReportUserDetail;
import com.ubs.manhatthan.model.Strategy;
import com.ubs.manhatthan.model.StrategyParameters;
import com.ubs.manhatthan.model.StrategyType;
import com.ubs.manhatthan.model.Unlegging;
import com.ubs.manhatthan.service.Facade;

public class Mock implements Facade {

	private static ArrayList<Market> markets;
	private static ArrayList<Account> accounts;
	private static ArrayList<Manager> managers;
	private static ArrayList<Unlegging> unlegging;
	private static ArrayList<Otc> otc;
	private static ArrayList<StrategyParameters> strategyParameters;
	private static ArrayList<Strategy> strategies;
	private static ArrayList<MarketWhatchTab> marketWhatchTabs;
	private static ArrayList<StrategyType> strategyTypes;
	private static ArrayList<ReportUserDetail> reportUserDetails;
	private static ArrayList<ReportPriceDetail> reportPriceDetails;
	private static ArrayList<ReportAverageDetail> reportAverageDetails;
	
	static {
		
// =================
// |	Markets    |
// =================
		markets = new ArrayList<Market>();

		markets.add(new Market("" , "DI1F16", 20, 14600, 50, 14600, 14700, 100));
		markets.add(new Market("" , "DI1F17", 10, 13510, 150, 13500, 13510, 25));
		markets.add(new Market("Inclination FRA" , "F16 / N16 / F17 / N17", 5, 13400, 25, 13400, 13410, 30));
		markets.add(new Market("Duration" , "F17 / F18", 5, 500, 10, 500, 550, 5));
		markets.add(new Market("Butterfly / FRA" , "F16 / F17 / F18", 10, -51000, 25, -40000, -55000, 40));
		markets.add(new Market("FRA DI" , "N17 / F18", 5, 880, 5, 880, 960, 10));
		markets.add(new Market("Butterfly / Price" , "F16 / N16 / F17", 15, 9500, 10, 8000, 9500, 20));
		markets.add(new Market("Butterfly / FRA" , "F16 / N16 / F17 / N17", 5, 6300, 20, 6300, 6100, 25));
		markets.add(new Market("Duration" , "F17 / F18", 5, 500, 10, 500, 550, 5));
		markets.add(new Market("Butterfly / FRA" , "F16 / F17 / F18", 10, -51000, 25, -40000, -55000, 40));
		markets.add(new Market("FRA DI" , "N17 / F18", 5, 880, 5, 880, 960, 10));
		
// =================
// |	Account    |
// =================	
		/*
		accounts = new ArrayList<Account>();
		
		accounts.add( new Account("Caso1", 1111L) );
		accounts.add( new Account("Caso2", 1112L) );
		accounts.add( new Account("Caso3", 1113L) );
		accounts.add( new Account("Teste1", 2224L) );
		accounts.add( new Account("Teste2", 2225L) );
		accounts.add( new Account("Teste3", 2226L) );
		accounts.add( new Account("Mock1", 3337L) );
		accounts.add( new Account("Mock2", 3338L) );
		accounts.add( new Account("Mock3", 3339L) );
		accounts.add( new Account("Finito", 6666L) );
		*/
		
// =================
// |	Managers   |
// =================
				
		managers = new ArrayList<Manager>();
	
		
		List<Legged> un2 = new ArrayList<Legged>();
		List<Legged> un4 = new ArrayList<Legged>();

		Legged legged1 = new Legged("S","DI1F16", 0, "", 500, 0, 0, 0, 0, 0, 0, 0, 0, -00600, 00511);
		Legged legged2 = new Legged("S","DI1F16", 0, "", 500, 0, 0, 0, 0, 0, 0, 0, 0, -00600, 00511);
		Legged legged3 = new Legged("S","DI1F16", 0, "", 500, 0, 0, 0, 0, 0, 0, 0, 0, -00600, 00511);
		Legged legged4 = new Legged("S","DI1F16", 0, "", 500, 0, 0, 0, 0, 0, 0, 0, 0, -00600, 00511);
		un2.add(legged1);
		un2.add(legged2);
		un4.add(legged1);
		un4.add(legged2);
		un4.add(legged3);
		un4.add(legged4);



		managers.add(new Manager(+ 2, true, "Condor FRA", "Client FGH", 58745, "Scheduled", 0,"LFERNANDO", "10:00", "15:55", un2));
		
		managers.add(new Manager(+ 3, true, "Duration", "BRADESCO CLIENTE PRODUTOS INVESTIMENTO DERIVATIVO", 12345, "Running", 35,"LFERNANDO", "10:00", "15:55", un2));
		managers.add(new Manager(+ 4, true, "Butterfly", "Client ABC", 12345, "Completed", 100,"LFERNANDO", "10:00", "15:55",un2));
		managers.add(new Manager(+ 5, false, "Condor Price", "Client ABC", 12345, "Cancelled", 50,"LFERNANDO", "10:00", "15:55", un4));
		managers.add(new Manager(+ 6, true, "Butterfly", "BANCO SANTANDER BRASIL FGH", 58745, "Error", 90,"LFERNANDO", "10:00", "15:55", un4));
		managers.add(new Manager(+ 7, true, "Duration", "Client FGH", 58745, "Time Stop", 0,"LFERNANDO", "10:00", "15:55", un4));
		managers.add(new Manager(+ 8, true, "Condor FRA", "Client FGH", 58745, "Scheduled", 0, "LFERNANDO", "10:00", "15:55", un4));
		managers.add(new Manager(+ 9, true, "Duration", "Client ABC", 12345, "Running", 35, "LFERNANDO", "10:00", "15:55", new ArrayList<Legged>()));
		managers.add(new Manager(+ 10, true, "Butterfly", "Client BANDEIRANTES BANCOS UNIDOS", 12345, "Completed", 100, "LFERNANDO", "10:00", "15:55",un4));
		managers.add(new Manager(+ 11, false, "Condor Price", "Client ABC", 12345, "Cancelled", 50,"LFERNANDO", "10:00", "15:55",new ArrayList<Legged>()));
		managers.add(new Manager(+ 12, false, "Butterfly", "Client FGH", 58745, "Error", 90, "LFERNANDO", "10:00", "15:55", new ArrayList<Legged>()));
		managers.add(new Manager(+ 13, false, "Duration", "Client FGH", 58745, "Time Stop", 0,"LFERNANDO", "10:00", "15:55", new ArrayList<Legged>()));

// =================
// |	Unlegging    |
// =================
		
		unlegging = new ArrayList<Unlegging>();

		unlegging.add(new Unlegging("" , "", 65, 0));
		unlegging.add(new Unlegging("DI1F23" , "BUY", 40, 1301));
		unlegging.add(new Unlegging("DI1F23" , "BUY", 10, 1302));
		unlegging.add(new Unlegging("DI1F23" , "BUY", 15, 1301));
		unlegging.add(new Unlegging("" , "", 0, 0));
		unlegging.add(new Unlegging("" , "", 0, 0));
		unlegging.add(new Unlegging("" , "", 0, 0));
				
// =================
// |	OTC    |
// =================
		
		otc = new ArrayList<Otc>();
		
		otc.add(new Otc("DI1F23" , "BUY", 1325, 20));
				
				
// ========================
// |	StrategyParameters  |
// ========================
							
		strategyParameters = new ArrayList<StrategyParameters>();

		strategyParameters.add(new StrategyParameters("DI1F23", 10, "BUY", 65, 10, 0, "DI1F24", "TESTE"));
		strategyParameters.add(new StrategyParameters("DI1F23", 40, "SELL", 40, 20, 1301, "DI1F24", "TESTE"));
		strategyParameters.add(new StrategyParameters("DI1F23", 50, "SELL", 10, 30, 1302, "DI1F24", "TESTE"));
		strategyParameters.add(new StrategyParameters("DI1F23", 60, "BUY", 15, 40, 1301, "DI1F24", "TESTE"));

// ========================
// |	Strategies 		   |
// ========================
							
		strategies = new ArrayList<Strategy>();

		strategies.add(new Strategy(1, "Strategy 1", "Strategy 1"));
		strategies.add(new Strategy(2, "Strategy 2", "Strategy 2"));
		
		
// ========================
// |	Strategies Tabs 		   |
// ========================
							
		marketWhatchTabs = new ArrayList<MarketWhatchTab>();

		marketWhatchTabs.add(new MarketWhatchTab(1, "View Strategy 1", "Strategy 1", markets));
		marketWhatchTabs.add(new MarketWhatchTab(2, "View Strategy 2", "Strategy 2", new ArrayList<Market>()));		

// ========================
// |	StrategyTypes  	   |
// ========================
							
		strategyTypes = new ArrayList<StrategyType>();

		strategyTypes.add(new StrategyType(1, "Condor By Price"));


		reportUserDetails = new ArrayList<ReportUserDetail>();
		
		reportUserDetails.add(new ReportUserDetail("Form 12", 100.00, 100, "User Report Test", 1000.05, "S"));
		reportUserDetails.add(new ReportUserDetail("BVMF", 100.00, 100, "User Report Test 1", 1000.05, "B"));
		reportUserDetails.add(new ReportUserDetail("BVMF", 100.00, 100, "User Report Test 2", 1000.05, "B"));
		reportUserDetails.add(new ReportUserDetail("BVMF", 100.00, 100, "User Report Test 3", 1000.05, "B"));
		reportUserDetails.add(new ReportUserDetail("BVMF", 100.00, 100, "User Report Test 4", 1000.05, "S"));
		reportUserDetails.add(new ReportUserDetail("BVMF", 100.00, 100, "User Report Test 5", 1000.05, "S"));

		reportPriceDetails = new ArrayList<ReportPriceDetail>();
		
		reportPriceDetails.add(new ReportPriceDetail("Form 18", 100.00, 100, "Price Report Test", 1000.05, "B"));
		reportPriceDetails.add(new ReportPriceDetail("BVMF", 100.00, 100, "Price Report Test 1", 1000.05, "S"));
		reportPriceDetails.add(new ReportPriceDetail("BVMF", 100.00, 100, "Price Report Test 2", 1000.05, "S"));
		reportPriceDetails.add(new ReportPriceDetail("BVMF", 100.00, 100, "Price Report Test 3", 1000.05, "B"));
		reportPriceDetails.add(new ReportPriceDetail("BVMF", 100.00, 100, "Price Report Test 4", 1000.05, "B"));
		reportPriceDetails.add(new ReportPriceDetail("BVMF", 100.00, 100, "Price Report Test 5", 1000.05, "B"));

		reportAverageDetails = new ArrayList<ReportAverageDetail>();
		
		reportAverageDetails.add(new ReportAverageDetail("Form 18", 100.00, 100, "Price Average Test", 1000.05, "S", 50.05));
		reportAverageDetails.add(new ReportAverageDetail("BVMF", 100.00, 100, "Price Average Test 1", 1000.05, "B", 50.05));
		reportAverageDetails.add(new ReportAverageDetail("BVMF", 100.00, 100, "Price Average Test 2", 1000.05, "B", 50.05));
		reportAverageDetails.add(new ReportAverageDetail("BVMF", 100.00, 100, "Price Average Test 3", 1000.05, "S", 50.05));
		reportAverageDetails.add(new ReportAverageDetail("BVMF", 100.00, 100, "Price Average Test 4", 1000.05, "S", 50.05));
		reportAverageDetails.add(new ReportAverageDetail("BVMF", 100.00, 100, "Price Average Test 5", 1000.05, "B", 50.05));
}
	
	
	@Override
	public List<Account> getAccountByNameOrNumber(String query) {
		
		ArrayList<Account> result = new ArrayList<Account>();
		
		if ( query != null && !query.isEmpty() ){
			for (Account item : accounts) {
				
				if ( item.getName().contains( query ) ){
					result.add( item );
				}
				else
					if ( String.valueOf( item.getNumber() ).contains( query ) ){
						result.add( item );
					}
			}
		} else {
			result.addAll( accounts );
		}
		
		return result;
	}


	public ArrayList<Market> getMarkets() {
		return markets;
	}


	public void setMarkets(ArrayList<Market> markets) {
		Mock.markets = markets;
	}


	public static ArrayList<Account> getAccounts() {
		return accounts;
	}


	public static void setAccounts(ArrayList<Account> accounts) {
		Mock.accounts = accounts;
	}


	public ArrayList<Manager> getManagers() {
		return managers;
	}


	public static void setManagers(ArrayList<Manager> managers) {
		Mock.managers = managers;
	}


	public ArrayList<Unlegging> getUnlegging() {
		return unlegging;
	}


	public static void setUnlegging(ArrayList<Unlegging> unlegging) {
		Mock.unlegging = unlegging;
	}


	public ArrayList<Otc> getOtc() {
		return otc;
	}


	public static void setOtc(ArrayList<Otc> otc) {
		Mock.otc = otc;
	}


	public ArrayList<StrategyParameters> getStrategyParameters() {
		return strategyParameters;
	}


	public static void setStrategyParameters(ArrayList<StrategyParameters> strategyParameters) {
		Mock.strategyParameters = strategyParameters;
	}
	
	public ArrayList<Strategy> getStrategies() {
		return strategies;
	}
	
	public ArrayList<MarketWhatchTab> getMarketWhatchTabs() {
		return marketWhatchTabs;
	}

	public static void setStrategy(ArrayList<Strategy> strategies) {
		Mock.strategies = strategies;
	}

	public ArrayList<StrategyType> getStrategyTypes() {
		return strategyTypes;
	}

	public static void setStrategyTypes(ArrayList<StrategyType> strategyTypes) {
		Mock.strategyTypes = strategyTypes;
	}

	public ArrayList<ReportUserDetail> getReportUserDetails() {
		return reportUserDetails;
	}

	public static void setReportUserDetails(ArrayList<ReportUserDetail> reportUserDetails) {
		Mock.reportUserDetails = reportUserDetails;
	}

	public ArrayList<ReportPriceDetail> getReportPriceDetails() {
		return reportPriceDetails;
	}

	public static void setReportPriceDetails(ArrayList<ReportPriceDetail> reportPriceDetails) {
		Mock.reportPriceDetails = reportPriceDetails;
	}

	public ArrayList<ReportAverageDetail> getReportAverageDetails() {
		return reportAverageDetails;
	}

	public static void setReportAverageDetails(ArrayList<ReportAverageDetail> reportAverageDetails) {
		Mock.reportAverageDetails = reportAverageDetails;
	}

	public static void setStrategiesTabs(ArrayList<MarketWhatchTab> marketWhatchTabs) {
		Mock.marketWhatchTabs = marketWhatchTabs;
	}


	public static void setStrategies(ArrayList<Strategy> strategies) {
		Mock.strategies = strategies;
	}
}
