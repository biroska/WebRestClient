package com.ubs.manhatthan.model;

public class Unlegging {

	private String side;
	private String contract;
	private int qty;
	private long price;
	
	public Unlegging(String side, String contract, int qty, long price) {
		
		super();
		
		this.side = side;
		this.contract = contract;
		this.qty = qty;
		this.price = price;

	}

	public String getSide() {
		return side;
	}


	public void setSide(String side) {
		this.side = side;
	}

	public String getContract() {
		return contract;
	}

	public void setContract(String contract) {
		this.contract = contract;
	}

	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	public long getPrice() {
		return price;
	}

	public void setPrice(long price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Unlegging [side=" + side + ", contract=" + contract + ", qty=" + qty + ", price=" + price + "]";
	}
}
