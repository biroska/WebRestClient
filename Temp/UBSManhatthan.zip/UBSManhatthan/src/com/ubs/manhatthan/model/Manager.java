package com.ubs.manhatthan.model;

import java.util.ArrayList;
import java.util.List;

public class Manager {

	private long id;
	private boolean cancel;
	private String strategy;
	private String client;
	private long account;
	private String status;
	private int percent;
	private String user;
	private String start;
	private String end; 
	
	private List<Legged> leggeds = new ArrayList<Legged>();

	public Manager(long long1, String string, long l){}

	public Manager(long id, boolean cancel, String strategy, String client, long account, String status, int percent, String user, String start, String end,List<Legged> leggeds) {
		
		super();
		
		this.id = id;
		this.cancel = cancel;
		this.strategy = strategy;
		this.client = client;
		this.account = account;
		this.status = status;
		this.percent = percent;
		this.leggeds = leggeds;
		this.user = user;
		this.start = start;
		this.end = end;

	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public boolean isCancel() {
		return cancel;
	}

	public void setCancel(boolean cancel) {
		this.cancel = cancel;
	}

	public String getStrategy() {
		return strategy;
	}

	public void setStrategy(String strategy) {
		this.strategy = strategy;
	}

	public String getClient() {
		return client;
	}

	public void setClient(String client) {
		this.client = client;
	}

	public long getAccount() {
		return account;
	}

	public void setAccount(long account) {
		this.account = account;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getPercent() {
		return percent;
	}

	public void setPercent(int percent) {
		this.percent = percent;
	}
	
	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getStart() {
		return start;
	}

	public void setStart(String start) {
		this.start = start;
	}

	public String getEnd() {
		return end;
	}

	public void setEnd(String end) {
		this.end = end;
	}
	
	public List<Legged> getLeggeds() {
		return leggeds;
	}

	public void setLeggeds(List<Legged> leggeds) {
		this.leggeds = leggeds;
	}

	@Override
	public String toString() {
		return "Manager [id=" + id + ", cancel=" + cancel + ", strategy=" + strategy + ", client=" + client + ", account=" + account + ", status=" + status + ", "
				+ "percent=" + percent + ", user=" + user + ", start=" + start + ", end=" + end + " ]";
	}
}
