package com.ubs.manhatthan.model;

import java.util.ArrayList;
import java.util.List;

public class StrategyTabsLista {

	private int id;

	private String displayName;

	private String name;

	private List<Market> markets = new ArrayList<Market>();

	public StrategyTabsLista() {
	}

	public StrategyTabsLista(int id, String displayName, String name, List<Market> markets) {
		this.id = id;
		this.displayName = displayName;
		this.name = name;
		this.markets = markets;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Market> getMarkets() {
		return markets;
	}

	public void setMarkets(List<Market> markets) {
		this.markets = markets;
	}

}
