package com.ubs.manhatthan.model;

public class Legged {

	private String bs;
	private String contract;
	private int leggedQty;
	private String leggedPrice; 
	private long totalQty;
	private long qtyRemaining;
	private int qtyExec;
	private long averPrice;
	private int otcQtyExec; // Verificar Depois Ivi
	private int otcPriceExec; // Verificar Depois Ivi
	private int poQty;
	private long poPrice;
	private int rank;
	private long target;
	private long efectiveTarget;
	
	public Legged(long long1, String string, long l){}

	public Legged(String bs, String contract, int leggedQty,
			String leggedPrice, long totalQty, long qtyRemaining, int qtyExec, long averPrice, int otcQtyExec, int otcPriceExec, int poQty, 
			long poPrice, int rank, long target, long efectiveTarget) {
		
		super();
		this.bs = bs;
		this.contract = contract;
		this.leggedQty = leggedQty;
		this.leggedPrice = leggedPrice; // Verificar Depois
		this.totalQty = totalQty;
		this.qtyRemaining = qtyRemaining;
		this.qtyExec = qtyExec;
		this.averPrice = averPrice;
		this.otcQtyExec = otcQtyExec;
		this.otcPriceExec = otcPriceExec;
		this.poQty = poQty;
		this.poPrice = poPrice;
		this.rank = rank;
		this.target = target;
		this.efectiveTarget = efectiveTarget;

	}

	@Override
	public String toString() {
		return "Manager [bs=" + bs + "contract=" + contract + ", leggedQty=" + leggedQty + ", leggedPrice=" + leggedPrice + ", totalQty=" + totalQty 
				+ ", qtyRemaining=" + qtyRemaining + ", qtyExec=" + qtyExec + ", averPrice=" + averPrice + ", otcQtyExec=" + otcQtyExec + ", "
				+ ", otcPriceExec=" + otcPriceExec + ", poQty=" + poQty + ", poPrice=" + poPrice + ", rank=" + rank + ", "
				+ ", target=" + target + ", efectiveTarget=" + efectiveTarget + "]";
	}
	
	public String getBs() {
		return bs;
	}

	public void setBs(String bs) {
		this.bs = bs;
	}

	public String getContract() {
		return contract;
	}

	public void setContract(String contract) {
		this.contract = contract;
	}

	public int getLeggedQty() {
		return leggedQty;
	}

	public void setLeggedQty(int leggedQty) {
		this.leggedQty = leggedQty;
	}

	public String getLeggedPrice() {
		return leggedPrice;
	}

	public void setLeggedPrice(String leggedPrice) {
		this.leggedPrice = leggedPrice;
	}

	public long getTotalQty() {
		return totalQty;
	}

	public void setTotalQty(long totalQty) {
		this.totalQty = totalQty;
	}

	public long getQtyRemaining() {
		return qtyRemaining;
	}

	public void setQtyRemaining(long qtyRemaining) {
		this.qtyRemaining = qtyRemaining;
	}

	public int getQtyExec() {
		return qtyExec;
	}

	public void setQtyExec(int qtyExec) {
		this.qtyExec = qtyExec;
	}

	public long getAverPrice() {
		return averPrice;
	}

	public void setAverPrice(long averPrice) {
		this.averPrice = averPrice;
	}

	public int getOtcQtyExec() {
		return otcQtyExec;
	}

	public void setOtcQtyExec(int otcQtyExec) {
		this.otcQtyExec = otcQtyExec;
	}

	public int getOtcPriceExec() {
		return otcPriceExec;
	}

	public void setOtcPriceExec(int otcPriceExec) {
		this.otcPriceExec = otcPriceExec;
	}

	public int getPoQty() {
		return poQty;
	}

	public void setPoQty(int poQty) {
		this.poQty = poQty;
	}

	public long getPoPrice() {
		return poPrice;
	}

	public void setPoPrice(long poPrice) {
		this.poPrice = poPrice;
	}

	public int getRank() {
		return rank;
	}

	public void setRank(int rank) {
		this.rank = rank;
	}

	public long getTarget() {
		return target;
	}

	public void setTarget(long target) {
		this.target = target;
	}

	public long getEfectiveTarget() {
		return efectiveTarget;
	}

	public void setEfectiveTarget(long efectiveTarget) {
		this.efectiveTarget = efectiveTarget;
	}
}
