package com.ubs.manhatthan.service;

import java.util.ArrayList;
import java.util.List;

import com.ubs.manhatthan.model.Account;
import com.ubs.manhatthan.model.Manager;
import com.ubs.manhatthan.model.Market;
import com.ubs.manhatthan.model.MarketWhatchTab;
import com.ubs.manhatthan.model.Otc;
import com.ubs.manhatthan.model.ReportPriceDetail;
import com.ubs.manhatthan.model.ReportUserDetail;
import com.ubs.manhatthan.model.Strategy;
import com.ubs.manhatthan.model.StrategyParameters;
import com.ubs.manhatthan.model.StrategyType;
import com.ubs.manhatthan.model.Unlegging;

public interface Facade {
	
	public List<Account> getAccountByNameOrNumber( String query );
	
	public ArrayList<Market> getMarkets();
	
	public ArrayList<Manager> getManagers();
	
	public ArrayList<Unlegging> getUnlegging();
	
	public ArrayList<Otc> getOtc();
	
	public ArrayList<StrategyParameters> getStrategyParameters();
	
	public ArrayList<Strategy> getStrategies();
	
	public List<MarketWhatchTab> getMarketWhatchTabs();
	
	public ArrayList<StrategyType> getStrategyTypes();
	
	public ArrayList<ReportUserDetail> getReportUserDetails();

	public ArrayList<ReportPriceDetail> getReportPriceDetails();
}
